import { Hono } from "jsr:@hono/hono";
import { cors } from "jsr:@hono/hono/cors";
import { logger } from "jsr:@hono/hono/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();
app.use("*", logger(console.log));
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization", "X-Init-Data", "X-Dev-Key"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

const P = "/make-server-f6480290";

// ─────────────────────────────────────────────────────────────
//  Константы модели прав. OWNER_TG обязан совпадать с shared.tsx.
// ─────────────────────────────────────────────────────────────
const OWNER = "@doken62";
const BOT_TOKEN = Deno.env.get("TELEGRAM_BOT_TOKEN") ?? "";
const DEV_ADMIN_KEY = Deno.env.get("DEV_ADMIN_KEY") ?? "";

const norm = (l?: string | null): string =>
  l ? (l.startsWith("@") ? l : "@" + l).toLowerCase() : "";

// ─────────────────────────────────────────────────────────────
//  Классификация ключей kv_store
// ─────────────────────────────────────────────────────────────
// Витрина + агрегаты, нужные для отрисовки. Читают все (в т.ч. аноним).
// Писать в них — только владелец/сотрудник (кроме USER_RECONCILE ниже).
const PUBLIC_READ = new Set<string>([
  "products", "sections", "home", "banner", "faq", "materials", "reviews",
  "promocodes", "customOrder", "notice", "allFavorites", "sbpInfo", "payMethods",
  "crmOrder", "crmLeft", "coverMode", "loyalty", "catalogFilters", "waitlist",
  "appVersion", "onboardEpoch", "deletedOrders",
]);
// Ключи, куда обычный пользователь может писать ТОЛЬКО свой срез (сервер сверяет).
// Владелец/сотрудник заменяют целиком.
const USER_RECONCILE = new Set<string>([
  "orders", "profiles", "allFavorites", "waitlist", "reviews",
]);
// Витринные ключи, писать которые может только владелец/сотрудник.
const STAFF_WRITE = new Set<string>([
  "products", "sections", "home", "banner", "faq", "materials",
  "promocodes", "customOrder", "notice", "sbpInfo", "payMethods",
  "crmOrder", "crmLeft", "coverMode", "loyalty", "catalogFilters",
  "appVersion", "onboardEpoch",
]);
// Всё остальное (users, roles, lastseen, ownerChatId, channelId,
// publishButtonText, log, pub_*, …) — читать и писать только владелец/сотрудник.

type Role = "admin" | "moderator" | "editor" | "user" | "anon";
interface Ident { login: string | null; role: Role; }
const isStaff = (id: Ident) => id.role === "admin" || id.role === "moderator" || id.role === "editor";

// ─────────────────────────────────────────────────────────────
//  Проверка подписи Telegram initData (защита личности от подделки)
// ─────────────────────────────────────────────────────────────
async function hmac(keyData: Uint8Array, msg: Uint8Array): Promise<ArrayBuffer> {
  const key = await crypto.subtle.importKey(
    "raw", keyData as BufferSource, { name: "HMAC", hash: "SHA-256" }, false, ["sign"],
  );
  return await crypto.subtle.sign("HMAC", key, msg as BufferSource);
}
const toHex = (buf: ArrayBuffer) =>
  [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");

async function verifyInitData(initData: string): Promise<{ username?: string; id?: number } | null> {
  if (!BOT_TOKEN) return null;
  let params: URLSearchParams;
  try { params = new URLSearchParams(initData); } catch { return null; }
  const hash = params.get("hash");
  if (!hash) return null;
  params.delete("hash");
  const pairs = [...params.entries()].map(([k, v]) => `${k}=${v}`).sort();
  const dataCheckString = pairs.join("\n");
  const enc = new TextEncoder();
  const secret = await hmac(enc.encode("WebAppData"), enc.encode(BOT_TOKEN));
  const computed = toHex(await hmac(new Uint8Array(secret), enc.encode(dataCheckString)));
  if (computed !== hash) return null;
  // Мягкая проверка свежести: подпись не старше 90 дней (сессия мини-аппа живёт долго).
  const authDate = Number(params.get("auth_date") || 0);
  if (authDate && Date.now() / 1000 - authDate > 90 * 24 * 3600) return null;
  const userRaw = params.get("user");
  if (!userRaw) return null;
  try {
    const u = JSON.parse(userRaw);
    return { username: u.username, id: u.id };
  } catch { return null; }
}

async function roleFor(login: string): Promise<Role> {
  if (login === OWNER) return "admin";
  const roles = (await kv.get("roles").catch(() => null)) as Record<string, Role> | null;
  if (roles) {
    const r = roles[login] ?? roles[login.replace(/^@/, "")];
    if (r && r !== "user") return r;
  }
  return "user";
}

// Доказательство личности берём из тела запроса (body._auth) — так браузеру не
// нужен CORS-preflight на кастомные заголовки. Заголовки X-Dev-Key/X-Init-Data
// оставлены как запасной путь (старые клиенты, серверные вызовы).
async function identify(c: any, body?: any): Promise<Ident> {
  const auth = body && typeof body === "object" ? body._auth : undefined;
  const devKey = (auth?.devKey as string | undefined) ?? c.req.header("X-Dev-Key");
  if (devKey && DEV_ADMIN_KEY && devKey === DEV_ADMIN_KEY) {
    return { login: OWNER, role: "admin" };
  }
  const initData = (auth?.initData as string | undefined) ?? c.req.header("X-Init-Data");
  if (initData) {
    const v = await verifyInitData(initData);
    if (v?.username) {
      const login = norm(v.username);
      return { login, role: await roleFor(login) };
    }
  }
  return { login: null, role: "anon" };
}

// ─────────────────────────────────────────────────────────────
//  Чтение с учётом прав
// ─────────────────────────────────────────────────────────────
async function readValue(key: string, id: Ident): Promise<any> {
  if (key.startsWith("rev:")) return await kv.get(key);

  if (key === "orders") {
    const all = ((await kv.get("orders")) as any[]) ?? [];
    if (isStaff(id)) return all;
    if (!id.login) return [];
    return all.filter((o) => norm(o?.userId) === id.login);
  }
  if (key === "profiles") {
    const all = ((await kv.get("profiles")) as Record<string, any>) ?? {};
    if (isStaff(id)) return all;
    if (!id.login) return {};
    const slice: Record<string, any> = {};
    for (const k of Object.keys(all)) if (norm(k) === id.login) slice[k] = all[k];
    return slice;
  }
  if (PUBLIC_READ.has(key)) return await kv.get(key);

  // Всё прочее — только для владельца/сотрудника.
  if (isStaff(id)) return await kv.get(key);
  return null;
}

// ─────────────────────────────────────────────────────────────
//  Запись с учётом прав + сверка «своего среза»
// ─────────────────────────────────────────────────────────────
async function writeValue(key: string, value: any, id: Ident): Promise<{ ok: boolean; code?: number; msg?: string }> {
  // Ревизии — служебные отметки времени; их пишет любой авторизованный.
  if (key.startsWith("rev:")) {
    if (id.role === "anon") return { ok: false, code: 401, msg: "auth required" };
    await kv.set(key, value);
    return { ok: true };
  }

  if (isStaff(id)) { await kv.set(key, value); return { ok: true }; }

  // Ниже — обычный пользователь. Разрешаем только сверяемые ключи.
  if (id.role === "anon") return { ok: false, code: 401, msg: "auth required" };
  if (!USER_RECONCILE.has(key)) return { ok: false, code: 403, msg: "forbidden" };
  const me = id.login!;

  if (key === "orders") {
    const stored = ((await kv.get("orders")) as any[]) ?? [];
    const submitted = Array.isArray(value) ? value : [];
    // Апсертим только СВОИ заказы; чужие не трогаем, свои по опущению не удаляем.
    const byId = new Map(stored.map((o) => [o.id, o]));
    for (const o of submitted) if (o && norm(o.userId) === me) byId.set(o.id, o);
    await kv.set("orders", [...byId.values()]);
    return { ok: true };
  }
  if (key === "profiles") {
    const stored = ((await kv.get("profiles")) as Record<string, any>) ?? {};
    const submitted = value && typeof value === "object" ? value : {};
    for (const k of Object.keys(submitted)) if (norm(k) === me) stored[k] = submitted[k];
    await kv.set("profiles", stored);
    return { ok: true };
  }
  if (key === "allFavorites") {
    const stored = ((await kv.get("allFavorites")) as Record<string, any>) ?? {};
    const submitted = value && typeof value === "object" ? value : {};
    for (const k of Object.keys(submitted)) if (norm(k) === me) stored[k] = submitted[k];
    await kv.set("allFavorites", stored);
    return { ok: true };
  }
  if (key === "reviews") {
    const stored = ((await kv.get("reviews")) as any[]) ?? [];
    const submitted = Array.isArray(value) ? value : [];
    const byId = new Map(stored.map((r) => [r.id, r]));
    for (const r of submitted) if (r && norm(r.userId) === me) byId.set(r.id, r);
    await kv.set("reviews", [...byId.values()]);
    return { ok: true };
  }
  if (key === "waitlist") {
    const stored = ((await kv.get("waitlist")) as Record<string, string[]>) ?? {};
    const submitted = value && typeof value === "object" ? value : {};
    const pids = new Set([...Object.keys(stored), ...Object.keys(submitted)]);
    for (const pid of pids) {
      const others = (stored[pid] ?? []).filter((l) => norm(l) !== me);
      const meWants = (submitted[pid] ?? []).some((l: string) => norm(l) === me);
      stored[pid] = meWants ? [...others, me] : others;
      if (stored[pid].length === 0) delete stored[pid];
    }
    await kv.set("waitlist", stored);
    return { ok: true };
  }
  return { ok: false, code: 403, msg: "forbidden" };
}

// ─────────────────────────────────────────────────────────────
//  Маршруты
// ─────────────────────────────────────────────────────────────
app.get(`${P}/health`, (c) => c.json({ status: "ok" }));

// Маркер версии — позволяет снаружи (GET, без preflight) убедиться, что
// развёрнут именно актуальный код функции, а не старая заглушка.
const FN_VERSION = "2026-08-30-body-auth-1";
app.get(`${P}/version`, (c) => c.json({ version: FN_VERSION }));

app.post(`${P}/kv/read`, async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const id = await identify(c, body);
  const keys: string[] = Array.isArray(body.keys) ? body.keys : [];
  const values: Record<string, any> = {};
  await Promise.all(keys.map(async (k) => {
    try { values[k] = await readValue(k, id); } catch { values[k] = null; }
  }));
  return c.json({ values });
});

app.post(`${P}/kv/write`, async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const id = await identify(c, body);
  const { key, value } = body;
  if (typeof key !== "string") return c.json({ error: "bad key" }, 400);
  const r = await writeValue(key, value, id);
  if (!r.ok) return c.json({ error: r.msg }, (r.code ?? 403) as any);
  return c.json({ ok: true });
});

// ─────────────────────────────────────────────────────────────
//  Telegram-уведомление владельцу
// ─────────────────────────────────────────────────────────────
async function tgApi(method: string, payload: any): Promise<any> {
  const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return await res.json().catch(() => ({}));
}

app.post(`${P}/notify`, async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const id = await identify(c, body);
  if (!isStaff(id)) return c.json({ ok: false, error: "forbidden" }, 403);
  if (!BOT_TOKEN) return c.json({ ok: false, error: "bot token not configured" });
  const { text } = body;
  const chatId = (await kv.get("ownerChatId").catch(() => null)) as number | string | null;
  if (!chatId) return c.json({ ok: false, error: "ownerChatId unknown" });
  const r = await tgApi("sendMessage", { chat_id: chatId, text, parse_mode: "HTML", disable_web_page_preview: true });
  return c.json({ ok: !!r.ok, error: r.description });
});

app.post(`${P}/publish`, async (c) => {
  const b = await c.req.json().catch(() => ({}));
  const id = await identify(c, b);
  if (!isStaff(id)) return c.json({ ok: false, error: "forbidden" }, 403);
  if (!BOT_TOKEN) return c.json({ ok: false, error: "bot token not configured" });
  const channel = b.channelId || (await kv.get("channelId").catch(() => null));
  if (!channel) return c.json({ ok: false, error: "channelId unknown" });
  const caption: string = b.caption ?? "";
  // Кнопка-ссылка под постом (если задан URL мини-аппа в kv).
  const btnUrl = (await kv.get("publishButtonUrl").catch(() => null)) as string | null;
  const btnText = b.buttonText || (await kv.get("publishButtonText").catch(() => null));
  const reply_markup = btnUrl && btnText ? { inline_keyboard: [[{ text: btnText, url: btnUrl }]] } : undefined;
  try {
    let r: any;
    if (Array.isArray(b.photos) && b.photos.length > 1) {
      const media = b.photos.slice(0, 10).map((url: string, i: number) => ({
        type: "photo", media: url, ...(i === 0 ? { caption, parse_mode: "HTML" } : {}),
      }));
      r = await tgApi("sendMediaGroup", { chat_id: channel, media });
    } else if (b.videoUrl) {
      r = await tgApi("sendVideo", { chat_id: channel, video: b.videoUrl, caption, parse_mode: "HTML", reply_markup });
    } else if (b.photoUrl || (Array.isArray(b.photos) && b.photos[0])) {
      r = await tgApi("sendPhoto", { chat_id: channel, photo: b.photoUrl || b.photos[0], caption, parse_mode: "HTML", reply_markup });
    } else {
      r = await tgApi("sendMessage", { chat_id: channel, text: caption, parse_mode: "HTML", reply_markup });
    }
    return c.json({ ok: !!r.ok, error: r.description });
  } catch (e) {
    return c.json({ ok: false, error: String(e) });
  }
});

app.post(`${P}/publish-vk`, async (c) => {
  const b = await c.req.json().catch(() => ({}));
  const id = await identify(c, b);
  if (!isStaff(id)) return c.json({ ok: false, error: "forbidden" }, 403);
  const { token, groupId, message, linkUrl } = b;
  if (!token || !groupId) return c.json({ ok: false, error: "token/groupId required" });
  try {
    const params = new URLSearchParams({
      owner_id: `-${String(groupId).replace(/^-/, "")}`,
      from_group: "1",
      message: (message ?? "") + (linkUrl ? `\n\n${linkUrl}` : ""),
      access_token: token,
      v: "5.199",
    });
    const res = await fetch("https://api.vk.com/method/wall.post", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: params.toString(),
    });
    const j = await res.json().catch(() => ({}));
    if (j.error) return c.json({ ok: false, error: j.error.error_msg });
    return c.json({ ok: true });
  } catch (e) {
    return c.json({ ok: false, error: String(e) });
  }
});

// ─────────────────────────────────────────────────────────────
//  Оплата — провайдеры пока не подключены (нет серверных секретов).
//  Возвращаем понятный статус, чтобы клиент не падал.
// ─────────────────────────────────────────────────────────────
app.post(`${P}/payments/create`, (c) => c.json({ error: "payments not configured" }, 501));
app.get(`${P}/payments/status/:id`, (c) => c.json({ status: "unknown" }));

Deno.serve(app.fetch);
