import { useState, useRef, useEffect, createContext, useContext, useCallback } from 'react'
import { createPortal } from 'react-dom'
import Cropper from 'react-easy-crop'
import { kv, storage, payments, notify, CloudQuotaError, type PayProvider } from './api'
import { initLogs, setLogActor, logAction, clearLogs } from './log'
import { getCroppedFile, getCroppedRectFile, type PixelCrop } from './cropImage'
import splashArt from './imports/37addb81-8123-4851-9ffe-d89b7f423529.webp'
import profileArt from './imports/e9eda78d-9745-421d-b6a0-43e98c0b4542.webp'
import CRMView from './crm/CRMView'
import { GamesView } from './games/Games'
import { CategoryTabs, CollectionBoard, PromoCarousel, PerkTile, useSigmaHold, MasterHint, MasterTransition, SigmaOnboarding, HoldRing } from './ui'
import { BannerConfig, CatalogSection, CatalogFilterButton, INIT_CATALOG_FILTERS, catalogFilterPass, allProductTags, CoverMode, INIT_COVER_MODE, CustomOrderConfig, DELIVERY_LABELS, DELIVERY_OPTIONS, DeliveryService, FaqSection, HomeConfig, HomeCollection, HomeMeme, HomeRow, INIT_BANNER, INIT_HOME, Icon, IconName, MaskedId, Material, NoticeContent, OWNER_TG, OnlineDot, Order, OrderStatus, PATHS, PAY_METHOD_DEFS, hScroll, PayMethodDef, PayStatus, Product, ProductVariant, PromoCode, PromoCountdown, PromoAnnounceBoard, pickFeaturedPromo, orderWindow, editionState, canOrder, OrderWindowPill, fmtLeft, LoyaltyConfig, INIT_LOYALTY, loyaltyCfg, redeemable, clubTiersOf, clubTierFor, RegisteredUser, Review, ReviewPhotos, Role, normLogin, profileKeys, readProfile, SbpInfo, STATUS_META, statusAccent, StarRating, Toggle, UserProfile, collectionProducts, compressImage, getVariants, priceRange, resolveBrandLogo, resolveHomeImg, variantCover, ShopStatus, INIT_SHOP_STATUS, smartBadges, SmartBadge, AutoVideo, storageThumb } from './shared'
import { sanitizeText, isSaneLength, allowAction, loginLockRemaining, registerLoginFailure, registerLoginSuccess } from './security'

// Сжимает изображение перед загрузкой: фото с телефона часто весят несколько МБ
// (или приходят в HEIC), из-за чего storage отклоняет загрузку. Приводим к JPEG
// с ограничением по стороне. Если декодировать не удалось — возвращаем исходный файл.
// Версия приложения — показывается в подвале профиля.
const APP_VERSION = '1.2.4'

// ─────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────
type Tab = 'home' | 'catalog' | 'profile' | 'orders' | 'faq' | 'crm' | 'settings'

interface AuthUser { login: string; name: string; role: Role; avatar: string }
// Привязанная карта. CVV намеренно НЕ храним — он вводится заново при каждой оплате.
// payStatus: 'awaiting' — клиент заявил о переводе, ждём подтверждения администратора;
// 'confirmed' — перевод подтверждён; 'rejected' — не поступил, заказ отменён.
// ─────────────────────────────────────────────────────────────
// Contexts
// ─────────────────────────────────────────────────────────────
const AuthCtx = createContext<{ user: AuthUser | null; login: (l: string, p: string, tg?: string) => boolean; logout: () => void }>({ user: null, login: () => false, logout: () => {} })
const useAuth = () => useContext(AuthCtx)
const ThemeCtx = createContext<{ theme: 'dark' | 'light'; toggle: () => void }>({ theme: 'dark', toggle: () => {} })
const useTheme = () => useContext(ThemeCtx)

// ─────────────────────────────────────────────────────────────
// Persistence
// ─────────────────────────────────────────────────────────────
function useLocalStorage<T>(key: string, initial: T): [T, React.Dispatch<React.SetStateAction<T>>] {
  const storageKey = 'fs_' + key
  const [state, setState] = useState<T>(() => {
    try { const raw = localStorage.getItem(storageKey); if (raw != null) return JSON.parse(raw) as T } catch {}
    return initial
  })
  // Track the last value we serialized so incoming storage events don't echo back.
  const lastWritten = useRef<string | null>(null)
  useEffect(() => {
    try {
      const serialized = JSON.stringify(state)
      lastWritten.current = serialized
      localStorage.setItem(storageKey, serialized)
    } catch {}
  }, [storageKey, state])
  // Sync live across tabs of the same browser: when another tab writes to this
  // key, adopt its value so local settings stay consistent everywhere.
  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key !== storageKey || e.newValue == null) return
      if (e.newValue === lastWritten.current) return
      try {
        lastWritten.current = e.newValue
        setState(JSON.parse(e.newValue) as T)
      } catch {}
    }
    window.addEventListener('storage', onStorage)
    return () => window.removeEventListener('storage', onStorage)
  }, [storageKey])
  return [state, setState]
}

// ─────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────
// Владелец магазина: CRM привязана к этому Telegram-аккаунту, роль снять нельзя.
// Какие вкладки CRM доступны роли. Владелец и админ — всё.
const ROLE_TABS: Record<string, string[]> = {
  moderator: ['dashboard', 'orders', 'neworder', 'payverify', 'users', 'reviews', 'pubhub'],
  editor:    ['products', 'sections', 'home', 'faq', 'materials', 'notice', 'custom', 'pubhub'],
}
const ADMIN_LOGIN = 'doken'
const ADMIN_PASS  = 'banduras338'
// ─────────────────────────────────────────────────────────────
// Static data
// ─────────────────────────────────────────────────────────────
const INIT_PRODUCTS: Product[] = []

const INIT_SECTIONS: CatalogSection[] = [
  { id: 1, name: 'Harry Potter', emoji: '⚡' }, { id: 2, name: 'Star Wars', emoji: '🌌' },
  { id: 3, name: 'Marvel', emoji: '🦸' }, { id: 4, name: 'Game Icons', emoji: '🎮' },
]

const INIT_FAQ: FaqSection[] = [
  { id: 'important', title: 'Важная информация', emoji: '📌',
    content: 'Все фигурки изготавливаются вручную под заказ.\n\nСрок изготовления — от 7 до 21 рабочего дня в зависимости от сложности модели.\n\nКаждая фигурка проходит несколько этапов: 3D-печать, шлифовка, многослойная покраска и лакировка.\n\nСтатус вашего заказа обновляется в разделе «Заказы».' },
  { id: 'howto', title: 'Как купить', emoji: '🛒',
    content: '1. Выберите фигурку из каталога.\n\n2. Нажмите кнопку «Заказать».\n\n3. Укажите адрес доставки и выберите способ оплаты.\n\n4. После подтверждения заказа мастер начнёт работу.\n\n5. Следите за статусом в разделе «Заказы».' },
  { id: 'delivery', title: 'Доставка', emoji: '🚚',
    content: 'Доставляем по всей России через СДЭК и Почту России.\n\nСредний срок доставки: 3–7 дней.\n\nСтоимость доставки рассчитывается при оформлении заказа.\n\nВсе заказы упакованы в защитную пену и фирменную коробку.\n\nТрек-номер появится в статусе заказа сразу после передачи посылки.' },
]

const INIT_MATERIALS: Material[] = [
  { id: 'abs',   name: 'ABS-пластик',         available: false, priceMultiplier: 1.0  },
  { id: 'resin', name: 'Фотополимерная смола', available: true,  priceMultiplier: 1.35 },
  { id: 'petg',  name: 'PETG-пластик',         available: false, priceMultiplier: 1.1  },
]

const INIT_REVIEWS: Review[] = []

const INIT_NOTICE: NoticeContent = {
  title: 'ВАЖНО',
  subtitle: 'ПЕРЕД ИСПОЛЬЗОВАНИЕМ',
  buttonText: 'Понятно, продолжить',
  items: [
    { id: '1', icon: 'package',  text: 'Все фигурки коллекционные под заказ.', sub: 'Срок изготовления 20–45 дней.' },
    { id: '2', icon: 'info',     text: 'Фигурки требуют бережного обращения.', sub: 'Избегайте падений и ударов.' },
    { id: '3', icon: 'truck',    text: 'Доставка по всему миру.', sub: 'Срок зависит от вашего региона.' },
    { id: '4', icon: 'document', text: 'Возврат и обмен не предусмотрены.', sub: 'Пожалуйста, ознакомьтесь со всеми деталями.' },
  ],
}

// Промокоды: код → размер скидки в процентах. Пополняйте список или см. пояснение
// про генератор ниже. Коды сравниваются в верхнем регистре.
const PROMO_CODES: Record<string, number> = {
  SIGMA10: 10,
  SPACE15: 15,
  WELCOME5: 5,
}

// Настройки hero-баннера главной страницы (редактируются в CRM)
// Блок «Заказ индивидуальной фигурки» — текст и ссылка редактируются в CRM.
// Текст выводится построчно: каждая непустая строка — отдельный пункт.
const INIT_CUSTOM_ORDER: CustomOrderConfig = {
  text: [
    'Напишите мастеру по печати в Telegram — расскажите, какую фигурку хотите.',
    'Мастер оценит модель и скажет, есть ли возможность её напечатать.',
    'После согласования в переписке мастер оформит для вас индивидуальный заказ.',
    'Такой заказ появится в разделе «Мои заказы» — статус можно отслеживать как обычно.',
  ].join('\n'),
  link: `https://t.me/${OWNER_TG.replace(/^@/, '')}`,
  buttonText: 'Написать мастеру',
  title: 'Фигурка по вашей идее',
  subtitle: 'Согласуем модель, материал и размер с мастером — от эскиза до готовой печати.',
  chips: ['Своя 3D-модель', 'Персонаж', 'Бюст', 'Диорама', 'Реставрация'],
}
// Локальные пути к ассетам (/assets, /src, blob:) существуют только в текущей сборке
// и не открываются в Telegram. Абсолютные https-ссылки (загрузка в Storage) — работают везде.
// Для нестабильных ссылок подставляем встроенную картинку текущей среды.
// Промокоды, управляемые из админ-панели (розыгрыши, скидки).
// maxUses — сколько раз всего можно применить (1 = одноразовый).
// expiresAt — метка времени (мс), 0 = бессрочно.
// targetUser — логин победителя ('' = промокод для всех).
const INIT_PROMOS: PromoCode[] = []

// ─── Способы оплаты ───────────────────────────────────────────────
// Ключи совпадают с провайдерами на сервере (crypto — задел на будущее).
// По умолчанию доступны карта и СБП; скины и крипта выключены (включаются в CRM).
const DEFAULT_PAY_ENABLED: Record<string, boolean> = { card: true, sbp: true, skins: false, crypto: false }

// Реквизиты для перевода по СБП — редактируются в CRM и синхронизируются.
// contact — Telegram-контакт магазина, который видят клиенты в «Мои заказы».
const INIT_SBP: SbpInfo = {
  contact: OWNER_TG,
  fio: 'Укажите ФИО получателя',
  card: '0000 0000 0000 0000',
  phone: '',
  bank: 'Т-Банк',
  note: 'Переводите ТОЧНУЮ сумму заказа — иначе платёж не будет засчитан.',
}

// Генератор кода без похожих символов (0/O, 1/I).
// Проверка промокода для конкретного пользователя. Возвращает найденный промо или причину отказа.
function evalPromo(list: PromoCode[], code: string, login: string): { promo?: PromoCode; error?: string } {
  const c = code.trim().toUpperCase()
  const promo = list.find(p => p.code.toUpperCase() === c && !p.deleted)
  if (!promo) return { error: 'Такого промокода не существует' }
  if (promo.expiresAt && Date.now() > promo.expiresAt) return { error: 'Срок действия промокода истёк' }
  if (promo.uses >= promo.maxUses) return { error: 'Промокод больше не действует' }
  if (promo.targetUser && promo.targetUser.toLowerCase() !== login.toLowerCase()) return { error: 'Промокод предназначен другому пользователю' }
  return { promo }
}


// ─────────────────────────────────────────────────────────────
// Icons
// ─────────────────────────────────────────────────────────────


// Фото с скелетоном-мерцанием и плавным появлением после загрузки.
// Требует, чтобы родитель имел position: relative (скелетон рисуется поверх).
/**
 * Картинка со скелетоном. При `whole` фигурка показывается целиком
 * (object-fit: contain), а поля кадра заполняет размытая копия того же фото —
 * так у вертикальных фигурок не срезает голову и ноги, и не нужно
 * переделывать разрешение каждого снимка вручную.
 */
function SmartImg({ src, alt = '', style, onClick, draggable, whole = false, w, eager = false }: {
  src: string; alt?: string; style?: React.CSSProperties; onClick?: () => void; draggable?: boolean
  whole?: boolean
  /** Целевая ширина кадра — запрашиваем уменьшенную версию из Storage. */
  w?: number
  /** Приоритетная загрузка (для хиро/первого экрана): грузим сразу, без lazy. */
  eager?: boolean
}) {
  const [loaded, setLoaded] = useState(false)
  const [error, setError] = useState(false)
  // Если render-трансформация недоступна, отступаем на оригинальный файл.
  const [fullFallback, setFullFallback] = useState(false)
  useEffect(() => { setLoaded(false); setError(false); setFullFallback(false) }, [src])
  const url = w && !fullFallback ? storageThumb(src, w) : src
  // Нет адреса или картинка не загрузилась — показываем аккуратную заглушку
  // с логотипом-Σ вместо вечного скелетона (иначе карточки «мерцают» полосками).
  const missing = !src || error
  if (missing) {
    return (
      <div style={{ ...style, position: 'relative', zIndex: 1, display: 'grid', placeItems: 'center', background: 'radial-gradient(120% 90% at 50% 30%, #150c2b 0%, #0a0810 60%, #05060a 100%)' }}>
        <span aria-hidden style={{ fontSize: '34px', fontWeight: 800, lineHeight: 1, color: 'var(--ss-brand-hi, #b79bff)', opacity: 0.5, textShadow: '0 0 22px var(--ss-brand-glow)' }}>Σ</span>
        <div onClick={onClick} style={{ position: 'absolute', inset: 0, zIndex: 3, cursor: onClick ? 'pointer' : undefined }} />
      </div>
    )
  }
  return (
    <>
      {!loaded && <div className="skeleton" style={{ position: 'absolute', inset: 0, zIndex: 1 }} />}
      {whole && loaded && (
        <div aria-hidden style={{ position: 'absolute', inset: 0, zIndex: 1, overflow: 'hidden', pointerEvents: 'none' }}>
          {/* Размытый дубль-фон заполняет поля вокруг фигурки, чтобы по бокам не
              зияли пустые полосы. Блюр в CSS-классе (не инлайн) — иначе на
              сенсорных устройствах правило pointer:coarse срезало бы его. */}
          <div className="img-whole-bg" style={{ position: 'absolute', inset: '-14%', backgroundImage: `url(${url})`, backgroundSize: 'cover', backgroundPosition: 'center' }} />
          {/* Виньетка сверху/снизу — кадр выглядит цельным, а не «обрезанным». */}
          <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(120% 84% at 50% 42%, transparent 46%, rgba(5,6,10,0.55) 100%)' }} />
        </div>
      )}
      {/* decoding=async — декодирование не блокирует кадр; lazy — не тянем то,
          что сейчас за экраном, чтобы видимые фото получили всю полосу. При
          ошибке уменьшенной версии повторяем запрос оригинала (fallback). */}
      <img src={url} alt={alt} draggable={draggable} onLoad={() => setLoaded(true)}
        onError={() => { if (url !== src) setFullFallback(true); else setError(true) }}
        loading={eager ? 'eager' : 'lazy'} decoding="async" fetchPriority={eager ? 'high' : 'auto'}
        style={{ ...style, ...(whole ? { objectFit: 'contain' as const } : null), opacity: loaded ? 1 : 0, transition: 'opacity 0.45s ease', position: 'relative', zIndex: 2 }} />
      {/* Щит поверх кадра: перехватывает наведение и клик вместо самой картинки. */}
      <div onClick={onClick} style={{ position: 'absolute', inset: 0, zIndex: 3, cursor: onClick ? 'pointer' : undefined }} />
    </>
  )
}

// ─────────────────────────────────────────────────────────────
// Atoms (all at module level)
// ─────────────────────────────────────────────────────────────

function EditableField({ label, value, onSave, placeholder = '', type = 'text', noBorder = false }: {
  label: string; value: string; onSave: (v: string) => void; placeholder?: string; type?: string; noBorder?: boolean
}) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(value)
  const ref = useRef<HTMLInputElement>(null)
  useEffect(() => { if (editing) { setDraft(value); setTimeout(() => ref.current?.focus(), 30) } }, [editing, value])
  const save = () => { onSave(draft); setEditing(false) }
  return (
    <div style={{ borderBottom: noBorder ? 'none' : '1px solid var(--border)', paddingBottom: noBorder ? 0 : '10px', marginBottom: noBorder ? 0 : '10px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
        <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0 }}>{label}</p>
        {!editing
          ? <button onClick={() => setEditing(true)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--accent-2-hi)', fontSize: '10px', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '3px', padding: 0 }}><Icon name="pencil" size={10} color="var(--accent-2-hi)" /> Изменить</button>
          : <div style={{ display: 'flex', gap: '10px' }}>
              <button onClick={() => setEditing(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, padding: 0 }}>Отмена</button>
              <button onClick={save} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--status-ready-color)', fontSize: '10px', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '3px', padding: 0 }}><Icon name="check" size={10} color="var(--status-ready-color)" /> Сохранить</button>
            </div>}
      </div>
      {editing
        ? <input ref={ref} type={type} value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => e.key === 'Enter' && save()}
            style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--accent)', borderRadius: '8px', padding: '7px 10px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
        : <p style={{ color: value ? 'var(--text-primary)' : 'var(--text-muted)', fontSize: '13px', fontWeight: value ? 500 : 400, margin: 0, fontStyle: value ? 'normal' : 'italic' }}>{value || placeholder}</p>}
    </div>
  )
}



// Ник автора отзыва: посторонним видны только первые символы, остальное под
// блюром — чтобы клиенты не переписывались между собой в обход мастерской.
// Фото в отзыве: миниатюры + просмотр во весь экран по нажатию (для всех).
// Online presence dot
// Order progress stepper (redesigned)
function OrderProgress({ status, painted }: { status: OrderStatus; painted: boolean }) {
  // Каждому этапу — свой цвет в сине-фиолетовой гамме 50/50; «Упаковка/Готов»
  // остаётся зелёной. Порядок: синий → фиолетовый → синий → зелёный → фиолетовый.
  const STEPS: Array<{ key: OrderStatus; label: string; icon: IconName; color: string }> = [
    { key: 'new',       label: 'Принят',   icon: 'check',   color: 'var(--ss-blue-hi, #4f8dff)'  },
    { key: 'printing',  label: 'Печать',   icon: 'layers',  color: 'var(--ss-brand-hi, #a855f7)' },
    { key: 'painting',  label: 'Покраска', icon: 'pencil',  color: 'var(--ss-blue-hi, #4f8dff)'  },
    { key: 'ready',     label: 'Упаковка', icon: 'package', color: 'var(--status-ready-color, #34c97d)' },
    { key: 'delivered', label: 'Доставка', icon: 'truck',   color: 'var(--ss-brand-hi, #a855f7)' },
  ]
  const currentIdx = STEPS.findIndex(s => s.key === status)
  // Заказ без покраски: этап пропускается — гасим его, но не разрываем цепочку.
  const skipped = (idx: number) => !painted && idx === 2

  return (
    <div style={{ marginTop: '12px', display: 'flex', alignItems: 'flex-start' }}>
      {STEPS.map((step, idx) => {
        const done = idx <= currentIdx
        const active = idx === currentIdx
        const col = skipped(idx) ? 'var(--text-muted)' : done ? step.color : 'var(--text-muted)'
        const lit = done && !skipped(idx)
        return (
          <div key={step.key} style={{ display: 'flex', alignItems: 'flex-start', flex: idx < STEPS.length - 1 ? 1 : '0 0 auto' }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px', flexShrink: 0, width: '52px' }}>
              <div style={{ position: 'relative', width: '30px', height: '30px' }}>
                {/* пульсирующий ореол вокруг текущего этапа */}
                {active && !skipped(idx) && (
                  <span aria-hidden className="ss-step-halo" style={{ position: 'absolute', inset: '-3px', borderRadius: '50%', border: `1.5px solid ${step.color}`, pointerEvents: 'none' }} />
                )}
                <div style={{ position: 'relative', width: '30px', height: '30px', borderRadius: '50%', boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: lit ? `color-mix(in srgb, ${step.color} 18%, transparent)` : 'var(--bg-input)',
                  border: `1px solid ${lit ? `color-mix(in srgb, ${step.color} 50%, transparent)` : 'var(--border)'}`,
                  boxShadow: active ? `0 0 18px -3px ${step.color}` : lit ? `0 0 10px -6px ${step.color}` : 'none',
                  transition: 'background 0.45s var(--ss-ease, ease), border-color 0.45s var(--ss-ease, ease), box-shadow 0.45s var(--ss-ease, ease)',
                  opacity: skipped(idx) ? 0.45 : 1 }}>
                  {/* иконка перемонтируется при смене статуса — мягкий «поп» на переходе */}
                  <span key={`${status}-${idx}`} className={active ? 'ss-step-pop' : undefined} style={{ display: 'flex' }}>
                    <Icon name={step.icon} size={14} color={col} />
                  </span>
                </div>
              </div>
              <span style={{ color: col, fontSize: '9px', fontWeight: active ? 700 : 500, textAlign: 'center', lineHeight: 1.2, opacity: skipped(idx) ? 0.5 : 1, transition: 'color 0.45s var(--ss-ease, ease)' }}>{step.label}</span>
            </div>
            {idx < STEPS.length - 1 && (
              // idx < currentIdx — пройденный участок (плавный градиент между этапами),
              // idx === currentIdx — текущий: штрихи «бегут», показывая, что заказ в работе.
              <div aria-hidden className={idx === currentIdx ? 'ss-order-flow' : undefined}
                style={{ flex: 1, height: '2.5px', marginTop: '14px', borderRadius: '2px', minWidth: '8px',
                backgroundSize: idx === currentIdx ? '14px 100%' : undefined,
                boxShadow: idx < currentIdx ? `0 0 8px -3px ${step.color}` : 'none',
                transition: 'background 0.45s var(--ss-ease, ease)',
                background: idx < currentIdx
                  ? `linear-gradient(90deg, ${step.color}, ${STEPS[idx + 1].color})`
                  : idx === currentIdx
                    ? `repeating-linear-gradient(90deg, ${step.color} 0 3px, transparent 3px 7px)`
                    : 'repeating-linear-gradient(90deg, var(--border) 0 3px, transparent 3px 7px)' }} />
            )}
          </div>
        )
      })}
    </div>
  )
}

// Уникальный id для варианта товара.
// Возвращает варианты товара. Для старых товаров (без поля variants) строит их
// из legacy-полей: «Без покраски» (дешевле) и «С покраской».
// Обложка варианта (выбранная либо первое фото).
// Диапазон цен по вариантам — для превью в каталоге.

// ─────────────────────────────────────────────────────────────
// Lightbox — полноэкранный просмотр со свайпом, пинч- и дабл-тап зумом
// ─────────────────────────────────────────────────────────────
function Lightbox({ images, index, onIndex, onClose, alt }: {
  images: string[]; index: number; onIndex: (i: number) => void; onClose: () => void; alt: string
}) {
  const [scale, setScale] = useState(1)
  const [tx, setTx] = useState(0)
  const [ty, setTy] = useState(0)
  const pointers = useRef<Map<number, { x: number; y: number }>>(new Map())
  const pinchStart = useRef<{ dist: number; scale: number } | null>(null)
  const panStart = useRef<{ x: number; y: number; tx: number; ty: number } | null>(null)
  const swipeStart = useRef<number | null>(null)
  const lastTap = useRef(0)
  const zoomed = scale > 1.01

  const reset = () => { setScale(1); setTx(0); setTy(0) }
  const go = (dir: number) => { reset(); onIndex((index + dir + images.length) % images.length) }

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
      else if (e.key === 'ArrowLeft') go(-1)
      else if (e.key === 'ArrowRight') go(1)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  })

  const dist = () => {
    const p = [...pointers.current.values()]
    return Math.hypot(p[0].x - p[1].x, p[0].y - p[1].y)
  }

  const onPointerDown = (e: React.PointerEvent) => {
    ;(e.target as Element).setPointerCapture?.(e.pointerId)
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY })
    if (pointers.current.size === 2) {
      pinchStart.current = { dist: dist(), scale }
      panStart.current = null; swipeStart.current = null
    } else if (zoomed) {
      panStart.current = { x: e.clientX, y: e.clientY, tx, ty }
    } else {
      swipeStart.current = e.clientX
    }
  }

  const onPointerMove = (e: React.PointerEvent) => {
    if (!pointers.current.has(e.pointerId)) return
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY })
    if (pointers.current.size === 2 && pinchStart.current) {
      const next = Math.min(4, Math.max(1, (dist() / pinchStart.current.dist) * pinchStart.current.scale))
      setScale(next)
      if (next <= 1.01) { setTx(0); setTy(0) }
    } else if (panStart.current) {
      setTx(panStart.current.tx + (e.clientX - panStart.current.x))
      setTy(panStart.current.ty + (e.clientY - panStart.current.y))
    }
  }

  const onPointerUp = (e: React.PointerEvent) => {
    pointers.current.delete(e.pointerId)
    if (pointers.current.size < 2) pinchStart.current = null
    if (panStart.current) panStart.current = null
    if (swipeStart.current != null && !zoomed) {
      const d = swipeStart.current - e.clientX
      if (images.length > 1 && Math.abs(d) > 55) go(d > 0 ? 1 : -1)
      swipeStart.current = null
    }
    // дабл-тап — переключение зума
    const now = Date.now()
    if (now - lastTap.current < 280 && pointers.current.size === 0) {
      if (zoomed) reset(); else setScale(2.4)
    }
    lastTap.current = now
  }

  return (
    <div className="overlay-fade" onClick={() => { if (!zoomed) onClose() }}
      style={{ position: 'fixed', inset: 0, background: 'radial-gradient(120% 80% at 50% 30%, rgba(21,12,43,0.92), rgba(3,3,8,0.96))', backdropFilter: 'blur(10px)', zIndex: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden', touchAction: 'none' }}>
      <button onClick={e => { e.stopPropagation(); onClose() }} style={{ position: 'absolute', top: '16px', right: '16px', width: '38px', height: '38px', borderRadius: '50%', background: 'rgba(255,255,255,0.12)', border: '1px solid var(--ss-brand-edge, rgba(168,85,247,0.3))', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 3 }}>
        <Icon name="close" size={18} color="#fff" />
      </button>
      {images.length > 1 && (
        <div style={{ position: 'absolute', top: '20px', left: '50%', transform: 'translateX(-50%)', color: '#fff', fontSize: '12px', fontWeight: 600, letterSpacing: '0.06em', opacity: 0.8, zIndex: 3 }}>
          {safeIndex(index, images.length) + 1} / {images.length}
        </div>
      )}
      {/* Жесты висят на обёртке, а не на <img>: сама картинка не принимает
          наведение, иначе браузеры вроде Яндекса рисуют над ней своё меню. */}
      <div
        onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp} onPointerCancel={onPointerUp}
        onClick={e => e.stopPropagation()}
        style={{ display: 'flex', maxWidth: '100%', maxHeight: '100%', userSelect: 'none',
          transform: `translate(${tx}px, ${ty}px) scale(${scale})`,
          transition: pinchStart.current || panStart.current ? 'none' : 'transform 0.24s cubic-bezier(0.22,1,0.36,1)',
          cursor: zoomed ? 'grab' : 'zoom-in', willChange: 'transform' }}>
        <img src={images[safeIndex(index, images.length)]} alt={alt} draggable={false}
          style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', borderRadius: '12px', display: 'block',
            boxShadow: '0 24px 80px -20px rgba(124,58,237,0.5)' }} />
      </div>
      {images.length > 1 && !zoomed && <>
        <button onClick={e => { e.stopPropagation(); go(-1) }} style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', width: '42px', height: '42px', borderRadius: '50%', background: 'rgba(255,255,255,0.1)', border: '1px solid var(--ss-brand-edge, rgba(168,85,247,0.3))', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 3 }}><Icon name="arrow-left" size={16} color="#fff" /></button>
        <button onClick={e => { e.stopPropagation(); go(1) }} style={{ position: 'absolute', right: '14px', top: '50%', transform: 'translateY(-50%)', width: '42px', height: '42px', borderRadius: '50%', background: 'rgba(255,255,255,0.1)', border: '1px solid var(--ss-brand-edge, rgba(168,85,247,0.3))', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 3 }}><Icon name="arrow-right" size={16} color="#fff" /></button>
        <div style={{ position: 'absolute', bottom: '22px', left: '50%', transform: 'translateX(-50%)', display: 'flex', gap: '5px', zIndex: 3 }}>
          {images.map((_, i) => <div key={i} onClick={e => { e.stopPropagation(); reset(); onIndex(i) }} style={{ width: i === safeIndex(index, images.length) ? '20px' : '6px', height: '6px', borderRadius: '3px', background: i === safeIndex(index, images.length) ? 'var(--ss-brand-hi, #a855f7)' : 'rgba(255,255,255,0.35)', transition: 'all 0.2s', cursor: 'pointer' }} />)}
        </div>
      </>}
      {!zoomed && (
        <div style={{ position: 'absolute', bottom: images.length > 1 ? '40px' : '22px', left: '50%', transform: 'translateX(-50%)', color: 'rgba(255,255,255,0.5)', fontSize: '10px', letterSpacing: '0.04em', zIndex: 3, pointerEvents: 'none' }}>
          Двойное касание или щипок — увеличить
        </div>
      )}
    </div>
  )
}

function safeIndex(i: number, len: number) { return Math.min(Math.max(i, 0), len - 1) }

// ─────────────────────────────────────────────────────────────
// Product modal
// ─────────────────────────────────────────────────────────────
function ProductModal({ product, orders, reviews, setReviews, authUser, onOrder, onClose, discount = 0, promoCode, payEnabled, waitlist, onToggleWaitlist, allProducts, onOpenProduct }: {
  product: Product; orders: Order[]; reviews: Review[]; setReviews: React.Dispatch<React.SetStateAction<Review[]>>
  authUser: AuthUser | null; onOrder: (variant: ProductVariant, provider: PayProvider) => void; onClose: () => void
  discount?: number; promoCode?: string; payEnabled: Record<string, boolean>
  waitlist?: Record<string, string[]>; onToggleWaitlist?: (productId: number) => void
  allProducts?: Product[]; onOpenProduct?: (p: Product) => void
}) {
  // Цена со скидкой активного промокода (для визуального превью до заказа).
  const disc = (p: number) => discount ? Math.round(p * (1 - discount / 100)) : p
  const variants = getVariants(product)
  const [selId, setSelId] = useState<string>(variants[0]?.id ?? '')
  const selVariant = variants.find(v => v.id === selId) ?? variants[0]
  // Перед заказом показываем выбор способа оплаты — только включённые (без «скоро»).
  const [payVariant, setPayVariant] = useState<ProductVariant | null>(null)
  // Окно приёма заказов и лимитированный тираж определяют, доступен ли заказ.
  const win = orderWindow(product)
  const ed = editionState(product)
  const orderable = product.inStock && !win.closed && !ed.soldOut
  const orderBlockLabel = !product.inStock ? 'Нет в наличии' : win.closed ? 'Приём заказов закрыт' : ed.soldOut ? 'Тираж распродан' : ''
  const inWaitlist = !!(authUser && waitlist?.[String(product.id)]?.includes(authUser.login))
  const requestOrder = () => { if (orderable && selVariant) setPayVariant(selVariant) }
  const PAY_METHODS = PAY_METHOD_DEFS.filter(m => !m.comingSoon && payEnabled[m.key]) as Array<PayMethodDef & { key: PayProvider }>
  const [imgIdx, setImgIdx] = useState(0)
  const [showReviews, setShowReviews] = useState(false)
  const [writing, setWriting] = useState(false)
  const [draftRating, setDraftRating] = useState(5)
  const [draftText, setDraftText] = useState('')
  const [draftPhotos, setDraftPhotos] = useState<string[]>([])
  const [photoBusy, setPhotoBusy] = useState(false)
  const reviewFileRef = useRef<HTMLInputElement>(null)
  const [zoom, setZoom] = useState(false)
  // Фото сужается при скролле вниз и возвращается при скролле вверх.
  // Кадр высокий: фигурки вертикальные, и показываем их целиком (contain).
  const IMG_MAX = 330, IMG_MIN = 140
  const [imgH, setImgH] = useState(IMG_MAX)
  const onContentScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const st = e.currentTarget.scrollTop
    const next = Math.round(Math.min(IMG_MAX, Math.max(IMG_MIN, IMG_MAX - st * 0.7)))
    // Мелкие колебания игнорируем, иначе на границе высота дрожит туда-сюда.
    setImgH(prev => (Math.abs(prev - next) < 2 ? prev : next))
  }
  const touchStart = useRef(0)
  const imgs = (selVariant && selVariant.images.length) ? selVariant.images : [product.img]
  const safeIdx = Math.min(imgIdx, imgs.length - 1)
  const selectVariant = (id: string) => { setSelId(id); setImgIdx(0) }
  const productReviews = reviews.filter(r => r.productId === product.id)
  // «С этим часто берут»: сначала фигурки из той же серии или с общими тегами,
  // затем добираем другими из наличия. Только видимые и доступные к заказу.
  const upsell = (() => {
    const pool = (allProducts ?? []).filter(p => p.id !== product.id && !p.hidden && p.inStock)
    const tags = new Set(product.tags ?? [])
    const kin = pool.filter(p => p.series === product.series || (p.tags ?? []).some(t => tags.has(t)))
    const rest = pool.filter(p => !kin.includes(p))
    return [...kin, ...rest].slice(0, 8)
  })()
  const hasDelivered = authUser ? orders.some(o => normLogin(o.userId) === normLogin(authUser.login) && o.status === 'delivered') : false
  const alreadyReviewed = authUser ? productReviews.some(r => r.userId === authUser.login) : false
  // Телефон декодирует крупные фото по секунде-полторы, поэтому свайп «залипал».
  // Прогреваем все кадры варианта заранее — переключение становится мгновенным.
  const imgsKey = imgs.join('|')
  useEffect(() => {
    for (const src of imgsKey.split('|')) {
      const im = new Image()
      im.decoding = 'async'
      im.src = src
      im.decode?.().catch(() => {})
    }
  }, [imgsKey])
  // Переключение на другой товар (через «с этим часто берут»): сбрасываем вариант,
  // кадр, высоту фото и свёрнутые отзывы, чтобы карточка открылась «с чистого листа».
  useEffect(() => {
    setSelId(getVariants(product)[0]?.id ?? '')
    setImgIdx(0)
    setImgH(IMG_MAX)
    setShowReviews(false)
  }, [product.id])
  const prev = () => setImgIdx(i => (i - 1 + imgs.length) % imgs.length)
  const next = () => setImgIdx(i => (i + 1) % imgs.length)
  const addReviewPhotos = async (files: FileList | null) => {
    if (!files || !files.length) return
    setPhotoBusy(true)
    try {
      const room = Math.max(0, 4 - draftPhotos.length) // не больше 4 фото на отзыв
      const list = Array.from(files).filter(f => f.type.startsWith('image/')).slice(0, room)
      const urls = await Promise.all(list.map(async f => {
        const compressed = await compressImage(f, 1000, 0.72)
        return storage.upload(compressed) // публичная ссылка, чтобы kv не раздувался base64
      }))
      setDraftPhotos(prev => [...prev, ...urls])
    } catch (err) {
      alert(`Не удалось загрузить фото: ${(err as Error)?.message ?? "ошибка"}`)
    }
    setPhotoBusy(false)
    if (reviewFileRef.current) reviewFileRef.current.value = ''
  }
  const submitReview = () => {
    if (!authUser) return
    // Чистим текст от управляющих/невидимых символов и режем длину.
    const text = sanitizeText(draftText, 1200)
    if (!isSaneLength(text, 1, 1200)) return
    // Анти-флуд: не чаще одного отзыва в 5 секунд с устройства.
    if (!allowAction('review-submit', 5000)) return
    setReviews(p => [...p, { id: Date.now().toString(), userId: authUser.login, userName: authUser.login, productId: product.id, rating: draftRating, text, date: new Date().toLocaleDateString('ru', { day: 'numeric', month: 'short', year: 'numeric' }), ...(draftPhotos.length ? { photos: draftPhotos } : {}) }])
    setWriting(false); setDraftText(''); setDraftRating(5); setDraftPhotos([])
  }
  const avgRating = productReviews.length ? productReviews.reduce((s,r)=>s+r.rating,0)/productReviews.length : product.rating
  // Пока карточка открыта, страница под ней не прокручивается.
  useEffect(() => {
    const host = document.querySelector('[data-app-scroll]') as HTMLElement | null
    if (host) host.style.overflowY = 'hidden'
    return () => { if (host) host.style.overflowY = 'auto' }
  }, [])

  return createPortal(
    <div className="overlay-fade" onClick={e => { if (e.target === e.currentTarget) onClose() }} style={{ position: 'fixed', left: 0, right: 0, top: 0, bottom: 0, height: '100dvh', background: 'rgba(0,0,0,0.72)', backdropFilter: 'blur(6px)', zIndex: 300, display: 'flex', alignItems: 'flex-end', justifyContent: 'center', overflow: 'hidden' }}>
      {/* dvh, а не vh: в Telegram WebApp панель браузера съедает часть 100vh,
          и у листа с максимальной высотой уезжал за экран верх с крестиком. */}
      <div className="sheet-enter" style={{ width: '100%', maxWidth: '430px', background: 'var(--bg-base)', borderRadius: '22px 22px 0 0', maxHeight: 'calc(100dvh - max(24px, env(safe-area-inset-top)))', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {/* Gallery */}
        {/* overflow: hidden обязателен — img-fade доводит кадр до scale(1.05),
            и без обрезки светлый край картинки вылезал из-под нижнего затемнения. */}
        <div style={{ position: 'relative', overflow: 'hidden', background: 'radial-gradient(120% 90% at 50% 0%, #150c2b 0%, var(--bg-card) 58%, var(--bg-base) 100%)', flexShrink: 0 }}
          onTouchStart={e => { touchStart.current = e.touches[0].clientX }}
          onTouchEnd={e => { const d = touchStart.current - e.changedTouches[0].clientX; if (d > 50) next(); else if (d < -50) prev() }}>
          {/* Размытая подложка из того же кадра — заполняет поля, чтобы фигурку
              можно было показать целиком (contain) без чёрных пустот по бокам. */}
          {/* Без key: пересоздание слоя с blur(26px) на телефоне занимало сотни
              миллисекунд на каждый свайп. Меняем только фон в том же узле. */}
          <div aria-hidden style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none' }}>
            <div style={{ position: 'absolute', inset: '-12%', backgroundImage: `url(${storageThumb(imgs[safeIdx], 200)})`, backgroundSize: 'cover', backgroundPosition: 'center', filter: 'blur(18px) saturate(1.25) brightness(0.5)', transform: 'scale(1.12) translateZ(0)', willChange: 'background-image' }} />
            <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(75% 60% at 50% 38%, transparent 0%, rgba(5,6,10,0.55) 100%)' }} />
          </div>
          {/* портальное свечение за фигуркой */}
          <div aria-hidden style={{ position: 'absolute', left: '50%', top: '-24%', width: '110%', height: '70%', marginLeft: '-55%', borderRadius: '50%', background: 'radial-gradient(circle, var(--ss-brand-glow) 0%, transparent 66%)', filter: 'blur(14px)', pointerEvents: 'none' }} />

          {/* contain, а не cover: у вертикальных фигурок раньше срезало голову и ноги */}
          <img key={`${selId}-${safeIdx}`} className="img-fade" src={storageThumb(imgs[safeIdx], 900)} alt={product.name} fetchPriority="high" onError={e => { const el = e.currentTarget; if (!el.dataset.full && imgs[safeIdx]) { el.dataset.full = '1'; el.src = imgs[safeIdx] } }} style={{ position: 'relative', width: '100%', height: `${imgH}px`, objectFit: 'contain', objectPosition: 'center', display: 'block', userSelect: 'none', cursor: 'zoom-in', transition: 'height 0.12s ease-out', filter: 'drop-shadow(0 14px 30px rgba(0,0,0,0.6))' }} draggable={false} />

          {/* Щит поверх кадра: наведение и клик достаются ему, а не картинке,
              поэтому Яндекс.Браузер не показывает своё меню над фигуркой. */}
          <div onClick={() => setZoom(true)} style={{ position: 'absolute', inset: 0, cursor: 'zoom-in' }} />

          {/* фигурка растворяется в фон карточки — портальная подача */}
          <div aria-hidden style={{ position: 'absolute', inset: 0, pointerEvents: 'none', background: 'linear-gradient(to bottom, transparent 68%, rgba(5,6,10,0.5) 88%, var(--bg-base) 100%)' }} />
          {/* HUD-уголки бренда */}
          {[[0,0,0],[0,'auto',90],['auto','auto',180],['auto',0,270]].map(([t,r,rot], i)=>(
            <svg key={i} viewBox="0 0 40 40" width="26" height="26" aria-hidden style={{ position: 'absolute', top: t === 0 ? 8 : 'auto', bottom: t === 'auto' ? 8 : 'auto', left: r === 0 ? 8 : 'auto', right: r === 'auto' ? 8 : 'auto', transform: `rotate(${rot}deg)`, opacity: 0.5, pointerEvents: 'none' }}>
              <path d="M2 12V2h10" fill="none" stroke="var(--ss-brand-hi)" strokeWidth="2" strokeLinecap="round" />
            </svg>
          ))}

          <span style={{ position: 'absolute', top: '12px', left: '12px', display: 'inline-flex', alignItems: 'center', height: '24px', padding: '0 10px', borderRadius: 'var(--ss-r-pill, 999px)', background: 'var(--ss-brand-wash)', border: '1px solid var(--ss-brand-edge)', color: 'var(--ss-brand-ink)', fontSize: '9.5px', fontWeight: 700, letterSpacing: '0.06em', boxShadow: '0 0 18px -7px var(--ss-brand-glow)' }}>{selVariant?.name}</span>

          <button onClick={onClose} aria-label="Закрыть" className="ss-press" style={{ position: 'absolute', top: '12px', right: '12px', width: '32px', height: '32px', borderRadius: '50%', background: 'rgba(6,6,12,0.78)', border: '1px solid var(--ss-hairline-lo)', cursor: 'pointer', display: 'grid', placeItems: 'center' }}>
            <Icon name="close" size={15} color="#fff" />
          </button>

          {/* Подсказка, что кадр открывается на весь экран */}
          <span style={{ position: 'absolute', bottom: '12px', right: '12px', display: 'inline-flex', alignItems: 'center', gap: '4px', height: '22px', padding: '0 8px', borderRadius: 'var(--ss-r-pill, 999px)', background: 'rgba(6,6,12,0.78)', border: '1px solid var(--ss-hairline-lo)', color: 'var(--ss-ink-3)', fontSize: '9px', fontWeight: 600, pointerEvents: 'none' }}>
            <Icon name="search" size={10} color="var(--ss-ink-3)" /> {safeIdx + 1}/{imgs.length}
          </span>

          {imgs.length > 1 && <>
            <button onClick={prev} aria-label="Предыдущее фото" className="ss-press" style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', width: '30px', height: '30px', borderRadius: '50%', background: 'rgba(6,6,12,0.72)', border: '1px solid var(--ss-hairline-lo)', cursor: 'pointer', display: 'grid', placeItems: 'center' }}><Icon name="arrow-left" size={13} color="#fff" /></button>
            <button onClick={next} aria-label="Следующее фото" className="ss-press" style={{ position: 'absolute', right: '10px', top: '50%', transform: 'translateY(-50%)', width: '30px', height: '30px', borderRadius: '50%', background: 'rgba(6,6,12,0.72)', border: '1px solid var(--ss-hairline-lo)', cursor: 'pointer', display: 'grid', placeItems: 'center' }}><Icon name="arrow-right" size={13} color="#fff" /></button>
          </>}
          {imgs.length > 1 && (
            <div style={{ position: 'absolute', bottom: '12px', left: '50%', transform: 'translateX(-50%)', display: 'flex', gap: '5px', alignItems: 'center' }}>
              {imgs.map((_, i) => <div key={i} onClick={() => setImgIdx(i)} style={{ width: i === safeIdx ? '20px' : '6px', height: '5px', borderRadius: '3px', cursor: 'pointer', transition: 'all 0.22s var(--ss-ease, ease)', background: i === safeIdx ? 'var(--ss-brand-hi)' : 'rgba(255,255,255,0.32)', boxShadow: i === safeIdx ? '0 0 12px -2px var(--ss-brand-glow)' : undefined }} />)}
            </div>
          )}
        </div>

        {/* Полноэкранный просмотр фото со свайпом, пинч- и дабл-тап зумом */}
        {zoom && (
          <Lightbox images={imgs} index={safeIdx} onIndex={setImgIdx} onClose={() => setZoom(false)} alt={product.name} />
        )}

        {/* Scrollable content */}
        <div onScroll={onContentScroll} style={{ flex: 1, overflowY: 'auto', overscrollBehavior: 'contain', padding: '16px' }}>
          <p style={{ color: 'var(--ss-brand-ink, var(--text-muted))', fontSize: '9px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.16em', margin: '0 0 5px' }}>{product.series}</p>
          <h2 style={{ color: 'var(--ss-ink)', fontSize: '22px', fontWeight: 700, letterSpacing: '-0.015em', lineHeight: 1.2, margin: '0 0 10px' }}>{product.name}</h2>
          {/* Рейтинг и размер одной строкой — стеклянные пилюли вместо серых плашек */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap', marginBottom: '16px' }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', height: '26px', padding: '0 10px', borderRadius: 'var(--ss-r-pill, 999px)', background: 'rgba(255,255,255,0.04)', border: '1px solid var(--ss-hairline-lo)' }}>
              <Icon name="star-fill" size={11} color="#f5c842" fill />
              <span style={{ color: 'var(--ss-ink)', fontSize: '11.5px', fontWeight: 700 }}>{avgRating.toFixed(1)}</span>
              <span style={{ color: 'var(--ss-ink-3)', fontSize: '10.5px' }}>· {productReviews.length}</span>
            </span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', height: '26px', padding: '0 10px', borderRadius: 'var(--ss-r-pill, 999px)', background: 'rgba(255,255,255,0.04)', border: '1px solid var(--ss-hairline-lo)' }}>
              <Icon name="layers" size={11} color="var(--ss-brand-hi)" />
              <span style={{ color: 'var(--ss-ink)', fontSize: '11.5px', fontWeight: 700 }}>{product.baseSize} см</span>
            </span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', height: '26px', padding: '0 10px', borderRadius: 'var(--ss-r-pill, 999px)', background: product.inStock ? 'var(--ss-brand-wash)' : 'rgba(255,255,255,0.04)', border: `1px solid ${product.inStock ? 'var(--ss-brand-edge)' : 'var(--ss-hairline-lo)'}` }}>
              <Icon name={product.inStock ? 'check' : 'close'} size={11} color={product.inStock ? 'var(--ss-brand-hi)' : 'var(--ss-ink-4)'} />
              <span style={{ color: product.inStock ? 'var(--ss-brand-ink)' : 'var(--ss-ink-3)', fontSize: '10.5px', fontWeight: 650 }}>{product.inStock ? 'Под заказ' : 'Нет в наличии'}</span>
            </span>
          </div>

          {/* Окно приёма заказов — живой обратный отсчёт (или пометка «закрыто») */}
          {win.hasDeadline && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '11px', marginBottom: '12px', padding: '11px 13px', borderRadius: '14px', background: win.closed ? 'rgba(255,255,255,0.03)' : 'linear-gradient(150deg, color-mix(in srgb, #f5b642 12%, transparent), rgba(255,255,255,0.015))', border: `1px solid ${win.closed ? 'var(--ss-hairline-lo)' : 'color-mix(in srgb, #f5b642 45%, transparent)'}` }}>
              <span aria-hidden style={{ fontSize: '18px', lineHeight: 1 }}>{win.closed ? '🔒' : '⏳'}</span>
              <div style={{ minWidth: 0, flex: 1 }}>
                <p style={{ margin: 0, color: win.closed ? 'var(--ss-ink-3)' : '#f5c874', fontSize: '12.5px', fontWeight: 700 }}>{win.closed ? 'Приём заказов закрыт' : `Окно заказа: осталось ${fmtLeft(win.msLeft)}`}</p>
                <p style={{ margin: '3px 0 0', color: 'var(--ss-ink-3)', fontSize: '10.5px', lineHeight: 1.4 }}>{win.closed ? 'Модель ушла в архив. Загляните позже — возможно, откроем новое окно.' : `Закрытие ${new Date(product.orderDeadline as number).toLocaleString('ru', { day: 'numeric', month: 'long', hour: '2-digit', minute: '2-digit' })}. Печатаем всё, что закажут за окно.`}</p>
              </div>
            </div>
          )}

          {/* Лимитированный тираж — номер покупателя и остаток */}
          {ed.limited && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '11px', marginBottom: '12px', padding: '11px 13px', borderRadius: '14px', background: ed.soldOut ? 'rgba(255,255,255,0.03)' : 'linear-gradient(150deg, var(--ss-brand-wash), rgba(255,255,255,0.015))', border: `1px solid ${ed.soldOut ? 'var(--ss-hairline-lo)' : 'var(--ss-brand-edge)'}` }}>
              <span aria-hidden style={{ fontSize: '18px', lineHeight: 1 }}>💠</span>
              <div style={{ minWidth: 0, flex: 1 }}>
                <p style={{ margin: 0, color: ed.soldOut ? 'var(--ss-ink-3)' : 'var(--ss-brand-ink)', fontSize: '12.5px', fontWeight: 700 }}>{ed.soldOut ? 'Тираж распродан' : `Лимитированный тираж · №${ed.nextNumber} из ${ed.total}`}</p>
                <p style={{ margin: '3px 0 0', color: 'var(--ss-ink-3)', fontSize: '10.5px', lineHeight: 1.4 }}>{ed.soldOut ? `Выпущены все ${ed.total} нумерованных экземпляра.` : `Осталось ${ed.left} из ${ed.total}. Вы получите именной номер экземпляра на подставке.`}</p>
              </div>
            </div>
          )}

          {/* Prices — карточки покраски одновременно переключают галерею */}
          {discount > 0 && (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '7px', marginBottom: '12px', padding: '8px 11px', background: 'linear-gradient(150deg, var(--ss-brand-wash), rgba(255,255,255,0.015))', border: '1px dashed var(--ss-brand-edge)', borderRadius: '12px' }}>
              <Icon name="gift" size={13} color="var(--ss-brand-hi, var(--accent))" />
              <span style={{ color: 'var(--ss-brand-ink, var(--accent))', fontSize: '11px', fontWeight: 700 }}>Промокод {promoCode ? `${promoCode} ` : ''}— скидка {discount}% уже в цене</span>
            </div>
          )}
          <p style={{ color: 'var(--ss-ink-3, var(--text-muted))', fontSize: '9px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.14em', margin: '0 0 8px' }}>Вариант исполнения</p>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '14px' }}>
            {variants.map(v => {
              const active = v.id === selId
              const cover = variantCover(v) || v.images[0]
              return (
                <button key={v.id} onClick={() => selectVariant(v.id)} className={`ss-press${active ? ' spin-border' : ''}`}
                  style={{ position: 'relative', overflow: 'hidden', display: 'flex', alignItems: 'center', gap: '9px', padding: '8px', borderRadius: '14px', cursor: 'pointer', textAlign: 'left', transition: 'background 0.18s, border-color 0.18s',
                    background: active ? 'linear-gradient(150deg, var(--ss-brand-wash), rgba(255,255,255,0.02))' : 'rgba(255,255,255,0.025)',
                    border: `1px solid ${active ? 'var(--ss-brand-edge)' : 'var(--ss-hairline-lo)'}`,
                    boxShadow: active ? '0 0 24px -10px var(--ss-brand-glow)' : undefined }}>
                  {/* мини-превью варианта, тоже целиком */}
                  <span style={{ position: 'relative', width: '42px', height: '42px', flexShrink: 0, borderRadius: '10px', overflow: 'hidden', background: 'rgba(0,0,0,0.35)', border: '1px solid var(--ss-hairline-lo)' }}>
                    {cover && <>
                      <span aria-hidden style={{ position: 'absolute', inset: '-20%', backgroundImage: `url(${cover})`, backgroundSize: 'cover', backgroundPosition: 'center', filter: 'blur(9px) brightness(0.45)' }} />
                      <img src={cover} alt="" style={{ position: 'relative', width: '100%', height: '100%', objectFit: 'contain', display: 'block' }} />
                    </>}
                  </span>
                  <span style={{ minWidth: 0, flex: 1 }}>
                    <span style={{ display: 'block', color: active ? 'var(--ss-ink)' : 'var(--ss-ink-2)', fontSize: '10.5px', fontWeight: 650, marginBottom: '2px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{v.name}</span>
                    {discount > 0 && <span style={{ display: 'block', color: 'var(--ss-ink-4)', fontSize: '9px', textDecoration: 'line-through', lineHeight: 1.2 }}>{v.price.toLocaleString()} ₽</span>}
                    <span style={{ display: 'block', color: active ? 'var(--ss-brand-hi, var(--accent))' : 'var(--ss-ink-2)', fontSize: '14px', fontWeight: 700, textShadow: active ? '0 0 14px var(--ss-brand-glow)' : undefined }}>{disc(v.price).toLocaleString()} ₽</span>
                  </span>
                </button>
              )
            })}
          </div>

          {/* Description */}
          {product.description && (
            <p style={{ color: 'var(--text-secondary)', fontSize: '12.5px', lineHeight: 1.65, margin: '0 0 14px' }}>{product.description}</p>
          )}

          {/* FAQ note */}
          <div style={{ position: 'relative', overflow: 'hidden', borderRadius: '14px', padding: '13px', marginBottom: '12px', display: 'flex', gap: '11px', background: 'linear-gradient(150deg, var(--ss-brand-wash), rgba(255,255,255,0.015))', border: '1px solid var(--ss-brand-edge)' }}>
            <span style={{ width: '30px', height: '30px', flexShrink: 0, borderRadius: '10px', display: 'grid', placeItems: 'center', background: 'rgba(0,0,0,0.3)', border: '1px solid var(--ss-brand-edge)' }}>
              <Icon name="info" size={15} color="var(--ss-brand-hi, var(--accent))" />
            </span>
            <p style={{ color: 'var(--text-secondary)', fontSize: '11.5px', margin: 0, lineHeight: 1.6 }}>Фигурки изготавливаются на заказ. Среднее время — от 3 до 25 дней. Время ожидания зависит от нагруженности. Прогресс отражается в статусе заказа.</p>
          </div>

          {/* Reviews */}
          <button onClick={() => setShowReviews(r => !r)} className="ss-press" style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 14px', background: 'rgba(255,255,255,0.025)', border: '1px solid var(--ss-hairline-lo)', borderRadius: showReviews ? '14px 14px 0 0' : '14px', cursor: 'pointer', marginBottom: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '9px' }}>
              <span style={{ width: '26px', height: '26px', borderRadius: '9px', display: 'grid', placeItems: 'center', background: 'var(--ss-brand-wash)', border: '1px solid var(--ss-brand-edge)' }}>
                <Icon name="star" size={13} color="var(--ss-brand-hi, var(--accent))" />
              </span>
              <span style={{ color: 'var(--ss-ink)', fontSize: '13px', fontWeight: 650 }}>Отзывы</span>
              <span style={{ color: 'var(--ss-ink-3)', fontSize: '12px' }}>({productReviews.length})</span>
            </div>
            <div style={{ transform: showReviews ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}><Icon name="chevron-down" size={15} color="var(--text-muted)" /></div>
          </button>
          {showReviews && (
            <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid var(--ss-hairline-lo)', borderTop: 'none', borderRadius: '0 0 14px 14px', padding: '12px', marginBottom: '8px' }}>
              {productReviews.length === 0 && <p style={{ color: 'var(--text-muted)', fontSize: '12px', textAlign: 'center', margin: '4px 0 10px', fontStyle: 'italic' }}>Пока нет отзывов</p>}
              {productReviews.map(r => (
                <div key={r.id} style={{ borderBottom: '1px solid var(--border)', paddingBottom: '10px', marginBottom: '10px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '4px' }}>
                    <MaskedId value={r.userName} reveal />
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}><StarRating value={r.rating} size={11} /><span style={{ color: 'var(--text-muted)', fontSize: '10px' }}>{r.date}</span></div>
                  </div>
                  <p style={{ color: 'var(--text-secondary)', fontSize: '12px', margin: 0, lineHeight: 1.5 }}>{r.text}</p>
                  <ReviewPhotos photos={r.photos} />
                </div>
              ))}
              {authUser && !alreadyReviewed && (
                hasDelivered ? (
                  writing ? (
                    <div>
                      <StarRating value={draftRating} onChange={setDraftRating} size={22} />
                      <textarea value={draftText} onChange={e => setDraftText(e.target.value)} placeholder="Ваш отзыв..." rows={3}
                        style={{ width: '100%', marginTop: '8px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '8px', padding: '9px 10px', color: 'var(--text-primary)', fontSize: '12px', outline: 'none', resize: 'none', fontFamily: 'inherit', boxSizing: 'border-box' }} />
                      {/* Фото к отзыву — до 4 штук, сжимаются перед сохранением */}
                      <ReviewPhotos photos={draftPhotos} onRemove={url => setDraftPhotos(prev => prev.filter(u => u !== url))} />
                      <input ref={reviewFileRef} type="file" accept="image/*" multiple style={{ display: 'none' }} onChange={e => addReviewPhotos(e.target.files)} />
                      {draftPhotos.length < 4 && (
                        <button onClick={() => reviewFileRef.current?.click()} disabled={photoBusy}
                          style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '8px', padding: '7px 11px', background: 'var(--bg-input)', border: '1px dashed var(--border)', borderRadius: '9px', color: 'var(--text-secondary)', fontSize: '11.5px', fontWeight: 600, cursor: photoBusy ? 'wait' : 'pointer' }}>
                          <Icon name="camera" size={13} color="var(--text-secondary)" />
                          {photoBusy ? 'Загрузка...' : `Добавить фото ${draftPhotos.length ? `(${draftPhotos.length}/4)` : ''}`}
                        </button>
                      )}
                      <div style={{ display: 'flex', gap: '8px', marginTop: '8px' }}>
                        <button className="btn-primary" style={{ padding: '9px' }} onClick={submitReview}>Опубликовать</button>
                        <button className="btn-secondary" style={{ padding: '9px' }} onClick={() => setWriting(false)}>Отмена</button>
                      </div>
                    </div>
                  ) : (
                    <button onClick={() => setWriting(true)} style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '9px 12px', background: 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', borderRadius: '10px', color: 'var(--accent-2-hi)', fontSize: '12px', fontWeight: 600, cursor: 'pointer', width: '100%', justifyContent: 'center' }}>
                      <Icon name="edit-3" size={13} color="var(--accent-2-hi)" /> Оставить отзыв
                    </button>
                  )
                ) : <p style={{ color: 'var(--text-muted)', fontSize: '11px', textAlign: 'center', margin: '4px 0 0', fontStyle: 'italic' }}>Доступно только покупателям с полученным заказом</p>
              )}
              {alreadyReviewed && <p style={{ color: 'var(--status-ready-color)', fontSize: '11px', textAlign: 'center', margin: '4px 0 0' }}>Вы уже оставили отзыв</p>}
            </div>
          )}
          {/* С этим часто берут — горизонтальная лента похожих фигурок */}
          {onOpenProduct && upsell.length > 0 && (
            <div style={{ marginTop: '16px' }}>
              <p style={{ color: 'var(--ss-ink)', fontSize: '13px', fontWeight: 650, margin: '0 0 10px' }}>С этим часто берут</p>
              <div className="no-scrollbar" style={{ display: 'flex', gap: '10px', overflowX: 'auto', margin: '0 -14px', padding: '0 14px 2px', scrollSnapType: 'x proximity' }}>
                {upsell.map(p => {
                  const pr = priceRange(p)
                  return (
                    <button key={p.id} onClick={() => onOpenProduct(p)} className="ss-press"
                      style={{ flex: '0 0 auto', width: '124px', scrollSnapAlign: 'start', textAlign: 'left', padding: 0, background: 'var(--bg-card)', border: '1px solid var(--ss-hairline-lo)', borderRadius: '14px', overflow: 'hidden', cursor: 'pointer' }}>
                      <div style={{ width: '100%', aspectRatio: '1 / 1', background: 'var(--bg-elevated)', overflow: 'hidden' }}>
                        <img src={storageThumb(p.img, 280)} alt={p.name} loading="lazy" decoding="async" style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} onError={e => { const el = e.currentTarget; if (!el.dataset.full && p.img) { el.dataset.full = '1'; el.src = p.img } else el.style.visibility = 'hidden' }} />
                      </div>
                      <div style={{ padding: '8px 9px 10px' }}>
                        <p style={{ color: 'var(--ss-ink)', fontSize: '12px', fontWeight: 600, margin: 0, lineHeight: 1.3, overflow: 'hidden', textOverflow: 'ellipsis', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', minHeight: '31px' }}>{p.name}</p>
                        <p style={{ color: 'var(--ss-brand-hi, var(--accent))', fontSize: '12px', fontWeight: 700, margin: '5px 0 0' }}>{pr.min === pr.max ? `${pr.min.toLocaleString('ru-RU')} ₽` : `от ${pr.min.toLocaleString('ru-RU')} ₽`}</p>
                      </div>
                    </button>
                  )
                })}
              </div>
            </div>
          )}

          {/* Компенсатор: пока фото сжимается, область прокрутки становится выше,
              и без этого распорки нижняя граница «убегает» — контент дёргается. */}
          <div aria-hidden style={{ height: `${IMG_MAX - imgH}px`, flexShrink: 0 }} />
        </div>

        {/* Fixed bottom — одна кнопка заказа (по выбранному варианту) */}
        <div style={{ borderTop: '1px solid var(--ss-hairline-lo)', padding: '12px 14px 18px', background: 'linear-gradient(180deg, transparent, var(--bg-base))', backdropFilter: 'blur(14px)', flexShrink: 0 }}>
          {!orderable && onToggleWaitlist ? (
            <>
              <button onClick={() => onToggleWaitlist(product.id)} className="ss-press"
                style={{ position: 'relative', overflow: 'hidden', width: '100%', padding: '15px', borderRadius: '14px', border: `1px solid ${inWaitlist ? 'var(--ss-brand-edge)' : 'var(--ss-hairline-lo)'}`, background: inWaitlist ? 'var(--ss-brand-wash)' : 'linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02))', color: inWaitlist ? 'var(--ss-brand-ink)' : '#fff', fontSize: '15px', fontWeight: 700, fontFamily: 'inherit', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '9px' }}>
                <span aria-hidden style={{ fontSize: '16px', lineHeight: 1 }}>🔔</span>
                <span>{inWaitlist ? 'Вы в списке · отписаться' : 'Сообщить, когда откроется'}</span>
              </button>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', textAlign: 'center', margin: '8px 0 0', lineHeight: 1.4 }}>{orderBlockLabel}. {inWaitlist ? 'Пришлём уведомление, как только откроем.' : 'Оставьте заявку — сообщим, когда снова примем заказы.'}</p>
            </>
          ) : (
          <>
          {(() => {
            const base = selVariant?.price ?? 0
            return (
              <button onClick={requestOrder} disabled={!orderable} className="ss-press"
                style={{ position: 'relative', overflow: 'hidden', width: '100%', padding: '15px', borderRadius: '14px', border: `1px solid ${orderable ? 'var(--ss-brand-edge)' : 'transparent'}`, background: orderable ? 'linear-gradient(180deg, var(--ss-brand-hi), var(--ss-brand))' : 'rgba(255,255,255,0.05)', color: orderable ? '#fff' : 'var(--ss-ink-4)', fontSize: '15px', fontWeight: 700, fontFamily: 'inherit', cursor: orderable ? 'pointer' : 'default', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '9px', boxShadow: orderable ? '0 10px 30px -12px var(--ss-brand-glow), inset 0 1px 0 rgba(255,255,255,0.18)' : undefined }}>
                {orderable ? <>
                  <span>Заказать · {selVariant?.name}</span>
                  <span aria-hidden style={{ width: '1px', height: '15px', background: 'rgba(255,255,255,0.28)' }} />
                  {discount > 0 && <span style={{ fontSize: '12px', fontWeight: 500, textDecoration: 'line-through', opacity: 0.7 }}>{base.toLocaleString()}</span>}
                  <span>{disc(base).toLocaleString()} ₽</span>
                </> : <span>{orderBlockLabel}</span>}
              </button>
            )
          })()}
          {!orderable && <p style={{ color: 'var(--text-muted)', fontSize: '11px', textAlign: 'center', margin: '8px 0 0', fontStyle: 'italic' }}>{orderBlockLabel}</p>}
          </>
          )}
        </div>

        {/* Выбор способа оплаты */}
        {payVariant !== null && (
          <div className="overlay-fade" onClick={e => { if (e.target === e.currentTarget) setPayVariant(null) }}
            style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(5px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center', zIndex: 250 }}>
            <div className="sheet-enter" style={{ width: '100%', background: 'var(--bg-card)', borderRadius: '22px 22px 0 0', padding: '6px 0 0' }}>
              <div style={{ width: '36px', height: '4px', borderRadius: '2px', background: 'var(--border)', margin: '0 auto 4px' }} />
              <div style={{ padding: '14px 18px 24px' }}>
                <p style={{ color: 'var(--text-primary)', fontSize: '16px', fontWeight: 700, margin: '0 0 3px' }}>Выберите способ оплаты</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 14px' }}>Вы перейдёте на защищённую страницу оплаты</p>
                {PAY_METHODS.length === 0 && (
                  <p style={{ color: 'var(--text-muted)', fontSize: '12px', margin: '10px 0 4px', textAlign: 'center', lineHeight: 1.5 }}>Приём оплаты временно приостановлен.<br />Загляните чуть позже 🙏</p>
                )}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {PAY_METHODS.map(m => (
                    <button key={m.key} onClick={() => { const v = payVariant; setPayVariant(null); onOrder(v!, m.key) }}
                      style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '13px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '14px', cursor: 'pointer', textAlign: 'left' }}>
                      <div style={{ width: '38px', height: '38px', borderRadius: '10px', background: 'var(--accent-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <Icon name={m.icon} size={17} color="var(--accent)" />
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: '0 0 3px' }}>{m.label}</p>
                        {m.brands
                          ? <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>{m.brands.map(b => <span key={b} style={{ fontSize: '8px', fontWeight: 800, letterSpacing: '0.4px', color: 'var(--text-secondary)', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '4px', padding: '2px 5px' }}>{b}</span>)}</div>
                          : <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0 }}>{m.sub}</p>}
                      </div>
                      <Icon name="chevron-right" size={15} color="var(--text-muted)" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>,
    document.body,
  )
}

// ─────────────────────────────────────────────────────────────
// Calculator modal
// ─────────────────────────────────────────────────────────────
function CalculatorModal({ products, materials, sections, onClose, onOrder, payEnabled, discount = 0, promoCode }: { products: Product[]; materials: Material[]; sections: CatalogSection[]; onClose: () => void; onOrder: (product: Product, variant: ProductVariant, provider: PayProvider) => void; payEnabled: Record<string, boolean>; discount?: number; promoCode?: string }) {
  const disc = (p: number) => discount ? Math.round(p * (1 - discount / 100)) : p
  const newestProd = products.reduce<Product | null>((acc, p) => !acc || p.id > acc.id ? p : acc, null)
  const [refId, setRefId] = useState<number>(newestProd?.id ?? 0)
  const [desiredSize, setDesiredSize] = useState<number>(newestProd?.baseSize ?? 20)
  const [matId, setMatId] = useState<string>(materials.find(m => m.available)?.id ?? '')
  // Результат — варианты выбранной фигурки с ценой, пересчитанной под размер.
  const [result, setResult] = useState<ProductVariant[] | null>(null)
  const [calcSearch, setCalcSearch] = useState('')
  const [calcSec, setCalcSec] = useState('Все')
  const [payVariant, setPayVariant] = useState<ProductVariant | null>(null)
  const enabled = payEnabled ?? DEFAULT_PAY_ENABLED
  const PAY_METHODS = PAY_METHOD_DEFS.filter(m => !m.comingSoon && enabled[m.key]) as Array<PayMethodDef & { key: PayProvider }>
  const availMats = materials.filter(m => m.available)
  const refProd = products.find(p => p.id === refId)
  // Формируем «товар» из расчёта: размер под желаемый; вариант несёт цену/фото.
  const placeOrder = (variant: ProductVariant, provider: PayProvider) => {
    if (!refProd) return
    const orderProduct: Product = { ...refProd, name: `${refProd.name} · ${desiredSize} см`, baseSize: desiredSize }
    onOrder(orderProduct, variant, provider)
    onClose()
  }
  // Новые фигурки сверху, старые внизу
  const calcFiltered = products.filter(p => {
    const q = calcSearch.toLowerCase()
    return (p.name.toLowerCase().includes(q) || p.series.toLowerCase().includes(q)) && (calcSec === 'Все' || p.series === calcSec)
  }).sort((a, b) => b.id - a.id)
  const calculate = () => {
    if (!refProd || !desiredSize) return
    const mat = materials.find(m => m.id === matId)
    const ratio = Math.pow(desiredSize / refProd.baseSize, 2)
    const mult = mat?.priceMultiplier ?? 1
    setResult(getVariants(refProd).map(v => ({ ...v, price: Math.round(v.price * ratio * mult / 100) * 100 })))
  }
  return createPortal((
    <div className="overlay-fade" onClick={e => { if (e.target === e.currentTarget) onClose() }} style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.72)', backdropFilter: 'blur(6px)', zIndex: 300, display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
      <div className="sheet-enter" style={{ width: '100%', maxWidth: '430px', background: 'var(--bg-base)', borderRadius: '22px 22px 0 0', padding: '6px 0 0', maxHeight: '88vh', display: 'flex', flexDirection: 'column' }}>
        <div style={{ width: '36px', height: '4px', borderRadius: '2px', background: 'var(--border)', margin: '0 auto', position: 'relative', zIndex: 2, flexShrink: 0 }} />
        <div style={{ flex: 1, overflowY: 'auto', padding: '0 0 16px', minHeight: 0 }}>
          {/* Портальная шапка — как в индивидуальном заказе: кольцо крутится вокруг иконки */}
          <div style={{ position: 'relative', overflow: 'hidden', padding: '24px 18px 18px', textAlign: 'center', marginBottom: '4px' }}>
            <div aria-hidden style={{ position: 'absolute', inset: 0, background: 'radial-gradient(90% 120% at 50% -10%, rgba(79,141,255,0.30) 0%, rgba(124,58,237,0.10) 42%, transparent 72%)', pointerEvents: 'none' }} />
            <button onClick={onClose} style={{ position: 'absolute', top: '10px', right: '12px', background: 'rgba(255,255,255,0.06)', border: '1px solid var(--border)', borderRadius: '50%', width: '30px', height: '30px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 2 }}><Icon name="close" size={15} color="var(--text-muted)" /></button>
            <div style={{ position: 'relative', width: '62px', height: '62px', margin: '0 auto 14px', display: 'grid', placeItems: 'center' }}>
              <svg viewBox="0 0 62 62" width="62" height="62" aria-hidden style={{ position: 'absolute', inset: 0, animation: 'ss-ring-spin 12s linear infinite', transformOrigin: '50% 50%' }}>
                <circle cx="31" cy="31" r="29" fill="none" stroke="var(--ss-blue, #3b6fe0)" strokeWidth="1.3" strokeDasharray="22 12" strokeLinecap="round" opacity="0.8" />
              </svg>
              <div style={{ width: '46px', height: '46px', borderRadius: '50%', background: 'radial-gradient(circle at 50% 34%, var(--ss-blue-hi, #4f8dff), var(--ss-blue, #3b6fe0))', display: 'grid', placeItems: 'center', boxShadow: '0 0 26px -4px var(--ss-blue-glow, rgba(79,141,255,0.6))' }}>
                <Icon name="calculator" size={20} color="#fff" />
              </div>
            </div>
            <p style={{ position: 'relative', color: 'var(--ss-blue-ink, #a8c6ff)', fontSize: '10px', fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', margin: '0 0 5px' }}>Калькулятор</p>
            <h2 style={{ position: 'relative', color: 'var(--text-primary)', fontSize: '20px', fontWeight: 700, margin: '0 0 6px' }}>Калькулятор стоимости</h2>
            <p style={{ position: 'relative', color: 'var(--text-secondary)', fontSize: '12.5px', lineHeight: 1.5, margin: '0 auto', maxWidth: '300px' }}>Рассчитайте цену под ваш размер</p>
          </div>
          <div style={{ padding: '0 16px' }}>
          <div style={{ marginBottom: '14px' }}>
            <p style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.7px', margin: '0 0 8px' }}>1. Выберите похожую фигурку</p>
            <div className="search-glow" style={{ position: 'relative', marginBottom: '8px', borderRadius: '12px' }}>
              <span style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', zIndex: 4 }}><Icon name="search" size={15} color="var(--text-muted)" /></span>
              <input value={calcSearch} onChange={e => setCalcSearch(e.target.value)} placeholder="Поиск фигурки..."
                style={{ width: '100%', padding: '10px 12px 10px 36px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '12px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
            </div>
            <div
              ref={el => { if (el) el.onwheel = (e) => { e.preventDefault(); el.scrollLeft += e.deltaY + e.deltaX } }}
              style={{ display: 'flex', gap: '6px', overflowX: 'auto', marginBottom: '8px', paddingBottom: '2px', scrollbarWidth: 'none' }}>
              {['Все', ...sections.map(s => s.name)].map(c => (
                <button key={c} onClick={() => setCalcSec(c)} className={calcSec === c ? 'spin-border' : ''} style={{ padding: '5px 12px', borderRadius: '20px', whiteSpace: 'nowrap', fontSize: '12px', fontWeight: 500, background: calcSec === c ? 'var(--accent-grad)' : 'var(--bg-card)', color: calcSec === c ? '#fff' : 'var(--text-secondary)', border: calcSec === c ? 'none' : '1px solid var(--border)', cursor: 'pointer', flexShrink: 0 }}>
                  {c}
                </button>
              ))}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', maxHeight: '188px', overflowY: 'auto' }}>
              {calcFiltered.length === 0 && <p style={{ color: 'var(--text-muted)', fontSize: '12px', textAlign: 'center', padding: '10px 0', margin: 0 }}>Ничего не найдено</p>}
              {calcFiltered.map(p => (
                <button key={p.id} onClick={() => { setRefId(p.id); setDesiredSize(p.baseSize); setResult(null) }}
                  style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '9px 12px', background: refId === p.id ? 'var(--accent-2-wash)' : 'var(--bg-card)', border: `1px solid ${refId === p.id ? 'var(--accent-2)' : 'var(--border)'}`, borderRadius: '12px', cursor: 'pointer', textAlign: 'left' }}>
                  <img src={storageThumb(p.img, 120)} alt="" loading="lazy" decoding="async" onError={e => { const el = e.currentTarget; if (!el.dataset.full && p.img) { el.dataset.full = '1'; el.src = p.img } }} style={{ width: '38px', height: '38px', borderRadius: '8px', objectFit: 'cover', flexShrink: 0 }} />
                  <div style={{ flex: 1 }}>
                    <p style={{ color: 'var(--text-primary)', fontSize: '12px', fontWeight: 600, margin: '0 0 1px' }}>{p.name}</p>
                    <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0 }}>Базовый: {p.baseSize} см</p>
                  </div>
                  {refId === p.id && <Icon name="check" size={14} color="var(--accent-2-hi)" />}
                </button>
              ))}
            </div>
          </div>
          <div style={{ marginBottom: '14px' }}>
            <p style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.7px', margin: '0 0 8px' }}>2. Желаемый размер (см)</p>
            <input type="number" inputMode="numeric" value={desiredSize || ''} min={5} max={100} placeholder="20" onChange={e => { setDesiredSize(Number(e.target.value)); setResult(null) }}
              style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '11px 14px', color: 'var(--text-primary)', fontSize: '16px', fontWeight: 600, outline: 'none', textAlign: 'center', boxSizing: 'border-box' }} />
          </div>
          <div style={{ marginBottom: '18px' }}>
            <p style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.7px', margin: '0 0 8px' }}>3. Материал</p>
            {availMats.length === 0
              ? <p style={{ color: 'var(--danger)', fontSize: '12px', margin: 0 }}>Временно нет доступных материалов</p>
              : <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                  {availMats.map(m => <button key={m.id} onClick={() => { setMatId(m.id); setResult(null) }} style={{ padding: '8px 14px', borderRadius: '10px', background: matId === m.id ? 'var(--accent-grad)' : 'var(--bg-card)', border: `1px solid ${matId === m.id ? 'transparent' : 'var(--border)'}`, color: matId === m.id ? '#fff' : 'var(--text-secondary)', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}>{m.name}</button>)}
                </div>}
          </div>
          {result && (
            <div style={{ background: 'var(--bg-card)', border: '1px solid var(--accent-2)', borderRadius: '14px', padding: '14px', marginBottom: '12px', boxShadow: '0 0 30px -14px var(--accent-2-glow)' }}>
              <p style={{ color: 'var(--accent-2-hi)', fontSize: '11px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.7px', margin: '0 0 10px' }}>Стоимость изменения</p>
              {discount > 0 && (
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', marginBottom: '10px', padding: '6px 10px', background: 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', borderRadius: '10px' }}>
                  <Icon name="gift" size={13} color="var(--accent-2-hi)" />
                  <span style={{ color: 'var(--accent-2-hi)', fontSize: '11px', fontWeight: 700 }}>Промокод {promoCode ? `${promoCode} ` : ''}— скидка {discount}% уже в цене</span>
                </div>
              )}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {result.map(v => (
                  <div key={v.id} className="spin-border" style={{ background: 'var(--bg-elevated)', borderRadius: '10px', padding: '10px', display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p style={{ color: 'var(--text-secondary)', fontSize: '11px', margin: '0 0 2px', fontWeight: 600 }}>{v.name}</p>
                      <div style={{ display: 'flex', alignItems: 'baseline', gap: '6px' }}>
                        {discount > 0 && <span style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 500, textDecoration: 'line-through' }}>{v.price.toLocaleString()}</span>}
                        <span style={{ color: 'var(--accent-2-hi)', fontSize: '18px', fontWeight: 700 }}>{disc(v.price).toLocaleString()} ₽</span>
                      </div>
                    </div>
                    <button onClick={() => setPayVariant(v)}
                      style={{ padding: '10px 14px', borderRadius: '10px', background: 'var(--accent-grad)', border: 'none', color: '#fff', fontSize: '12px', fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '6px', flexShrink: 0 }}>
                      <Icon name="cart" size={14} color="#fff" /> Заказать
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
          </div>
        </div>
        {/* Кнопка расчёта закреплена у нижнего борда — не уезжает при скролле */}
        <div style={{ flexShrink: 0, padding: '12px 16px calc(14px + env(safe-area-inset-bottom))', borderTop: '1px solid var(--border)', background: 'var(--bg-base)' }}>
          <button className="btn-primary spin-border" onClick={calculate} disabled={!refProd || !desiredSize || !matId} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', margin: 0 }}>
            <Icon name="calculator" size={15} color="#fff" /> Рассчитать
          </button>
        </div>

        {payVariant !== null && (
          <div className="overlay-fade" onClick={e => { if (e.target === e.currentTarget) setPayVariant(null) }}
            style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(5px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center', zIndex: 400 }}>
            <div className="sheet-enter" style={{ width: '100%', maxWidth: '430px', background: 'var(--bg-card)', borderRadius: '22px 22px 0 0', padding: '6px 0 0' }}>
              <div style={{ width: '36px', height: '4px', borderRadius: '2px', background: 'var(--border)', margin: '0 auto 4px' }} />
              <div style={{ padding: '14px 18px 24px' }}>
                <p style={{ color: 'var(--text-primary)', fontSize: '16px', fontWeight: 700, margin: '0 0 3px' }}>Выберите способ оплаты</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 14px' }}>{payVariant?.name} · {disc(payVariant?.price ?? 0).toLocaleString()} ₽{discount > 0 ? ` (−${discount}%)` : ''}</p>
                {PAY_METHODS.length === 0 && (
                  <p style={{ color: 'var(--text-muted)', fontSize: '12px', margin: '10px 0 4px', textAlign: 'center', lineHeight: 1.5 }}>Приём оплаты временно приостановлен.<br />Загляните чуть позже 🙏</p>
                )}
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {PAY_METHODS.map(m => (
                    <button key={m.key} onClick={() => { const v = payVariant; setPayVariant(null); placeOrder(v!, m.key) }}
                      style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '13px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '14px', cursor: 'pointer', textAlign: 'left' }}>
                      <div style={{ width: '38px', height: '38px', borderRadius: '10px', background: 'var(--accent-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <Icon name={m.icon} size={17} color="var(--accent)" />
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: '0 0 3px' }}>{m.label}</p>
                        {m.brands
                          ? <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>{m.brands.map(b => <span key={b} style={{ fontSize: '8px', fontWeight: 800, letterSpacing: '0.4px', color: 'var(--text-secondary)', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '4px', padding: '2px 5px' }}>{b}</span>)}</div>
                          : <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0 }}>{m.sub}</p>}
                      </div>
                      <Icon name="chevron-right" size={15} color="var(--text-muted)" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  ), document.body)
}

// ─────────────────────────────────────────────────────────────
// Login
// ─────────────────────────────────────────────────────────────
// Маска «за фигуркой»: гасит слои в центральной колонке, где стоит фигурка,
// оставляя их только в тёмном фоне слева/справа/сверху. Используется для
// портала, дыма и частиц, чтобы они читались строго позади фигурки.
const SPLASH_BEHIND_MASK =
  'linear-gradient(to right, #000 0%, #000 20%, transparent 33%, transparent 67%, #000 80%, #000 100%), radial-gradient(ellipse 60% 30% at 50% 8%, #000 60%, transparent 100%)'

// Красные линейные SVG-иконки для карточек приветственного окна.
// Угловой киберпанк-декор: скошённая скобка с диагональными палочками под 45°
// (тоньше→толще) и точками. Один рисунок, поворачивается на 4 угла — симметрично.
function CyberCorner({ rot, style }: { rot: number; style: React.CSSProperties }) {
  const c = '#ff4d4d'
  return (
    <svg viewBox="0 0 64 64" width="58" height="58" style={{ position: 'absolute', pointerEvents: 'none', transform: `rotate(${rot}deg)`, filter: 'drop-shadow(0 0 5px rgba(239,68,68,0.7))', ...style }}>
      {/* диагональные палочки параллельно срезу (тоньше → толще к углу) */}
      <line x1="53" y1="1.5" x2="62.5" y2="11" stroke={c} strokeWidth="2.6" strokeLinecap="round" opacity="0.95" />
      <line x1="45" y1="2.5" x2="55" y2="12.5" stroke={c} strokeWidth="1.5" strokeLinecap="round" opacity="0.65" />
      <line x1="38" y1="3.5" x2="45" y2="10.5" stroke={c} strokeWidth="1" strokeLinecap="round" opacity="0.4" />
      {/* верхняя горизонтальная линия скобки: тонко идёт от края */}
      <line x1="30" y1="2.4" x2="46" y2="2.4" stroke={c} strokeWidth="1.4" strokeLinecap="round" opacity="0.8" />
      {/* правая вертикальная линия скобки, тоньше */}
      <line x1="61.6" y1="14" x2="61.6" y2="34" stroke={c} strokeWidth="1.1" strokeLinecap="round" opacity="0.55" />
      {/* точки */}
      <circle cx="27" cy="2.4" r="1.1" fill={c} opacity="0.75" />
      <circle cx="61.6" cy="38" r="1.1" fill={c} opacity="0.5" />
    </svg>
  )
}

// Световая частица, разлетающаяся из центра портала во все стороны.
function SplashParticle({ i, n }: { i: number; n: number }) {
  const angle = (i / n) * Math.PI * 2 + (i % 4) * 0.28
  const dist = 90 + ((i * 47) % 140)
  const tx = Math.cos(angle) * dist
  const ty = Math.sin(angle) * dist
  const size = 1 + (i % 3)
  const dur = 2.8 + (i % 6) * 0.55
  const delay = (i % 10) * 0.3
  const op = 0.35 + (i % 4) * 0.14
  return (
    <span className="splash-burst" style={{
      position: 'absolute', top: '40%', left: '50%',
      width: `${size}px`, height: `${size}px`, borderRadius: '50%',
      background: i % 2 ? '#a9c6ff' : '#cbb0ff', boxShadow: i % 2 ? '0 0 7px #4f8dff' : '0 0 7px #a855f7',
      ['--tx' as string]: `${tx}px`, ['--ty' as string]: `${ty}px`,
      ['--p-dur' as string]: `${dur}s`, ['--p-op' as string]: op,
      animationDelay: `${delay}s`, pointerEvents: 'none',
    }} />
  )
}

// Декоративный портал: набор технологичных вращающихся колец (SVG).
// Заполняет родителя (inset:0); позиционируется внешним контейнером.
function SplashPortal({ glow = true }: { glow?: boolean }) {
  const ticks = Array.from({ length: 60 })
  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', mixBlendMode: 'screen' }}>
      {/* мягкое свечение-подложка + пульсация */}
      {glow && <div className="splash-glow-pulse" style={{ position: 'absolute', inset: '6%', borderRadius: '50%', background: 'radial-gradient(circle, transparent 30%, rgba(139,92,246,0.26) 50%, rgba(139,92,246,0.06) 66%, transparent 76%)' }} />}

      {/* внешнее кольцо с делениями — по часовой, 20с */}
      <svg className="splash-ring-cw" viewBox="0 0 200 200" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', filter: 'drop-shadow(0 0 4px rgba(139,92,246,0.8))' }}>
        <circle cx="100" cy="100" r="96" fill="none" stroke="rgba(167,139,250,0.85)" strokeWidth="1.6" />
        <circle cx="100" cy="100" r="88" fill="none" stroke="rgba(167,139,250,0.6)" strokeWidth="1.2" strokeDasharray="1 5" />
        {ticks.map((_, i) => {
          const a = (i / ticks.length) * Math.PI * 2
          const r1 = i % 5 === 0 ? 90 : 93
          return <line key={i} x1={100 + Math.cos(a) * r1} y1={100 + Math.sin(a) * r1} x2={100 + Math.cos(a) * 96} y2={100 + Math.sin(a) * 96} stroke="rgba(216,180,254,0.95)" strokeWidth={i % 5 === 0 ? 1.8 : 1} />
        })}
      </svg>

      {/* среднее кольцо — против часовой, 26с, сегменты (синее) */}
      <svg className="splash-ring-ccw" viewBox="0 0 200 200" style={{ position: 'absolute', inset: '9%', width: '82%', height: '82%', filter: 'drop-shadow(0 0 4px rgba(79,141,255,0.85))' }}>
        <circle cx="100" cy="100" r="94" fill="none" stroke="rgba(122,168,255,0.95)" strokeWidth="2.6" strokeDasharray="34 20" strokeLinecap="round" />
        <circle cx="100" cy="100" r="80" fill="none" stroke="rgba(96,152,234,0.7)" strokeWidth="1.4" strokeDasharray="2 8" />
      </svg>

      {/* внутреннее кольцо — по часовой медленно, 34с (синее) */}
      <svg className="splash-ring-cw-slow" viewBox="0 0 200 200" style={{ position: 'absolute', inset: '20%', width: '60%', height: '60%', filter: 'drop-shadow(0 0 3px rgba(124,176,255,0.75))' }}>
        <circle cx="100" cy="100" r="96" fill="none" stroke="rgba(160,190,255,0.9)" strokeWidth="2" strokeDasharray="6 14" strokeLinecap="round" />
        <circle cx="100" cy="100" r="70" fill="none" stroke="rgba(160,190,255,0.7)" strokeWidth="1.4" strokeDasharray="60 120" strokeLinecap="round" />
      </svg>
    </div>
  )
}

function LoginScreen({ onLogin }: { onLogin: (l: string, p: string, tg?: string) => boolean }) {
  const [progress, setProgress] = useState(0)
  const [leaving, setLeaving] = useState(false)
  const [finish, setFinish] = useState(false)
  const doneRef = useRef(false)
  const unameRef = useRef<string | null>(null)

  // Круг прогресса
  const R = 52, C = 2 * Math.PI * R
  const shown = Math.round(progress)

  // Сообщения загрузки — привязаны к прогрессу, а не к таймеру
  const LOADING_NOTES = [
    'Подготовка лучшего опыта для вас',
    'Готовим витрину коллекций…',
    'Собираем рекомендации для вас…',
    'Загружаем вашу вселенную…',
  ]
  const loadingNote = LOADING_NOTES[Math.min(LOADING_NOTES.length - 1, Math.floor(progress / (100 / LOADING_NOTES.length)))]

  useEffect(() => {
    const detect = () => {
      try {
        const tg = (window as unknown as { Telegram?: { WebApp?: { ready?: () => void; expand?: () => void; initDataUnsafe?: { user?: { username?: string; id?: number } } } } }).Telegram?.WebApp
        if (!tg) return
        tg.ready?.(); tg.expand?.()
        const u = tg.initDataUnsafe?.user
        if (u?.username) unameRef.current = u.username
        else if (u?.id) unameRef.current = `id${u.id}`
        // Числовой chat id владельца нужен боту, чтобы присылать уведомления о переводах.
        if (u?.id && unameRef.current && `@${unameRef.current}`.toLowerCase() === OWNER_TG.toLowerCase()) {
          kv.set('ownerChatId', u.id).catch(() => { /* offline */ })
        }
      } catch {}
    }
    detect()
    const SRC = 'https://telegram.org/js/telegram-web-app.js'
    let script = document.querySelector<HTMLScriptElement>(`script[src="${SRC}"]`)
    if (!script) {
      script = document.createElement('script')
      script.src = SRC
      script.async = true
      document.head.appendChild(script)
    }
    script.addEventListener('load', detect)

    // Предзагружаем витрину, пока идёт заставка.
    try {
      Array.from(new Set(INIT_PRODUCTS.map(p => p.img).filter(Boolean)))
        .slice(0, 8).forEach(u => { const im = new Image(); im.src = u })
    } catch {}

    // Плавный прогресс ~6 с: постепенно, без скачков, с лёгким замедлением.
    const start = Date.now()
    const DURATION = 6000
    const tick = setInterval(() => {
      const t = Math.min(1, (Date.now() - start) / DURATION)
      // ease-out — быстрее в начале, мягко подходит к 100
      const eased = 1 - Math.pow(1 - t, 2.2)
      setProgress(eased * 100)
      if (t >= 1) clearInterval(tick)
    }, 40)

    return () => { clearInterval(tick); script?.removeEventListener('load', detect) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Завершение: 100% → яркость логотипа (300 мс) → fade out (300 мс) → вход.
  useEffect(() => {
    if (progress < 100 || doneRef.current) return
    doneRef.current = true
    const t1 = setTimeout(() => setFinish(true), 300)
    const t2 = setTimeout(() => setLeaving(true), 700)
    const t3 = setTimeout(() => {
      onLogin('__tg__', 'user123', unameRef.current || 'preview')
    }, 1000)
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [progress])

  return (
    <div data-theme="dark" className={`splash-screen${leaving ? ' out' : ''}`} style={{
      position: 'absolute', inset: 0, zIndex: 500, display: 'flex', flexDirection: 'column', alignItems: 'center',
      background: 'radial-gradient(105% 62% at 50% 26%, #150c2b 0%, #09050f 52%, #030208 78%, #020106 100%)', overflow: 'hidden',
    }}>
      {/* ── Верх: фигурка в световом портале ── */}
      {/* Маска вместо непрозрачной заливки снизу: на телефонах фиксированный
          цвет #040309 не совпадал с фоном экрана и был виден стык-полоса. */}
      {/* Высота портала считается от ШИРИНЫ (aspectRatio), а не от высоты экрана.
          В Telegram при разворачивании мини-приложения меняется только высота
          окна — ширина остаётся прежней. Из-за прежних 52% высоты этот блок при
          растягивании рос, а фигурка (objectFit: cover) и живые кольца
          пересчитывались и «уезжали». Теперь размер зависит только от ширины —
          кольца стоят на месте при любом изменении высоты. */}
      {/* Портал ВСЕГДА держит квадратную пропорцию (высота = ширина × 1.02), поэтому
          вращающиеся кольца стоят строго на запечённом в фото круге и не «съезжают».
          Чтобы на низком окне Telegram Desktop нижний блок с «Загрузка…» не обрезался,
          ограничиваем портал по ШИРИНЕ через dvh (а не по высоте!): так пропорция не
          ломается — портал просто равномерно уменьшается и остаётся по центру.
          На телефоне/превью окно высокое → min выбирает 100% и портал во всю ширину. */}
      <div style={{ position: 'relative', width: 'min(100%, 44dvh)', flex: '0 0 auto', aspectRatio: '1 / 1.02', overflow: 'hidden',
        WebkitMaskImage: 'linear-gradient(to bottom, #000 58%, rgba(0,0,0,0) 100%)',
        maskImage: 'linear-gradient(to bottom, #000 58%, rgba(0,0,0,0) 100%)' }}>
        {/* Фигурка Sigma Space (реальное фото), выходит из темноты */}
        <div className="splash-figure" style={{ position: 'absolute', inset: 0, zIndex: 1 }}>
          <img src={splashArt} alt="Sigma Space" style={{ width: '100%', height: '100%', objectFit: 'cover', objectPosition: 'center 17%', filter: 'contrast(1.05) saturate(1.12) hue-rotate(52deg)' }} />
        </div>

        {/* Синий дым за фигуркой: клубится и поднимается вверх по бокам от неё.
            Та же маска, что и у портала → дым виден только в тёмном фоне слева
            и справа, а над телом гаснет — читается как дымка позади фигурки. */}
        <div style={{ position: 'absolute', inset: 0, mixBlendMode: 'screen', pointerEvents: 'none', zIndex: 2, WebkitMaskImage: SPLASH_BEHIND_MASK, maskImage: SPLASH_BEHIND_MASK }}>
          <div className="splash-smoke splash-smoke-a" />
          <div className="splash-smoke splash-smoke-b" />
          <div className="splash-smoke splash-smoke-c" />
        </div>

        {/* Живые вращающиеся кольца портала — параллельно статичному кругу,
            запечённому в фото за фигуркой (центр на уровне груди, top ~46%).
            Screen-бленд → кольца светятся на тёмном фоне и гаснут на фигурке,
            создавая ощущение, что портал именно ЗА ней. */}
        <div style={{
          position: 'absolute', top: '40%', left: '50%', width: '92%', aspectRatio: '1',
          transform: 'translate(-50%, -50%)', pointerEvents: 'none', zIndex: 3,
          // маска полностью скрывает кольца в центральной колонке, где стоит
          // фигурка, оставляя их только в тёмном фоне слева/справа/сверху —
          // портал читается строго «за фигуркой», а не поверх неё
          WebkitMaskImage: SPLASH_BEHIND_MASK,
          maskImage: SPLASH_BEHIND_MASK,
        }}>
          <SplashPortal />
        </div>

        {/* частицы разлетаются из-за фигурки во все стороны — верхний слой
            со screen-блендом; та же маска прячет частицы над телом (и яркую
            точку в центре), оставляя их только в фоне вокруг фигурки */}
        <div style={{ position: 'absolute', inset: 0, mixBlendMode: 'screen', pointerEvents: 'none', zIndex: 4, WebkitMaskImage: SPLASH_BEHIND_MASK, maskImage: SPLASH_BEHIND_MASK }}>
          {Array.from({ length: 46 }).map((_, i) => <SplashParticle key={i} i={i} n={46} />)}
        </div>

        {/* виньетка по краям + плавный переход к низу без рамок */}
        <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', background: 'radial-gradient(120% 78% at 50% 40%, transparent 46%, rgba(6,4,13,0.5) 78%, rgba(4,3,9,0.85) 100%)' }} />
        <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: '40%', pointerEvents: 'none', background: 'linear-gradient(to bottom, transparent, rgba(4,3,9,0.8) 86%)' }} />
      </div>

      {/* ── Низ: логотип и индикатор загрузки ── */}
      <div style={{ flex: 1, minHeight: 0, width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '4px', padding: '6px 24px max(18px, env(safe-area-inset-bottom))', position: 'relative', zIndex: 2 }}>
        {/* Логотип Σ */}
        <span className={`splash-logo${finish ? ' finish' : ''}`} style={{ fontSize: '52px', lineHeight: 1, fontWeight: 500, color: '#c9a6ff', fontFamily: '"Georgia","Times New Roman",serif', display: 'block' }}>Σ</span>

        <h1 style={{ margin: '6px 0 0', fontSize: '26px', fontWeight: 500, letterSpacing: '0.06em' }}>
          <span style={{ color: '#ffffff' }}>Sigma </span><span style={{ color: '#a855f7' }}>Space</span>
        </h1>
        <p style={{ color: '#7a7095', fontSize: '13px', margin: '0 0 14px' }}>авторские фигурки</p>

        {/* Круглый индикатор загрузки: портал из вложенных колец + яркая дуга */}
        <div style={{ position: 'relative', width: 'min(208px, 24dvh)', height: 'min(208px, 24dvh)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          {/* эффект портала: несколько колец на уменьшение, крутятся в разные
              стороны. Все SVG — общий viewBox 208 и центр 104, поэтому кольца
              строго концентричны; видимый размер задаётся только inset/width. */}
          <svg className="splash-ring-cw" viewBox="0 0 208 208" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', filter: 'drop-shadow(0 0 3px rgba(139,92,246,0.7))' }}>
            <circle cx="104" cy="104" r="103" fill="none" stroke="rgba(167,139,250,0.7)" strokeWidth="1.6" strokeDasharray="2 6" />
          </svg>
          {/* доп. кольцо — тонкая длинная дуга, по часовой */}
          <svg className="splash-ring-cw2" viewBox="0 0 208 208" style={{ position: 'absolute', inset: '1.5%', width: '97%', height: '97%', filter: 'drop-shadow(0 0 4px rgba(79,141,255,0.85))' }}>
            <circle cx="104" cy="104" r="103" fill="none" stroke="rgba(122,168,255,0.95)" strokeWidth="3" strokeDasharray="60 300" strokeLinecap="round" />
          </svg>
          {/* кольцо из точек — вращается против часовой, точки мерцают волной */}
          <svg className="splash-dot-ring" viewBox="0 0 208 208" style={{ position: 'absolute', inset: '4%', width: '92%', height: '92%', filter: 'drop-shadow(0 0 3px rgba(192,132,252,0.9))' }}>
            {Array.from({ length: 48 }).map((_, i) => {
              const a = (i / 48) * Math.PI * 2
              return (
                <circle key={i} className="splash-dot" style={{ ['--td' as string]: `${(i % 16) * 0.1}s` }}
                  cx={104 + Math.cos(a) * 103} cy={104 + Math.sin(a) * 103} r="2.1"
                  fill="#d8b4fe" />
              )
            })}
          </svg>
          <svg className="splash-ring-ccw" viewBox="0 0 208 208" style={{ position: 'absolute', inset: '9%', width: '82%', height: '82%', filter: 'drop-shadow(0 0 4px rgba(139,92,246,0.8))' }}>
            <circle cx="104" cy="104" r="103" fill="none" stroke="rgba(167,139,250,0.9)" strokeWidth="2.6" strokeDasharray="30 22" strokeLinecap="round" />
          </svg>
          <svg className="splash-ring-cw-slow" viewBox="0 0 208 208" style={{ position: 'absolute', inset: '15%', width: '70%', height: '70%', filter: 'drop-shadow(0 0 3px rgba(122,168,255,0.75))' }}>
            <circle cx="104" cy="104" r="103" fill="none" stroke="rgba(147,197,253,0.85)" strokeWidth="2" strokeDasharray="6 12" strokeLinecap="round" />
          </svg>
          {/* кольцо тонких палочек-делений, бегущая подсветка по кругу */}
          <svg className="splash-tick-ring" viewBox="0 0 208 208" style={{ position: 'absolute', inset: '20%', width: '60%', height: '60%', filter: 'drop-shadow(0 0 3px rgba(139,92,246,0.8))' }}>
            {Array.from({ length: 72 }).map((_, i) => {
              const a = (i / 72) * Math.PI * 2
              const long = i % 6 === 0
              const r2 = 103
              const r1 = long ? 93 : 98
              return (
                <line key={i} className="splash-tick" style={{ ['--td' as string]: `${(i % 24) * 0.08}s` }}
                  x1={104 + Math.cos(a) * r1} y1={104 + Math.sin(a) * r1}
                  x2={104 + Math.cos(a) * r2} y2={104 + Math.sin(a) * r2}
                  stroke="#a78bfa" strokeWidth={long ? 2.4 : 1.6} strokeLinecap="round" />
              )
            })}
          </svg>
          {/* доп. внутреннее кольцо-дуга — против часовой */}
          <svg className="splash-ring-ccw2" viewBox="0 0 208 208" style={{ position: 'absolute', inset: '26%', width: '48%', height: '48%', filter: 'drop-shadow(0 0 4px rgba(124,176,255,0.8))' }}>
            <circle cx="104" cy="104" r="103" fill="none" stroke="rgba(147,197,253,0.95)" strokeWidth="2.6" strokeDasharray="40 200" strokeLinecap="round" />
          </svg>

          <div style={{ position: 'relative', width: 'min(138px, 16dvh)', height: 'min(138px, 16dvh)' }}>
            <svg viewBox="0 0 138 138" style={{ width: '100%', height: '100%', transform: 'rotate(-90deg)' }}>
              <defs>
                <linearGradient id="splashLoaderGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#a855f7" />
                  <stop offset="52%" stopColor="#6d6bf6" />
                  <stop offset="100%" stopColor="#4f8dff" />
                </linearGradient>
                <filter id="splashLoaderGlow" x="-60%" y="-60%" width="220%" height="220%">
                  <feGaussianBlur stdDeviation="4" result="b" />
                  <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
                </filter>
              </defs>
              {/* тёмная дорожка */}
              <circle cx="69" cy="69" r={R} fill="none" stroke="rgba(139,92,246,0.16)" strokeWidth="6" />
              {/* яркая дуга прогресса */}
              <circle cx="69" cy="69" r={R} fill="none" stroke="url(#splashLoaderGrad)" strokeWidth="6" strokeLinecap="round"
                strokeDasharray={C} strokeDashoffset={C * (1 - progress / 100)} filter="url(#splashLoaderGlow)"
                style={{ transition: 'stroke-dashoffset 0.12s linear' }} />
            </svg>
            {/* процент */}
            <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <span style={{ display: 'flex', alignItems: 'baseline', gap: '2px', color: '#ffffff', fontSize: '36px', fontWeight: 300, letterSpacing: '0.01em', fontVariantNumeric: 'tabular-nums', textShadow: '0 0 20px rgba(168,85,247,0.45)' }}>
                {shown}<span style={{ fontSize: '16px', fontWeight: 400, color: '#c9a6ff' }}>%</span>
              </span>
            </div>
          </div>
        </div>

        <p style={{ color: '#ece6fb', fontSize: '14px', fontWeight: 600, margin: '12px 0 3px' }}>Загрузка…</p>
        {/* Сообщения сменяются по мере прогресса — загрузка ощущается осмысленной */}
        <p key={loadingNote} className="ss-fade" style={{ color: '#8b81a8', fontSize: '12px', margin: 0 }}>{loadingNote}</p>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────
// Home
// ─────────────────────────────────────────────────────────────
interface HomeSharedProps {
  onOrder: (product: Product, variant: ProductVariant, provider: PayProvider) => void
  products: Product[]; orders: Order[]; reviews: Review[]
  setReviews: React.Dispatch<React.SetStateAction<Review[]>>; authUser: AuthUser | null
  favorites: number[]; setFavorites: React.Dispatch<React.SetStateAction<number[]>>
  activeDiscount?: number; activePromoCode?: string; payEnabled: Record<string, boolean>
  allFavorites?: Record<string, number[]>
  featuredPromo?: PromoCode; promoApplied?: boolean; onActivatePromo?: () => void
  loyalty?: LoyaltyConfig; bonusPoints?: number
  waitlist?: Record<string, string[]>; onToggleWaitlist?: (productId: number) => void
}

// Компактная карточка товара — общая для главной, коллекций и строки «Новинки».
/** Пилюля умной подсказки (ХИТ/ТОП). Стеклянная, в одном ряду с рейтингом/NEW. */
function SmartBadgePill({ b }: { b: SmartBadge }) {
  const tone = b.tone === 'hit'
    ? { fg: '#ffb454', edge: 'rgba(255,150,40,0.5)', bg: 'rgba(255,150,40,0.16)', glow: '0 0 18px -6px rgba(255,150,40,0.7)', mark: '🔥' }
    : { fg: '#ffd66b', edge: 'rgba(245,200,66,0.5)', bg: 'rgba(245,200,66,0.16)', glow: '0 0 18px -6px rgba(245,200,66,0.7)', mark: '★' }
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', padding: '3px 8px', borderRadius: 'var(--ss-r-pill, 999px)', background: tone.bg, border: `1px solid ${tone.edge}`, color: tone.fg, fontSize: '8.5px', fontWeight: 800, letterSpacing: '0.10em', backdropFilter: 'blur(6px)', boxShadow: tone.glow, whiteSpace: 'nowrap' }}>
      <span aria-hidden style={{ fontSize: '9px', lineHeight: 1 }}>{tone.mark}</span>{b.label}
    </span>
  )
}

function HomeProductCard({ item, reviews, favorites, setFavorites, allFavorites, activeDiscount = 0, badge, onOpen, width }: {
  item: Product; reviews: Review[]; favorites: number[]
  setFavorites: React.Dispatch<React.SetStateAction<number[]>>
  allFavorites?: Record<string, number[]>; activeDiscount?: number
  badge?: string; onOpen: () => void; width?: number
}) {
  const favMap = allFavorites ?? {}
  const favCount = Object.values(favMap).filter(arr => arr.includes(item.id)).length
  const itemReviews = reviews.filter(r => r.productId === item.id)
  const avgR = itemReviews.length ? itemReviews.reduce((s, r) => s + r.rating, 0) / itemReviews.length : item.rating
  const isFav = favorites.includes(item.id)
  const { min, max } = priceRange(item)
  const d = (n: number) => activeDiscount > 0 ? Math.round(n * (1 - activeDiscount / 100)) : n
  const multi = getVariants(item).length > 1 && max > min
  const win = orderWindow(item)
  const ed = editionState(item)
  const unavailable = !item.inStock || win.closed || ed.soldOut
  const overlayLabel = !item.inStock ? 'Нет в наличии' : win.closed ? 'Приём закрыт' : ed.soldOut ? 'Тираж закрыт' : ''
  return (
    <div onClick={onOpen} className="ripple prod-card card-in ss-press ss-lift-hover"
      style={{
        position: 'relative', overflow: 'hidden', cursor: 'pointer', flexShrink: 0,
        width: width ? `${width}px` : undefined, opacity: unavailable ? 0.62 : 1,
        borderRadius: 'var(--ss-r-md, 14px)', border: '1px solid var(--ss-brand-edge)',
        background: 'linear-gradient(160deg, #130d24 0%, #0a0810 56%, #05060a 100%)',
        boxShadow: 'var(--ss-e2), 0 0 22px -13px var(--ss-brand-glow)',
      }}>
      {/* портальное свечение за фигуркой — общий приём наших бордов */}
      <div aria-hidden style={{ position: 'absolute', left: '50%', top: '-34%', width: '128%', height: '78%', marginLeft: '-64%', borderRadius: '50%', background: 'radial-gradient(circle, var(--ss-brand-glow) 0%, transparent 68%)', filter: 'blur(8px)', pointerEvents: 'none' }} />

      <div style={{ position: 'relative', aspectRatio: '1 / 1' }}>
        <SmartImg src={item.img} alt={item.name} w={360} style={{ width: '100%', height: '100%', display: 'block', objectFit: 'cover', objectPosition: 'center' }} />
        {/* Показываем изображение 1:1 целиком, без затемняющего оверлея. */}

        {/* Слева сверху: звёзды отзывов, под ними — плашка NEW при необходимости */}
        <div style={{ position: 'absolute', top: '8px', left: '8px', display: 'flex', flexDirection: 'column', gap: '5px', alignItems: 'flex-start', zIndex: 3 }}>
          <span style={{ display: 'flex', alignItems: 'center', gap: '3px', height: '21px', padding: '0 7px', borderRadius: 'var(--ss-r-pill, 999px)', background: 'rgba(6,6,12,0.62)', border: '1px solid var(--ss-hairline-lo)', backdropFilter: 'blur(6px)' }}>
            <Icon name="star-fill" size={9} color="#f5c842" fill />
            <span style={{ color: '#fff', fontSize: '9.5px', fontWeight: 700, lineHeight: 1 }}>{avgR.toFixed(1)}</span>
          </span>
          {(badge || item.isNew) && (
            <span style={{ padding: '3px 8px', borderRadius: 'var(--ss-r-pill, 999px)', background: 'rgba(56,132,255,0.16)', border: '1px solid rgba(56,132,255,0.5)', color: '#4d9bff', fontSize: '8.5px', fontWeight: 800, letterSpacing: '0.10em', backdropFilter: 'blur(6px)', boxShadow: '0 0 18px -6px rgba(56,132,255,0.7)' }}>{badge || 'NEW'}</span>
          )}
          {smartBadges(item, { favCount, avgRating: avgR }).map(b => <SmartBadgePill key={b.key} b={b} />)}
          {/* Окно приёма заказов — живой обратный отсчёт */}
          {win.hasDeadline && <OrderWindowPill expiresAt={item.orderDeadline as number} />}
          {/* Лимитированный тираж — сколько экземпляров осталось */}
          {ed.limited && (
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', padding: '3px 8px', borderRadius: 'var(--ss-r-pill, 999px)', background: ed.soldOut ? 'rgba(6,6,12,0.72)' : 'color-mix(in srgb, #b79bff 16%, rgba(6,6,12,0.6))', border: `1px solid color-mix(in srgb, ${ed.soldOut ? '#9aa3b2' : '#b79bff'} 55%, transparent)`, color: ed.soldOut ? '#9aa3b2' : '#c9b6ff', fontSize: '8.5px', fontWeight: 800, letterSpacing: '0.06em', backdropFilter: 'blur(6px)', whiteSpace: 'nowrap' }}>
              <span aria-hidden style={{ fontSize: '9px', lineHeight: 1 }}>💠</span>
              {ed.soldOut ? 'ТИРАЖ ЗАКРЫТ' : `ОСТАЛОСЬ ${ed.left}/${ed.total}`}
            </span>
          )}
        </div>

        {/* Справа сверху: лайки (избранное) */}
        <button key={isFav ? 'fav' : 'unfav'} className={isFav ? 'heart-pop' : ''} aria-label={isFav ? 'Убрать из избранного' : 'В избранное'}
          onClick={e => { e.stopPropagation(); setFavorites(prev => prev.includes(item.id) ? prev.filter(id => id !== item.id) : [...prev, item.id]) }}
          style={{ position: 'absolute', top: '8px', right: '8px', zIndex: 3, display: 'flex', alignItems: 'center', gap: '3px', height: '21px', padding: '0 7px', borderRadius: 'var(--ss-r-pill, 999px)', cursor: 'pointer', background: isFav ? 'rgba(239,68,68,0.18)' : 'rgba(6,6,12,0.62)', border: `1px solid ${isFav ? 'rgba(239,68,68,0.45)' : 'var(--ss-hairline-lo)'}`, backdropFilter: 'blur(6px)' }}>
          <Icon name="heart" size={10} color={isFav ? '#ef4444' : '#fff'} fill={isFav} strokeWidth={isFav ? 0 : 1.75} />
          <span style={{ color: '#fff', fontSize: '9.5px', fontWeight: 700, lineHeight: 1 }}>{favCount}</span>
        </button>

        {unavailable && (
          <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', zIndex: 3, background: 'rgba(4,4,9,0.55)' }}>
            <span style={{ color: 'rgba(255,255,255,0.82)', fontSize: '9.5px', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', padding: '4px 10px', borderRadius: 'var(--ss-r-pill, 999px)', background: 'rgba(6,6,12,0.7)', border: '1px solid rgba(255,255,255,0.14)' }}>{overlayLabel}</span>
          </div>
        )}
      </div>

      <div style={{ position: 'relative', padding: '2px 10px 11px' }}>
        <p style={{ color: 'var(--ss-brand-ink, var(--text-muted))', fontSize: '8.5px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.14em', margin: '0 0 3px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.series}</p>
        <p style={{ color: '#fff', fontSize: '12.5px', fontWeight: 620, margin: '0 0 7px', lineHeight: 1.25, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.name}</p>
        <div style={{ display: 'flex', gap: '5px', alignItems: 'baseline' }}>
          {multi && <span style={{ fontSize: '9.5px', color: 'rgba(255,255,255,0.55)' }}>от</span>}
          <span style={{ fontSize: '13px', fontWeight: 700, color: 'var(--ss-brand-hi, var(--accent))', textShadow: '0 0 14px var(--ss-brand-glow)' }}>{d(min).toLocaleString()} ₽</span>
          {activeDiscount > 0 && <span style={{ fontSize: '9.5px', color: 'rgba(255,255,255,0.42)', textDecoration: 'line-through' }}>{min.toLocaleString()}</span>}
        </div>
      </div>
    </div>
  )
}

/** Домашняя витрина «Сигма-Аркада»: анимированный баннер с частицами и
 *  плавающими SVG-глифами игр. Тап открывает раздел мини-игр. */
function ArcadeEntry({ points, onOpen }: { points: number; onOpen: () => void }) {
  return (
    <button type="button" onClick={onOpen} aria-label="Открыть Сигма-Аркаду"
      className="spin-border ss-arcade"
      style={{ position: 'relative', width: '100%', textAlign: 'left', cursor: 'pointer', border: 'none',
        borderRadius: 22, padding: '18px 20px', overflow: 'hidden', display: 'block',
        background: 'radial-gradient(130% 130% at 18% 10%, #1b1140 0%, #0c0820 52%, #060510 100%)' }}>
      {/* дрейфующие частицы */}
      <div aria-hidden style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden' }}>
        {[...Array(9)].map((_, i) => (
          <span key={i} className="ss-spark" style={{
            left: `${8 + i * 10}%`, bottom: '-6px',
            width: 3 + (i % 3), height: 3 + (i % 3),
            animationDelay: `${(i * 0.7).toFixed(2)}s`, animationDuration: `${5 + (i % 4)}s`,
            background: i % 2 ? 'var(--ss-brand-hi, #b79bff)' : '#7de3ff' }} />
        ))}
      </div>
      <div style={{ position: 'relative', maxWidth: '76%' }}>
        <span style={{ display: 'inline-block', fontSize: 11, fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase',
          color: 'var(--ss-brand-hi, #b79bff)', opacity: 0.85, marginBottom: 6 }}>Новое · играй на баллы</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 30, fontWeight: 800, lineHeight: 1, color: 'var(--ss-brand-hi, #b79bff)',
            textShadow: '0 0 22px var(--ss-brand-glow)' }}>Σ</span>
          <span style={{ fontSize: 22, fontWeight: 800, color: '#fff', letterSpacing: '-0.01em' }}>Сигма-Аркада</span>
        </div>
        <p style={{ margin: '8px 0 14px', fontSize: 13, lineHeight: 1.4, color: 'rgba(255,255,255,0.72)' }}>
          Ставь бонусы, забирай выигрыш и увеличивай скидку. 5 мини-игр.
        </p>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '7px 14px', borderRadius: 999,
            fontSize: 14, fontWeight: 700, color: '#0a0810',
            background: 'linear-gradient(180deg, #cbb6ff, #9a7bff)', boxShadow: '0 6px 18px -6px var(--ss-brand-glow)' }}>
            Играть ▸
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '6px 12px', borderRadius: 999,
            fontSize: 13, fontWeight: 600, color: 'rgba(255,255,255,0.85)',
            background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)' }}>
            <svg viewBox="0 0 24 24" width={14} height={14} fill="#ffd27d"><circle cx="12" cy="12" r="9" /></svg>
            {points.toLocaleString('ru-RU')} Σ
          </span>
        </div>
      </div>
    </button>
  )
}

/** Арочная витрина мем-фигурок: горизонтальный ряд «полукруглых» карточек с
 *  зацикленным видео (или постером). Тап открывает связанный товар. */
function MemeShowcase({ title, memes, onOpen }: { title: string; memes: HomeMeme[]; onOpen: (m: HomeMeme) => void }) {
  const W = 132, DOME = W / 2
  return (
    <div style={{ marginBottom: '20px' }}>
      <p style={{ color: '#fff', fontSize: '15px', fontWeight: 700, margin: '0 0 10px', display: 'flex', alignItems: 'center', gap: '7px' }}>
        <span aria-hidden style={{ fontSize: '15px' }}>😹</span>{title}
      </p>
      <div style={{ display: 'flex', gap: '12px', overflowX: 'auto', scrollbarWidth: 'none', padding: '4px 2px 2px', WebkitOverflowScrolling: 'touch' }}>
        {memes.map(m => {
          const clickable = typeof m.productId === 'number'
          const media = resolveHomeImg(m.id, m.image)
          return (
            <div key={m.id} onClick={() => clickable && onOpen(m)} className={clickable ? 'ss-press ss-lift-hover' : ''}
              style={{ flexShrink: 0, width: `${W}px`, cursor: clickable ? 'pointer' : 'default', textAlign: 'center' }}>
              <div style={{
                position: 'relative', width: `${W}px`, height: `${W + 26}px`, overflow: 'hidden',
                borderRadius: `${DOME}px ${DOME}px 18px 18px`,
                border: '1px solid var(--ss-brand-edge)',
                background: 'linear-gradient(170deg, #17102b 0%, #0a0810 58%, #05060a 100%)',
                boxShadow: 'var(--ss-e2), 0 0 26px -12px var(--ss-brand-glow)',
              }}>
                {/* сияние в куполе арки */}
                <div aria-hidden style={{ position: 'absolute', left: '50%', top: '-24%', width: '150%', height: '70%', marginLeft: '-75%', borderRadius: '50%', background: 'radial-gradient(circle, var(--ss-brand-glow) 0%, transparent 66%)', filter: 'blur(7px)', pointerEvents: 'none', zIndex: 0 }} />
                {m.video ? (
                  <AutoVideo src={m.video} poster={media || undefined}
                    style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', zIndex: 1 }} />
                ) : media ? (
                  <img src={media} alt={m.title} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', zIndex: 1 }} />
                ) : null}
                <div aria-hidden style={{ position: 'absolute', inset: 0, zIndex: 2, pointerEvents: 'none', background: 'linear-gradient(180deg, transparent 55%, rgba(5,6,10,0.55) 82%, #06060c 100%)' }} />
              </div>
              <p style={{ color: '#fff', fontSize: '12px', fontWeight: 650, margin: '8px 0 0', lineHeight: 1.25, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{m.title}</p>
              {m.caption && <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '2px 0 0', lineHeight: 1.3, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{m.caption}</p>}
            </div>
          )
        })}
      </div>
    </div>
  )
}

// Верхняя обложка-фото убрана: главная сразу начинается с промо-бордов.
function HomeView({ home, onOpenCollection, sections, materials, customOrder, onGoFaq, onGoCatalog, onOpenGames, ...shared }: HomeSharedProps & {
  home: HomeConfig; onOpenCollection: (c: HomeCollection) => void
  sections: CatalogSection[]; materials: Material[]; customOrder?: CustomOrderConfig
  onGoFaq?: (sectionId?: string) => void
  onGoCatalog?: (filter: 'all' | 'favorites' | 'orders') => void
  onOpenGames?: () => void
}) {
  const { onOrder, products, orders, reviews, setReviews, authUser, favorites, setFavorites, activeDiscount = 0, activePromoCode, payEnabled, allFavorites, featuredPromo, promoApplied, onActivatePromo, loyalty, bonusPoints, waitlist, onToggleWaitlist } = shared
  const club = loyaltyCfg(loyalty)
  const cfg = { ...INIT_HOME, ...home }
  // Катаны сняты с продажи — прячем коллекцию, даже если она осталась в старом конфиге.
  const collections = cfg.collections.filter(c => c.id !== 'hc-katana' && c.title.trim().toLowerCase() !== 'katana')
  // Старые конфиги без rows: собираем ряды из legacy-полей popular/novelty.
  const rows: HomeRow[] = home.rows ?? [
    { id: 'r-pop', title: 'Популярное', mode: (home.popular?.length ? 'manual' : 'popular'), ids: home.popular ?? [] },
    { id: 'r-new', title: 'Новинки', mode: (home.novelty?.length ? 'manual' : 'novelty'), ids: home.novelty ?? [] },
  ]
  // Sigma Club: настоящий борд привилегий, если включён в CRM, иначе «скоро».
  const [showClub, setShowClub] = useState(false)
  const custom = { ...INIT_CUSTOM_ORDER, ...(customOrder ?? {}) }
  const [openProduct, setOpenProduct] = useState<Product | null>(null)
  const [showCalc, setShowCalc] = useState(false)
  const [showCustom, setShowCustom] = useState(false)
  /** Ряд по списку id из CRM; пустой список — автоподбор. */
  const pickRow = (ids: number[], fallback: () => Product[]) => {
    if (!ids.length) return fallback()
    const order = new Map(ids.map((id, i) => [id, i]))
    return products.filter(p => order.has(p.id)).sort((a, b) => order.get(a.id)! - order.get(b.id)!)
  }
  /** В ленте показываем максимум 10 карточек — дальше листать незачем. */
  const ROW_MAX = 10
  // Сколько раз каждый товар встречается в заказах — для режима «по кол-ву заказов».
  const orderCount = new Map<string, number>()
  for (const o of orders) orderCount.set(o.name, (orderCount.get(o.name) ?? 0) + 1)
  // Сколько лайков (добавлений в избранное) у товара — по всем пользователям.
  const favMapAll = allFavorites ?? {}
  const favCount = (id: number) => Object.values(favMapAll).filter(arr => arr.includes(id)).length
  // Полный упорядоченный список товаров ряда (без ограничения в 10 карточек).
  const rowProductsAll = (r: HomeRow): Product[] => {
    if (r.mode === 'manual') return pickRow(r.ids, () => [])
    const base = [...products]
    // «Популярное» = по числу лайков (избранное), при равенстве — по рейтингу.
    if (r.mode === 'popular') base.sort((a, b) => (favCount(b.id) - favCount(a.id)) || ((b.rating ?? 0) - (a.rating ?? 0)))
    else if (r.mode === 'novelty') base.sort((a, b) => b.id - a.id)
    else if (r.mode === 'orders') base.sort((a, b) => (orderCount.get(b.name) ?? 0) - (orderCount.get(a.name) ?? 0))
    return base
  }
  const slides = cfg.banners.map(b => ({
    title: b.title, subtitle: b.subtitle, eyebrow: b.eyebrow, cta: b.cta, image: resolveHomeImg(b.id, b.image), video: b.video || undefined, style: b.style,
    onClick: () => { const c = cfg.collections.find(x => x.id === b.collectionId); if (c) onOpenCollection(c) },
  }))
  const row = (label: string, items: Product[], withBadge: boolean, onMore?: () => void) => items.length > 0 && (
    <div style={{ marginBottom: '20px' }}>
      <p style={{ color: 'var(--text-primary)', fontSize: '15px', fontWeight: 700, margin: '0 0 10px' }}>{label}</p>
      <div ref={hScroll} className="ss-hrow" style={{ display: 'flex', gap: '10px', overflowX: 'auto', overflowY: 'hidden', overscrollBehaviorX: 'contain', margin: '0 -14px', padding: '2px 14px 4px' }}>
        {items.map((item) => (
          <HomeProductCard key={item.id} item={item} reviews={reviews} favorites={favorites} setFavorites={setFavorites} allFavorites={allFavorites} activeDiscount={activeDiscount} width={148} badge={withBadge ? 'NEW' : undefined} onOpen={() => setOpenProduct(item)} />
        ))}
        {onMore && (
          <button onClick={onMore} className="ss-press ss-lift-hover" aria-label={`Показать все: ${label}`}
            style={{ flexShrink: 0, width: '112px', alignSelf: 'stretch', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '10px', cursor: 'pointer',
              borderRadius: 'var(--ss-r-md, 14px)', border: '1px solid var(--ss-brand-edge)', background: 'linear-gradient(135deg, #0c1226 0%, #08090f 60%, #05060a 100%)', boxShadow: 'var(--ss-e2), 0 0 24px -12px var(--ss-brand-glow)' }}>
            <span style={{ display: 'grid', placeItems: 'center', width: '40px', height: '40px', borderRadius: '50%', background: 'var(--ss-brand-wash, rgba(140,90,255,0.12))', border: '1px solid var(--ss-brand-edge)', color: 'var(--ss-brand-hi, #b79bff)', boxShadow: '0 0 22px -8px var(--ss-brand-glow)' }}>
              <svg viewBox="0 0 24 24" width={18} height={18} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h13M13 6l6 6-6 6" /></svg>
            </span>
            <span style={{ color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 650 }}>Ещё</span>
          </button>
        )}
      </div>
    </div>
  )
  return (
    <>
      <div style={{ padding: '14px', paddingBottom: '20px' }}>
        {featuredPromo && (
          <div style={{ marginBottom: '18px' }}>
            <PromoAnnounceBoard promo={featuredPromo} applied={!!promoApplied} onActivate={() => onActivatePromo?.()} />
          </div>
        )}
        {slides.length > 0 && <div style={{ marginBottom: '18px' }}><PromoCarousel slides={slides} /></div>}

        {club.enabled && onOpenGames && (
          <div style={{ marginBottom: '18px' }}><ArcadeEntry points={bonusPoints ?? 0} onOpen={onOpenGames} /></div>
        )}

        {(cfg.memes ?? []).length > 0 && (
          <MemeShowcase title={cfg.memesTitle || 'Мем-фигурки'} memes={cfg.memes as HomeMeme[]}
            onOpen={m => { const p = products.find(x => x.id === m.productId); if (p) setOpenProduct(p) }} />
        )}

        {/* Калькулятор и индивидуальный заказ — компактные кнопки в стиле промо-бордов */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '20px' }}>
          {([
            { icon: 'calculator' as IconName, title: 'Рассчитать стоимость', sub: 'Размер, материал и покраска', action: () => setShowCalc(true) },
            { icon: 'star' as IconName, title: 'Своя модель под твою идею', sub: 'Согласуйте эскиз с мастером', action: () => setShowCustom(true) },
          ]).map(b => (
            <button key={b.title} onClick={b.action} className="ss-press ss-lift-hover"
              style={{ position: 'relative', overflow: 'hidden', width: '100%', boxSizing: 'border-box', display: 'flex', alignItems: 'center', gap: '12px', padding: '13px 14px', textAlign: 'left', cursor: 'pointer',
                borderRadius: 'var(--ss-r-md, 14px)', border: '1px solid var(--ss-blue-edge)', boxShadow: 'var(--ss-e2), 0 0 24px -12px var(--ss-blue-glow)',
                background: 'linear-gradient(135deg, #0c1226 0%, #08090f 58%, #05060a 100%)' }}>
              {/* портальное свечение — синий тон для инструментов */}
              <div aria-hidden style={{ position: 'absolute', right: '-4%', top: '-60%', width: 130, height: 130, borderRadius: '50%', background: 'radial-gradient(circle, var(--ss-blue-glow) 0%, transparent 66%)', filter: 'blur(6px)', pointerEvents: 'none' }} />
              <div style={{ position: 'relative', width: '38px', height: '38px', borderRadius: '50%', flexShrink: 0, display: 'grid', placeItems: 'center', background: 'rgba(0,0,0,0.35)', border: '1px solid var(--ss-blue-edge)' }}>
                <Icon name={b.icon} size={17} color="var(--ss-blue-hi)" />
              </div>
              <div style={{ position: 'relative', flex: 1, minWidth: 0 }}>
                <p style={{ margin: 0, color: '#fff', fontSize: 14, fontWeight: 620, lineHeight: 1.25 }}>{b.title}</p>
                <p style={{ margin: '3px 0 0', color: 'var(--ss-ink-2)', fontSize: 11.5, lineHeight: 1.35, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{b.sub}</p>
              </div>
              <span aria-hidden style={{ position: 'relative', flexShrink: 0, display: 'grid', placeItems: 'center', width: 30, height: 30, borderRadius: 'var(--ss-r-sm, 10px)', background: 'var(--ss-blue-wash)', border: '1px solid var(--ss-blue-edge)', color: 'var(--ss-blue-hi)', boxShadow: '0 0 22px -8px var(--ss-blue-glow)' }}>
                <svg viewBox="0 0 24 24" width={15} height={15} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h13M13 6l6 6-6 6" /></svg>
              </span>
            </button>
          ))}
        </div>

        {/* Ряды товаров: состав и способ фильтрации задаются в CRM */}
        {rows.map(r => {
          const all = rowProductsAll(r)
          const items = all.slice(0, ROW_MAX)
          const isNoveltyRow = r.mode === 'novelty' || r.title.trim().toLowerCase() === 'новинки'
          const isPopularRow = r.mode === 'popular' || r.title.trim().toLowerCase() === 'популярное'
          // «Ещё» только у «Популярного» — открывает Каталог с фильтром «Избранное»
          // (по убыванию лайков). У «Новинок» кнопки нет — просто до 10 карточек.
          const onMore = isPopularRow && onGoCatalog && all.length > items.length ? () => onGoCatalog('favorites') : undefined
          return items.length > 0 ? <div key={r.id}>{row(r.title, items, isNoveltyRow, onMore)}</div> : null
        })}

        {/* Коллекции */}
        {collections.length > 0 && (
          <div style={{ marginBottom: '18px' }}>
            <p style={{ color: 'var(--text-primary)', fontSize: '15px', fontWeight: 700, margin: '0 0 10px' }}>Коллекции</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {collections.map((c, ci) => (
                <CollectionBoard key={c.id} title={c.title} subtitle={c.subtitle} eyebrow={c.eyebrow} cta={c.cta} image={resolveHomeImg(c.id, c.image)} style={c.style} height={Math.max(cfg.collectionHeight ?? 300, 288)} index={ci + 1} total={collections.length} onClick={() => onOpenCollection(c)} />
              ))}
            </div>
          </div>
        )}

        {/* Преимущества */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
          <PerkTile title={cfg.club.title} text={cfg.club.text} onClick={() => setShowClub(true)}
            icon={<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M3 7l4.5 4L12 4l4.5 7L21 7l-2 12H5L3 7z" /></svg>} />
          <PerkTile title={cfg.delivery.title} text={cfg.delivery.text} onClick={() => onGoFaq?.('delivery')}
            icon={<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round"><path d="M1 5h12v10H1zM13 8h4.5l3.5 3.5V15h-8z" /><circle cx="5.5" cy="18" r="2" /><circle cx="17.5" cy="18" r="2" /></svg>} />
        </div>
      </div>
      {showClub && (club.clubEnabled
        ? <ClubSheet onClose={() => setShowClub(false)} spent={clubSpent(orders, authUser?.login)} points={bonusPoints ?? 0} loyalty={club} />
        : <ClubSoonSheet onClose={() => setShowClub(false)} />)}
      {openProduct && <ProductModal product={openProduct} orders={orders} reviews={reviews} setReviews={setReviews} authUser={authUser} onOrder={(variant, provider) => { onOrder(openProduct!, variant, provider); setOpenProduct(null) }} onClose={() => setOpenProduct(null)} discount={activeDiscount} promoCode={activePromoCode} payEnabled={payEnabled} waitlist={waitlist} onToggleWaitlist={onToggleWaitlist} allProducts={products} onOpenProduct={setOpenProduct} />}
      {showCalc && <CalculatorModal products={products} materials={materials} sections={sections} onClose={() => setShowCalc(false)} onOrder={onOrder} payEnabled={payEnabled} discount={activeDiscount} promoCode={activePromoCode} />}
      {showCustom && <CustomOrderSheet custom={custom} onClose={() => setShowCustom(false)} />}
    </>
  )
}

function CollectionView({ collection, onBack, ...shared }: HomeSharedProps & {
  collection: HomeCollection; onBack: () => void
}) {
  const { onOrder, products, orders, reviews, setReviews, authUser, favorites, setFavorites, allFavorites, activeDiscount = 0, activePromoCode, payEnabled, waitlist, onToggleWaitlist } = shared
  const [openProduct, setOpenProduct] = useState<Product | null>(null)
  const items = collectionProducts(collection, products)
  return (
    <>
      {/* Шапка коллекции */}
      <div style={{ position: 'relative', height: '176px', flexShrink: 0, overflow: 'hidden' }}>
        {collection.image && <img src={collection.image} alt="" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }} />}
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(5,6,10,0.55) 0%, rgba(5,6,10,0.35) 40%, var(--ss-void) 100%)' }} />
        <button onClick={onBack} aria-label="Назад" className="ss-press" style={{ position: 'absolute', top: '12px', left: '12px', zIndex: 3, width: '36px', height: '36px', borderRadius: '50%', background: 'rgba(10,12,18,0.55)', border: '1px solid var(--ss-hairline-lo)', backdropFilter: 'blur(10px)', display: 'grid', placeItems: 'center', cursor: 'pointer' }}>
          <Icon name="arrow-left" size={18} color="#fff" />
        </button>
        <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, padding: '18px' }}>
          <h2 style={{ margin: 0, color: '#fff', fontSize: 24, fontWeight: 700, textShadow: '0 2px 14px rgba(0,0,0,0.7)' }}>{collection.title}</h2>
          <p style={{ margin: '6px 0 0', color: 'var(--ss-ink-2)', fontSize: 12.5 }}>{collection.subtitle}</p>
        </div>
      </div>
      <div style={{ padding: '14px', paddingBottom: '20px' }}>
        <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 12px' }}>{items.length} {items.length === 1 ? 'модель' : items.length >= 2 && items.length <= 4 ? 'модели' : 'моделей'} в коллекции</p>
        {items.length > 0 ? (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
            {items.map(item => (
              <HomeProductCard key={item.id} item={item} reviews={reviews} favorites={favorites} setFavorites={setFavorites} allFavorites={allFavorites} activeDiscount={activeDiscount} onOpen={() => setOpenProduct(item)} />
            ))}
          </div>
        ) : (
          <div style={{ textAlign: 'center', padding: '48px 20px', color: 'var(--text-muted)' }}>
            <div style={{ width: '58px', height: '58px', borderRadius: '50%', margin: '0 auto 14px', display: 'grid', placeItems: 'center', background: 'var(--ss-brand-wash)', border: '1px solid var(--ss-brand-edge)' }}>
              <Icon name="package" size={24} color="var(--ss-brand-hi)" />
            </div>
            <p style={{ color: 'var(--text-secondary)', fontSize: '13px', fontWeight: 600, margin: '0 0 4px' }}>Скоро здесь появятся модели</p>
            <p style={{ fontSize: '11.5px', margin: 0, lineHeight: 1.5 }}>Товары этой коллекции добавляются мастером<br />в панели управления.</p>
          </div>
        )}
      </div>
      {openProduct && <ProductModal product={openProduct} orders={orders} reviews={reviews} setReviews={setReviews} authUser={authUser} onOrder={(variant, provider) => { onOrder(openProduct!, variant, provider); setOpenProduct(null) }} onClose={() => setOpenProduct(null)} discount={activeDiscount} promoCode={activePromoCode} payEnabled={payEnabled} waitlist={waitlist} onToggleWaitlist={onToggleWaitlist} allProducts={products} onOpenProduct={setOpenProduct} />}
    </>
  )
}

// ─────────────────────────────────────────────────────────────
// Catalog
// ─────────────────────────────────────────────────────────────
type CatalogFilterMode = 'all' | 'favorites' | 'orders'

// Обложка каталога убрана: страница начинается сразу с разделов.
// Каталог: поиск, фильтры (цена/кнопки/хештеги) и сетка товаров.
function CatalogView({ onOrder, products, sections, orders, reviews, setReviews, authUser, favorites, setFavorites, activeDiscount = 0, activePromoCode, promoExpiresAt = 0, payEnabled, allFavorites, featuredPromo, promoApplied, onActivatePromo, catalogFilters = INIT_CATALOG_FILTERS, initialFilter = 'all', waitlist, onToggleWaitlist }: {
  onOrder: (product: Product, variant: ProductVariant, provider: PayProvider) => void; products: Product[]; sections: CatalogSection[]
  orders: Order[]; reviews: Review[]
  setReviews: React.Dispatch<React.SetStateAction<Review[]>>; authUser: AuthUser | null
  favorites: number[]; setFavorites: React.Dispatch<React.SetStateAction<number[]>>
  activeDiscount?: number; activePromoCode?: string; promoExpiresAt?: number; payEnabled: Record<string, boolean>
  allFavorites?: Record<string, number[]>
  featuredPromo?: PromoCode; promoApplied?: boolean; onActivatePromo?: () => void
  /** Настраиваемые в CRM кнопки-фильтры (порядок и состав). */
  catalogFilters?: CatalogFilterButton[]
  /** Фильтр, с которым открыть каталог (например, «Избранное» по кнопке «Ещё»). */
  initialFilter?: CatalogFilterMode
  waitlist?: Record<string, string[]>; onToggleWaitlist?: (productId: number) => void
}) {
  const [search, setSearch] = useState('')
  const [activeSec, setActiveSec] = useState('Все')
  const [openProduct, setOpenProduct] = useState<Product | null>(null)
  const [filterMode, setFilterMode] = useState<CatalogFilterMode>(initialFilter)
  // true — приоритет «сверху новые / больше», false — «сверху старые / меньше»
  const [sortDesc, setSortDesc] = useState(true)
  const [showFilters, setShowFilters] = useState(false)

  // Границы цен по всему каталогу — для ползунка фильтра.
  const priceFloor = products.length ? Math.floor(Math.min(...products.map(p => priceRange(p).min))) : 0
  const priceCeil = products.length ? Math.ceil(Math.max(...products.map(p => priceRange(p).max))) : 0
  // Кнопки-фильтры из CRM (только включённые, в заданном порядке).
  const activeFilterBtns = catalogFilters.filter(f => f.enabled)
  const allTags = allProductTags(products)
  const [adv, setAdv] = useState<{ maxPrice: number; active: string[]; tags: string[] }>({ maxPrice: 0, active: [], tags: [] })
  // Убираем из активных те кнопки/теги, что удалили/выключили в CRM.
  const activeIds = adv.active.filter(id => activeFilterBtns.some(f => f.id === id))
  const activeTags = adv.tags.filter(t => allTags.includes(t))
  // Активный ценовой потолок: 0 (не задан) трактуем как максимум.
  const priceCap = adv.maxPrice > 0 ? adv.maxPrice : priceCeil
  const priceActive = adv.maxPrice > 0 && adv.maxPrice < priceCeil
  const advActive = priceActive || activeIds.length > 0 || activeTags.length > 0
  const advCount = (priceActive ? 1 : 0) + activeIds.length + activeTags.length
  const resetAdv = () => setAdv({ maxPrice: 0, active: [], tags: [] })

  const favMap = allFavorites ?? {}
  const getFavCount = (id: number) => Object.values(favMap).filter(arr => arr.includes(id)).length
  const getOrderCount = (id: number) => orders.filter(o => {
    const pId = products.find(p => p.name === o.figure)?.id
    return pId === id
  }).length

  // Ключ сортировки зависит от выбранной кнопки, направление — от иконки стрелок
  const sortKey = (p: Product) => filterMode === 'favorites' ? getFavCount(p.id) : filterMode === 'orders' ? getOrderCount(p.id) : p.id

  const filtered = products.filter(p => {
    const q = search.toLowerCase().replace(/^#+/, '')
    const pTags = (p.tags ?? []).map(t => t.toLowerCase())
    const matchSearch = p.name.toLowerCase().includes(q) || p.series.toLowerCase().includes(q) || pTags.some(t => t.includes(q))
    const matchSec = activeSec === 'Все' || p.series === activeSec
    const matchPrice = priceRange(p).min <= priceCap
    const matchTags = activeTags.length === 0 || activeTags.some(t => pTags.includes(t.toLowerCase()))
    const matchBtns = activeIds.every(id => {
      const f = activeFilterBtns.find(b => b.id === id)
      return !f || catalogFilterPass(f.kind, p)
    })
    return matchSearch && matchSec && matchPrice && matchTags && matchBtns
  }).sort((a, b) => {
    // Товары в наличии всегда выше — покупатель видит доступное первым.
    if (a.inStock !== b.inStock) return a.inStock ? -1 : 1
    const diff = sortKey(b) - sortKey(a) || b.id - a.id
    return sortDesc ? diff : -diff
  })

  const sortLabel = filterMode === 'favorites' ? (sortDesc ? 'больше лайков' : 'меньше лайков')
    : filterMode === 'orders' ? (sortDesc ? 'больше заказов' : 'меньше заказов')
    : (sortDesc ? 'сначала новые' : 'сначала старые')

  const pickFilter = (mode: CatalogFilterMode) => {
    // Повторное нажатие на активную кнопку переворачивает приоритет
    if (mode === filterMode) setSortDesc(v => !v)
    else { setFilterMode(mode); setSortDesc(true) }
  }
  return (
    <>
      {/* Разделы каталога сразу сверху — обложка убрана */}
      <CategoryTabs items={['Все', ...sections.map(s => s.name)]} active={activeSec} onSelect={setActiveSec} />

      <div style={{ padding: '14px', paddingBottom: '20px' }}>
        {featuredPromo ? (
          <div style={{ marginBottom: '12px' }}>
            <PromoAnnounceBoard promo={featuredPromo} applied={!!promoApplied} onActivate={() => onActivatePromo?.()} />
          </div>
        ) : activeDiscount > 0 && promoExpiresAt > 0 && (
          <div style={{ marginBottom: '12px' }}>
            <PromoCountdown expiresAt={promoExpiresAt} discount={activeDiscount} code={activePromoCode} />
          </div>
        )}
        {/* Панель поиска и фильтров — липнет к верху при прокрутке */}
        <div style={{ position: 'sticky', top: 0, zIndex: 6, margin: '0 -14px', padding: '6px 14px 10px', background: 'linear-gradient(180deg, var(--bg-base) 82%, transparent)', backdropFilter: 'blur(6px)', WebkitBackdropFilter: 'blur(6px)' }}>
          <div style={{ display: 'flex', gap: '8px', marginBottom: '10px' }}>
            <div className="search-glow" style={{ position: 'relative', flex: 1, minWidth: 0, borderRadius: '12px' }}>
              <span style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', zIndex: 4 }}><Icon name="search" size={15} color="var(--text-muted)" /></span>
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Поиск..." aria-label="Поиск по каталогу"
                style={{ width: '100%', padding: '10px 34px 10px 36px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '12px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
              {search && (
                <button onClick={() => setSearch('')} aria-label="Очистить поиск" className="ss-press"
                  style={{ position: 'absolute', right: '7px', top: '50%', transform: 'translateY(-50%)', width: '24px', height: '24px', display: 'grid', placeItems: 'center', borderRadius: '50%', border: 'none', background: 'rgba(255,255,255,0.07)', cursor: 'pointer', zIndex: 4 }}>
                  <Icon name="close" size={13} color="var(--text-muted)" />
                </button>
              )}
            </div>
            <button onClick={() => setShowFilters(true)} aria-label="Фильтры" className="ss-press"
              style={{ position: 'relative', flexShrink: 0, width: '44px', display: 'grid', placeItems: 'center', borderRadius: '12px', cursor: 'pointer',
                background: advActive ? 'linear-gradient(180deg, var(--ss-blue-hi), var(--ss-blue))' : 'var(--bg-card)',
                border: `1px solid ${advActive ? 'var(--ss-blue-edge)' : 'var(--border)'}`, boxShadow: advActive ? '0 6px 18px -8px var(--ss-blue-glow)' : undefined }}>
              <svg viewBox="0 0 24 24" width={17} height={17} fill="none" stroke={advActive ? '#fff' : 'var(--text-secondary)'} strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><path d="M4 6h16M7 12h10M10 18h4" /></svg>
              {advCount > 0 && <span style={{ position: 'absolute', top: '-5px', right: '-5px', minWidth: '17px', height: '17px', padding: '0 4px', borderRadius: '999px', background: 'var(--ss-brand)', color: '#fff', fontSize: '10px', fontWeight: 800, display: 'grid', placeItems: 'center', boxShadow: '0 0 10px -1px var(--ss-brand-glow)' }}>{advCount}</span>}
            </button>
          </div>
          {/* Фильтр + сортировка */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '6px' }}>
          {([['all','Все'],['favorites','Избранное'],['orders','Заказы']] as [CatalogFilterMode, string][]).map(([mode, label]) => {
            const on = filterMode === mode
            return (
              <button key={mode} onClick={() => pickFilter(mode)} className="ss-press"
                style={{
                  position: 'relative', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  gap: '5px', height: '36px', padding: '0 8px', borderRadius: 'var(--ss-r-sm, 11px)',
                  fontSize: '11.5px', fontWeight: on ? 650 : 550, fontFamily: 'inherit', cursor: 'pointer',
                  background: on ? 'linear-gradient(180deg, var(--ss-blue-hi), var(--ss-blue))' : 'rgba(255,255,255,0.025)',
                  border: `1px solid ${on ? 'var(--ss-blue-edge)' : 'var(--ss-hairline-lo)'}`,
                  color: on ? '#fff' : 'var(--ss-ink-2, var(--text-secondary))',
                  boxShadow: on ? '0 6px 18px -8px var(--ss-blue-glow), inset 0 1px 0 rgba(255,255,255,0.18)' : undefined,
                  transition: 'background var(--ss-t-base, 0.2s) var(--ss-ease, ease), color var(--ss-t-base, 0.2s) var(--ss-ease, ease), border-color 0.2s',
                }}>
                <span style={{ whiteSpace: 'nowrap' }}>{label}</span>
                <span style={{ display: 'flex', opacity: on ? 1 : 0.5, transform: on && !sortDesc ? 'scaleY(-1)' : 'none', transition: 'transform 0.22s var(--ss-ease, ease), opacity 0.2s' }}>
                  <Icon name="sort" size={12} color={on ? '#fff' : 'var(--ss-ink-3, var(--text-muted))'} strokeWidth={2} />
                </span>
              </button>
            )
          })}
          </div>
        </div>

        {/* Счётчик результатов и подпись сортировки */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px', margin: '12px 2px 12px' }}>
          <span style={{ color: 'var(--text-secondary)', fontSize: '12px', fontWeight: 600 }}>Найдено: <span style={{ color: 'var(--text-primary)' }}>{filtered.length}</span></span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', color: 'var(--text-muted)', fontSize: '11px' }}>
            <Icon name="sort" size={11} color="var(--text-muted)" strokeWidth={2} />{sortLabel}
          </span>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
          {filtered.map((item, i) => {
            const itemReviews = reviews.filter(r => r.productId === item.id)
            const avgR = itemReviews.length ? itemReviews.reduce((s,r)=>s+r.rating,0)/itemReviews.length : item.rating
            const win = orderWindow(item)
            const ed = editionState(item)
            const unavailable = !item.inStock || win.closed || ed.soldOut
            const overlayLabel = !item.inStock ? 'Нет в наличии' : win.closed ? 'Приём закрыт' : ed.soldOut ? 'Тираж закрыт' : ''
            return (
              <div key={item.id} className={`ripple prod-card ss-press ss-lift-hover${item.inStock ? ' card-in' : ''}`}
                style={{
                  position: 'relative', overflow: 'hidden', cursor: 'pointer', opacity: unavailable ? 0.55 : 1,
                  animationDelay: item.inStock ? `${Math.min(i * 45, 400)}ms` : undefined,
                  borderRadius: '16px', border: '1px solid var(--ss-brand-edge)',
                  background: 'linear-gradient(158deg, #140e26 0%, #0a0810 54%, #05060a 100%)',
                  boxShadow: 'var(--ss-e2), 0 0 26px -14px var(--ss-brand-glow)',
                }} onClick={() => setOpenProduct(item)}>
                {/* верхний световой блик по кромке карточки */}
                <div aria-hidden style={{ position: 'absolute', top: 0, left: '12%', right: '12%', height: '1px', background: 'linear-gradient(90deg, transparent, var(--ss-brand-hi), transparent)', opacity: 0.55, pointerEvents: 'none', zIndex: 4 }} />
                {/* портальное свечение за фигуркой */}
                <div aria-hidden style={{ position: 'absolute', left: '50%', top: '-32%', width: '130%', height: '76%', marginLeft: '-65%', borderRadius: '50%', background: 'radial-gradient(circle, var(--ss-brand-glow) 0%, transparent 68%)', filter: 'blur(9px)', pointerEvents: 'none' }} />

                <div style={{ position: 'relative', aspectRatio: '1 / 1' }}>
                  <SmartImg src={item.img} alt={item.name} w={420} style={{ width: '100%', height: '100%', display: 'block', objectFit: 'cover', objectPosition: 'center' }} />
                  {/* Изображение показываем 1:1 целиком, как загрузил пользователь —
                      без затемняющего оверлея, чтобы рамка и подиум не срезались. */}

                  {item.isNew && (
                    <span style={{ position: 'absolute', top: '8px', right: '8px', zIndex: 3, padding: '3px 8px', borderRadius: 'var(--ss-r-pill, 999px)', background: 'rgba(56,132,255,0.16)', border: '1px solid rgba(56,132,255,0.5)', color: '#4d9bff', fontSize: '8.5px', fontWeight: 800, letterSpacing: '0.10em', backdropFilter: 'blur(6px)', boxShadow: '0 0 18px -6px rgba(56,132,255,0.7)' }}>NEW</span>
                  )}
                  {/* Слева сверху: счётчик заказов (зелёный), а под ним — лайки и звёзды */}
                  <div style={{ position: 'absolute', top: '8px', left: '8px', display: 'flex', flexDirection: 'column', gap: '5px', alignItems: 'flex-start', zIndex: 3 }}>
                    {/* Счётчик заказов виден всегда, даже при нуле */}
                    <span style={{ display: 'flex', alignItems: 'center', gap: '3px', height: '21px', padding: '0 7px', borderRadius: 'var(--ss-r-pill, 999px)', background: 'rgba(52,201,125,0.16)', border: '1px solid rgba(52,201,125,0.45)', backdropFilter: 'blur(6px)', boxShadow: '0 0 16px -6px rgba(52,201,125,0.6)' }}>
                      <Icon name="package" size={10} color="#34c97d" /><span style={{ color: '#34c97d', fontSize: '9.5px', fontWeight: 700, lineHeight: 1 }}>{getOrderCount(item.id)}</span>
                    </span>
                    <span style={{ display: 'flex', alignItems: 'center', gap: '3px', height: '21px', padding: '0 7px', borderRadius: 'var(--ss-r-pill, 999px)', background: 'rgba(6,6,12,0.62)', border: '1px solid var(--ss-hairline-lo)', backdropFilter: 'blur(6px)' }}>
                      <Icon name="star-fill" size={9} color="#f5c842" fill /><span style={{ color: '#fff', fontSize: '9.5px', fontWeight: 700, lineHeight: 1 }}>{avgR.toFixed(1)}</span>
                    </span>
                    <button key={favorites.includes(item.id) ? 'fav' : 'unfav'} className={favorites.includes(item.id) ? 'heart-pop' : ''} aria-label={favorites.includes(item.id) ? 'Убрать из избранного' : 'В избранное'}
                      onClick={e => { e.stopPropagation(); setFavorites(prev => prev.includes(item.id) ? prev.filter(id => id !== item.id) : [...prev, item.id]) }}
                      style={{ display: 'flex', alignItems: 'center', gap: '3px', height: '21px', padding: '0 7px', borderRadius: 'var(--ss-r-pill, 999px)', cursor: 'pointer', background: favorites.includes(item.id) ? 'rgba(239,68,68,0.18)' : 'rgba(6,6,12,0.62)', border: `1px solid ${favorites.includes(item.id) ? 'rgba(239,68,68,0.45)' : 'var(--ss-hairline-lo)'}`, backdropFilter: 'blur(6px)' }}>
                      <Icon name="heart" size={10} color={favorites.includes(item.id) ? '#ef4444' : '#fff'} fill={favorites.includes(item.id)} strokeWidth={favorites.includes(item.id) ? 0 : 1.75} />
                      <span style={{ color: '#fff', fontSize: '9.5px', fontWeight: 700, lineHeight: 1 }}>{getFavCount(item.id)}</span>
                    </button>
                    {win.hasDeadline && <OrderWindowPill expiresAt={item.orderDeadline as number} />}
                    {ed.limited && (
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', padding: '3px 8px', borderRadius: 'var(--ss-r-pill, 999px)', background: ed.soldOut ? 'rgba(6,6,12,0.72)' : 'color-mix(in srgb, #b79bff 16%, rgba(6,6,12,0.6))', border: `1px solid color-mix(in srgb, ${ed.soldOut ? '#9aa3b2' : '#b79bff'} 55%, transparent)`, color: ed.soldOut ? '#9aa3b2' : '#c9b6ff', fontSize: '8.5px', fontWeight: 800, letterSpacing: '0.06em', backdropFilter: 'blur(6px)', whiteSpace: 'nowrap' }}>
                        <span aria-hidden style={{ fontSize: '9px', lineHeight: 1 }}>💠</span>
                        {ed.soldOut ? 'ТИРАЖ ЗАКРЫТ' : `ОСТАЛОСЬ ${ed.left}/${ed.total}`}
                      </span>
                    )}
                    {smartBadges(item, { favCount: getFavCount(item.id), avgRating: avgR }).map(b => <SmartBadgePill key={b.key} b={b} />)}
                  </div>
                  {unavailable && (
                    <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', zIndex: 3, background: 'rgba(4,4,9,0.55)' }}>
                      <span style={{ color: 'rgba(255,255,255,0.82)', fontSize: '9.5px', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', padding: '4px 10px', borderRadius: 'var(--ss-r-pill, 999px)', background: 'rgba(6,6,12,0.7)', border: '1px solid rgba(255,255,255,0.14)' }}>{overlayLabel}</span>
                    </div>
                  )}
                </div>

                <div style={{ position: 'relative', padding: '2px 10px 11px' }}>
                  <p style={{ color: 'var(--ss-brand-ink, var(--text-muted))', fontSize: '8.5px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.14em', margin: '0 0 3px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.series}</p>
                  <p style={{ color: '#fff', fontSize: '12.5px', fontWeight: 620, margin: '0 0 8px', lineHeight: 1.25, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.name}</p>
                  {(() => {
                    const { min, max } = priceRange(item)
                    const d = (n: number) => activeDiscount > 0 ? Math.round(n * (1 - activeDiscount / 100)) : n
                    const vars = getVariants(item).length
                    const multi = vars > 1 && max > min
                    return (
                      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: '6px' }}>
                        <div style={{ minWidth: 0 }}>
                          {activeDiscount > 0 && <span style={{ display: 'block', fontSize: '9px', color: 'rgba(255,255,255,0.42)', textDecoration: 'line-through', lineHeight: 1.2 }}>{min.toLocaleString()} ₽</span>}
                          <div style={{ display: 'flex', gap: '4px', alignItems: 'baseline' }}>
                            {multi && <span style={{ fontSize: '9.5px', color: 'rgba(255,255,255,0.55)' }}>от</span>}
                            <span style={{ fontSize: '13.5px', fontWeight: 700, color: 'var(--ss-brand-hi, var(--accent))', textShadow: '0 0 14px var(--ss-brand-glow)' }}>{d(min).toLocaleString()} ₽</span>
                          </div>
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '5px', flexShrink: 0 }}>
                          {vars > 1 && (
                            <span style={{ padding: '2px 7px', borderRadius: 'var(--ss-r-pill, 999px)', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', color: 'rgba(255,255,255,0.6)', fontSize: '9px', fontWeight: 600, lineHeight: 1.5 }}>{vars} вар.</span>
                          )}
                          {!unavailable && (
                            <button onClick={e => { e.stopPropagation(); setOpenProduct(item) }} aria-label={`Заказать ${item.name}`} className="ss-press"
                              style={{ width: '30px', height: '30px', display: 'grid', placeItems: 'center', borderRadius: '9px', cursor: 'pointer', background: 'var(--ss-brand-wash)', border: '1px solid var(--ss-brand-edge)', boxShadow: '0 0 18px -8px var(--ss-brand-glow)' }}>
                              <Icon name="cart" size={14} color="var(--ss-brand-hi, var(--accent))" />
                            </button>
                          )}
                        </div>
                      </div>
                    )
                  })()}
                </div>
              </div>
            )
          })}
        </div>

        {/* Пустое состояние — когда под фильтры ничего не подошло */}
        {filtered.length === 0 && (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', padding: '46px 20px 40px' }}>
            <div style={{ position: 'relative', width: '70px', height: '70px', marginBottom: '16px', display: 'grid', placeItems: 'center' }}>
              <div aria-hidden style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: 'radial-gradient(circle, var(--ss-brand-glow) 0%, transparent 68%)', filter: 'blur(8px)' }} />
              <div style={{ position: 'relative', width: '58px', height: '58px', borderRadius: '50%', display: 'grid', placeItems: 'center', background: 'rgba(6,6,12,0.6)', border: '1px solid var(--ss-brand-edge)' }}>
                <Icon name={filterMode === 'favorites' ? 'heart' : 'search'} size={24} color="var(--ss-brand-hi, var(--accent))" />
              </div>
            </div>
            <p style={{ color: 'var(--text-primary)', fontSize: '15px', fontWeight: 700, margin: '0 0 5px' }}>
              {filterMode === 'favorites' ? 'В избранном пусто' : 'Ничего не найдено'}
            </p>
            <p style={{ color: 'var(--text-muted)', fontSize: '12.5px', margin: '0 0 18px', maxWidth: '260px', lineHeight: 1.5 }}>
              {filterMode === 'favorites'
                ? 'Отмечайте фигурки сердечком — они появятся здесь.'
                : 'Попробуйте изменить запрос, раздел или сбросить фильтры.'}
            </p>
            {(search || activeSec !== 'Все' || advActive || filterMode !== 'all') && (
              <button className="btn-secondary" onClick={() => { setSearch(''); setActiveSec('Все'); setFilterMode('all'); resetAdv() }}
                style={{ padding: '10px 20px' }}>Сбросить всё</button>
            )}
          </div>
        )}
      </div>

      {showFilters && (
        <CatalogFilters
          adv={{ maxPrice: adv.maxPrice, active: activeIds, tags: activeTags }} setAdv={setAdv} floor={priceFloor} ceil={priceCeil}
          buttons={activeFilterBtns} allTags={allTags} resultCount={filtered.length} onReset={resetAdv} onClose={() => setShowFilters(false)}
        />
      )}
      {openProduct && <ProductModal product={openProduct} orders={orders} reviews={reviews} setReviews={setReviews} authUser={authUser} onOrder={(variant, provider) => { onOrder(openProduct!, variant, provider); setOpenProduct(null) }} onClose={() => setOpenProduct(null)} discount={activeDiscount} promoCode={activePromoCode} payEnabled={payEnabled} waitlist={waitlist} onToggleWaitlist={onToggleWaitlist} allProducts={products} onOpenProduct={setOpenProduct} />}
    </>
  )
}

// Шторка фильтров каталога — цена/наличие/новинки.
function CatalogFilters({ adv, setAdv, floor, ceil, buttons, allTags, resultCount, onReset, onClose }: {
  adv: { maxPrice: number; active: string[]; tags: string[] }
  setAdv: React.Dispatch<React.SetStateAction<{ maxPrice: number; active: string[]; tags: string[] }>>
  floor: number; ceil: number; buttons: CatalogFilterButton[]; allTags: string[]; resultCount: number; onReset: () => void; onClose: () => void
}) {
  const cap = adv.maxPrice > 0 ? adv.maxPrice : ceil
  const toggleBtn = (id: string) => setAdv(a => ({ ...a, active: a.active.includes(id) ? a.active.filter(x => x !== id) : [...a.active, id] }))
  const toggleTag = (t: string) => setAdv(a => ({ ...a, tags: a.tags.includes(t) ? a.tags.filter(x => x !== t) : [...a.tags, t] }))
  const Toggle = ({ on, label, hint, onToggle }: { on: boolean; label: string; hint: string; onToggle: () => void }) => (
    <button onClick={onToggle} className="ss-press"
      style={{ display: 'flex', alignItems: 'center', gap: '12px', width: '100%', textAlign: 'left', padding: '14px', borderRadius: '14px', cursor: 'pointer',
        background: on ? 'var(--ss-brand-wash)' : 'rgba(255,255,255,0.03)', border: `1px solid ${on ? 'var(--ss-brand-edge)' : 'var(--ss-hairline-lo, var(--border))'}` }}>
      <div style={{ flex: 1 }}>
        <div style={{ color: 'var(--text-primary)', fontSize: '13.5px', fontWeight: 700 }}>{label}</div>
        <div style={{ color: 'var(--text-muted)', fontSize: '11px', marginTop: '2px' }}>{hint}</div>
      </div>
      <div style={{ flexShrink: 0, width: '42px', height: '25px', borderRadius: '999px', padding: '2px', transition: 'background 0.18s',
        background: on ? 'var(--ss-brand-hi, var(--accent))' : 'rgba(255,255,255,0.12)', display: 'flex', justifyContent: on ? 'flex-end' : 'flex-start' }}>
        <div style={{ width: '21px', height: '21px', borderRadius: '50%', background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,0.35)' }} />
      </div>
    </button>
  )
  return (
    <Sheet onClose={onClose}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 20px 10px', flexShrink: 0 }}>
        <h2 style={{ color: 'var(--text-primary)', fontSize: '17px', fontWeight: 800, margin: 0 }}>Фильтры</h2>
        <button onClick={onClose} style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid var(--border)', borderRadius: '50%', width: '30px', height: '30px', cursor: 'pointer', display: 'grid', placeItems: 'center' }}><Icon name="close" size={15} color="var(--text-muted)" /></button>
      </div>
      <div style={{ flex: 1, minHeight: 0, overflowY: 'auto', WebkitOverflowScrolling: 'touch', padding: '6px 20px 18px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
        {/* Максимальная цена */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: '10px' }}>
            <span style={{ color: 'var(--text-secondary)', fontSize: '11px', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase' }}>Цена до</span>
            <span style={{ color: 'var(--ss-brand-hi, var(--accent))', fontSize: '15px', fontWeight: 800 }}>{cap.toLocaleString('ru-RU')} ₽</span>
          </div>
          <input type="range" min={floor} max={ceil} step={Math.max(1, Math.round((ceil - floor) / 100))} value={cap}
            onChange={e => { const v = Number(e.target.value); setAdv(a => ({ ...a, maxPrice: v >= ceil ? 0 : v })) }}
            style={{ width: '100%', accentColor: 'var(--ss-brand-hi, var(--accent))' }} />
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: '4px' }}>
            <span style={{ color: 'var(--text-muted)', fontSize: '10.5px' }}>{floor.toLocaleString('ru-RU')} ₽</span>
            <span style={{ color: 'var(--text-muted)', fontSize: '10.5px' }}>{ceil.toLocaleString('ru-RU')} ₽</span>
          </div>
        </div>
        {buttons.map(b => (
          <Toggle key={b.id} on={adv.active.includes(b.id)} label={b.label} hint={b.hint} onToggle={() => toggleBtn(b.id)} />
        ))}
        {allTags.length > 0 && (
          <div>
            <span style={{ display: 'block', marginBottom: '10px', color: 'var(--text-secondary)', fontSize: '11px', fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase' }}>Хештеги</span>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '7px' }}>
              {allTags.map(t => {
                const on = adv.tags.includes(t)
                return (
                  <button key={t} onClick={() => toggleTag(t)} className="ss-press"
                    style={{ padding: '7px 12px', borderRadius: '999px', cursor: 'pointer', fontSize: '12.5px', fontWeight: 600, transition: 'background 0.15s, border-color 0.15s',
                      color: on ? '#fff' : 'var(--text-secondary)',
                      background: on ? 'var(--ss-brand-hi, var(--accent))' : 'rgba(255,255,255,0.04)',
                      border: `1px solid ${on ? 'var(--ss-brand-edge, var(--accent))' : 'var(--ss-hairline-lo, var(--border))'}` }}>
                    #{t}
                  </button>
                )
              })}
            </div>
          </div>
        )}
      </div>
      <div style={{ flexShrink: 0, display: 'flex', gap: '10px', padding: '12px 20px calc(14px + env(safe-area-inset-bottom))', borderTop: '1px solid var(--border)' }}>
        <button className="btn-secondary" onClick={onReset} style={{ flex: 1, padding: '14px' }}>Сбросить</button>
        <button className="spin-border" onClick={onClose} style={{ flex: 2, padding: '14px', borderRadius: '14px', background: 'var(--accent-grad)', color: '#fff', fontSize: '14px', fontWeight: 700, cursor: 'pointer', border: 'none' }}>
          Показать {resultCount}
        </button>
      </div>
    </Sheet>
  )
}

// Шторка «Заказ индивидуальной фигурки» — открывается с главной.
// Приводит контакт мастера к рабочей ссылке t.me. Принимает любой формат:
// @username, username, t.me/username, полный https-URL. Если поле пустое или в нём
// остался старый плейсхолдер (несуществующий sigmaspace_master) — подставляем
// контакт владельца, чтобы кнопка вела на реальный аккаунт, а не «в никуда».
function masterLink(raw?: string): string {
  const v = (raw || '').trim()
  if (!v || /sigmaspace_master/i.test(v)) return `https://t.me/${OWNER_TG.replace(/^@/, '')}`
  if (/^https?:\/\//i.test(v)) return v
  const handle = v.replace(/^https?:\/\//i, '').replace(/^t\.me\//i, '').replace(/^@/, '')
  return `https://t.me/${handle}`
}

// Открывает внешнюю ссылку корректно. Внутри Telegram WebApp обычный
// <a target="_blank"> на t.me не срабатывает (Telegram отвечает «нет») —
// такие ссылки надо открывать через openTelegramLink. Вне Telegram (веб-превью,
// телефон в браузере) — обычный window.open.
function openExternal(url: string) {
  const tg = (window as unknown as { Telegram?: { WebApp?: { openTelegramLink?: (u: string) => void; openLink?: (u: string) => void } } })?.Telegram?.WebApp
  try {
    if (tg && /^https?:\/\/t\.me\//i.test(url) && typeof tg.openTelegramLink === 'function') { tg.openTelegramLink(url); return }
    if (tg && typeof tg.openLink === 'function') { tg.openLink(url); return }
  } catch { /* падаем в обычное открытие ниже */ }
  window.open(url, '_blank', 'noopener,noreferrer')
}

function CustomOrderSheet({ custom, onClose }: { custom: CustomOrderConfig; onClose: () => void }) {
  const customSteps = custom.text.split('\n').map(t => t.trim()).filter(Boolean)
  const ctaLink = masterLink(custom.link)
  return createPortal((
      <div className="overlay-fade" onClick={e => { if (e.target === e.currentTarget) onClose() }}
        style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.72)', backdropFilter: 'blur(6px)', zIndex: 300, display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
        <div className="sheet-enter" style={{ width: '100%', maxWidth: '430px', background: 'var(--bg-base)', borderRadius: '22px 22px 0 0', maxHeight: '72vh', display: 'flex', flexDirection: 'column', overflow: 'hidden', padding: '6px 0 0' }}>
          <div style={{ width: '36px', height: '4px', borderRadius: '2px', background: 'var(--border)', margin: '0 auto', position: 'relative', zIndex: 2, flexShrink: 0 }} />
          {/* Прокручивается только внутренняя часть, CTA закреплён снизу */}
          <div style={{ flex: 1, overflowY: 'auto', minHeight: 0 }}>
          {/* Портальная шапка — «студийная консультация» */}
          <div style={{ position: 'relative', overflow: 'hidden', padding: '26px 18px 20px', textAlign: 'center' }}>
            <div aria-hidden style={{ position: 'absolute', inset: 0, background: 'radial-gradient(90% 120% at 50% -10%, rgba(79,141,255,0.30) 0%, rgba(124,58,237,0.10) 42%, transparent 72%)', pointerEvents: 'none' }} />
            <button onClick={() => onClose()} style={{ position: 'absolute', top: '10px', right: '12px', background: 'rgba(255,255,255,0.06)', border: '1px solid var(--border)', borderRadius: '50%', width: '30px', height: '30px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 2 }}><Icon name="close" size={15} color="var(--text-muted)" /></button>
            <div style={{ position: 'relative', width: '62px', height: '62px', margin: '0 auto 14px', display: 'grid', placeItems: 'center' }}>
              <svg viewBox="0 0 62 62" width="62" height="62" aria-hidden style={{ position: 'absolute', inset: 0, animation: 'ss-ring-spin 12s linear infinite', transformOrigin: '50% 50%' }}>
                <circle cx="31" cy="31" r="29" fill="none" stroke="var(--ss-blue, #3b6fe0)" strokeWidth="1.3" strokeDasharray="22 12" strokeLinecap="round" opacity="0.8" />
              </svg>
              <div style={{ width: '46px', height: '46px', borderRadius: '50%', background: 'radial-gradient(circle at 50% 34%, var(--ss-blue-hi, #4f8dff), var(--ss-blue, #3b6fe0))', display: 'grid', placeItems: 'center', boxShadow: '0 0 26px -4px var(--ss-blue-glow, rgba(79,141,255,0.6))' }}>
                <Icon name="star" size={20} color="#fff" />
              </div>
            </div>
            <p style={{ position: 'relative', color: 'var(--ss-blue-ink, #a8c6ff)', fontSize: '10px', fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', margin: '0 0 5px' }}>Студийная консультация</p>
            <h2 style={{ position: 'relative', color: 'var(--text-primary)', fontSize: '20px', fontWeight: 700, margin: '0 0 6px' }}>{custom.title || INIT_CUSTOM_ORDER.title}</h2>
            <p style={{ position: 'relative', color: 'var(--text-secondary)', fontSize: '12.5px', lineHeight: 1.5, margin: '0 auto', maxWidth: '300px' }}>{custom.subtitle || INIT_CUSTOM_ORDER.subtitle}</p>
          </div>
          <div style={{ padding: '0 18px 26px' }}>
            {/* Что можно напечатать — чипы */}
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', justifyContent: 'center', marginBottom: '20px' }}>
              {(custom.chips?.length ? custom.chips : INIT_CUSTOM_ORDER.chips!).map(t => (
                <span key={t} style={{ fontSize: '10.5px', fontWeight: 600, color: 'var(--ss-blue-ink, #a8c6ff)', background: 'var(--ss-blue-wash, rgba(79,141,255,0.11))', border: '1px solid var(--ss-blue-edge, rgba(79,141,255,0.34))', borderRadius: '20px', padding: '4px 10px' }}>{t}</span>
              ))}
            </div>
            {/* Шаги как связанный таймлайн */}
            <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', gap: '0' }}>
              {customSteps.map((text, i) => {
                const stepIcon: IconName = (['send', 'search', 'pencil', 'check'] as IconName[])[i] ?? 'star'
                const last = i === customSteps.length - 1
                return (
                  <div key={i} style={{ display: 'flex', gap: '13px', alignItems: 'flex-start' }}>
                    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', flexShrink: 0 }}>
                      <div style={{ width: '30px', height: '30px', borderRadius: '50%', background: 'var(--ss-blue-wash, rgba(79,141,255,0.11))', border: '1.5px solid var(--ss-blue-edge, rgba(79,141,255,0.34))', color: 'var(--ss-blue-hi, #4f8dff)', display: 'grid', placeItems: 'center' }}><Icon name={stepIcon} size={13} color="var(--ss-blue-hi, #4f8dff)" /></div>
                      {!last && <div style={{ width: '2px', flex: 1, minHeight: '22px', background: 'linear-gradient(var(--ss-blue-edge, rgba(79,141,255,0.34)), transparent)', margin: '3px 0' }} />}
                    </div>
                    <div style={{ paddingBottom: last ? 0 : '16px', paddingTop: '4px' }}>
                      <p style={{ color: 'var(--text-muted)', fontSize: '9px', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', margin: '0 0 3px' }}>Шаг {i + 1}</p>
                      <p style={{ color: 'var(--text-secondary)', fontSize: '12.5px', lineHeight: 1.5, margin: 0 }}>{text}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
          </div>
          {/* CTA закреплён у нижнего борда */}
          <div style={{ flexShrink: 0, padding: '12px 18px calc(14px + env(safe-area-inset-bottom))', borderTop: '1px solid var(--border)', background: 'var(--bg-base)' }}>
            <a href={ctaLink} target="_blank" rel="noopener noreferrer" onClick={e => { e.preventDefault(); openExternal(ctaLink) }} className="spin-border"
              style={{ width: '100%', boxSizing: 'border-box', padding: '15px', borderRadius: '14px', background: 'var(--accent-grad)', color: '#fff', fontSize: '14px', fontWeight: 700, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', textDecoration: 'none', boxShadow: '0 10px 30px -8px var(--ss-blue-glow, rgba(79,141,255,0.5))' }}>
              <Icon name="send" size={15} color="#fff" /> {custom.buttonText}
            </a>
            <p style={{ color: 'var(--text-muted)', fontSize: '10px', textAlign: 'center', margin: '10px 0 0' }}>Консультация бесплатна · ответим в Telegram</p>
          </div>
        </div>
      </div>
  ), document.body)
}

// ─────────────────────────────────────────────────────────────
// Profile
// ─────────────────────────────────────────────────────────────
// Модальная «шторка». Объявлена на уровне модуля, чтобы её тип был стабильным
// между рендерами — иначе фоновый опрос (каждые 5с) перемонтировал бы её и
// повторно проигрывал анимацию появления (визуальное «дёргание»).
/**
 * Нижний лист. Рендерится порталом в body: у контентного контейнера есть
 * анимация, а она создаёт containing block — из-за этого лист раньше липнул
 * к низу прокручиваемого содержимого, а не к низу экрана. Пока лист открыт,
 * прокрутка страницы под ним заблокирована.
 */
/**
 * Борд «Привилегии Sigma Club скоро» — раздел ещё не собран.
 * Открывается и из профиля, и с карточки Sigma Club на главной.
 */
function ClubSoonSheet({ onClose }: { onClose: () => void }) {
  return (
    <Sheet onClose={onClose}>
          <div style={{ position: 'relative', overflow: 'hidden', padding: '30px 22px 26px', textAlign: 'center' }}>
            <div aria-hidden style={{ position: 'absolute', left: '50%', top: '-46%', width: '150%', height: '96%', marginLeft: '-75%', borderRadius: '50%', background: 'radial-gradient(circle, var(--ss-brand-glow) 0%, transparent 66%)', filter: 'blur(12px)', pointerEvents: 'none' }} />

            <div style={{ position: 'relative', width: '78px', height: '78px', margin: '0 auto 16px' }}>
              <svg viewBox="0 0 78 78" width="78" height="78" aria-hidden style={{ position: 'absolute', inset: 0, animation: 'ss-ring-spin 16s linear infinite', transformOrigin: '50% 50%' }}>
                <circle cx="39" cy="39" r="37" fill="none" stroke="var(--ss-brand, #7c3aed)" strokeWidth="1.3" strokeDasharray="26 13" strokeLinecap="round" opacity="0.8" />
              </svg>
              <div style={{ position: 'absolute', inset: '9px', borderRadius: '50%', display: 'grid', placeItems: 'center', background: 'rgba(6,6,12,0.6)', border: '1px solid var(--ss-brand-edge)', boxShadow: '0 0 30px -8px var(--ss-brand-glow)' }}>
                <Icon name="star-fill" size={28} color="var(--ss-brand-hi, var(--accent))" />
              </div>
            </div>

            <span style={{ position: 'relative', display: 'inline-block', padding: '4px 11px', marginBottom: '12px', borderRadius: 'var(--ss-r-pill, 999px)', background: 'var(--ss-brand-wash)', border: '1px solid var(--ss-brand-edge)', color: 'var(--ss-brand-ink)', fontSize: '9px', fontWeight: 800, letterSpacing: '0.16em', textTransform: 'uppercase' }}>Скоро</span>

            <h2 style={{ position: 'relative', color: 'var(--text-primary)', fontSize: '21px', fontWeight: 700, margin: '0 0 9px', letterSpacing: '-0.01em' }}>Привилегии Sigma Club</h2>
            <p style={{ position: 'relative', color: 'var(--text-secondary)', fontSize: '13px', lineHeight: 1.55, margin: '0 auto 22px', maxWidth: '290px' }}>
              Раздел пока не добавлен — мастер ещё собирает систему привилегий. Ждите добавления: уровни, накопительные скидки и закрытые дропы появятся здесь совсем скоро.
            </p>

            {/* Полоса «в разработке» — те же бегущие штрихи, что и в прогрессе заказа */}
            <div aria-hidden className="ss-order-flow" style={{ position: 'relative', height: '2px', borderRadius: '1px', margin: '0 auto 22px', maxWidth: '210px', backgroundSize: '14px 100%', background: 'repeating-linear-gradient(90deg, var(--ss-brand-hi) 0 3px, transparent 3px 7px)', opacity: 0.75 }} />

            <button className="btn-primary" onClick={onClose} style={{ position: 'relative', width: '100%' }}>Понятно, подожду</button>
          </div>
        </Sheet>
  )
}

/** Сумма доставленных заказов клиента за всё время (для уровня клуба). */
function clubSpent(orders: Order[], login?: string | null): number {
  if (!login) return 0
  const key = normLogin(login)
  return orders
    .filter(o => normLogin(o.userId) === key && o.status === 'delivered')
    .reduce((s, o) => s + ((o.painted ? o.price : o.priceUnpainted) || 0), 0)
}

/**
 * Борд привилегий Sigma Club — уровни, прогресс и льготы.
 * Показывается, когда программа включена в CRM (loyalty.clubEnabled).
 */
function ClubSheet({ onClose, spent, points, loyalty }: { onClose: () => void; spent: number; points: number; loyalty: LoyaltyConfig }) {
  const cashback = loyalty.cashback
  const tiers = clubTiersOf(loyalty)
  const { tier, next, idx } = clubTierFor(spent, tiers)
  const toNext = next ? Math.max(0, next.from - spent) : 0
  const span = next ? next.from - tier.from : 1
  const pct = next ? Math.min(100, Math.round(((spent - tier.from) / span) * 100)) : 100
  const fmt = (n: number) => n.toLocaleString('ru')

  return (
    <Sheet onClose={onClose}>
      <div style={{ position: 'relative', flex: 1, minHeight: 0, overflowY: 'auto', overflowX: 'hidden', WebkitOverflowScrolling: 'touch', padding: '26px 20px 22px' }}>
        <button onClick={onClose} aria-label="Закрыть" className="ss-press" style={{ position: 'absolute', top: '12px', right: '14px', zIndex: 2, width: '32px', height: '32px', borderRadius: '50%', display: 'grid', placeItems: 'center', background: 'var(--bg-elevated)', border: '1px solid var(--border)', cursor: 'pointer' }}>
          <Icon name="close" size={16} color="var(--text-secondary)" />
        </button>
        <div aria-hidden style={{ position: 'absolute', left: '50%', top: '-40%', width: '150%', height: '90%', marginLeft: '-75%', borderRadius: '50%', background: `radial-gradient(circle, ${tier.color}55 0%, transparent 66%)`, filter: 'blur(20px)', pointerEvents: 'none' }} />

        {/* Текущий уровень */}
        <div style={{ position: 'relative', textAlign: 'center', marginBottom: '18px' }}>
          <span style={{ display: 'inline-block', padding: '4px 11px', marginBottom: '12px', borderRadius: '999px', background: 'var(--ss-brand-wash)', border: '1px solid var(--ss-brand-edge)', color: 'var(--ss-brand-ink)', fontSize: '9px', fontWeight: 800, letterSpacing: '0.16em', textTransform: 'uppercase' }}>{loyalty.clubTitle || 'Sigma Club'}</span>
          <div style={{ width: '72px', height: '72px', margin: '0 auto 12px', borderRadius: '50%', display: 'grid', placeItems: 'center', background: `radial-gradient(circle at 50% 35%, ${tier.color}33, rgba(6,6,12,0.7))`, border: `1.5px solid ${tier.color}`, boxShadow: `0 0 34px -8px ${tier.color}` }}>
            <Icon name="star-fill" size={30} color={tier.color} />
          </div>
          <h2 style={{ color: 'var(--text-primary)', fontSize: '22px', fontWeight: 800, margin: '0 0 2px', letterSpacing: '-0.01em' }}>{tier.name}</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '12px', margin: 0 }}>Ваш уровень · потрачено {fmt(spent)} ₽</p>
          {loyalty.clubIntro && <p style={{ color: 'var(--text-secondary)', fontSize: '12px', margin: '9px auto 0', maxWidth: '300px', lineHeight: 1.5 }}>{loyalty.clubIntro}</p>}
        </div>

        {/* Прогресс к следующему уровню */}
        <div style={{ position: 'relative', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '14px', padding: '13px 14px', marginBottom: '16px' }}>
          {next ? (
            <>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '8px' }}>
                <span style={{ color: 'var(--text-secondary)', fontSize: '12px' }}>До уровня <b style={{ color: next.color }}>{next.name}</b></span>
                <span style={{ color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 700 }}>{fmt(toNext)} ₽</span>
              </div>
              <div style={{ height: '7px', borderRadius: '999px', background: 'var(--bg-input)', overflow: 'hidden' }}>
                <div style={{ height: '100%', width: `${pct}%`, borderRadius: '999px', background: `linear-gradient(90deg, ${tier.color}, ${next.color})`, transition: 'width 0.4s' }} />
              </div>
            </>
          ) : (
            <p style={{ color: 'var(--text-secondary)', fontSize: '12px', margin: 0, textAlign: 'center' }}>🏆 Вы достигли максимального уровня клуба. Спасибо, что с нами!</p>
          )}
        </div>

        {/* Бонусы + скидка сейчас */}
        <div style={{ position: 'relative', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginBottom: '16px' }}>
          <div style={{ background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '12px', padding: '12px' }}>
            <p style={{ color: tier.color, fontSize: '18px', fontWeight: 800, margin: 0, lineHeight: 1 }}>{tier.discount || cashback}%</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', margin: '3px 0 0' }}>{tier.discount ? 'скидка на заказы' : 'кешбэк бонусами'}</p>
          </div>
          <div style={{ background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '12px', padding: '12px' }}>
            <p style={{ color: 'var(--accent-2-hi)', fontSize: '18px', fontWeight: 800, margin: 0, lineHeight: 1 }}>{fmt(points)} ₽</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', margin: '3px 0 0' }}>бонусов на счету</p>
          </div>
        </div>

        {/* Все уровни */}
        <p style={{ position: 'relative', color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, margin: '0 0 10px' }}>Уровни и привилегии</p>
        <div style={{ position: 'relative', display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '18px' }}>
          {tiers.map((t, i) => {
            const reached = spent >= t.from
            const current = i === idx
            return (
              <div key={t.key} style={{ borderRadius: '13px', padding: '12px 13px', background: current ? `${t.color}18` : 'var(--bg-elevated)', border: `1px solid ${current ? t.color : 'var(--border)'}`, opacity: reached || current ? 1 : 0.72 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '9px', marginBottom: '8px' }}>
                  <span style={{ width: '26px', height: '26px', borderRadius: '8px', display: 'grid', placeItems: 'center', flexShrink: 0, background: `${t.color}22`, border: `1px solid ${t.color}` }}>
                    <Icon name={reached ? 'check' : 'star'} size={13} color={t.color} />
                  </span>
                  <span style={{ flex: 1, minWidth: 0, color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700 }}>{t.name}</span>
                  <span style={{ flexShrink: 0, color: 'var(--text-muted)', fontSize: '11px', fontWeight: 600 }}>{t.from === 0 ? 'старт' : `от ${fmt(t.from)} ₽`}</span>
                </div>
                <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: '4px' }}>
                  {t.perks.map((p, pi) => (
                    <li key={pi} style={{ display: 'flex', gap: '7px', alignItems: 'flex-start', color: 'var(--text-secondary)', fontSize: '11.5px', lineHeight: 1.35 }}>
                      <span style={{ color: t.color, flexShrink: 0, marginTop: '1px' }}>›</span>{p}
                    </li>
                  ))}
                </ul>
              </div>
            )
          })}
        </div>

        <button className="btn-primary" onClick={onClose} style={{ position: 'relative', width: '100%' }}>Отлично</button>
      </div>
    </Sheet>
  )
}

type NotifItem = { key: string; icon: IconName; color: string; title: string; text: string; date: string; unread: boolean }
function NotifRow({ n, last, onOpen, onDismiss }: { n: NotifItem; last: boolean; onOpen: () => void; onDismiss: () => void }) {
  const [dx, setDx] = useState(0)
  const [leaving, setLeaving] = useState(false)
  const start = useRef<number | null>(null)
  const moved = useRef(false)
  const finish = () => {
    setLeaving(true)
    setDx(dx < 0 ? -400 : 400)
    setTimeout(onDismiss, 180)
  }
  return (
    <div style={{ position: 'relative', borderBottom: last ? 'none' : '1px solid var(--border)', overflow: 'hidden' }}>
      <div aria-hidden style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: dx < 0 ? 'flex-end' : 'flex-start', padding: '0 18px', background: 'color-mix(in srgb, var(--danger) 14%, transparent)' }}>
        <Icon name="trash" size={15} color="var(--danger)" />
      </div>
      <button
        onClick={() => { if (!moved.current) onOpen() }}
        onTouchStart={e => { start.current = e.touches[0].clientX; moved.current = false }}
        onTouchMove={e => { if (start.current == null) return; const d = e.touches[0].clientX - start.current; if (Math.abs(d) > 6) moved.current = true; setDx(d) }}
        onTouchEnd={() => { if (Math.abs(dx) > 90) finish(); else setDx(0); start.current = null }}
        style={{ position: 'relative', width: '100%', boxSizing: 'border-box', display: 'flex', alignItems: 'flex-start', gap: '11px', padding: '12px 14px', background: n.unread ? 'var(--ss-brand-wash, rgba(124,58,237,0.08))' : 'var(--bg-card)', border: 'none', cursor: 'pointer', textAlign: 'left', transform: `translateX(${dx}px)`, transition: leaving || start.current == null ? 'transform 0.18s ease' : 'none', opacity: leaving ? 0 : 1 }}>
        <div style={{ width: '30px', height: '30px', borderRadius: '9px', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: `color-mix(in srgb, ${n.color} 14%, transparent)`, border: `1px solid color-mix(in srgb, ${n.color} 38%, transparent)` }}>
          <Icon name={n.icon} size={14} color={n.color} />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 600, margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{n.title}</p>
          <p style={{ color: 'var(--text-secondary)', fontSize: '11px', margin: '2px 0 0', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{n.text}</p>
          <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '3px 0 0' }}>{n.date}</p>
        </div>
        {n.unread && <span aria-label="Новое" style={{ width: '7px', height: '7px', borderRadius: '50%', background: 'var(--ss-brand-hi, var(--accent))', marginTop: '5px', flexShrink: 0, boxShadow: '0 0 8px var(--ss-brand-glow, rgba(168,85,247,0.8))' }} />}
      </button>
    </div>
  )
}

function Sheet({ onClose, children }: { onClose: () => void; children: React.ReactNode }) {
  useEffect(() => {
    const host = document.querySelector('[data-app-scroll]') as HTMLElement | null
    if (host) host.style.overflowY = 'hidden'
    return () => { if (host) host.style.overflowY = 'auto' }
  }, [])
  return createPortal(
    <div className="overlay-fade" onClick={e => { if (e.target === e.currentTarget) onClose() }}
      style={{ position: 'fixed', left: 0, right: 0, top: 0, bottom: 0, height: '100dvh', background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(5px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center', zIndex: 400 }}>
      <div className="sheet-enter" style={{ width: '100%', maxWidth: '430px', background: 'var(--bg-card)', borderRadius: '22px 22px 0 0', maxHeight: 'calc(100dvh - max(24px, env(safe-area-inset-top)))', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <div style={{ width: '36px', height: '4px', borderRadius: '2px', background: 'var(--border)', margin: '10px auto 0', flexShrink: 0 }} />
        {children}
      </div>
    </div>,
    document.body,
  )
}

function ProfileView({ orders, profile, onProfileChange, onGoOrders, onGoSettings, onGoFaq, onGoCrm, onGoCatalog, products, favorites, setFavorites, reviews, setReviews, onOrder, promocodes, authLogin, activeDiscount = 0, activePromoCode, payEnabled, canEditCover = false, coverUrl = null, loyalty, appVersion = APP_VERSION, onVersionChange, waitlist, onToggleWaitlist }: {
  orders: Order[]; profile: UserProfile; onProfileChange: (p: UserProfile) => void
  onGoOrders: () => void; onGoSettings: () => void; onGoFaq: () => void; onGoCrm?: () => void; onGoCatalog?: () => void
  products: Product[]; favorites: number[]; setFavorites: React.Dispatch<React.SetStateAction<number[]>>
  reviews: Review[]; setReviews: React.Dispatch<React.SetStateAction<Review[]>>; onOrder: (product: Product, variant: ProductVariant, provider: PayProvider) => void
  promocodes: PromoCode[]; authLogin: string; activeDiscount?: number; activePromoCode?: string; payEnabled: Record<string, boolean>
  /** Настройки программы лояльности — для карточки бонусов. */
  loyalty: LoyaltyConfig
  /** Разрешено ли этому пользователю ставить свою обложку профиля (настраивается в CRM «Роли»). */
  canEditCover?: boolean
  /** Какая обложка показывается: своя или общая от владельца — зависит от режима в CRM. */
  coverUrl?: string | null
  /** Текущая версия приложения (синхронизируется из облака). */
  appVersion?: string
  /** Изменение версии — передаётся только админу; у остальных undefined (редактор скрыт). */
  onVersionChange?: (v: string) => void
  waitlist?: Record<string, string[]>; onToggleWaitlist?: (productId: number) => void
}) {
  const { user, logout } = useAuth()
  const fileRef = useRef<HTMLInputElement>(null)
  const [showTray, setShowTray] = useState(false)
  const [showAddress, setShowAddress] = useState(false)
  const [showFavorites, setShowFavorites] = useState(false)
  const [showPromoBag, setShowPromoBag] = useState(false)
  // Sigma Club: настоящий борд, если включён в CRM, иначе «скоро».
  const [showClubSoon, setShowClubSoon] = useState(false)
  // Бонусный баланс: узкая карточка-строка, детали открываются в шторке.
  const [showBonus, setShowBonus] = useState(false)
  // Программа лояльности: ввод кода друга (реферал) и подсказки.
  const [refInput, setRefInput] = useState('')
  const [refMsg, setRefMsg] = useState('')
  const points = profile.points ?? 0
  const applyRefCode = () => {
    const code = normLogin(refInput)
    if (!code) { setRefMsg('Введите @username друга'); return }
    if (code === normLogin(authLogin)) { setRefMsg('Нельзя пригласить самого себя'); return }
    onProfileChange({ ...profile, refBy: code })
    setRefInput(''); setRefMsg('Код принят! Бонус придёт после первого доставленного заказа.')
  }
  const [showPayment, setShowPayment] = useState(false)
  const [openProduct, setOpenProduct] = useState<Product | null>(null)
  const [addrDraft, setAddrDraft] = useState(profile)
  // Редактор версии приложения — только для админа (см. onVersionChange).
  const [editingVer, setEditingVer] = useState(false)
  const [verDraft, setVerDraft] = useState(appVersion)
  const isAdmin = user?.role === 'admin'
  const totalSpent = orders.reduce((s, o) => s + (o.painted ? o.price : o.priceUnpainted), 0)
  const displayName = profile.nickname || user?.name || '—'
  const favProducts = products.filter(p => favorites.includes(p.id))
  // Промики, доступные пользователю: адресные (его логин) или общие, не истёкшие и с остатком использований.
  const myPromos = promocodes.filter(p =>
    !p.deleted &&
    (!p.targetUser || p.targetUser.toLowerCase() === authLogin.toLowerCase()) &&
    (!p.expiresAt || Date.now() <= p.expiresAt) &&
    p.uses < p.maxUses)

  const [avatarUploading, setAvatarUploading] = useState(false)
  // Кадрирование аватара: как в редакторе товара — выбираем квадрат перед загрузкой.
  const [avatarCropSrc, setAvatarCropSrc] = useState<string | null>(null)
  const [avatarCrop, setAvatarCrop] = useState({ x: 0, y: 0 })
  const [avatarZoom, setAvatarZoom] = useState(1)
  const avatarPixelsRef = useRef<PixelCrop | null>(null)
  const handleAvatarFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file || !file.type.startsWith('image/')) return
    const r = new FileReader()
    r.onload = () => { setAvatarCrop({ x: 0, y: 0 }); setAvatarZoom(1); avatarPixelsRef.current = null; setAvatarCropSrc(String(r.result)) }
    r.readAsDataURL(file)
  }
  const applyAvatarCrop = async () => {
    if (!avatarCropSrc || !avatarPixelsRef.current) return
    setAvatarUploading(true)
    try {
      const cropped = await getCroppedFile(avatarCropSrc, avatarPixelsRef.current)
      const compressed = await compressImage(cropped, 512, 0.85)
      const url = await storage.upload(compressed)
      onProfileChange({ ...profile, avatarUrl: url })
      setAvatarCropSrc(null)
    } catch (err) {
      alert(`Не удалось загрузить аватар: ${(err as Error)?.message ?? 'ошибка'}`)
    } finally {
      setAvatarUploading(false)
    }
  }

  // Обложка профиля за аватаркой: широкий кадр, тот же принцип, что и у аватара.
  const bgFileRef = useRef<HTMLInputElement>(null)
  const [bgUploading, setBgUploading] = useState(false)
  const [bgCropSrc, setBgCropSrc] = useState<string | null>(null)
  const [bgCrop, setBgCrop] = useState({ x: 0, y: 0 })
  const [bgZoom, setBgZoom] = useState(1)
  const bgPixelsRef = useRef<PixelCrop | null>(null)
  const handleBgFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file || !file.type.startsWith('image/')) return
    const r = new FileReader()
    r.onload = () => { setBgCrop({ x: 0, y: 0 }); setBgZoom(1); bgPixelsRef.current = null; setBgCropSrc(String(r.result)) }
    r.readAsDataURL(file)
  }
  const applyBgCrop = async () => {
    if (!bgCropSrc || !bgPixelsRef.current) return
    setBgUploading(true)
    try {
      const cropped = await getCroppedRectFile(bgCropSrc, bgPixelsRef.current, 1000)
      const url = await storage.upload(cropped)
      onProfileChange({ ...profile, bgUrl: url })
      setBgCropSrc(null)
    } catch (err) {
      alert(`Не удалось загрузить обложку: ${(err as Error)?.message ?? 'ошибка'}`)
    } finally {
      setBgUploading(false)
    }
  }

  // Каждой строке профиля — свой приглушённый цвет иконки, чтобы список
  // «дышал» и не сливался в один фиолетовый.
  const menuItems = [
    { icon: 'pin'     as IconName, color: '#cf9f57', label: 'Адрес доставки', sub: profile.city ? `${profile.city}${profile.address ? ', ' + profile.address : ''}` : 'Не указан', action: () => { setAddrDraft(profile); setShowAddress(true) } },
    { icon: 'card'    as IconName, color: '#5ba172', label: 'Способы оплаты', sub: (() => { const on = PAY_METHOD_DEFS.filter(m => !m.comingSoon && payEnabled[m.key]); return on.length ? on.map(m => m.short).join(', ') : 'Временно недоступно' })(), action: () => setShowPayment(true) },
    { icon: 'heart'   as IconName, color: '#c76b6b', label: 'Избранное',      sub: favProducts.length > 0 ? `${favProducts.length} фигурок` : 'Пусто', action: () => setShowFavorites(true) },
    { icon: 'gift'    as IconName, color: '#cbb149', label: 'Сумка для промиков', sub: myPromos.length > 0 ? `${myPromos.length} доступно` : 'Пусто', action: () => setShowPromoBag(true) },
    { icon: 'gear'    as IconName, color: '#8b90a0', label: 'Настройки профиля', sub: 'Имя, email, тема оформления', action: () => setShowTray(true) },
  ]
  // Сводка по заказам — плитки со счётчиками по стадиям производства.
  const orderStages: Array<{ label: string; statuses: OrderStatus[]; color: string }> = [
    { label: 'В работе',      statuses: ['new'],                   color: 'var(--status-new-color)' },
    { label: 'Печать',        statuses: ['printing', 'painting'],  color: 'var(--status-printing-color)' },
    { label: 'Готово',        statuses: ['ready'],                 color: 'var(--status-ready-color)' },
    { label: 'Доставлено',    statuses: ['delivered'],             color: 'var(--status-delivered-color)' },
  ]

  return (
    <>
      {avatarCropSrc && (
        <div className="overlay-fade" style={{ position: 'absolute', inset: 0, zIndex: 300, background: 'rgba(0,0,0,0.72)', backdropFilter: 'blur(5px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
          <div className="sheet-enter" style={{ width: '100%', maxWidth: '430px', background: 'var(--bg-card)', borderRadius: '22px 22px 0 0', padding: '14px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: 0 }}>Кадрирование аватара</p>
              <button onClick={() => setAvatarCropSrc(null)} disabled={avatarUploading} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px' }}><Icon name="close" size={18} color="var(--text-secondary)" /></button>
            </div>
            <div style={{ position: 'relative', width: '100%', height: '260px', background: '#000', borderRadius: '12px', overflow: 'hidden' }}>
              <Cropper image={avatarCropSrc} crop={avatarCrop} zoom={avatarZoom} aspect={1} cropShape="round" showGrid={false} onCropChange={setAvatarCrop} onZoomChange={setAvatarZoom} onCropComplete={(_, px) => { avatarPixelsRef.current = px }} />
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Icon name="search" size={15} color="var(--text-muted)" />
              <input type="range" min={1} max={4} step={0.01} value={avatarZoom} onChange={e => setAvatarZoom(Number(e.target.value))} style={{ flex: 1, accentColor: 'var(--accent)' }} />
            </div>
            <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0, textAlign: 'center' }}>Двигайте фото пальцем и приближайте ползунком — в аватар попадёт выбранный круг.</p>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button className="btn-secondary" onClick={() => setAvatarCropSrc(null)} disabled={avatarUploading} style={{ flex: 1 }}>Отмена</button>
              <button className="btn-primary" onClick={applyAvatarCrop} disabled={avatarUploading} style={{ flex: 2 }}>{avatarUploading ? 'Загрузка…' : 'Готово'}</button>
            </div>
          </div>
        </div>
      )}

      {/* Кадрирование обложки профиля — широкий кадр за аватаркой */}
      {bgCropSrc && (
        <div className="overlay-fade" style={{ position: 'absolute', inset: 0, zIndex: 200, background: 'rgba(0,0,0,0.72)', backdropFilter: 'blur(5px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
          <div className="sheet-enter" style={{ width: '100%', maxWidth: '430px', background: 'var(--bg-card)', borderRadius: '22px 22px 0 0', padding: '14px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: 0 }}>Обложка профиля</p>
              <button onClick={() => setBgCropSrc(null)} disabled={bgUploading} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px' }}><Icon name="close" size={18} color="var(--text-secondary)" /></button>
            </div>
            <div style={{ position: 'relative', width: '100%', height: '220px', background: '#000', borderRadius: '12px', overflow: 'hidden' }}>
              <Cropper image={bgCropSrc} crop={bgCrop} zoom={bgZoom} aspect={16 / 9} showGrid onCropChange={setBgCrop} onZoomChange={setBgZoom} onCropComplete={(_, px) => { bgPixelsRef.current = px }} />
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <Icon name="search" size={15} color="var(--text-muted)" />
              <input type="range" min={1} max={4} step={0.01} value={bgZoom} onChange={e => setBgZoom(Number(e.target.value))} style={{ flex: 1, accentColor: 'var(--accent)' }} />
            </div>
            <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0, textAlign: 'center' }}>Выбранный кадр встанет фоном за аватаркой. Слева он мягко растворяется, чтобы имя оставалось читаемым.</p>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button className="btn-secondary" onClick={() => setBgCropSrc(null)} disabled={bgUploading} style={{ flex: 1 }}>Отмена</button>
              <button className="btn-primary" onClick={applyBgCrop} disabled={bgUploading} style={{ flex: 2 }}>{bgUploading ? 'Загрузка…' : 'Готово'}</button>
            </div>
          </div>
        </div>
      )}
      <div style={{ padding: '14px', paddingBottom: '20px' }}>
        <h1 style={{ color: 'var(--text-primary)', fontSize: '27px', fontWeight: 700, letterSpacing: '-0.01em', margin: '2px 0 14px' }}>Профиль</h1>

        {/* Портальная карточка профиля: аватар слева, за ним — приглушённый арт */}
        <div style={{ position: 'relative', overflow: 'hidden', borderRadius: '20px', border: '1px solid var(--ss-hairline-lo, var(--border))', background: 'linear-gradient(180deg, var(--bg-card), var(--bg-base))', marginBottom: '12px' }}>
          {/* Обложка за аватаркой: своя, если пользователь загрузил, иначе стандартный арт.
              Своя обложка тянется на всю карточку, стандартная — прижата вправо, как раньше. */}
          {coverUrl ? (
            <div aria-hidden style={{ position: 'absolute', inset: 0, backgroundImage: `url(${coverUrl})`, backgroundSize: 'cover', backgroundPosition: 'center', opacity: 0.62, maskImage: 'linear-gradient(90deg, rgba(0,0,0,0.18) 0%, #000 58%)', WebkitMaskImage: 'linear-gradient(90deg, rgba(0,0,0,0.18) 0%, #000 58%)', pointerEvents: 'none' }} />
          ) : (
            <div aria-hidden style={{ position: 'absolute', top: 0, right: 0, bottom: 0, width: '62%', backgroundImage: `url(${profileArt})`, backgroundSize: 'cover', backgroundPosition: 'center top', opacity: 0.5, maskImage: 'linear-gradient(90deg, transparent 0%, #000 62%)', WebkitMaskImage: 'linear-gradient(90deg, transparent 0%, #000 62%)', pointerEvents: 'none' }} />
          )}
          {/* Затемнение снизу, чтобы имя и статистика читались на любой обложке */}
          {coverUrl && <div aria-hidden style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(5,6,10,0.30) 0%, rgba(5,6,10,0.55) 68%, rgba(5,6,10,0.86) 100%)', pointerEvents: 'none' }} />}

          {/* Смена / сброс обложки — только тем, кому владелец разрешил в разделе «Роли» */}
          {canEditCover && (<><div style={{ position: 'absolute', top: '10px', right: '10px', zIndex: 3, display: 'flex', gap: '6px' }}>
            {coverUrl && (
              <button onClick={() => onProfileChange({ ...profile, bgUrl: null })} aria-label="Вернуть стандартную обложку" title="Вернуть стандартную обложку"
                style={{ width: '30px', height: '30px', borderRadius: '10px', display: 'grid', placeItems: 'center', cursor: 'pointer', background: 'rgba(6,6,12,0.55)', border: '1px solid var(--ss-hairline-lo, var(--border))', backdropFilter: 'blur(8px)' }}>
                <Icon name="close" size={14} color="var(--ss-ink-2, var(--text-secondary))" />
              </button>
            )}
            <button onClick={() => bgFileRef.current?.click()} aria-label="Изменить обложку профиля" title="Изменить обложку профиля"
              style={{ display: 'flex', alignItems: 'center', gap: '5px', height: '30px', padding: '0 10px', borderRadius: '10px', cursor: 'pointer', background: 'rgba(6,6,12,0.55)', border: '1px solid var(--ss-brand-edge, var(--border))', backdropFilter: 'blur(8px)' }}>
              <Icon name="image" size={13} color="var(--ss-brand-hi, var(--accent))" />
              <span style={{ color: 'var(--ss-brand-ink, var(--accent))', fontSize: '10.5px', fontWeight: 650 }}>Обложка</span>
            </button>
          </div>
          <input ref={bgFileRef} type="file" accept="image/*" onChange={handleBgFile} style={{ display: 'none' }} /></>)}

          <div aria-hidden style={{ position: 'absolute', inset: 0, background: isAdmin
            ? 'radial-gradient(80% 100% at 0% 0%, rgba(239,68,68,0.20) 0%, transparent 62%)'
            : 'radial-gradient(80% 100% at 0% 0%, rgba(124,58,237,0.30) 0%, rgba(96,132,255,0.08) 45%, transparent 70%)', pointerEvents: 'none' }} />

          <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: '14px', padding: '16px 16px 0' }}>
            <div style={{ position: 'relative', width: '86px', height: '86px', flexShrink: 0 }}>
              <svg viewBox="0 0 86 86" width="86" height="86" aria-hidden style={{ position: 'absolute', inset: 0, animation: 'ss-ring-spin 16s linear infinite', transformOrigin: '50% 50%' }}>
                <defs>
                  <linearGradient id="avatar-ring-duo" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="var(--ss-brand-hi, #a855f7)" />
                    <stop offset="100%" stopColor="var(--ss-blue-hi, #4f8dff)" />
                  </linearGradient>
                </defs>
                <circle cx="43" cy="43" r="41" fill="none" stroke={isAdmin ? '#ef4444' : 'url(#avatar-ring-duo)'} strokeWidth="1.3" strokeDasharray="30 14" strokeLinecap="round" opacity="0.85" />
              </svg>
              <div style={{ position: 'absolute', inset: '6px', borderRadius: '50%', background: isAdmin ? 'linear-gradient(135deg,#ef4444,#b91c1c)' : 'linear-gradient(135deg,var(--ss-brand-hi, #a855f7),var(--ss-brand, #6d28d9))', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: `0 0 0 3px var(--bg-card), 0 0 28px -6px ${isAdmin ? 'rgba(239,68,68,0.6)' : 'var(--ss-brand-glow, rgba(168,85,247,0.6))'}`, overflow: 'hidden', cursor: 'pointer' }} onClick={() => fileRef.current?.click()}>
                {profile.avatarUrl ? <img src={profile.avatarUrl} alt="avatar" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : <span style={{ fontSize: '26px', color: '#fff', fontWeight: 700 }}>{user?.avatar ?? 'U'}</span>}
                {avatarUploading && <div style={{ position: 'absolute', inset: 0, background: 'rgba(0,0,0,0.55)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><div style={{ width: '22px', height: '22px', border: '2px solid rgba(255,255,255,0.35)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin 0.7s linear infinite' }} /></div>}
              </div>
              <button onClick={() => fileRef.current?.click()} aria-label="Изменить фото профиля" style={{ position: 'absolute', bottom: 0, right: 0, width: '28px', height: '28px', borderRadius: '9px', background: 'var(--ss-brand-wash, var(--accent-glow))', border: '1px solid var(--ss-brand-edge, var(--border))', boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', zIndex: 2, backdropFilter: 'blur(6px)' }}>
                <Icon name="pencil" size={13} color="var(--ss-brand-hi, var(--accent))" />
              </button>
              <input ref={fileRef} type="file" accept="image/*" onChange={handleAvatarFile} style={{ display: 'none' }} />
            </div>
            <div style={{ minWidth: 0 }}>
              <h2 style={{ color: 'var(--text-primary)', fontSize: '22px', fontWeight: 700, margin: '0 0 6px', textShadow: '0 2px 12px rgba(0,0,0,0.6)' }}>{displayName}</h2>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', fontSize: '10px', fontWeight: 700, padding: '3px 10px', borderRadius: '7px', textTransform: 'uppercase', letterSpacing: '0.08em', background: isAdmin ? 'rgba(239,68,68,0.14)' : 'var(--ss-brand-wash, var(--accent-glow))', color: isAdmin ? '#ef4444' : 'var(--ss-brand-ink, var(--accent))', border: `1px solid ${isAdmin ? 'rgba(239,68,68,0.28)' : 'var(--ss-brand-edge, transparent)'}` }}>
                {isAdmin ? 'Admin' : 'Client'}
              </span>
              <p style={{ color: 'var(--text-secondary)', fontSize: '13px', margin: '7px 0 0', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', textShadow: '0 2px 10px rgba(0,0,0,0.7)' }}>@{authLogin}</p>
            </div>
          </div>

          {/* Статистика внутри карточки */}
          <div style={{ position: 'relative', display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', margin: '16px 0 0', borderTop: '1px solid var(--border)' }}>
            {[
              { icon: 'star-fill' as IconName, color: '#f5b942', value: `${(totalSpent / 1000).toFixed(1)}к ₽`, label: 'Потрачено' },
              { icon: 'package'   as IconName, color: 'var(--ss-brand-hi, var(--accent))', value: orders.length, label: 'Заказов' },
              { icon: 'heart'     as IconName, color: '#f0524f', value: favProducts.length, label: 'В избранном' },
            ].map((s, i) => (
              <div key={s.label} style={{ padding: '12px 10px 14px', borderLeft: i > 0 ? '1px solid var(--border)' : 'none' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
                  <Icon name={s.icon} size={17} color={s.color} />
                  <span style={{ color: 'var(--text-primary)', fontSize: '17px', fontWeight: 700 }}>{s.value}</span>
                </div>
                <p style={{ color: 'var(--text-secondary)', fontSize: '11px', margin: '4px 0 0' }}>{s.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Sigma Club */}
        <div style={{ position: 'relative', overflow: 'hidden', display: 'flex', alignItems: 'center', gap: '14px', padding: '14px 14px', borderRadius: '18px', border: '1px solid var(--ss-brand-edge, var(--border))', background: 'linear-gradient(100deg, var(--ss-brand-wash, rgba(124,58,237,0.12)), var(--bg-card) 62%)', marginBottom: '12px' }}>
          <div aria-hidden style={{ position: 'absolute', left: -60, top: -60, width: 200, height: 200, borderRadius: '50%', background: 'radial-gradient(circle, var(--ss-brand-glow, rgba(168,85,247,0.35)) 0%, transparent 62%)', pointerEvents: 'none' }} />
          <div style={{ position: 'relative', width: '46px', height: '46px', borderRadius: '14px', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.35)', border: '1px solid var(--ss-brand-edge, var(--border))' }}>
            <Icon name="star-fill" size={22} color="var(--ss-brand-hi, var(--accent))" />
          </div>
          <div style={{ position: 'relative', flex: 1, minWidth: 0 }}>
            <p style={{ color: 'var(--text-primary)', fontSize: '14.5px', fontWeight: 700, margin: 0 }}>Sigma Club</p>
            <p style={{ color: 'var(--text-secondary)', fontSize: '11.5px', margin: '3px 0 0', lineHeight: 1.35 }}>
              {activeDiscount > 0 ? `Скидка ${activeDiscount}%${activePromoCode ? ` — ${activePromoCode}` : ''}` : 'Заказы открывают привилегии'}
            </p>
          </div>
          <button onClick={() => setShowClubSoon(true)} style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: '5px', padding: '9px 12px', borderRadius: '11px', background: 'var(--bg-elevated)', border: '1px solid var(--ss-brand-edge, var(--border))', color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 600, cursor: 'pointer', flexShrink: 0 }}>
            Привилегии <Icon name="chevron-right" size={13} color="var(--text-secondary)" />
          </button>
        </div>

        {/* Бонусы — узкая карточка-строка (как Sigma Club), детали в шторке */}
        {loyalty.enabled && (
          <div style={{ position: 'relative', overflow: 'hidden', display: 'flex', alignItems: 'center', gap: '14px', padding: '14px 14px', borderRadius: '18px', border: '1px solid var(--accent-2)', background: 'linear-gradient(100deg, var(--accent-2-wash), var(--bg-card) 62%)', marginBottom: '12px' }}>
            <div aria-hidden style={{ position: 'absolute', left: -60, top: -60, width: 200, height: 200, borderRadius: '50%', background: 'radial-gradient(circle, rgba(52,201,125,0.30) 0%, transparent 62%)', pointerEvents: 'none' }} />
            <div style={{ position: 'relative', width: '46px', height: '46px', borderRadius: '14px', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.35)', border: '1px solid var(--accent-2)' }}>
              <span style={{ fontSize: '22px', lineHeight: 1 }}>💎</span>
            </div>
            <div style={{ position: 'relative', flex: 1, minWidth: 0 }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '14.5px', fontWeight: 700, margin: 0 }}>Баланс</p>
              <p style={{ color: 'var(--text-secondary)', fontSize: '11.5px', margin: '3px 0 0', lineHeight: 1.35 }}>
                <b style={{ color: 'var(--accent-2-hi)' }}>{points.toLocaleString('ru')} ₽</b> на счету
              </p>
            </div>
            <button onClick={() => setShowBonus(true)} style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: '5px', padding: '9px 12px', borderRadius: '11px', background: 'var(--bg-elevated)', border: '1px solid var(--accent-2)', color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 600, cursor: 'pointer', flexShrink: 0 }}>
              Подробнее <Icon name="chevron-right" size={13} color="var(--text-secondary)" />
            </button>
          </div>
        )}

        {/* Мои заказы — сводка по стадиям */}
        <div className="glass-card" style={{ padding: '14px 14px 6px', marginBottom: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
            <p style={{ color: 'var(--text-primary)', fontSize: '16px', fontWeight: 700, margin: 0 }}>Мои заказы</p>
            <button onClick={onGoOrders} style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', color: 'var(--ss-brand-hi, var(--accent))', fontSize: '12.5px', fontWeight: 600 }}>Смотреть все</button>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)' }}>
            {orderStages.map((s, i) => (
              <button key={s.label} onClick={onGoOrders} style={{ padding: '6px 2px 14px', background: 'none', border: 'none', borderLeft: i > 0 ? '1px solid var(--border)' : 'none', cursor: 'pointer' }}>
                <p style={{ color: s.color, fontSize: '24px', fontWeight: 700, margin: '0 0 4px' }}>{orders.filter(o => s.statuses.includes(o.status)).length}</p>
                <p style={{ color: 'var(--text-secondary)', fontSize: '11px', margin: 0 }}>{s.label}</p>
              </button>
            ))}
          </div>
        </div>

        <div className="glass-card" style={{ overflow: 'hidden', marginBottom: '12px' }}>
          {menuItems.map((item, i, arr) => (
            <button key={item.label} onClick={item.action} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: '14px', padding: '14px 16px', background: 'none', border: 'none', cursor: 'pointer', borderBottom: i < arr.length - 1 ? '1px solid var(--border)' : 'none', textAlign: 'left' }}>
              <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '34px', height: '34px', borderRadius: '10px', background: `color-mix(in srgb, ${item.color} 15%, transparent)`, flexShrink: 0 }}>
                <Icon name={item.icon} size={18} color={item.color} />
              </span>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ color: 'var(--text-primary)', fontSize: '14.5px', fontWeight: 500, margin: 0 }}>{item.label}</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '2px 0 0', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.sub}</p>
              </div>
              <Icon name="chevron-right" size={16} color="var(--text-muted)" />
            </button>
          ))}
        </div>

        {/* Вход в панель мастера — только для тех, у кого есть доступ */}
        {onGoCrm && (
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '14px 14px', borderRadius: '18px', border: '1px solid var(--ss-brand-edge, var(--border))', background: 'linear-gradient(100deg, rgba(124,58,237,0.14), var(--bg-card) 70%)', marginBottom: '12px' }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ color: 'var(--ss-brand-hi, var(--accent))', fontSize: '17px', fontWeight: 700, margin: 0 }}>Sigma Master</p>
              <p style={{ color: 'var(--text-secondary)', fontSize: '11.5px', margin: '3px 0 0' }}>Панель управления мастерской</p>
            </div>
            <button onClick={onGoCrm} style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '10px 13px', borderRadius: '12px', background: 'var(--bg-elevated)', border: '1px solid var(--ss-brand-edge, var(--border))', color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 600, cursor: 'pointer', flexShrink: 0 }}>
              <Icon name="layers" size={14} color="var(--ss-brand-hi, var(--accent))" />
              Перейти в CRM
              <Icon name="chevron-right" size={13} color="var(--text-secondary)" />
            </button>
          </div>
        )}

        {/* Поддержка */}
        <button onClick={onGoFaq} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: '14px', padding: '14px 16px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '18px', cursor: 'pointer', marginBottom: '14px' }}>
          <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '34px', height: '34px', borderRadius: '10px', background: 'color-mix(in srgb, #5ea0ac 15%, transparent)', flexShrink: 0 }}>
            <Icon name="question" size={19} color="#5ea0ac" />
          </span>
          <div style={{ flex: 1, textAlign: 'left' }}>
            <p style={{ color: 'var(--text-primary)', fontSize: '14.5px', fontWeight: 600, margin: 0 }}>Поддержка</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '2px 0 0' }}>Частые вопросы и ответы мастера</p>
          </div>
          <Icon name="chevron-right" size={16} color="var(--text-muted)" />
        </button>

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 4px' }}>
          {editingVer && onVersionChange ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span style={{ color: 'var(--text-muted)', fontSize: '11.5px' }}>Версия</span>
              <input
                value={verDraft}
                autoFocus
                onChange={e => setVerDraft(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter') { onVersionChange(verDraft); setEditingVer(false) }
                  if (e.key === 'Escape') { setVerDraft(appVersion); setEditingVer(false) }
                }}
                placeholder="напр. 1.2.5"
                style={{ width: '96px', padding: '4px 8px', borderRadius: '8px', border: '1px solid var(--ss-brand-edge, var(--border))', background: 'var(--bg-elevated)', color: 'var(--text-primary)', fontSize: '12px' }}
              />
              <button onClick={() => { onVersionChange(verDraft); setEditingVer(false) }} aria-label="Сохранить версию" style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: '28px', height: '28px', borderRadius: '8px', border: 'none', background: 'var(--ss-brand-wash, var(--accent-glow))', cursor: 'pointer' }}>
                <Icon name="check" size={15} color="var(--ss-brand-hi, var(--accent))" />
              </button>
              <button onClick={() => { setVerDraft(appVersion); setEditingVer(false) }} aria-label="Отмена" style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: '28px', height: '28px', borderRadius: '8px', border: '1px solid var(--border)', background: 'none', cursor: 'pointer' }}>
                <Icon name="close" size={14} color="var(--text-muted)" />
              </button>
            </div>
          ) : (
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', color: 'var(--text-muted)', fontSize: '11.5px' }}>
              Версия приложения {appVersion}
              {onVersionChange && (
                <button onClick={() => { setVerDraft(appVersion); setEditingVer(true) }} aria-label="Изменить версию" style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: '22px', height: '22px', borderRadius: '6px', border: 'none', background: 'none', cursor: 'pointer', padding: 0 }}>
                  <Icon name="pencil" size={13} color="var(--ss-brand-hi, var(--accent))" />
                </button>
              )}
            </span>
          )}
          <button onClick={logout} style={{ display: 'flex', alignItems: 'center', gap: '7px', background: 'none', border: 'none', padding: '4px 0', cursor: 'pointer', color: 'var(--danger)', fontSize: '13px', fontWeight: 600 }}>
            <Icon name="sign-out" size={16} color="var(--danger)" />
            Выйти
          </button>
        </div>
      </div>

      {/* Settings tray */}
      {showTray && (
        <Sheet onClose={() => setShowTray(false)}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '16px 18px 8px', flexShrink: 0 }}>
            <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: 'var(--accent-glow)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Icon name="gear" size={16} color="var(--accent)" />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '16px', fontWeight: 700, margin: 0 }}>Настройки профиля</p>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Фото, настройки, выход</p>
            </div>
            <button onClick={() => setShowTray(false)} aria-label="Закрыть" className="ss-press" style={{ flexShrink: 0, width: '32px', height: '32px', borderRadius: '50%', display: 'grid', placeItems: 'center', background: 'var(--bg-elevated)', border: '1px solid var(--border)', cursor: 'pointer' }}>
              <Icon name="close" size={16} color="var(--text-secondary)" />
            </button>
          </div>
          <div style={{ padding: '4px 0 32px' }}>
            {[
              { icon: 'camera' as IconName, label: 'Изменить фото профиля', color: 'var(--accent)', action: () => { setShowTray(false); setTimeout(() => fileRef.current?.click(), 100) } },
              { icon: 'gear'   as IconName, label: 'Настройки',             color: 'var(--text-primary)', action: () => { setShowTray(false); onGoSettings() } },
              { icon: 'sign-out' as IconName, label: 'Выйти из аккаунта',   color: 'var(--danger)', action: () => { setShowTray(false); logout() } },
            ].map((item, i, arr) => (
              <button key={item.label} onClick={item.action} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: '14px', padding: '16px 20px', background: 'none', border: 'none', cursor: 'pointer', borderBottom: i < arr.length - 1 ? '1px solid var(--border)' : 'none', textAlign: 'left' }}>
                <div style={{ width: '38px', height: '38px', borderRadius: '12px', background: item.color === 'var(--danger)' ? 'rgba(239,68,68,0.08)' : 'var(--bg-elevated)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Icon name={item.icon} size={18} color={item.color} />
                </div>
                <span style={{ color: item.color, fontSize: '15px', fontWeight: 500 }}>{item.label}</span>
              </button>
            ))}
          </div>
        </Sheet>
      )}

      {/* Address sheet */}
      {showAddress && (
        <Sheet onClose={() => setShowAddress(false)}>
          <div style={{ padding: '16px 18px 6px', flexShrink: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '16px' }}>
              <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: 'var(--accent-glow)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="pin" size={16} color="var(--accent)" />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ color: 'var(--text-primary)', fontSize: '16px', fontWeight: 700, margin: 0 }}>Адрес доставки</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Укажи куда доставить заказ</p>
              </div>
              <button onClick={() => setShowAddress(false)} aria-label="Закрыть" className="ss-press" style={{ flexShrink: 0, width: '32px', height: '32px', borderRadius: '50%', display: 'grid', placeItems: 'center', background: 'var(--bg-elevated)', border: '1px solid var(--border)', cursor: 'pointer' }}>
                <Icon name="close" size={16} color="var(--text-secondary)" />
              </button>
            </div>
          </div>
          <div style={{ flex: 1, overflowY: 'auto', padding: '0 18px 28px' }}>
            <div style={{ marginBottom: '12px' }}>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 600, margin: '0 0 6px' }}>Город</p>
              <input value={addrDraft.city} onChange={e => setAddrDraft(p => ({ ...p, city: e.target.value }))} placeholder="Например: Москва"
                style={{ width: '100%', padding: '11px 13px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '12px', color: 'var(--text-primary)', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
            </div>
            <div style={{ marginBottom: '12px' }}>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 600, margin: '0 0 6px' }}>Улица и дом</p>
              <input value={addrDraft.address} onChange={e => setAddrDraft(p => ({ ...p, address: e.target.value }))} placeholder="ул. Ленина, д. 1"
                style={{ width: '100%', padding: '11px 13px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '12px', color: 'var(--text-primary)', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
              <p style={{ color: 'var(--accent)', fontSize: '10.5px', margin: '6px 0 0', lineHeight: 1.45 }}>Укажите адрес пункта выдачи выбранной ниже службы доставки.</p>
            </div>
            <div style={{ marginBottom: '20px' }}>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 600, margin: '0 0 8px' }}>Служба доставки</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {DELIVERY_OPTIONS.map(opt => (
                  <button key={opt.key} onClick={() => setAddrDraft(p => ({ ...p, deliveryService: opt.key }))}
                    style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 14px', background: addrDraft.deliveryService === opt.key ? 'var(--accent-2-wash)' : 'var(--bg-elevated)', border: `1px solid ${addrDraft.deliveryService === opt.key ? 'var(--accent-2)' : 'var(--border)'}`, borderRadius: '12px', cursor: 'pointer', textAlign: 'left' }}>
                    <Icon name={opt.icon} size={18} color={addrDraft.deliveryService === opt.key ? 'var(--accent-2-hi)' : 'var(--text-muted)'} />
                    <div style={{ flex: 1 }}>
                      <p style={{ color: addrDraft.deliveryService === opt.key ? 'var(--accent-2-hi)' : 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: 0 }}>{opt.label}</p>
                      <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>{opt.sub}</p>
                    </div>
                    {addrDraft.deliveryService === opt.key && <Icon name="check" size={15} color="var(--accent-2-hi)" />}
                  </button>
                ))}
              </div>
            </div>
            <button className="btn-primary" onClick={() => { onProfileChange(addrDraft); setShowAddress(false) }}>
              Сохранить адрес
            </button>
          </div>
        </Sheet>
      )}

      {/* Favorites sheet */}
      {showFavorites && (
        <Sheet onClose={() => setShowFavorites(false)}>
          <div style={{ padding: '16px 18px 12px', flexShrink: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="heart" size={16} color="#ef4444" fill />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ color: 'var(--text-primary)', fontSize: '16px', fontWeight: 700, margin: 0 }}>Избранное</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>{favProducts.length} фигурок</p>
              </div>
              <button onClick={() => setShowFavorites(false)} aria-label="Закрыть" className="ss-press" style={{ flexShrink: 0, width: '32px', height: '32px', borderRadius: '50%', display: 'grid', placeItems: 'center', background: 'var(--bg-elevated)', border: '1px solid var(--border)', cursor: 'pointer' }}>
                <Icon name="close" size={16} color="var(--text-secondary)" />
              </button>
            </div>
          </div>
          <div style={{ maxHeight: '45dvh', overflowY: 'auto', overscrollBehavior: 'contain', WebkitOverflowScrolling: 'touch', padding: '0 18px 28px' }}>
            {favProducts.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '46px 20px' }}>
                <div style={{ width: '72px', height: '72px', margin: '0 auto', borderRadius: '22px', display: 'grid', placeItems: 'center', background: 'radial-gradient(circle at 50% 35%, var(--ss-brand-wash), transparent 70%)', border: '1px solid var(--ss-brand-edge)' }}>
                  <Icon name="heart" size={30} color="var(--ss-brand-hi, var(--accent))" />
                </div>
                <p style={{ color: 'var(--ss-ink)', fontSize: '14px', fontWeight: 700, margin: '14px 0 0' }}>В избранном пусто</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '12px', margin: '5px 0 16px', lineHeight: 1.5 }}>Отмечайте фигурки сердечком — они соберутся здесь, чтобы вернуться к ним позже.</p>
                <button onClick={() => { setShowFavorites(false); onGoCatalog?.() }} className="ss-press"
                  style={{ display: 'inline-flex', alignItems: 'center', gap: '7px', padding: '10px 16px', borderRadius: '12px', border: '1px solid var(--ss-brand-edge)', background: 'linear-gradient(180deg, var(--ss-brand-hi), var(--ss-brand))', color: '#fff', fontSize: '12.5px', fontWeight: 700, fontFamily: 'inherit', cursor: 'pointer' }}>
                  <Icon name="grid" size={14} color="#fff" /> В каталог
                </button>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {favProducts.map(p => (
                  <div key={p.id} style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '10px 12px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '14px', cursor: 'pointer' }}
                    onClick={() => { setOpenProduct(p) }}>
                    <img src={storageThumb(p.img, 160)} alt={p.name} loading="lazy" decoding="async" onError={e => { const el = e.currentTarget; if (!el.dataset.full && p.img) { el.dataset.full = '1'; el.src = p.img } }} style={{ width: '52px', height: '52px', borderRadius: '10px', objectFit: 'cover', flexShrink: 0 }} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p style={{ color: 'var(--text-muted)', fontSize: '9px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', margin: '0 0 2px' }}>{p.series}</p>
                      <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: '0 0 3px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</p>
                      <p style={{ color: 'var(--accent)', fontSize: '12px', fontWeight: 700, margin: 0 }}>{p.price.toLocaleString()} ₽</p>
                    </div>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', alignItems: 'center', flexShrink: 0 }}>
                      <button onClick={e => { e.stopPropagation(); setFavorites(prev => prev.filter(id => id !== p.id)) }}
                        style={{ width: '32px', height: '32px', borderRadius: '50%', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Icon name="heart" size={15} color="#ef4444" fill />
                      </button>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '2px' }}>
                        <Icon name="chevron-right" size={13} color="var(--text-muted)" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </Sheet>
      )}

      {showClubSoon && (loyalty.clubEnabled
        ? <ClubSheet onClose={() => setShowClubSoon(false)} spent={clubSpent(orders, authLogin)} points={points} loyalty={loyalty} />
        : <ClubSoonSheet onClose={() => setShowClubSoon(false)} />)}

      {/* Полная информация по бонусам — открывается из узкой карточки баланса */}
      {showBonus && (
        <Sheet onClose={() => setShowBonus(false)}>
          <div style={{ padding: '18px 18px 28px' }}>
            {/* Шапка: баланс */}
            <div style={{ position: 'relative', overflow: 'hidden', borderRadius: '18px', border: '1px solid var(--accent-2)', background: 'linear-gradient(135deg, var(--accent-2-wash), var(--bg-card) 70%)', padding: '16px', marginBottom: '14px' }}>
              <div aria-hidden style={{ position: 'absolute', right: -56, top: -56, width: 190, height: 190, borderRadius: '50%', background: 'radial-gradient(circle, rgba(52,201,125,0.30) 0%, transparent 62%)', pointerEvents: 'none' }} />
              <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: '12px' }}>
                <span style={{ width: '44px', height: '44px', borderRadius: '13px', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.28)', border: '1px solid var(--accent-2)' }}>
                  <span style={{ fontSize: '22px', lineHeight: 1 }}>💎</span>
                </span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.06em', margin: 0 }}>Баланс</p>
                  <p style={{ color: 'var(--text-primary)', fontSize: '24px', fontWeight: 800, margin: '1px 0 0', lineHeight: 1 }}>{points.toLocaleString('ru')} <span style={{ fontSize: '15px' }}>₽</span></p>
                </div>
              </div>
              <p style={{ position: 'relative', color: 'var(--text-secondary)', fontSize: '11.5px', margin: '10px 0 0', lineHeight: 1.4 }}>
                Возвращаем <b style={{ color: 'var(--accent-2-hi)' }}>{loyalty.cashback}%</b> бонусами с каждого доставленного заказа. Бонусами можно оплатить до {loyalty.maxRedeemPct}% следующего заказа.
              </p>
            </div>

            {/* Автосписание бонусов при заказе */}
            {points > 0 && (
              <button onClick={() => onProfileChange({ ...profile, useBonus: !profile.useBonus })}
                style={{ display: 'flex', alignItems: 'center', gap: '11px', width: '100%', marginBottom: '14px', padding: '12px', borderRadius: '12px', cursor: 'pointer', textAlign: 'left',
                  background: profile.useBonus ? 'rgba(52,201,125,0.14)' : 'var(--bg-elevated)', border: `1px solid ${profile.useBonus ? 'var(--status-ready-color)' : 'var(--border)'}` }}>
                <span style={{ flex: 1, minWidth: 0 }}>
                  <span style={{ display: 'block', color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 650 }}>Списывать бонусы при заказе</span>
                  <span style={{ display: 'block', color: 'var(--text-muted)', fontSize: '10.5px', marginTop: '1px' }}>Автоматически уменьшат сумму к оплате</span>
                </span>
                <span style={{ flexShrink: 0, width: '38px', height: '22px', borderRadius: '999px', position: 'relative', transition: 'background 0.2s', background: profile.useBonus ? 'var(--status-ready-color)' : 'var(--border)' }}>
                  <span style={{ position: 'absolute', top: '2px', left: profile.useBonus ? '18px' : '2px', width: '18px', height: '18px', borderRadius: '50%', background: '#fff', transition: 'left 0.2s' }} />
                </span>
              </button>
            )}

            {/* Реферальная программа */}
            <div style={{ padding: '14px', borderRadius: '14px', border: '1px solid var(--border)', background: 'var(--bg-card)' }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 700, margin: '0 0 6px' }}>Приглашайте друзей 🎁</p>
              <p style={{ color: 'var(--text-secondary)', fontSize: '11px', margin: '0 0 8px', lineHeight: 1.4 }}>
                За каждого друга, оформившего первый заказ, вы оба получите <b style={{ color: 'var(--accent-2-hi)' }}>{loyalty.referral} ₽</b> бонусами. Ваш код — ваш @username:
              </p>
              <button onClick={() => { navigator.clipboard?.writeText(authLogin).catch(() => {}); setRefMsg('Ваш код скопирован') }}
                style={{ display: 'flex', alignItems: 'center', gap: '8px', width: '100%', padding: '9px 12px', borderRadius: '10px', background: 'var(--bg-input)', border: '1px dashed var(--accent-2)', cursor: 'pointer', marginBottom: '8px' }}>
                <span style={{ flex: 1, textAlign: 'left', color: 'var(--accent-2-hi)', fontSize: '13px', fontWeight: 700, fontFamily: 'monospace', letterSpacing: '0.5px' }}>{authLogin}</span>
                <Icon name="save" size={14} color="var(--accent-2-hi)" />
              </button>
              {profile.refBy ? (
                <p style={{ color: 'var(--status-ready-color)', fontSize: '11px', margin: 0, fontWeight: 600 }}>✓ Вы пришли по приглашению {profile.refBy}</p>
              ) : (
                <div style={{ display: 'flex', gap: '6px' }}>
                  <input value={refInput} onChange={e => { setRefInput(e.target.value); setRefMsg('') }} placeholder="@код друга"
                    style={{ flex: 1, background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '9px', padding: '9px 11px', color: 'var(--text-primary)', fontSize: '12.5px', outline: 'none', minWidth: 0 }} />
                  <button onClick={applyRefCode} style={{ padding: '0 14px', borderRadius: '9px', border: 'none', background: 'var(--accent-grad)', color: '#fff', fontSize: '12.5px', fontWeight: 700, cursor: 'pointer', flexShrink: 0 }}>Применить</button>
                </div>
              )}
              {refMsg && <p style={{ color: 'var(--accent-2-hi)', fontSize: '10.5px', margin: '6px 0 0' }}>{refMsg}</p>}
            </div>
          </div>
        </Sheet>
      )}

      {showPromoBag && (
        <Sheet onClose={() => setShowPromoBag(false)}>
          <div style={{ padding: '16px 18px 12px', flexShrink: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: 'var(--accent-glow)', border: '1px solid var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="gift" size={16} color="var(--accent)" />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ color: 'var(--text-primary)', fontSize: '16px', fontWeight: 700, margin: 0 }}>Сумка для промиков</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>{myPromos.length} доступно</p>
              </div>
              <button onClick={() => setShowPromoBag(false)} aria-label="Закрыть" className="ss-press" style={{ flexShrink: 0, width: '32px', height: '32px', borderRadius: '50%', display: 'grid', placeItems: 'center', background: 'var(--bg-elevated)', border: '1px solid var(--border)', cursor: 'pointer' }}>
                <Icon name="close" size={16} color="var(--text-secondary)" />
              </button>
            </div>
          </div>
          <div style={{ maxHeight: '45dvh', overflowY: 'auto', overscrollBehavior: 'contain', WebkitOverflowScrolling: 'touch', padding: '0 18px 28px' }}>
            {myPromos.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '40px 0' }}>
                <Icon name="gift" size={40} color="var(--border)" />
                <p style={{ color: 'var(--text-muted)', fontSize: '13px', margin: '12px 0 0', fontStyle: 'italic' }}>Пока пусто</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '4px 0 0' }}>Промокоды за розыгрыши появятся здесь</p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                {myPromos.map(p => {
                  const active = profile.promoCode?.toUpperCase() === p.code.toUpperCase()
                  const left = p.maxUses - p.uses
                  const personal = !!p.targetUser
                  return (
                    <div key={p.id} style={{ position: 'relative', padding: '14px', borderRadius: '14px', overflow: 'hidden', background: 'var(--accent-glow)', border: `1px dashed ${active ? 'var(--accent)' : 'var(--border)'}` }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px' }}>
                        <div style={{ minWidth: 0 }}>
                          <p style={{ color: 'var(--accent)', fontSize: '22px', fontWeight: 800, margin: '0 0 3px', lineHeight: 1 }}>−{p.discount}%</p>
                          <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, letterSpacing: '1.5px', margin: 0, fontFamily: 'monospace' }}>{p.code}</p>
                        </div>
                        <div style={{ textAlign: 'right', flexShrink: 0 }}>
                          {personal && <span style={{ display: 'inline-block', fontSize: '9px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.5px', padding: '3px 8px', borderRadius: '20px', background: 'rgba(168,85,247,0.15)', color: '#a855f7', marginBottom: '6px' }}>розыгрыш</span>}
                          {personal && <p style={{ color: 'var(--text-secondary)', fontSize: '10px', margin: 0 }}>{left === 1 ? 'одноразовый' : `осталось: ${left}`}</p>}
                          {p.expiresAt ? <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '2px 0 0' }}>до {new Date(p.expiresAt).toLocaleDateString('ru', { day: 'numeric', month: 'short' })}</p> : <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '2px 0 0' }}>бессрочно</p>}
                        </div>
                      </div>
                      {active
                        ? <p style={{ color: 'var(--accent)', fontSize: '11px', fontWeight: 600, margin: '10px 0 0', display: 'flex', alignItems: 'center', gap: '4px' }}><Icon name="check" size={12} color="var(--accent)" /> Активирован</p>
                        : <button onClick={() => onProfileChange({ ...profile, promoCode: p.code })}
                            style={{ width: '100%', marginTop: '10px', padding: '8px', background: 'var(--accent-grad)', border: 'none', borderRadius: '9px', color: '#fff', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}>Применить к заказу</button>}
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </Sheet>
      )}

      {showPayment && (
        <Sheet onClose={() => setShowPayment(false)}>
          <div style={{ padding: '16px 18px 12px', flexShrink: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
              <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: 'var(--accent-glow)', border: '1px solid var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Icon name="card" size={16} color="var(--accent)" />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <p style={{ color: 'var(--text-primary)', fontSize: '16px', fontWeight: 700, margin: 0 }}>Способы оплаты</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Оплата проходит на защищённой странице — данные карты вводить заранее не нужно</p>
              </div>
              <button onClick={() => setShowPayment(false)} aria-label="Закрыть" className="ss-press" style={{ flexShrink: 0, alignSelf: 'flex-start', width: '32px', height: '32px', borderRadius: '50%', display: 'grid', placeItems: 'center', background: 'var(--bg-elevated)', border: '1px solid var(--border)', cursor: 'pointer' }}>
                <Icon name="close" size={16} color="var(--text-secondary)" />
              </button>
            </div>
          </div>
          <div style={{ overflowY: 'auto', padding: '4px 18px 28px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {PAY_METHOD_DEFS.map(m => {
              const on = !m.comingSoon && payEnabled[m.key]
              const status = m.comingSoon ? 'Скоро' : on ? 'Доступно' : 'Временно недоступно'
              const sColor = m.comingSoon ? '#a855f7' : on ? '#22c55e' : 'var(--text-muted)'
              return (
                <div key={m.key} style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '14px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '14px', opacity: on || m.comingSoon ? 1 : 0.65 }}>
                  <div style={{ width: '40px', height: '40px', borderRadius: '11px', background: on ? 'var(--accent-glow)' : 'var(--bg-card)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Icon name={m.icon} size={18} color={on ? 'var(--accent)' : 'var(--text-muted)'} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: '0 0 4px' }}>{m.label}</p>
                    {m.brands
                      ? <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>{m.brands.map(b => <span key={b} style={{ fontSize: '8px', fontWeight: 800, letterSpacing: '0.4px', color: 'var(--text-secondary)', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '4px', padding: '2px 5px' }}>{b}</span>)}</div>
                      : <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0 }}>{m.sub}</p>}
                  </div>
                  <span style={{ fontSize: '9px', fontWeight: 700, color: sColor, background: on ? 'rgba(34,197,94,0.12)' : m.comingSoon ? 'rgba(168,85,247,0.12)' : 'var(--bg-card)', border: `1px solid ${on ? 'rgba(34,197,94,0.25)' : m.comingSoon ? 'rgba(168,85,247,0.25)' : 'var(--border)'}`, borderRadius: '6px', padding: '3px 7px', whiteSpace: 'nowrap', flexShrink: 0 }}>{status}</span>
                </div>
              )
            })}
            <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '4px 0 0', lineHeight: 1.5 }}>Список способов оплаты настраивает магазин. Реквизиты карты вводятся уже на странице банка при оформлении.</p>
          </div>
        </Sheet>
      )}

      {openProduct && (
        <ProductModal
          product={openProduct}
          orders={orders}
          reviews={reviews}
          setReviews={setReviews}
          authUser={user}
          onOrder={(variant, provider) => { onOrder(openProduct!, variant, provider); setOpenProduct(null); setShowFavorites(false) }}
          onClose={() => setOpenProduct(null)}
          discount={activeDiscount}
          promoCode={activePromoCode}
          payEnabled={payEnabled}
          waitlist={waitlist}
          onToggleWaitlist={onToggleWaitlist}
          allProducts={products}
          onOpenProduct={setOpenProduct}
        />
      )}
    </>
  )
}

// ─────────────────────────────────────────────────────────────
// Orders
// ─────────────────────────────────────────────────────────────
// Админский редактор трек-номера и службы доставки для одного заказа.
// Кнопка связи в заказе: клиент пишет магазину, магазин — клиенту.
// Размер и форма — как у плашки трек-номера; админ может тут же поменять свой ID.
function ContactRow({ tg, isAdmin, ownContact = '', onChange }: { tg: string; isAdmin?: boolean; ownContact?: string; onChange?: (v: string) => void }) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(ownContact)
  useEffect(() => { setDraft(ownContact) }, [ownContact])
  const handle = tg.replace(/^@/, '')
  const href = handle ? `https://t.me/${handle}` : undefined

  if (editing) {
    return (
      <div style={{ marginTop: '10px', width: '100%', display: 'flex', alignItems: 'center', gap: '8px', padding: '9px 11px', background: 'var(--bg-elevated)', border: '1px solid var(--accent)', borderRadius: '10px', boxSizing: 'border-box' }}>
        <Icon name="chat" size={15} color="var(--accent)" />
        <span style={{ color: 'var(--text-muted)', fontSize: '9px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.5px', flexShrink: 0 }}>Мой ID</span>
        <input autoFocus value={draft} onChange={e => setDraft(e.target.value)} onClick={e => e.stopPropagation()}
          onKeyDown={e => { if (e.key === 'Enter') { onChange?.(draft.trim()); setEditing(false) } }}
          placeholder="@username"
          style={{ flex: 1, minWidth: 0, background: 'transparent', border: 'none', outline: 'none', color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700 }} />
        <button onClick={e => { e.stopPropagation(); onChange?.(draft.trim()); setEditing(false) }}
          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px', display: 'flex' }}>
          <Icon name="check" size={15} color="var(--success)" strokeWidth={2.4} />
        </button>
        <button onClick={e => { e.stopPropagation(); setDraft(ownContact); setEditing(false) }}
          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px', display: 'flex' }}>
          <Icon name="close" size={15} color="var(--text-muted)" />
        </button>
        {/* draft всегда правит мой контакт, а не ID клиента из заказа */}
      </div>
    )
  }
  return (
    <div style={{ marginTop: '10px', width: '100%', display: 'flex', alignItems: 'center', gap: '8px', padding: '9px 11px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '10px', boxSizing: 'border-box' }}>
      <a href={href} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()}
        style={{ flex: 1, minWidth: 0, display: 'flex', alignItems: 'center', gap: '8px', textDecoration: 'none' }}>
        <Icon name="chat" size={15} color="var(--accent)" />
        <span style={{ flex: 1, minWidth: 0 }}>
          <span style={{ display: 'block', color: 'var(--text-muted)', fontSize: '9px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px' }}>{isAdmin ? 'Связь с клиентом' : 'Связь с магазином'}</span>
          <span style={{ display: 'block', color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, marginTop: '1px', wordBreak: 'break-all' }}>{tg || '—'}</span>
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: '4px', flexShrink: 0, color: 'var(--accent)', fontSize: '10px', fontWeight: 600 }}>
          <Icon name="send" size={13} color="var(--accent)" /> Написать
        </span>
      </a>
      {isAdmin && onChange && (
        <button onClick={e => { e.stopPropagation(); setEditing(true) }} title="Изменить мой Telegram ID"
          style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px', display: 'flex', flexShrink: 0 }}>
          <Icon name="pencil" size={13} color="var(--text-muted)" />
        </button>
      )}
    </div>
  )
}

// Трек-номер у клиента: показ + копирование в буфер (с запасным способом для Telegram/iframe).
function TrackRow({ track, carrier }: { track: string; carrier?: DeliveryService }) {
  const [copied, setCopied] = useState(false)
  const copy = async () => {
    let ok = false
    try { await navigator.clipboard.writeText(track); ok = true } catch {}
    if (!ok) {
      try {
        const ta = document.createElement('textarea')
        ta.value = track; ta.style.position = 'fixed'; ta.style.top = '0'; ta.style.opacity = '0'
        document.body.appendChild(ta); ta.focus(); ta.select()
        document.execCommand('copy'); document.body.removeChild(ta); ok = true
      } catch {}
    }
    if (ok) { setCopied(true); setTimeout(() => setCopied(false), 1600) }
  }
  return (
    <button type="button" onClick={e => { e.stopPropagation(); copy() }}
      style={{ marginTop: '10px', width: '100%', display: 'flex', alignItems: 'center', gap: '8px', padding: '9px 11px', background: 'var(--bg-elevated)', border: `1px solid ${copied ? 'var(--success)' : 'var(--border)'}`, borderRadius: '10px', cursor: 'pointer', textAlign: 'left' }}>
      <Icon name="truck" size={15} color="var(--accent)" />
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ color: 'var(--text-muted)', fontSize: '9px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.5px', margin: 0 }}>Трек-номер{carrier ? ` · ${DELIVERY_LABELS[carrier]}` : ''}</p>
        <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, margin: '1px 0 0', fontFamily: 'monospace', letterSpacing: '0.5px', wordBreak: 'break-all' }}>{track}</p>
      </div>
      <span style={{ display: 'flex', alignItems: 'center', gap: '4px', flexShrink: 0, color: copied ? 'var(--success)' : 'var(--text-secondary)', fontSize: '10px', fontWeight: 600 }}>
        <Icon name={copied ? 'check' : 'save'} size={13} color={copied ? 'var(--success)' : 'var(--text-secondary)'} />
        {copied ? 'Скопировано' : 'Копировать'}
      </span>
    </button>
  )
}

function OrderCard({ order, isAdmin, shopContact, onShopContactChange }: {
  order: Order; isAdmin: boolean; shopContact: string; onShopContactChange?: (v: string) => void
}) {
  const [open, setOpen] = useState(false)
  const [zoom, setZoom] = useState(false)   // полноэкранный просмотр картинки заказа
  const meta = STATUS_META[order.status]
  const accent = statusAccent(order.status)
  const price = (order.painted ? order.price : order.priceUnpainted).toLocaleString()
  const payNote = order.payProvider && (order.payStatus === 'awaiting'
    ? { text: 'Ожидает подтверждения', color: '#f59e0b' }
    : order.payStatus === 'rejected'
    ? { text: 'Отменён · оплата не поступила', color: 'var(--danger)' }
    : order.paid
    ? { text: 'Оплата подтверждена', color: '#22c55e' }
    : { text: 'Ожидает оплаты', color: '#f59e0b' })

  return (
    <>
    <div className="glass-card" style={{ padding: '12px', overflow: 'hidden' }}>
      <div style={{ display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
        <button onClick={() => setZoom(true)} aria-label="Открыть картинку" title="Нажмите, чтобы увеличить"
          style={{ position: 'relative', padding: 0, border: 'none', background: 'none', cursor: 'zoom-in', flexShrink: 0, lineHeight: 0, borderRadius: '12px' }}>
          <img src={order.thumb} alt={order.name} style={{ width: '76px', height: '92px', borderRadius: '12px', objectFit: 'cover', display: 'block', border: '1px solid var(--border)' }} />
          <span aria-hidden style={{ position: 'absolute', right: '5px', bottom: '5px', width: '20px', height: '20px', borderRadius: '7px', display: 'grid', placeItems: 'center', background: 'rgba(6,6,12,0.62)', border: '1px solid var(--ss-hairline-lo, var(--border))', backdropFilter: 'blur(6px)' }}>
            <Icon name="eye" size={12} color="#fff" />
          </span>
        </button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '8px' }}>
            <div style={{ minWidth: 0 }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '15px', fontWeight: 700, margin: 0 }}>Заказ {order.id}</p>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '3px 0 0' }}>{order.date}</p>
            </div>
            <span style={{ flexShrink: 0, fontSize: '11px', fontWeight: 700, padding: '6px 11px', borderRadius: '10px', whiteSpace: 'nowrap', color: accent, background: `color-mix(in srgb, ${accent} 12%, transparent)`, border: `1px solid color-mix(in srgb, ${accent} 40%, transparent)` }}>{meta.label}</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: '8px', marginTop: '12px' }}>
            <div style={{ minWidth: 0 }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '13.5px', fontWeight: 600, margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{order.name}</p>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '3px 0 0', display: 'flex', alignItems: 'center', gap: '6px', flexWrap: 'wrap' }}>
                <span>{order.variantName ?? (order.painted ? 'С покраской' : 'Без покраски')} · 1 шт.</span>
                {typeof order.editionNo === 'number' && (
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: '3px', padding: '1px 7px', borderRadius: 'var(--ss-r-pill, 999px)', background: 'var(--ss-brand-wash)', border: '1px solid var(--ss-brand-edge)', color: 'var(--ss-brand-ink)', fontSize: '10px', fontWeight: 700 }}>💠 №{order.editionNo}{order.editionTotal ? ` / ${order.editionTotal}` : ''}</span>
                )}
              </p>
            </div>
            <span style={{ color: 'var(--text-primary)', fontSize: '16px', fontWeight: 700, flexShrink: 0 }}>{price} ₽</span>
          </div>
        </div>
      </div>

      <OrderProgress status={order.status} painted={order.painted} />

      {payNote && (
        <p style={{ margin: '12px 0 0', fontSize: '10.5px', fontWeight: 700, color: payNote.color, textAlign: 'center' }}>{payNote.text}</p>
      )}

      <button onClick={() => setOpen(v => !v)} style={{ width: '100%', boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px', marginTop: '12px', padding: '12px 14px', borderRadius: '12px', background: 'var(--bg-input)', border: '1px solid var(--border)', cursor: 'pointer' }}>
        <span style={{ color: 'var(--text-secondary)', fontSize: '13px', fontWeight: 500 }}>Подробнее о заказе</span>
        <div style={{ transform: open ? 'rotate(90deg)' : 'none', transition: 'transform 0.2s', display: 'flex' }}>
          <Icon name="chevron-right" size={16} color="var(--text-muted)" />
        </div>
      </button>

      {open && (
        <div className="ss-fade" style={{ marginTop: '10px' }}>
          <ContactRow tg={isAdmin ? order.userId : shopContact} isAdmin={isAdmin} ownContact={shopContact} onChange={onShopContactChange} />
          {order.track && <TrackRow track={order.track} carrier={order.carrier} />}
        </div>
      )}
    </div>

    {/* Полноэкранный просмотр картинки заказа */}
    {zoom && (
      <div className="overlay-fade" onClick={() => setZoom(false)}
        style={{ position: 'fixed', inset: 0, height: '100dvh', zIndex: 600, background: 'rgba(3,3,8,0.92)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px', cursor: 'zoom-out', touchAction: 'none' }}>
        <button onClick={() => setZoom(false)} aria-label="Закрыть"
          style={{ position: 'absolute', top: '16px', right: '16px', width: '38px', height: '38px', borderRadius: '12px', display: 'grid', placeItems: 'center', cursor: 'pointer', background: 'rgba(6,6,12,0.6)', border: '1px solid var(--ss-hairline-lo, var(--border))', backdropFilter: 'blur(8px)' }}>
          <Icon name="close" size={18} color="#fff" />
        </button>
        <img src={order.thumb} alt={order.name} onClick={e => e.stopPropagation()}
          style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain', borderRadius: '16px', boxShadow: '0 24px 80px -20px rgba(0,0,0,0.8)' }} />
        <p style={{ position: 'absolute', bottom: '18px', left: 0, right: 0, textAlign: 'center', color: 'rgba(255,255,255,0.8)', fontSize: '12.5px', fontWeight: 600, margin: 0, pointerEvents: 'none', padding: '0 24px' }}>{order.name}</p>
      </div>
    )}
    </>
  )
}

function OrdersView({ orders, isAdmin = false, shopContact = OWNER_TG, onShopContactChange }: {
  orders: Order[]; isAdmin?: boolean; shopContact?: string; onShopContactChange?: (v: string) => void
}) {
  // У клиента только «Все / В работе / Полученные»; у мастера — полный набор статусов.
  const [filter, setFilter] = useState<'all' | 'active' | OrderStatus>('all')
  const match = (o: Order, key: 'all' | 'active' | OrderStatus) =>
    key === 'all' ? true : key === 'active' ? o.status !== 'delivered' : o.status === key
  const filters: Array<{ key: 'all' | 'active' | OrderStatus; label: string }> = isAdmin
    ? [
        { key: 'all', label: 'Все' }, { key: 'new', label: 'Оплачен' }, { key: 'printing', label: 'Печать' },
        { key: 'painting', label: 'Красим' }, { key: 'ready', label: 'Готов' }, { key: 'delivered', label: 'Получен' },
      ]
    : [
        { key: 'all', label: 'Все' }, { key: 'active', label: 'В работе' }, { key: 'delivered', label: 'Полученные' },
      ]
  const visible = orders.filter(o => match(o, filter))
  const plural = orders.length % 10 === 1 && orders.length % 100 !== 11 ? 'заказ'
    : [2, 3, 4].includes(orders.length % 10) && ![12, 13, 14].includes(orders.length % 100) ? 'заказа' : 'заказов'

  return (
    <div style={{ paddingBottom: '20px' }}>
      {/* Шапка с приглушённым артом справа */}
      <div style={{ position: 'relative', overflow: 'hidden', padding: '18px 14px 16px' }}>
        <div aria-hidden style={{ position: 'absolute', top: 0, right: 0, bottom: 0, width: '58%', backgroundImage: `url(${profileArt})`, backgroundSize: 'cover', backgroundPosition: 'center top', opacity: 0.42, maskImage: 'linear-gradient(90deg, transparent 0%, #000 70%)', WebkitMaskImage: 'linear-gradient(90deg, transparent 0%, #000 70%)', pointerEvents: 'none' }} />
        <div aria-hidden style={{ position: 'absolute', inset: 0, background: 'radial-gradient(70% 120% at 0% 0%, rgba(124,58,237,0.22) 0%, transparent 65%)', pointerEvents: 'none' }} />
        <h1 style={{ position: 'relative', color: 'var(--text-primary)', fontSize: '27px', fontWeight: 700, letterSpacing: '-0.01em', margin: 0, textShadow: '0 2px 14px rgba(0,0,0,0.6)' }}>Мои заказы</h1>
        <p style={{ position: 'relative', color: 'var(--text-secondary)', fontSize: '13px', margin: '4px 0 0', textShadow: '0 2px 10px rgba(0,0,0,0.7)' }}>{orders.length} {plural}</p>
      </div>

      {/* Фильтры со счётчиками */}
      <div ref={hScroll} style={{ display: 'flex', gap: '8px', overflowX: 'auto', scrollbarWidth: 'none', padding: '0 14px 14px', WebkitOverflowScrolling: 'touch' }}>
        {filters.map(f => {
          const on = filter === f.key
          return (
            <button key={f.key} onClick={() => setFilter(f.key)}
              style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '9px 14px', borderRadius: '12px', whiteSpace: 'nowrap', fontSize: '13px', fontWeight: on ? 700 : 500, cursor: 'pointer',
                background: on ? 'var(--ss-brand-wash, var(--accent-glow))' : 'var(--bg-card)',
                color: on ? 'var(--ss-brand-hi, var(--accent))' : 'var(--text-secondary)',
                border: `1px solid ${on ? 'var(--ss-brand-hi, var(--accent))' : 'var(--border)'}`,
                boxShadow: on ? '0 0 20px -8px var(--ss-brand-glow, rgba(168,85,247,0.7))' : 'none' }}>
              {f.label}
              <span style={{ fontSize: '11px', fontWeight: 700, opacity: on ? 0.9 : 0.6 }}>{orders.filter(o => match(o, f.key)).length}</span>
            </button>
          )
        })}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', padding: '0 14px' }}>
        {visible.length === 0 ? (
          <div className="glass-card" style={{ padding: '40px 20px', textAlign: 'center' }}>
            <div style={{ width: '72px', height: '72px', margin: '0 auto', borderRadius: '22px', display: 'grid', placeItems: 'center', background: 'radial-gradient(circle at 50% 35%, var(--ss-brand-wash), transparent 70%)', border: '1px solid var(--ss-brand-edge)' }}>
              <Icon name="package" size={30} color="var(--ss-brand-hi, var(--accent))" />
            </div>
            <p style={{ color: 'var(--ss-ink)', fontSize: '14px', fontWeight: 700, margin: '14px 0 4px' }}>Заказов пока нет</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '12px', margin: 0, lineHeight: 1.5 }}>Оформленные заказы появятся здесь — со статусом печати, покраски и доставки в реальном времени.</p>
          </div>
        ) : visible.map(order => (
          <OrderCard key={order.id} order={order} isAdmin={isAdmin} shopContact={shopContact} onShopContactChange={onShopContactChange} />
        ))}
      </div>
    </div>
  )
}


// ─────────────────────────────────────────────────────────────
// FAQ
// ─────────────────────────────────────────────────────────────
function FAQView({ sections, initialOpen, supportTg }: { sections: FaqSection[]; initialOpen?: string | null; supportTg?: string }) {
  const [open, setOpen] = useState<string | null>(initialOpen ?? 'important')
  const DEFAULT_ICONS: Record<string, IconName> = { important: 'info', howto: 'cart', delivery: 'truck' }
  const supportHandle = (supportTg || OWNER_TG).replace(/^https?:\/\/t\.me\//, '').replace(/^@/, '')
  return (
    <div style={{ padding: '14px', paddingBottom: '24px' }}>
      <h1 style={{ color: 'var(--text-primary)', fontSize: '21px', fontWeight: 700, margin: '0 0 4px' }}>FAQ</h1>
      <p style={{ color: 'var(--text-secondary)', fontSize: '12px', margin: '0 0 18px' }}>Часто задаваемые вопросы</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {sections.map(sec => {
          const iconName: IconName = (sec.emoji && sec.emoji in PATHS) ? sec.emoji as IconName : (DEFAULT_ICONS[sec.id] ?? 'question')
          return (
            <div key={sec.id} className="glass-card" style={{ overflow: 'hidden' }}>
              <button onClick={() => setOpen(open === sec.id ? null : sec.id)} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: '12px', padding: '14px', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left' }}>
                <div style={{ width: '36px', height: '36px', borderRadius: '10px', background: 'var(--accent-glow)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><Icon name={iconName} size={16} color="var(--accent)" /></div>
                <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 600, margin: 0, flex: 1 }}>{sec.title}</p>
                <div style={{ transform: open === sec.id ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}><Icon name="chevron-down" size={16} color="var(--text-muted)" /></div>
              </button>
              {open === sec.id && <div style={{ padding: '0 14px 16px' }}><div style={{ height: '1px', background: 'var(--border)', marginBottom: '14px' }} />{sec.content.split('\n\n').map((p, i) => <p key={i} style={{ color: 'var(--text-secondary)', fontSize: '13px', lineHeight: 1.65, margin: i === 0 ? '0 0 10px' : '10px 0 0' }}>{p}</p>)}</div>}
            </div>
          )
        })}
      </div>

      {/* Фиксированная кнопка техподдержки — связаться с мастером (создателем) */}
      <a href={`https://t.me/${supportHandle}`} target="_blank" rel="noopener noreferrer"
        style={{ position: 'sticky', bottom: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px', marginTop: '18px', padding: '14px 16px', borderRadius: '16px', textDecoration: 'none', background: 'var(--accent-grad)', border: '1px solid var(--accent-2, #4f8dff)', boxShadow: '0 8px 26px -10px var(--accent-2, #4f8dff)', cursor: 'pointer' }}>
        <div style={{ width: '34px', height: '34px', borderRadius: '50%', background: 'rgba(255,255,255,0.16)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Icon name="send" size={17} color="#fff" />
        </div>
        <div style={{ minWidth: 0 }}>
          <p style={{ color: '#fff', fontSize: '14px', fontWeight: 700, margin: 0 }}>Техподдержка</p>
          <p style={{ color: 'rgba(255,255,255,0.85)', fontSize: '11px', margin: 0 }}>Связаться с мастером — @{supportHandle}</p>
        </div>
      </a>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────
// Icon picker
// ─────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────
// CRM
// ─────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────
// Settings
// ─────────────────────────────────────────────────────────────
function SettingsView({ profile, onProfileChange, promocodes, authLogin, onReplayOnboard, onResetOnboardAll }: { profile: UserProfile; onProfileChange: (p: UserProfile) => void; promocodes: PromoCode[]; authLogin: string; onReplayOnboard?: () => void; onResetOnboardAll?: () => void }) {
  const { theme, toggle } = useTheme()
  const { user } = useAuth()
  const [notif, setNotif] = useState(true)
  const [editingAddress, setEditingAddress] = useState(false)
  const [addrDraft, setAddrDraft] = useState({ city: profile.city, address: profile.address, deliveryService: profile.deliveryService })
  useEffect(() => { setAddrDraft({ city: profile.city, address: profile.address, deliveryService: profile.deliveryService }) }, [profile.city, profile.address, profile.deliveryService])
  const saveAddress = () => { onProfileChange({ ...profile, ...addrDraft }); setEditingAddress(false) }

  // Промокод
  const [promoInput, setPromoInput] = useState(profile.promoCode ?? '')
  const [promoMsg, setPromoMsg] = useState<{ ok: boolean; text: string } | null>(null)
  const applyPromo = () => {
    const code = promoInput.trim().toUpperCase()
    if (!code) return
    const { promo, error } = evalPromo(promocodes, code, authLogin)
    if (promo) {
      // Привязываем код к профилю; списывается он уже при оформлении заказа.
      onProfileChange({ ...profile, promoCode: promo.code })
      setPromoMsg({ ok: true, text: `Промокод активирован — скидка ${promo.discount}%` })
    } else {
      setPromoMsg({ ok: false, text: error ?? 'Ошибка' })
    }
  }
  const removePromo = () => {
    onProfileChange({ ...profile, promoCode: '' })
    setPromoInput('')
    setPromoMsg(null)
  }
  const activeDiscount = profile.promoCode
    ? promocodes.find(p => p.code.toUpperCase() === profile.promoCode!.toUpperCase())?.discount ?? PROMO_CODES[profile.promoCode]
    : undefined

  // Единый стиль карточки-раздела в фирменной фиолетовой гамме бота.
  const ssCard: React.CSSProperties = { position: 'relative', overflow: 'hidden', background: 'linear-gradient(160deg, var(--ss-brand-wash, rgba(124,58,237,0.06)) 0%, var(--bg-card) 60%)', border: '1px solid var(--ss-brand-edge, var(--border))', borderRadius: '16px', padding: '14px', marginBottom: '12px', boxShadow: 'var(--ss-e2)' }
  const SsHead = ({ icon, title }: { icon: IconName; title: string }) => (
    <div style={{ display: 'flex', alignItems: 'center', gap: '9px', marginBottom: '12px' }}>
      <span aria-hidden style={{ display: 'grid', placeItems: 'center', width: 28, height: 28, borderRadius: 'var(--ss-r-sm, 9px)', background: 'var(--ss-brand-wash)', border: '1px solid var(--ss-brand-edge)', color: 'var(--ss-brand-hi)', boxShadow: '0 0 20px -8px var(--ss-brand-glow)', flexShrink: 0 }}>
        <Icon name={icon} size={14} color="var(--ss-brand-hi, var(--accent))" />
      </span>
      <span style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, letterSpacing: '0.01em' }}>{title}</span>
    </div>
  )
  return (
    <div style={{ padding: '14px', paddingBottom: '20px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', margin: '0 0 18px' }}>
        <h1 style={{ color: 'var(--text-primary)', fontSize: '21px', fontWeight: 700, margin: 0 }}>Настройки</h1>
        <span aria-hidden style={{ flex: 1, height: 1, background: 'linear-gradient(90deg, var(--ss-brand-edge), transparent)' }} />
      </div>
      <div style={ssCard}>
        <SsHead icon="person" title="Личные данные" />
        <div style={{ borderBottom: '1px solid var(--ss-hairline-lo, var(--border))', paddingBottom: '10px', marginBottom: '10px' }}>
          <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '0 0 3px' }}>Telegram ID</p>
          <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: 0 }}>{user?.name ?? '—'}</p>
        </div>
        <EditableField label="Ник / Имя" value={profile.nickname} placeholder="Не указан (будет использован Telegram ID)" onSave={v => onProfileChange({ ...profile, nickname: v })} />
        <EditableField label="Email" value={profile.email} placeholder="Не указан" type="email" onSave={v => onProfileChange({ ...profile, email: v })} noBorder />
      </div>

      {/* Промокод */}
      <div style={ssCard}>
        <SsHead icon="gift" title="Промокод" />
        {activeDiscount ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '10px 12px', background: 'var(--accent-glow)', border: '1px solid var(--accent)', borderRadius: '10px' }}>
            <Icon name="check" size={16} color="var(--accent)" />
            <div style={{ flex: 1 }}>
              <p style={{ color: 'var(--accent)', fontSize: '13px', fontWeight: 700, margin: '0 0 1px' }}>{profile.promoCode}</p>
              <p style={{ color: 'var(--text-secondary)', fontSize: '11px', margin: 0 }}>Скидка {activeDiscount}% применится при заказе</p>
            </div>
            <button onClick={removePromo} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '4px' }}><Icon name="close" size={15} color="var(--text-muted)" /></button>
          </div>
        ) : (
          <>
            <div style={{ display: 'flex', gap: '6px' }}>
              <div className="search-glow" style={{ position: 'relative', flex: 1, borderRadius: '10px' }}>
                <input value={promoInput} onChange={e => { setPromoInput(e.target.value); setPromoMsg(null) }} onKeyDown={e => e.key === 'Enter' && applyPromo()}
                  placeholder="Введите промокод" style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '10px 12px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', textTransform: 'uppercase', letterSpacing: '1px', boxSizing: 'border-box' }} />
              </div>
              <button onClick={applyPromo} style={{ padding: '10px 16px', background: 'var(--accent-grad)', border: 'none', borderRadius: '10px', color: '#fff', fontSize: '13px', fontWeight: 600, cursor: 'pointer', flexShrink: 0 }}>Применить</button>
            </div>
            {promoMsg && <p style={{ color: promoMsg.ok ? 'var(--status-ready-color)' : 'var(--danger)', fontSize: '11px', margin: '8px 0 0', fontWeight: 500 }}>{promoMsg.text}</p>}
          </>
        )}
      </div>

      <div style={{ ...ssCard, padding: 0 }}>
        <div style={{ padding: '14px 14px 0' }}>
          <SsHead icon="gear" title="Внешний вид и уведомления" />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', padding: '12px 14px', gap: '12px', borderTop: '1px solid var(--ss-hairline-lo, var(--border))' }}>
          <Icon name={theme === 'dark' ? 'moon' : 'sun'} size={16} color="var(--text-muted)" />
          <div style={{ flex: 1 }}>
            <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 500, margin: '0 0 1px' }}>{theme === 'dark' ? 'Тёмная тема' : 'Светлая тема'}</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Переключить на {theme === 'dark' ? 'светлую' : 'тёмную'}</p>
          </div>
          <Toggle on={theme === 'light'} onToggle={toggle} />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', padding: '12px 14px', gap: '12px' }}>
          <Icon name="bell" size={16} color="var(--text-muted)" />
          <div style={{ flex: 1 }}>
            <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 500, margin: '0 0 1px' }}>Уведомления</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Статус заказа</p>
          </div>
          <Toggle on={notif} onToggle={() => setNotif(p=>!p)} />
        </div>
        {onReplayOnboard && (
          <div style={{ display: 'flex', alignItems: 'center', padding: '12px 14px', gap: '12px', borderTop: '1px solid var(--ss-hairline-lo, var(--border))' }}>
            <Icon name="planet" size={16} color="var(--text-muted)" />
            <div style={{ flex: 1 }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 500, margin: '0 0 1px' }}>Экскурсия по приложению</p>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Приветственный тур — можно пройти снова</p>
            </div>
            <button onClick={onReplayOnboard} className="ss-press"
              style={{ padding: '7px 12px', borderRadius: '9px', background: 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', color: 'var(--accent-2-hi)', fontSize: '11.5px', fontWeight: 650, cursor: 'pointer', fontFamily: 'inherit', flexShrink: 0 }}>Пройти</button>
          </div>
        )}
        {onResetOnboardAll && (
          <div style={{ display: 'flex', alignItems: 'center', padding: '12px 14px', gap: '12px', borderTop: '1px solid var(--ss-hairline-lo, var(--border))' }}>
            <Icon name="users" size={16} color="var(--text-muted)" />
            <div style={{ flex: 1 }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 500, margin: '0 0 1px' }}>Показать обучение всем заново</p>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Тур снова покажется каждому пользователю при входе</p>
            </div>
            <button onClick={onResetOnboardAll} className="ss-press"
              style={{ padding: '7px 12px', borderRadius: '9px', background: 'var(--ss-blue-wash, var(--accent-2-wash))', border: '1px solid var(--ss-blue-edge, var(--accent-2))', color: 'var(--ss-blue-ink, var(--accent-2-hi))', fontSize: '11.5px', fontWeight: 650, cursor: 'pointer', fontFamily: 'inherit', flexShrink: 0 }}>Сбросить</button>
          </div>
        )}
      </div>

      <div style={{ ...ssCard, marginBottom: '16px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
          <SsHead icon="pin" title="Адрес доставки" />
          {!editingAddress
            ? <button onClick={() => setEditingAddress(true)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--accent-2-hi)', fontSize: '10px', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '3px', padding: 0 }}><Icon name="pencil" size={10} color="var(--accent-2-hi)" /> Изменить</button>
            : <div style={{ display: 'flex', gap: '10px' }}>
                <button onClick={() => { setEditingAddress(false); setAddrDraft({ city: profile.city, address: profile.address, deliveryService: profile.deliveryService }) }} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, padding: 0 }}>Отмена</button>
                <button onClick={saveAddress} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--status-ready-color)', fontSize: '10px', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '3px', padding: 0 }}><Icon name="check" size={10} color="var(--status-ready-color)" /> Сохранить</button>
              </div>}
        </div>
        <div style={{ borderBottom: '1px solid var(--border)', paddingBottom: '10px', marginBottom: '10px' }}>
          <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '0 0 6px' }}>Способ доставки</p>
          {editingAddress ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '5px' }}>
              {DELIVERY_OPTIONS.map(opt => {
                const isActive = addrDraft.deliveryService === opt.key
                return (
                  <button key={opt.key} onClick={() => setAddrDraft(d=>({...d,deliveryService:opt.key}))}
                    style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '9px 12px', background: isActive ? 'var(--accent-2-wash)' : 'var(--bg-input)', border: `1px solid ${isActive ? 'var(--accent-2)' : 'var(--border)'}`, borderRadius: '10px', cursor: 'pointer', textAlign: 'left' }}>
                    <div style={{ width: '28px', height: '28px', borderRadius: '7px', background: isActive ? 'var(--accent-2-grad)' : 'var(--bg-elevated)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <Icon name={opt.icon} size={14} color={isActive ? '#fff' : 'var(--text-muted)'} />
                    </div>
                    <div style={{ flex: 1 }}>
                      <p style={{ color: isActive ? 'var(--accent-2-hi)' : 'var(--text-primary)', fontSize: '13px', fontWeight: isActive ? 600 : 400, margin: '0 0 1px' }}>{opt.label}</p>
                      <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0 }}>{opt.sub}</p>
                    </div>
                    {isActive && <Icon name="check" size={14} color="var(--accent-2-hi)" />}
                  </button>
                )
              })}
            </div>
          ) : (
            <p style={{ color: profile.deliveryService ? 'var(--text-primary)' : 'var(--text-muted)', fontSize: '13px', fontWeight: profile.deliveryService ? 500 : 400, margin: 0, fontStyle: profile.deliveryService ? 'normal' : 'italic' }}>
              {profile.deliveryService ? DELIVERY_LABELS[profile.deliveryService] : 'Не выбран'}
            </p>
          )}
        </div>
        <div style={{ borderBottom: '1px solid var(--border)', paddingBottom: '10px', marginBottom: '10px' }}>
          <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '0 0 4px' }}>Город</p>
          {editingAddress
            ? <input value={addrDraft.city} onChange={e => setAddrDraft(d=>({...d,city:e.target.value}))} placeholder="Москва" style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '8px', padding: '7px 10px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box', marginTop: '4px' }} />
            : <p style={{ color: profile.city ? 'var(--text-primary)' : 'var(--text-muted)', fontSize: '13px', fontWeight: profile.city ? 500 : 400, margin: 0, fontStyle: profile.city ? 'normal' : 'italic' }}>{profile.city || 'Не указан'}</p>}
        </div>
        <div>
          <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '0 0 4px' }}>Адрес</p>
          {editingAddress
            ? <>
                <input value={addrDraft.address} onChange={e => setAddrDraft(d=>({...d,address:e.target.value}))} placeholder="ул. Тверская, д. 10" style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '8px', padding: '7px 10px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box', marginTop: '4px' }} />
                <p style={{ color: 'var(--accent)', fontSize: '10px', margin: '5px 0 0', lineHeight: 1.45 }}>Укажите адрес пункта выдачи выбранной службы доставки.</p>
              </>
            : <p style={{ color: profile.address ? 'var(--text-primary)' : 'var(--text-muted)', fontSize: '13px', fontWeight: profile.address ? 500 : 400, margin: 0, fontStyle: profile.address ? 'normal' : 'italic' }}>{profile.address || 'Не указан'}</p>}
        </div>
      </div>
      {editingAddress && <button className="btn-primary" onClick={saveAddress} style={{ marginBottom: '16px' }}>Сохранить адрес</button>}
    </div>
  )
}

// ─────────────────────────────────────────────────────────────
// Root App
// ─────────────────────────────────────────────────────────────

// «Тяжёлые» ключи, которые могут содержать base64-картинки или большие списки.
// Чтобы не перекачивать их из облака каждые 5 секунд (это и съедало десятки ГБ
// трафика PostgREST), мы держим рядом крошечную «ревизию» rev:<key> = timestamp
// и тянем полное значение ТОЛЬКО когда ревизия изменилась. Опрос вхолостую теперь
// стоит сотни байт вместо мегабайтов.
const GATED_KEYS = [
  'products', 'sections', 'home', 'banner', 'faq', 'materials', 'reviews',
  'profiles', 'orders', 'promocodes', 'customOrder', 'notice', 'allFavorites',
  'lastseen', 'roles', 'sbpInfo', 'payMethods', 'crmOrder', 'crmLeft', 'coverMode', 'loyalty', 'catalogFilters', 'waitlist',
  'appVersion', 'onboardEpoch', 'shopStatus',
] as const
// Мелкие ключи без картинок — тянем каждый цикл, они дешёвые.
const ALWAYS_KEYS = ['users', 'deletedOrders'] as const
const REV_SET = new Set<string>(GATED_KEYS)

export default function App() {
  const [theme, setTheme]   = useLocalStorage<'dark'|'light'>('theme', 'dark')
  const [authUser, setAuthUser] = useState<AuthUser | null>(null)
  const [tab, setTab]       = useState<Tab>('catalog')
  // Какой раздел FAQ раскрыть при переходе (например, «доставка» с главной)
  const [faqTarget, setFaqTarget] = useState<string | null>(null)
  // С каким фильтром открыть Каталог (кнопка «Ещё» в «Популярном» → «Избранное»)
  const [catalogInitFilter, setCatalogInitFilter] = useState<'all' | 'favorites' | 'orders'>('all')
  const [toast, setToast]   = useState('')
  // Офлайн-режим: каталог, избранное и заказы уже хранятся локально (useLocalStorage),
  // поэтому при обрыве сети приложение продолжает работать на сохранённых данных —
  // показываем только индикатор, что данные могут быть неактуальны.
  const [online, setOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true)
  useEffect(() => {
    const up = () => setOnline(true)
    const down = () => setOnline(false)
    window.addEventListener('online', up)
    window.addEventListener('offline', down)
    return () => { window.removeEventListener('online', up); window.removeEventListener('offline', down) }
  }, [])
  const [showWelcome, setShowWelcome] = useState(false)
  const [welcomeLeaving, setWelcomeLeaving] = useState(false)
  const [welcomeNoShow, setWelcomeNoShow] = useLocalStorage<boolean>('welcomeNoShow', false)
  // Закрытие приветственного окна: анимация сжатия/исчезновения ~250 мс.
  const closeWelcome = useCallback(() => {
    setWelcomeLeaving(true)
    setTimeout(() => { setShowWelcome(false); setWelcomeLeaving(false) }, 250)
  }, [])
  // Разовый сброс флага «больше не показывать» — возвращает приветственное окно
  // (например, если его случайно отключили). Срабатывает один раз на устройство.
  useEffect(() => {
    try {
      if (!localStorage.getItem('welcomeResetV1')) {
        localStorage.setItem('welcomeResetV1', '1')
        setWelcomeNoShow(false)
      }
    } catch {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  // Небольшой тост об успешном заказе (справа снизу, сам исчезает).
  const [orderToast, setOrderToast] = useState<{ text: string; leaving: boolean } | null>(null)
  const showOrderToast = useCallback((text: string) => {
    setOrderToast({ text, leaving: false })
    setTimeout(() => setOrderToast(t => t ? { ...t, leaving: true } : t), 3600)
    setTimeout(() => setOrderToast(null), 4000)
  }, [])

  // ── Все данные хранятся в localStorage (offline-first) + синхронизируются с Supabase kv_store ──
  const [orders, setOrders]           = useLocalStorage<Order[]>('orders', [])
  const [products, setProducts]       = useLocalStorage<Product[]>('products', INIT_PRODUCTS)
  const [sections, setSections]       = useLocalStorage<CatalogSection[]>('sections', INIT_SECTIONS)
  const [faqSections, setFaqSections] = useLocalStorage<FaqSection[]>('faq', INIT_FAQ)
  const [materials, setMaterials]     = useLocalStorage<Material[]>('materials', INIT_MATERIALS)
  const [reviews, setReviews]         = useLocalStorage<Review[]>('reviews', INIT_REVIEWS)
  const [notice, setNotice]           = useLocalStorage<NoticeContent>('notice', INIT_NOTICE)
  const [banner, setBanner]           = useLocalStorage<BannerConfig>('banner', INIT_BANNER)
  const [home, setHome]               = useLocalStorage<HomeConfig>('home', INIT_HOME)
  const [appVersion, setAppVersion]   = useLocalStorage<string>('appVersion', APP_VERSION)
  const [onboardEpoch, setOnboardEpoch] = useLocalStorage<number>('onboardEpoch', 1)
  const [customOrder, setCustomOrder] = useLocalStorage<CustomOrderConfig>('customOrder', INIT_CUSTOM_ORDER)
  const [crmOrder, setCrmOrder]       = useLocalStorage<string[]>('crmOrder', [])
  const [crmLeft, setCrmLeft]         = useLocalStorage<string[]>('crmLeft', [])
  // Лист ожидания: productId → список логинов, ждущих открытия окна/нового тиража.
  const [waitlist, setWaitlist]       = useLocalStorage<Record<string, string[]>>('waitlist', {})
  const [coverMode, setCoverMode]     = useLocalStorage<CoverMode>('coverMode', INIT_COVER_MODE)
  const [promocodes, setPromocodes]   = useLocalStorage<PromoCode[]>('promocodes', INIT_PROMOS)
  const [loyalty, setLoyalty]         = useLocalStorage<LoyaltyConfig>('loyalty', INIT_LOYALTY)
  const [catalogFilters, setCatalogFilters] = useLocalStorage<CatalogFilterButton[]>('catalogFilters', INIT_CATALOG_FILTERS)
  const [registeredUsers, setRegisteredUsers] = useLocalStorage<RegisteredUser[]>('regusers', [])
  const [profiles, setProfiles]       = useLocalStorage<Record<string, UserProfile>>('profiles', {})
  const [lastSeenTimes, setLastSeenTimes] = useLocalStorage<Record<string, number>>('lastseen', {})
  // Избранное хранится отдельно для каждого пользователя
  const [allFavorites, setAllFavorites] = useLocalStorage<Record<string, number[]>>('allFavorites', {})
  // Какие способы оплаты включены (управляется из админ-панели, синхронизируется)
  const [payEnabled, setPayEnabled] = useLocalStorage<Record<string, boolean>>('payMethods', DEFAULT_PAY_ENABLED)
  // Роли сотрудников: '@username' → роль. Владелец задаётся кодом и неизменяем.
  const [roles, setRoles] = useLocalStorage<Record<string, Role>>('roles', {})
  // Открытое окно с реквизитами для перевода по СБП.
  const [sbpPay, setSbpPay] = useState<{ order: Order; amount: number; promoId?: string; productId?: number } | null>(null)
  // Запрос адреса доставки перед оплатой, если он не заполнен в профиле.
  const [addrPrompt, setAddrPrompt] = useState<{ order: Order; amount: number; promoId?: string; productId?: number } | null>(null)
  const [addrPromptDraft, setAddrPromptDraft] = useState<{ deliveryService: DeliveryService; address: string }>({ deliveryService: '', address: '' })
  const [sbpInfo, setSbpInfo] = useLocalStorage<SbpInfo>('sbpInfo', INIT_SBP)
  // Режим «магазин на паузе»: баннер клиентам + блокировка новых заказов.
  const [shopStatus, setShopStatus] = useLocalStorage<ShopStatus>('shopStatus', INIT_SHOP_STATUS)
  // ID удалённых заказов: «надгробия» не дают устройству со старой копией
  // вернуть удалённый заказ в облако. Храним последние 500 записей.
  const [deletedOrders, setDeletedOrders] = useLocalStorage<string[]>('deletedOrders', [])
  const deletedOrdersRef = useRef<string[]>(deletedOrders)
  useEffect(() => { deletedOrdersRef.current = deletedOrders }, [deletedOrders])
  // Актуальный список заказов для таймеров — чтобы не пересоздавать интервалы.
  const ordersRef = useRef<Order[]>(orders)
  useEffect(() => { ordersRef.current = orders }, [orders])
  const productsRef = useRef<Product[]>(products)
  useEffect(() => { productsRef.current = products }, [products])

  // Утилита: debounced push конкретного ключа
  const pushTimers = useRef<Record<string, ReturnType<typeof setTimeout>>>({})
  // Запомненные ревизии тяжёлых ключей — чтобы понимать, что реально изменилось.
  const revSeen = useRef<Record<string, number>>({})
  // Когда последний раз показывали тост про исчерпанную квоту облака.
  const quotaToastAt = useRef<number>(0)
  // Пишем метку ревизии рядом с ключом; ставим и в revSeen, чтобы собственный
  // push не спровоцировал лишнюю перекачку этого же ключа на следующем опросе.
  const bumpRev = useCallback((key: string) => {
    if (!REV_SET.has(key)) return
    const now = Date.now()
    revSeen.current[key] = now
    kv.set(`rev:${key}`, now).catch(() => { /* ревизия некритична, догонит */ })
  }, [])
  const kvPush = useCallback((key: string, value: unknown, delay = 400) => {
    if (pushTimers.current[key]) clearTimeout(pushTimers.current[key])
    pushTimers.current[key] = setTimeout(() => {
      kv.set(key, value).then(() => bumpRev(key)).catch((err) => {
        // Квота проекта исчерпана — это не «ошибка приложения», а лимит облака.
        // Не спамим тостами на каждую запись: показываем одно спокойное уведомление
        // не чаще раза в 2 минуты и не шумим в консоли на служебных ключах.
        if (err instanceof CloudQuotaError) {
          const now = Date.now()
          if (now - quotaToastAt.current > 120000) {
            quotaToastAt.current = now
            setToast('☁ Облако на паузе: превышена квота проекта. Данные сохранены локально.')
            setTimeout(() => setToast(''), 6000)
          }
          return
        }
        // Прочие ошибки записи по-прежнему показываем с причиной.
        console.error('[cloud sync] запись не удалась:', key, err)
        setToast(`⚠ Облако: ${err?.message ?? 'ошибка записи'}`)
        setTimeout(() => setToast(''), 6000)
      })
    }, delay)
  }, [bumpRev])

  // Удаление заказов «навсегда»: список ID уходит в облако отдельным ключом,
  // поэтому заказ не вернётся ни после обновления, ни с другого устройства.
  const forgetOrders = useCallback((ids: string[]) => {
    if (!ids.length) return
    const kill = new Set(ids)
    setOrders(prev => {
      const next = prev.filter(o => !kill.has(o.id))
      kvPush('orders', next, 0)
      return next
    })
    setDeletedOrders(prev => {
      const union = Array.from(new Set([...prev, ...ids])).slice(-500)
      deletedOrdersRef.current = union
      return union
    })
    // Сливаем с облачным списком, чтобы не затереть удаления с других устройств.
    ;(async () => {
      try {
        const cloud = (await kv.get('deletedOrders')) as string[] | null
        const union = Array.from(new Set([...(Array.isArray(cloud) ? cloud : []), ...deletedOrdersRef.current])).slice(-500)
        deletedOrdersRef.current = union
        setDeletedOrders(union)
        await kv.set('deletedOrders', union)
      } catch { /* offline — синхронизируется при следующем удалении */ }
    })()
  }, [kvPush, setOrders, setDeletedOrders])

  // Синхронизация с облаком: тянем все данные из kv_store
  const refreshState = useCallback(async () => {
    try {
      const pending = (key: string) => !!pushTimers.current[key]
      // Шаг 1 — дешёвый опрос: тянем только крошечные ревизии тяжёлых ключей и
      // мелкие «всегда» ключи. Это сотни байт вместо мегабайтов на каждый цикл.
      const head = await kv.mget([...GATED_KEYS.map(k => `rev:${k}`), ...ALWAYS_KEYS])
      // Определяем, какие тяжёлые ключи реально изменились с прошлого раза.
      const changed = (GATED_KEYS as readonly string[]).filter(k => {
        if (pending(k)) return false
        const r = head[`rev:${k}`]
        const seen = revSeen.current[k]
        if (typeof r === 'number') return seen !== r
        // Ревизии ещё нет (данные записаны до этого обновления) — тянем один раз.
        return seen === undefined
      })
      // Шаг 2 — полностью подтягиваем ТОЛЬКО изменившиеся ключи.
      const heavy = changed.length ? await kv.mget(changed) : {}
      for (const k of changed) revSeen.current[k] = typeof head[`rev:${k}`] === 'number' ? head[`rev:${k}`] as number : 0
      const cloud: Record<string, any> = { ...heavy, users: head.users, deletedOrders: head.deletedOrders }
      // Не применяем облачное значение, если по этому ключу есть несохранённая
      // локальная правка (иначе опрос затрёт то, что пользователь только что изменил).
      // Для «списочных» ключей игнорируем пустой массив из облака — он почти всегда
      // означает устаревшее/затёртое значение и не должен обнулять локальные данные.
      // Для товаров применяем даже пустой массив: kv.mget не возвращает ключ,
      // которого нет в облаке (тогда cloud.products === undefined и мы сохраняем
      // локальные значения), а пустой [] приходит ТОЛЬКО когда владелец реально
      // удалил все товары — это удаление должно доходить до всех устройств.
      if (Array.isArray(cloud.products) && !pending('products'))
        setProducts(cloud.products as Product[])
      if (Array.isArray(cloud.sections) && cloud.sections.length && !pending('sections'))
        setSections(cloud.sections as CatalogSection[])
      if (Array.isArray(cloud.faq) && cloud.faq.length && !pending('faq'))
        setFaqSections(cloud.faq as FaqSection[])
      if (Array.isArray(cloud.materials) && cloud.materials.length && !pending('materials'))
        setMaterials(cloud.materials as Material[])
      if (Array.isArray(cloud.reviews) && cloud.reviews.length && !pending('reviews'))
        setReviews(cloud.reviews as Review[])
      if (cloud.notice && typeof cloud.notice === 'object' && !pending('notice')) setNotice(cloud.notice as NoticeContent)
      if (cloud.banner && typeof cloud.banner === 'object' && !pending('banner')) setBanner(cloud.banner as BannerConfig)
      if (cloud.home && typeof cloud.home === 'object' && !pending('home')) setHome(cloud.home as HomeConfig)
      if (typeof cloud.appVersion === 'string' && cloud.appVersion.trim() && !pending('appVersion')) setAppVersion(cloud.appVersion)
      if (typeof cloud.onboardEpoch === 'number' && !pending('onboardEpoch')) setOnboardEpoch(cloud.onboardEpoch)
      if (cloud.customOrder && typeof cloud.customOrder === 'object' && !pending('customOrder')) setCustomOrder(cloud.customOrder as CustomOrderConfig)
      if (Array.isArray(cloud.crmOrder) && !pending('crmOrder')) setCrmOrder(cloud.crmOrder as string[])
      if (Array.isArray(cloud.crmLeft) && !pending('crmLeft')) setCrmLeft(cloud.crmLeft as string[])
      if (cloud.waitlist && typeof cloud.waitlist === 'object' && !pending('waitlist')) setWaitlist(cloud.waitlist as Record<string, string[]>)
      if ((cloud.coverMode === 'owner' || cloud.coverMode === 'all') && !pending('coverMode')) setCoverMode(cloud.coverMode)
      if (Array.isArray(cloud.promocodes) && !pending('promocodes')) {
        // Мерджим по id (как заказы), чтобы промики не терялись между устройствами
        // и надёжно доходили до сумки пользователя. Счётчик использований берём максимальный.
        setPromocodes(prev => {
          const map = new Map(prev.map(p => [p.id, p]))
          for (const c of cloud.promocodes as PromoCode[]) {
            const ex = map.get(c.id)
            map.set(c.id, ex ? { ...c, uses: Math.max(ex.uses, c.uses) } : c)
          }
          return Array.from(map.values()).sort((a, b) => b.createdAt - a.createdAt)
        })
      }
      if (cloud.loyalty && typeof cloud.loyalty === 'object' && !pending('loyalty'))
        setLoyalty(loyaltyCfg(cloud.loyalty as Partial<LoyaltyConfig>))
      if (Array.isArray(cloud.catalogFilters) && !pending('catalogFilters'))
        setCatalogFilters(cloud.catalogFilters as CatalogFilterButton[])
      if (cloud.roles && typeof cloud.roles === 'object' && !pending('roles'))
        setRoles(cloud.roles as Record<string, Role>)
      if (cloud.sbpInfo && typeof cloud.sbpInfo === 'object' && !pending('sbpInfo'))
        setSbpInfo(cloud.sbpInfo as SbpInfo)
      if (cloud.payMethods && typeof cloud.payMethods === 'object' && !pending('payMethods'))
        setPayEnabled({ ...DEFAULT_PAY_ENABLED, ...(cloud.payMethods as Record<string, boolean>) })
      if (cloud.shopStatus && typeof cloud.shopStatus === 'object' && !pending('shopStatus'))
        setShopStatus({ ...INIT_SHOP_STATUS, ...(cloud.shopStatus as Partial<ShopStatus>) })
      if (cloud.allFavorites && typeof cloud.allFavorites === 'object' && !pending('allFavorites'))
        setAllFavorites(prev => ({ ...prev, ...(cloud.allFavorites as Record<string, number[]>) }))
      if (Array.isArray(cloud.users) && !pending('users')) {
        setRegisteredUsers(prev => {
          const map = new Map(prev.map(u => [u.login, u]))
          for (const u of cloud.users as RegisteredUser[]) map.set(u.login, u)
          return Array.from(map.values())
        })
      }
      // Без проверки pending опрос раз в 5 секунд успевал затереть только что
      // загруженную аватарку старым облачным профилем.
      if (cloud.profiles && typeof cloud.profiles === 'object' && !pending('profiles'))
        setProfiles(prev => ({ ...prev, ...(cloud.profiles as Record<string, UserProfile>) }))
      // «Был в сети» тоже общий: иначе в CRM время последнего визита видно только
      // на том устройстве, с которого человек заходил. Берём максимум из двух.
      if (cloud.lastseen && typeof cloud.lastseen === 'object' && !pending('lastseen'))
        setLastSeenTimes(prev => {
          const next = { ...prev }
          for (const [l, t] of Object.entries(cloud.lastseen as Record<string, number>))
            if (typeof t === 'number' && t > (next[l] ?? 0)) next[l] = t
          return next
        })
      // Удалённые заказы помним отдельным списком-«надгробием»: без него любое
      // устройство со старой копией возвращало удалённый заказ обратно всем.
      const cloudDeleted = Array.isArray(cloud.deletedOrders) ? (cloud.deletedOrders as string[]) : []
      let killed = deletedOrdersRef.current
      if (cloudDeleted.length) {
        const union = Array.from(new Set([...killed, ...cloudDeleted]))
        if (union.length !== killed.length) { killed = union; setDeletedOrders(union) }
      }
      if (Array.isArray(cloud.orders)) {
        const kill = new Set(killed)
        setOrders(prev => {
          const map = new Map(prev.map(o => [o.id, o]))
          for (const o of cloud.orders as Order[]) map.set(o.id, o)
          for (const id of kill) map.delete(id)
          return Array.from(map.values()).sort((a, b) => (a.id < b.id ? 1 : -1))
        })
      }
    } catch (e) {
      // Offline или сервер перегружен — продолжаем работать из localStorage,
      // но пробрасываем ошибку, чтобы цикл опроса ушёл в бэкофф и не добивал бэкенд.
      throw e
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [setDeletedOrders])

  // Опрос облака. Вместо жёсткого setInterval раз в 5 сек используем адаптивный
  // цикл, который бережёт и клиента, и сервер при наплыве пользователей:
  //  • пока вкладка скрыта — не долбим сеть вообще (у Telegram WebApp это частый кейс);
  //  • базовый интервал 5 сек + случайный джиттер, чтобы тысячи клиентов не били
  //    в одну и ту же секунду («thundering herd»);
  //  • при ошибке (сервер перегружен/лежит) — экспоненциальный бэкофф до 60 сек,
  //    так толпа не добивает уже упавший бэкенд запросами.
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout> | undefined
    let stopped = false
    let fails = 0
    const BASE = 5000, MAX = 60000
    const jitter = () => Math.floor(Math.random() * 1500)
    const schedule = (ms: number) => { if (!stopped) timer = setTimeout(loop, ms + jitter()) }
    async function loop() {
      if (stopped) return
      if (typeof document !== 'undefined' && document.hidden) { schedule(BASE); return }
      try {
        await refreshState()
        fails = 0
        schedule(BASE)
      } catch {
        fails = Math.min(fails + 1, 5)
        schedule(Math.min(BASE * 2 ** fails, MAX))
      }
    }
    // Когда пользователь возвращается на вкладку — обновляемся сразу, не ждём таймер.
    const onVisible = () => { if (!document.hidden) { if (timer) clearTimeout(timer); loop() } }
    document.addEventListener('visibilitychange', onVisible)
    loop()
    return () => { stopped = true; if (timer) clearTimeout(timer); document.removeEventListener('visibilitychange', onVisible) }
  }, [refreshState])

  const toggleTheme = useCallback(() => setTheme(t => t === 'dark' ? 'light' : 'dark'), [setTheme])
  const today = new Date().toLocaleDateString('ru', { day: 'numeric', month: 'short', year: 'numeric' })

  // Избранное: геттер и сеттер для текущего пользователя
  const userLogin = authUser?.login ?? ''
  const favorites = allFavorites[userLogin] ?? []
  const setFavorites = useCallback((action: React.SetStateAction<number[]>) => {
    if (!userLogin) return
    setAllFavorites(prev => {
      const cur = prev[userLogin] ?? []
      const next = typeof action === 'function' ? action(cur) : action
      const updated = { ...prev, [userLogin]: next }
      kvPush('allFavorites', updated)
      return updated
    })
  }, [userLogin, kvPush])

  // Обёртки для всех данных, которые нужно синхронизировать при изменении
  const setFaqCloud: React.Dispatch<React.SetStateAction<FaqSection[]>> = useCallback((action) => {
    setFaqSections(prev => {
      const next = typeof action === 'function' ? action(prev) : action
      kvPush('faq', next)
      return next
    })
  }, [kvPush])

  const setMaterialsCloud: React.Dispatch<React.SetStateAction<Material[]>> = useCallback((action) => {
    setMaterials(prev => {
      const next = typeof action === 'function' ? action(prev) : action
      kvPush('materials', next)
      return next
    })
  }, [kvPush])

  const setReviewsCloud: React.Dispatch<React.SetStateAction<Review[]>> = useCallback((action) => {
    setReviews(prev => {
      const next = typeof action === 'function' ? action(prev) : action
      kvPush('reviews', next)
      return next
    })
  }, [kvPush])

  const setNoticeCloud: React.Dispatch<React.SetStateAction<NoticeContent>> = useCallback((action) => {
    setNotice(prev => {
      const next = typeof action === 'function' ? action(prev) : action
      kvPush('notice', next)
      return next
    })
  }, [kvPush])

  const setBannerCloud: React.Dispatch<React.SetStateAction<BannerConfig>> = useCallback((action) => {
    setBanner(prev => {
      const next = typeof action === 'function' ? action(prev) : action
      kvPush('banner', next)
      return next
    })
  }, [kvPush])

  const setHomeCloud: React.Dispatch<React.SetStateAction<HomeConfig>> = useCallback((action) => {
    setHome(prev => {
      const next = typeof action === 'function' ? action(prev) : action
      kvPush('home', next)
      return next
    })
  }, [kvPush])

  // Версия приложения — редактируется админом в профиле и синхронизируется всем.
  const setAppVersionCloud = useCallback((v: string) => {
    const next = sanitizeText(v, 24).replace(/\s+/g, ' ').trim()
    setAppVersion(next)
    kvPush('appVersion', next)
  }, [kvPush, setAppVersion])

  // Сброс обучения для всех: поднимаем «эпоху». У каждого аккаунта хранится,
  // до какой эпохи он уже видел тур; при повышении эпохи тур покажется заново.
  const resetOnboardForAll = useCallback(() => {
    setOnboardEpoch(prev => {
      const next = (typeof prev === 'number' ? prev : 1) + 1
      kvPush('onboardEpoch', next)
      return next
    })
  }, [kvPush, setOnboardEpoch])

  const setCustomOrderCloud: React.Dispatch<React.SetStateAction<CustomOrderConfig>> = useCallback((action) => {
    setCustomOrder(prev => {
      const next = typeof action === 'function' ? action(prev) : action
      kvPush('customOrder', next)
      return next
    })
  }, [kvPush])

  const setCrmOrderCloud: React.Dispatch<React.SetStateAction<string[]>> = useCallback((action) => {
    setCrmOrder(prev => {
      const next = typeof action === 'function' ? action(prev) : action
      kvPush('crmOrder', next)
      return next
    })
  }, [kvPush])

  const setCrmLeftCloud: React.Dispatch<React.SetStateAction<string[]>> = useCallback((action) => {
    setCrmLeft(prev => {
      const next = typeof action === 'function' ? action(prev) : action
      kvPush('crmLeft', next)
      return next
    })
  }, [kvPush])

  const setCoverModeCloud: React.Dispatch<React.SetStateAction<CoverMode>> = useCallback((action) => {
    setCoverMode(prev => {
      const next = typeof action === 'function' ? action(prev) : action
      kvPush('coverMode', next)
      return next
    })
  }, [kvPush])

  const setPromosCloud: React.Dispatch<React.SetStateAction<PromoCode[]>> = useCallback((action) => {
    setPromocodes(prev => {
      const next = typeof action === 'function' ? action(prev) : action
      kvPush('promocodes', next)
      return next
    })
  }, [kvPush])

  const setLoyaltyCloud: React.Dispatch<React.SetStateAction<LoyaltyConfig>> = useCallback((action) => {
    setLoyalty(prev => {
      const next = typeof action === 'function' ? action(prev) : action
      kvPush('loyalty', next)
      logAction('loyalty', `Изменены настройки лояльности (кешбэк ${next.cashback}%, реферал ${next.referral} ₽)`)
      return next
    })
  }, [kvPush, setLoyalty])

  const setCatalogFiltersCloud: React.Dispatch<React.SetStateAction<CatalogFilterButton[]>> = useCallback((action) => {
    setCatalogFilters(prev => {
      const next = typeof action === 'function' ? action(prev) : action
      kvPush('catalogFilters', next)
      logAction('loyalty', `Изменены фильтры каталога (${next.length} шт.)`)
      return next
    })
  }, [kvPush, setCatalogFilters])

  const setPayEnabledCloud: React.Dispatch<React.SetStateAction<Record<string, boolean>>> = useCallback((action) => {
    setPayEnabled(prev => {
      const next = typeof action === 'function' ? action(prev) : action
      kvPush('payMethods', next)
      return next
    })
  }, [kvPush, setPayEnabled])

  const setShopStatusCloud: React.Dispatch<React.SetStateAction<ShopStatus>> = useCallback((action) => {
    setShopStatus(prev => {
      const next = typeof action === 'function' ? action(prev) : action
      kvPush('shopStatus', next)
      logAction('system', next.on ? 'Магазин переведён на паузу' : 'Магазин снова принимает заказы')
      return next
    })
  }, [kvPush, setShopStatus])

  const setRolesCloud: React.Dispatch<React.SetStateAction<Record<string, Role>>> = useCallback((action) => {
    setRoles(prev => { const next = typeof action === 'function' ? action(prev) : action; kvPush('roles', next); return next })
  }, [kvPush, setRoles])
  const setSbpCloud: React.Dispatch<React.SetStateAction<SbpInfo>> = useCallback((action) => {
    setSbpInfo(prev => { const next = typeof action === 'function' ? action(prev) : action; kvPush('sbpInfo', next); return next })
  }, [kvPush, setSbpInfo])

  const pushProductsToCloud = useCallback((p: Product[]) => kvPush('products', p, 600), [kvPush])
  // Оформлен заказ — увеличиваем счётчик продаж товара (питает «Хиты продаж» и номер
  // экземпляра в лимитированном тираже) и синхронизируем с облаком.
  const bumpProductSold = useCallback((id: number) => {
    setProducts(prev => {
      const next = prev.map(p => p.id === id ? { ...p, sold: (p.sold ?? 0) + 1 } : p)
      pushProductsToCloud(next)
      return next
    })
  }, [setProducts, pushProductsToCloud])
  const pushSectionsToCloud = useCallback((s: CatalogSection[]) => kvPush('sections', s), [kvPush])
  // Лист ожидания: клиент подписывается/отписывается на открытие окна заказа или нового тиража.
  // При новой подписке шлём владельцу уведомление в Telegram — это сигнал спроса.
  const toggleWaitlist = useCallback((productId: number) => {
    if (!authUser) { setToast('Войдите, чтобы записаться в лист ожидания'); setTimeout(() => setToast(''), 3000); return }
    const login = authUser.login
    setWaitlist(prev => {
      const key = String(productId)
      const cur = prev[key] ?? []
      const has = cur.includes(login)
      const arr = has ? cur.filter(u => u !== login) : [...cur, login]
      const next = { ...prev, [key]: arr }
      kvPush('waitlist', next)
      if (!has) {
        const p = productsRef.current.find(pp => pp.id === productId)
        notify(`🔔 <b>Запись в лист ожидания</b>\nФигурка: ${p?.name ?? productId}\nКлиент: ${login}\nВсего ждут: <b>${arr.length}</b>`).catch(() => { /* уведомление не критично */ })
        setToast('Вы в списке — оповестим, когда откроем')
      } else {
        setToast('Вы вышли из списка ожидания')
      }
      setTimeout(() => setToast(''), 3000)
      return next
    })
  }, [authUser, kvPush, setWaitlist])

  const handleLogin = useCallback((login: string, password: string, tgUsername?: string): boolean => {
    // Защита от перебора пароля: пока держится блокировка — вход запрещён.
    // Telegram-вход (`__tg__`) не блокируем — это не подбор пароля.
    if (login !== '__tg__' && loginLockRemaining() > 0) return false
    let user: AuthUser
    if (login === '__tg__' && password === 'user123' && tgUsername) {
      // Вне Telegram (веб-превью) Telegram не отдаёт username → используем «preview».
      // Роль всегда обычная: иначе любой человек, открывший приложение в браузере
      // мимо Telegram, получал бы панель мастера. Доступ к CRM даёт только
      // владелец (OWNER_TG) и назначенные в разделе «Роли» сотрудники.
      user = { login: tgUsername, name: tgUsername, role: 'user', avatar: tgUsername[1]?.toUpperCase() ?? 'U' }
      setRegisteredUsers(prev =>
        prev.find(u => u.login === tgUsername)
          ? prev
          : [...prev, { login: tgUsername, name: tgUsername, role: 'user' as const, joinedAt: today }])
      // Всегда синхронизируем клиента в облако через безопасный merge,
      // чтобы не затирать список остальных клиентов подмножеством с этого устройства.
      const record = { login: tgUsername, name: tgUsername, role: 'user' as const, joinedAt: today }
      ;(async () => {
        try {
          const cloud = (await kv.get('users')) as RegisteredUser[] | null
          const map = new Map((Array.isArray(cloud) ? cloud : []).map(u => [u.login, u]))
          if (!map.has(record.login)) map.set(record.login, record)
          await kv.set('users', Array.from(map.values()))
        } catch { /* offline */ }
      })()
      if (!welcomeNoShow) setShowWelcome(true)
      // Подчищаем демо-заказы, оставшиеся от прежних версий приложения.
      setOrders(prev => {
        const next = prev.filter(o => !o.id.startsWith('#DEMO'))
        if (next.length === prev.length) return prev
        kvPush('orders', next)
        return next
      })
    } else {
      if (login !== ADMIN_LOGIN || password !== ADMIN_PASS) {
        registerLoginFailure()   // растущая пауза после каждой неудачи
        return false
      }
      registerLoginSuccess()     // успех — сбрасываем счётчик блокировки
      user = { login: ADMIN_LOGIN, name: 'Администратор', role: 'admin', avatar: 'D' }
    }
    setAuthUser(user)
    setLastSeenTimes(prev => {
      const next = { ...prev, [user.login]: Date.now() }
      kvPush('lastseen', next)
      return next
    })
    setTab('home')
    return true
  }, [today, setLastSeenTimes, setRegisteredUsers, kvPush])

  const handleLogout = useCallback(() => {
    if (authUser) setLastSeenTimes(prev => {
      const next = { ...prev, [authUser.login]: Date.now() }
      kvPush('lastseen', next)
      return next
    })
    // После явного выхода не логинимся по Telegram автоматически — чтобы показать меню
    // входа (в т.ч. скрытый вход в админ-панель). Флаг живёт до перезапуска приложения.
    try { sessionStorage.setItem('skipAutoLogin', '1') } catch {}
    setAuthUser(null); setTab('catalog')
  }, [authUser, kvPush, setLastSeenTimes])

  const currentProfile: UserProfile = authUser
    ? (readProfile(profiles, authUser.login) ?? { email: '', avatarUrl: null, nickname: '', city: '', address: '', deliveryService: '' })
    : { email: '', avatarUrl: null, nickname: '', city: '', address: '', deliveryService: '' }

  // Активный промокод текущего пользователя — для визуального превью скидки.
  const activePromo = authUser && currentProfile.promoCode
    ? evalPromo(promocodes, currentProfile.promoCode, authUser.login).promo
    : undefined
  const activeDiscount = activePromo?.discount ?? 0

  // Публичный промокод-анонс (баннер с таймером) — показываем всем клиентам.
  const featuredPromo = pickFeaturedPromo(promocodes)
  const promoApplied = !!featuredPromo && currentProfile.promoCode?.toUpperCase() === featuredPromo.code.toUpperCase()

  const updateProfile = useCallback((p: UserProfile) => {
    if (!authUser) return
    setProfiles(prev => {
      // Пишем во все варианты написания логина сразу, чтобы профиль не раздваивался
      // и читался одинаково и в CRM, и в клиентском приложении.
      const next = { ...prev, [authUser.login]: p }
      for (const k of profileKeys(prev, authUser.login)) next[k] = p
      kvPush('profiles', next)
      return next
    })
  }, [authUser, kvPush])

  // Журнал действий: подтягиваем один раз и держим актуального «автора» записей.
  useEffect(() => { initLogs() }, [])
  useEffect(() => { setLogActor(authUser?.login) }, [authUser?.login])

  // Изменить профиль ЛЮБОГО клиента по логину (для бонусов/рефералов). Пишем во все
  // варианты написания логина, как updateProfile, чтобы баланс не раздваивался.
  const mutateProfileFor = useCallback((login: string, fn: (p: UserProfile) => UserProfile) => {
    if (!login) return
    setProfiles(prev => {
      const base = readProfile(prev, login) ?? { email: '', avatarUrl: null, nickname: '', city: '', address: '', deliveryService: '' as DeliveryService }
      const np = fn(base)
      const next = { ...prev }
      const keys = new Set<string>([login, normLogin(login), ...profileKeys(prev, login)])
      for (const k of keys) if (k) next[k] = np
      kvPush('profiles', next)
      return next
    })
  }, [kvPush, setProfiles])

  // Начислить (delta>0) или списать (delta<0) бонусы клиенту.
  const awardPoints = useCallback((login: string, delta: number) => {
    if (!delta) return
    mutateProfileFor(login, p => ({ ...p, points: Math.max(0, Math.round((p.points ?? 0) + delta)) }))
  }, [mutateProfileFor])

  // Ручная корректировка баланса администратором (из CRM «Лояльность»).
  const onAdjustPoints = useCallback((login: string, delta: number, reason: string) => {
    awardPoints(login, delta)
    logAction('loyalty', `${delta > 0 ? 'Начислено' : 'Списано'} ${Math.abs(delta)} ₽ клиенту ${login} (${reason})`)
  }, [awardPoints])

  // Активация публичного промокода в один тап — прописываем его в профиль клиента.
  const activateFeaturedPromo = useCallback(() => {
    if (!featuredPromo) return
    updateProfile({ ...currentProfile, promoCode: featuredPromo.code })
    setToast(`Промокод ${featuredPromo.code} активирован — скидка −${featuredPromo.discount}%`)
    setTimeout(() => setToast(''), 3000)
  }, [featuredPromo, currentProfile, updateProfile])

  // Telegram отдаёт username без «собачки» (doken62), а владелец и роли записаны
  // с ней (@doken62) — без нормализации владелец заходил как обычный клиент.
  const roleOf = (l?: string | null) => {
    const n = normLogin(l)
    return (n ? (roles[n] ?? roles[n.slice(1)]) : undefined) ?? undefined
  }
  // Доступ к админке в веб-превью (вне Telegram) выдаётся ТОЛЬКО при наличии
  // «ключа разработчика» в localStorage (`fs_devKey`). Этот же ключ уходит на
  // сервер заголовком X-Dev-Key, и сервер проверяет его по секрету DEV_ADMIN_KEY —
  // без совпадения никакие облачные права админа не работают. Клиентская роль
  // здесь нужна лишь чтобы показать CRM-интерфейс; настоящую защиту держит сервер.
  const inTelegram = typeof window !== 'undefined' && !!(window as unknown as { Telegram?: { WebApp?: { initDataUnsafe?: { user?: unknown } } } }).Telegram?.WebApp?.initDataUnsafe?.user
  const previewOwner = !inTelegram && typeof localStorage !== 'undefined' && !!localStorage.getItem('fs_devKey')
  const isOwner = previewOwner || normLogin(authUser?.login) === OWNER_TG.toLowerCase()
  const isAdmin = isOwner || authUser?.role === 'admin'
  // Модератор и редактор тоже получают CRM, но с урезанным набором вкладок.
  const staffRole: Role | null = isOwner ? 'admin' : (roleOf(authUser?.login) ?? null)
  const canCRM = isAdmin || staffRole === 'moderator' || staffRole === 'editor'
  const crmAllowed: string[] | null = isAdmin ? null : (staffRole ? ROLE_TABS[staffRole] ?? [] : [])

  // Скрытые товары не показываем в витрине (каталог, главная, коллекции, избранное).
  // В CRM владелец/админ/редактор по-прежнему видят и редактируют их целиком.
  const visibleProducts = products.filter(p => !p.hidden)

  // Обложка профиля. В режиме owner её ставит только владелец, и его обложку
  // видят все пользователи; в режиме all каждый оформляет себя сам.
  const canEditCover = isOwner || coverMode === 'all'
  const ownerCover = readProfile(profiles, OWNER_TG)?.bgUrl ?? null
  // В режиме owner все видят обложку владельца. Но сам владелец (в т.ч. превью-
  // владелец, чей логин ≠ OWNER_TG) редактирует и видит свою — иначе в превью
  // загрузка обложки не давала видимого результата.
  const coverUrl = coverMode === 'owner'
    ? (isOwner ? (currentProfile.bgUrl ?? ownerCover) : ownerCover)
    : (currentProfile.bgUrl ?? null)

  const handleOrder = useCallback(async (product: Product, variant: ProductVariant, provider: PayProvider) => {
    // Анти-флуд: не даём спамить оформлением заказа (запись в облако + уведомление
    // в Telegram) — не чаще одного заказа в 3 секунды с устройства.
    if (!allowAction('order-submit', 3000)) return
    // Магазин на паузе — новые заказы не принимаем (витрину листать можно).
    if (shopStatus.on) {
      setToast(shopStatus.title || 'Магазин временно на паузе')
      setTimeout(() => setToast(''), 3500)
      return
    }
    // Окно заказа закрыто или тираж распродан — заказ не принимаем.
    if (!canOrder(product)) {
      setToast(orderWindow(product).closed ? 'Приём заказов на эту модель закрыт' : 'Тираж этой модели распродан')
      setTimeout(() => setToast(''), 3500)
      return
    }
    // Номер экземпляра в лимитированном тираже (если задан лимит).
    const ed = editionState(product)
    const basePrice = variant.price
    // Активный промокод пользователя применяем к цене заказа и «списываем» его.
    const active = currentProfile.promoCode
      ? evalPromo(promocodes, currentProfile.promoCode, authUser!.login).promo
      : undefined
    const discount = active?.discount ?? 0
    const afterPromo = discount ? Math.round(basePrice * (1 - discount / 100)) : basePrice
    // Списание бонусов: если клиент включил автосписание — снимаем часть цены (в пределах лимита).
    const bonusSpent = (loyalty.enabled && currentProfile.useBonus)
      ? redeemable(loyalty, afterPromo, currentProfile.points ?? 0) : 0
    const finalPrice = afterPromo - bonusSpent
    const orderId = '#' + Date.now().toString(36).slice(-6).toUpperCase()
    const newOrder: Order = {
      id: orderId,
      name: product.name,
      figure: product.series,
      // Итоговая цена варианта — кладём в оба поля, чтобы любой экран показал верно.
      price: finalPrice,
      priceUnpainted: finalPrice,
      date: today,
      status: 'new',
      thumb: variantCover(variant) || product.img,
      userId: authUser!.login,
      painted: true,
      variantName: variant.name,
      promoCode: active?.code,
      discount: discount || undefined,
      bonusSpent: bonusSpent || undefined,
      paid: false,
      payProvider: provider,
      createdAt: Date.now(),
      // Снимок себестоимости варианта — для расчёта прибыли в отчётах CRM.
      ...(typeof variant.cost === 'number' && variant.cost > 0 ? { cost: variant.cost } : {}),
      ...(ed.limited ? { editionNo: ed.nextNumber, editionTotal: ed.total } : {}),
    }

    // СБП — перевод вручную. Заказ пока НЕ создаём: он появится только после того,
    // как клиент нажмёт «Я уже оплатил». Кнопка «Нет» просто закрывает окно.
    if (provider === 'sbp') {
      const pending = { order: { ...newOrder, payStatus: 'awaiting' as const }, amount: finalPrice, promoId: active?.id, productId: product.id }
      // Нет адреса доставки — просим указать перед показом реквизитов, сохраняем в профиль.
      if (!currentProfile.address?.trim()) {
        setAddrPromptDraft({ deliveryService: currentProfile.deliveryService || '', address: '' })
        setAddrPrompt(pending)
        return
      }
      setSbpPay(pending)
      return
    }

    // 1. Создаём платёж на сервере (секретные ключи там, не в браузере).
    let checkoutUrl = ''
    try {
      const res = await payments.create({
        provider,
        orderId,
        amount: finalPrice,
        description: `${product.name} (${variant.name})`,
        returnUrl: window.location.href,
      })
      checkoutUrl = res.confirmationUrl
    } catch (e) {
      setToast(`Не удалось создать оплату: ${(e as Error).message}`)
      setTimeout(() => setToast(''), 4000)
      return
    }

    // 2. Заказ создан со статусом «ожидает оплаты».
    setOrders(prev => {
      const next = [newOrder, ...prev]
      kvPush('orders', next)
      return next
    })
    bumpProductSold(product.id)
    if (active) setPromosCloud(prev => prev.map(p => p.id === active.id ? { ...p, uses: p.uses + 1 } : p))
    // Списываем использованный промокод и потраченные бонусы одним обновлением профиля.
    if (active || bonusSpent) {
      updateProfile({
        ...currentProfile,
        ...(active ? { promoCode: '' } : {}),
        ...(bonusSpent ? { points: Math.max(0, (currentProfile.points ?? 0) - bonusSpent) } : {}),
      })
    }
    showOrderToast(`Заказ ${orderId} оформлен — отслеживайте в «Мои заказы»`)
    setToast('Открываем страницу оплаты…')
    setTimeout(() => setToast(''), 2500)
    setTab('orders')

    // 3. Открываем страницу оплаты провайдера.
    window.open(checkoutUrl, '_blank')

    // 4. Опрашиваем сервер — как только webhook подтвердит оплату, помечаем заказ.
    let tries = 0
    const poll = setInterval(async () => {
      tries++
      try {
        const { status } = await payments.status(orderId)
        if (status === 'paid') {
          clearInterval(poll)
          setOrders(prev => {
            const next = prev.map(o => o.id === orderId ? { ...o, paid: true } : o)
            kvPush('orders', next)
            return next
          })
          setToast(`Оплата получена — заказ ${orderId} оплачен ✓`)
          setTimeout(() => setToast(''), 4000)
        } else if (status === 'failed') {
          clearInterval(poll)
          setToast(`Оплата не прошла по заказу ${orderId}`)
          setTimeout(() => setToast(''), 4000)
        }
      } catch { /* сеть — пробуем ещё */ }
      if (tries > 120) clearInterval(poll) // ~10 минут
    }, 5000)
  }, [authUser, today, kvPush, currentProfile, promocodes, setPromosCloud, updateProfile, showOrderToast, setTab, loyalty, bumpProductSold, shopStatus])

  // Клиент нажал «Я уже оплатил»: только здесь заказ реально создаётся,
  // списывается промокод и уходит уведомление владельцу в Telegram.
  const confirmSbpPaid = useCallback(() => {
    if (!sbpPay) return
    const order: Order = { ...sbpPay.order, createdAt: Date.now() }
    setOrders(prev => { const next = [order, ...prev]; kvPush('orders', next); return next })
    if (typeof sbpPay.productId === 'number') bumpProductSold(sbpPay.productId)
    if (sbpPay.promoId) setPromosCloud(prev => prev.map(p => p.id === sbpPay.promoId ? { ...p, uses: p.uses + 1 } : p))
    const sbpBonus = order.bonusSpent ?? 0
    if (sbpPay.promoId || sbpBonus) {
      updateProfile({
        ...currentProfile,
        ...(sbpPay.promoId ? { promoCode: '' } : {}),
        ...(sbpBonus ? { points: Math.max(0, (currentProfile.points ?? 0) - sbpBonus) } : {}),
      })
    }
    // Сообщение владельцу магазина (если задан TELEGRAM_BOT_TOKEN на сервере).
    notify(
      `💸 <b>Новый перевод по СБП</b>\n` +
      `Заказ: <b>${order.id}</b>\n` +
      `Клиент: ${order.userId}\n` +
      `Фигурка: ${order.name}${order.variantName ? ` · ${order.variantName}` : ''}\n` +
      `Сумма: <b>${sbpPay.amount.toLocaleString()} ₽</b>\n` +
      `Подтвердите оплату в CRM → «Оплаты» (заказ отменится через 12 часов без подтверждения).`
    ).catch(() => { /* уведомление не критично для заказа */ })
    setSbpPay(null)
    showOrderToast(`Заказ ${order.id} принят — ожидайте подтверждения оплаты`)
    setTab('orders')
  }, [sbpPay, kvPush, setPromosCloud, updateProfile, currentProfile, showOrderToast, bumpProductSold])

  // Автоотмена: заказ, ожидающий подтверждения оплаты дольше 12 часов, удаляется.
  useEffect(() => {
    const TTL = 12 * 60 * 60 * 1000
    const purge = () => {
      const now = Date.now()
      const expired = ordersRef.current
        .filter(o => o.payStatus === 'awaiting' && o.createdAt && now - o.createdAt > TTL)
        .map(o => o.id)
      if (expired.length) forgetOrders(expired)
    }
    purge()
    const t = setInterval(purge, 60_000)
    return () => clearInterval(t)
  }, [forgetOrders])

  // Смена статуса заказа администратором — сохраняется в облако
  const handleOrderStatus = useCallback((id: string, status: OrderStatus) => {
    const target = ordersRef.current.find(o => o.id === id)
    // Кешбэк начисляем один раз — при первом переходе заказа в «Доставлено».
    const willAward = !!target && status === 'delivered' && loyalty.enabled && target.bonusPaid == null
    const cash = willAward ? Math.round(((target!.painted ? target!.price : target!.priceUnpainted) || 0) * loyalty.cashback / 100) : 0
    setOrders(prev => {
      const next = prev.map(o => o.id === id ? { ...o, status, ...(willAward ? { bonusPaid: cash } : {}) } : o)
      kvPush('orders', next)
      return next
    })
    if (willAward && target) {
      if (cash > 0) { awardPoints(target.userId, cash); logAction('loyalty', `Кешбэк ${cash} ₽ клиенту ${target.userId} за заказ ${id}`) }
      // Реферальный бонус: первый доставленный заказ приглашённого — награда обоим.
      const prof = readProfile(profiles, target.userId)
      if (prof?.refBy && !prof.refReward && loyalty.referral > 0) {
        awardPoints(prof.refBy, loyalty.referral)
        awardPoints(target.userId, loyalty.referral)
        mutateProfileFor(target.userId, p => ({ ...p, refReward: true }))
        logAction('loyalty', `Реферальный бонус ${loyalty.referral} ₽: ${prof.refBy} ← ${target.userId}`)
      }
    }
    logAction('order', `Заказ ${id} → «${STATUS_META[status].label}»`)
  }, [kvPush, loyalty, awardPoints, mutateProfileFor, profiles])

  // Трек-номер и служба доставки — администратор задаёт, клиент видит и отслеживает.
  const handleOrderTrack = useCallback((id: string, track: string, carrier: DeliveryService) => {
    setOrders(prev => {
      const next = prev.map(o => o.id === id ? { ...o, track: track.trim() || undefined, carrier: track.trim() ? carrier : undefined } : o)
      kvPush('orders', next)
      return next
    })
  }, [kvPush])

  // Удаление ошибочного заказа администратором — сохраняется в облако
  const handleOrderDelete = useCallback((id: string) => {
    forgetOrders([id])
    logAction('order', `Удалён заказ ${id}`)
  }, [forgetOrders])

  // Ручное создание заказа администратором (индивидуальные заказы) — в облако.
  const handleOrderCreate = useCallback((o: Order) => {
    setOrders(prev => {
      const next = [o, ...prev]
      kvPush('orders', next)
      return next
    })
  }, [kvPush])

  // Подтверждение / отклонение перевода по СБП администратором.
  const handlePayVerify = useCallback((id: string, ok: boolean) => {
    setOrders(prev => {
      const next = prev.map(o => o.id === id
        ? (ok
            ? { ...o, paid: true, payStatus: 'confirmed' as PayStatus }
            : { ...o, paid: false, payStatus: 'rejected' as PayStatus, status: 'delivered' as OrderStatus })
        : o)
      kvPush('orders', next)
      return next
    })
    logAction('order', `Оплата заказа ${id} ${ok ? 'подтверждена ✓' : 'отклонена ✗'}`)
  }, [kvPush])

  // Удаление клиента администратором — сохраняется в облако (safe merge-delete)
  const handleUserDelete = useCallback((login: string) => {
    logAction('user', `Удалён клиент ${login}`)
    setRegisteredUsers(prev => {
      const next = prev.filter(u => u.login !== login)
      // Пишем в облако через merge-delete, чтобы не затереть чужие изменения.
      ;(async () => {
        try {
          const cloud = (await kv.get('users')) as RegisteredUser[] | null
          const filtered = (Array.isArray(cloud) ? cloud : next).filter(u => u.login !== login)
          await kv.set('users', filtered)
        } catch { /* offline */ }
      })()
      return next
    })
  }, [setRegisteredUsers])

  // Полная очистка клиентской базы (только владелец). Стираем клиентов, профили,
  // заказы, отзывы, избранное и «был в сети» и локально, и в облаке. ID старых
  // заказов уводим в «надгробие», чтобы они не вернулись с других устройств.
  const wipeClients = useCallback(async () => {
    const oldOrderIds = ordersRef.current.map(o => o.id)
    // Гасим отложенные пуши, чтобы они не восстановили только что стёртое.
    for (const k of ['orders', 'users', 'profiles', 'lastseen', 'reviews', 'allFavorites']) {
      if (pushTimers.current[k]) { clearTimeout(pushTimers.current[k]); delete pushTimers.current[k] }
    }
    const tomb = Array.from(new Set([...deletedOrdersRef.current, ...oldOrderIds])).slice(-1000)
    deletedOrdersRef.current = tomb
    setOrders([]); setRegisteredUsers([]); setProfiles({}); setLastSeenTimes({})
    setReviews([]); setAllFavorites({}); setDeletedOrders(tomb)
    try {
      await Promise.all([
        kv.set('orders', []), kv.set('users', []), kv.set('profiles', {}),
        kv.set('lastseen', {}), kv.set('reviews', []), kv.set('allFavorites', {}),
        kv.set('deletedOrders', tomb),
      ])
      // Бампаем ревизии стёртых ключей, иначе другие устройства не поймут, что
      // данные обнулились, и продолжат показывать старую клиентскую базу.
      for (const k of ['orders', 'profiles', 'lastseen', 'reviews', 'allFavorites']) bumpRev(k)
      logAction('system', 'Клиентская база полностью очищена')
      setToast('🧹 Клиентская база очищена')
    } catch (err) {
      setToast(`⚠ Не удалось очистить облако: ${(err as Error)?.message ?? 'ошибка'}`)
    }
    setTimeout(() => setToast(''), 5000)
  }, [bumpRev, setOrders, setRegisteredUsers, setProfiles, setLastSeenTimes, setReviews, setAllFavorites, setDeletedOrders])

  // Обнуление статистики перед публичным запуском: стираем ВСЮ историю продаж и
  // активности (тестовые заказы, счётчики продаж, использования промокодов,
  // начисленные бонусы, отзывы, журнал действий), но СОХРАНЯЕМ каталог товаров,
  // разделы, настройки и аккаунты клиентов. После сброса вся аналитика — по нулям.
  const wipeStats = useCallback(async () => {
    // Гасим отложенные пуши, чтобы они не восстановили только что стёртое.
    for (const k of ['orders', 'products', 'promocodes', 'profiles', 'reviews']) {
      if (pushTimers.current[k]) { clearTimeout(pushTimers.current[k]); delete pushTimers.current[k] }
    }
    // Заказы уводим «под надгробие», иначе они вернутся с других устройств.
    const oldOrderIds = ordersRef.current.map(o => o.id)
    const tomb = Array.from(new Set([...deletedOrdersRef.current, ...oldOrderIds])).slice(-1000)
    deletedOrdersRef.current = tomb
    // Готовим обнулённые версии (каталог/промокоды/клиентов сохраняем как есть).
    const resetProducts = products.map(p => (p.sold ? { ...p, sold: 0 } : p))
    const resetPromos = promocodes.map(c => (c.uses ? { ...c, uses: 0 } : c))
    const resetProfiles: Record<string, UserProfile> = {}
    for (const [k, v] of Object.entries(profiles)) resetProfiles[k] = { ...v, points: 0, refReward: false }
    setOrders([]); setDeletedOrders(tomb)
    setProducts(resetProducts); setPromocodes(resetPromos); setProfiles(resetProfiles); setReviews([])
    try {
      await Promise.all([
        kv.set('orders', []), kv.set('deletedOrders', tomb),
        kv.set('products', resetProducts), kv.set('promocodes', resetPromos),
        kv.set('profiles', resetProfiles), kv.set('reviews', []),
      ])
      // Бампаем ревизии, чтобы другие устройства подтянули обнулённые данные.
      for (const k of ['orders', 'products', 'promocodes', 'profiles', 'reviews']) bumpRev(k)
      clearLogs()
      logAction('system', 'Статистика и история продаж обнулены перед запуском')
      setToast('🧹 Статистика обнулена — магазин готов к запуску')
    } catch (err) {
      setToast(`⚠ Не удалось обнулить облако: ${(err as Error)?.message ?? 'ошибка'}`)
    }
    setTimeout(() => setToast(''), 5000)
  }, [bumpRev, products, promocodes, profiles, setOrders, setDeletedOrders, setProducts, setPromocodes, setProfiles, setReviews])

  // Разовый перенос «старых» картинок из базы в хранилище. Раньше часть
  // изображений сохранялась прямо в БД строкой base64 — они тяжёлые и качались
  // при каждой синхронизации. Здесь мы находим такие строки, заливаем файл в
  // Storage (CDN + кэш на год) и подменяем на короткую ссылку. Идемпотентно:
  // трогаем только строки, начинающиеся на "data:", остальное не меняем.
  const migrateImages = useCallback(async () => {
    setToast('🔄 Переношу старые картинки в хранилище…')
    let moved = 0, failed = 0
    const cache = new Map<string, string>() // одинаковые base64 заливаем один раз
    const dataUrlToFile = async (dataUrl: string): Promise<File> => {
      const blob = await (await fetch(dataUrl)).blob()
      const ext = (blob.type.split('/')[1] || 'jpg').split('+')[0]
      return new File([blob], `legacy-${Date.now()}.${ext}`, { type: blob.type || 'image/jpeg' })
    }
    const walk = async (v: any): Promise<any> => {
      if (typeof v === 'string') {
        if (v.startsWith('data:image') || v.startsWith('data:video')) {
          const hit = cache.get(v)
          if (hit) return hit
          try { const url = await storage.upload(await dataUrlToFile(v)); cache.set(v, url); moved++; return url }
          catch { failed++; return v }
        }
        return v
      }
      if (Array.isArray(v)) { const out = []; for (const x of v) out.push(await walk(x)); return out }
      if (v && typeof v === 'object') { const o: any = {}; for (const k of Object.keys(v)) o[k] = await walk(v[k]); return o }
      return v
    }
    // Обрабатываем ключи, где реально живут картинки. Сохраняем только то, что
    // изменилось, чтобы не гонять лишний трафик остальным устройствам.
    try {
      const runKey = async (before: any, save: (next: any) => void) => {
        const start = moved
        const next = await walk(before)
        if (moved > start) save(next)
      }
      await runKey(products, (n) => { setProducts(n); pushProductsToCloud(n) })
      await runKey(reviews, (n) => setReviewsCloud(n))
      await runKey(profiles, (n) => { setProfiles(n); kvPush('profiles', n) })
      await runKey(banner, (n) => setBannerCloud(n))
      await runKey(home, (n) => setHomeCloud(n))
      await runKey(customOrder, (n) => setCustomOrderCloud(n))
      await runKey(notice, (n) => setNoticeCloud(n))
      setToast(moved
        ? `✅ Перенесено картинок: ${moved}${failed ? ` · не удалось: ${failed}` : ''}`
        : '✅ Старых картинок в базе не найдено — всё уже в хранилище')
    } catch (err) {
      setToast(`⚠ Ошибка переноса: ${(err as Error)?.message ?? 'ошибка'}`)
    }
    setTimeout(() => setToast(''), 7000)
  }, [products, reviews, profiles, banner, home, customOrder, notice, kvPush, pushProductsToCloud, setProducts, setReviewsCloud, setProfiles, setBannerCloud, setHomeCloud, setCustomOrderCloud, setNoticeCloud])

  const myOrders = authUser ? orders.filter(o => normLogin(o.userId) === normLogin(authUser.login)) : orders

  // ── Уведомления ────────────────────────────────────────────
  // Лента строится из заказов: каждое событие получает стабильный ключ вида
  // «id:статус:оплата», поэтому смена статуса создаёт новое непрочитанное
  // уведомление, а уже просмотренные не всплывают заново.
  const [notifRead, setNotifRead] = useLocalStorage<string[]>('notifRead', [])
  const [notifDismissed, setNotifDismissed] = useLocalStorage<string[]>('notifDismissed', [])
  const [showNotif, setShowNotif] = useState(false)
  const notifications = (isAdmin ? orders : myOrders)
    .slice()
    .sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0))
    .map(o => {
      const key = `${o.id}:${o.status}:${o.payStatus ?? ''}`
      const meta = STATUS_META[o.status]
      const payWait = o.payStatus === 'awaiting'
      const payBad = o.payStatus === 'rejected'
      return {
        key,
        icon: (payBad ? 'close' : payWait ? 'card' : o.status === 'delivered' ? 'check' : 'package') as IconName,
        color: payBad ? 'var(--danger)' : payWait ? '#f59e0b' : statusAccent(o.status),
        title: payBad ? `Оплата не поступила · ${o.id}`
          : payWait ? (isAdmin ? `Проверьте оплату · ${o.id}` : `Оплата на проверке · ${o.id}`)
          : `${meta.label} · ${o.id}`,
        text: `${o.name} — ${(o.painted ? o.price : o.priceUnpainted).toLocaleString()} ₽`,
        date: o.date,
        unread: !notifRead.includes(key),
      }
    })
    .filter(n => !notifDismissed.includes(n.key))
  const notifCount = notifications.filter(n => n.unread).length
  // Бренд в верхней панели — редактируется в CRM «Главная страница»
  const brandCfg = { ...INIT_HOME.brand, ...(home?.brand ?? {}) }
  const markAllRead = () => setNotifRead(prev => Array.from(new Set([...prev, ...notifications.map(n => n.key)])))
  const dismissNotif = (key: string) => setNotifDismissed(prev => prev.includes(key) ? prev : [...prev, key])
  const clearAllNotif = () => {
    setNotifDismissed(prev => Array.from(new Set([...prev, ...notifications.map(n => n.key)])))
    setNotifRead(prev => Array.from(new Set([...prev, ...notifications.map(n => n.key)])))
  }
  const activeOrders = (isAdmin ? orders : myOrders).filter(o => o.status !== 'delivered').length
  const topBarName = currentProfile.nickname || authUser?.login || ''

  // Нижняя навигация фиксирована: слева от центральной Σ — «Каталог» и «Профиль»,
  // справа — «Заказы» и «Настройки». CRM и FAQ снизу не выводятся: CRM открывается
  // удержанием Σ, FAQ — из профиля.
  const leftTabs: Array<{ key: Tab; label: string; icon: IconName; badge?: number }> = [
    { key: 'catalog', label: 'Каталог', icon: 'grid' },
    { key: 'profile', label: 'Профиль', icon: 'person' },
  ]
  const rightTabs: Array<{ key: Tab; label: string; icon: IconName; badge?: number }> = [
    { key: 'orders',   label: 'Заказы',    icon: 'document', badge: activeOrders },
    { key: 'settings', label: 'Настройки', icon: 'gear' },
  ]
  const isFull = tab === 'crm'
  // Открытая страница коллекции на главной (null — корень главной).
  const [openCollection, setOpenCollection] = useState<HomeCollection | null>(null)
  useEffect(() => { if (tab !== 'home') setOpenCollection(null) }, [tab])
  // Вход в панель мастера — удержание центральной кнопки Σ (только при правах).
  const [masterTransition, setMasterTransition] = useState(false)
  const [gamesOpen, setGamesOpen] = useState(false)
  const sigmaHold = useSigmaHold(canCRM, () => setMasterTransition(true))
  // Обучающая подсказка про кнопку Σ — один раз на аккаунт, после приветственного
  // окна. Мастеру объясняем удержание для входа в панель, клиенту — что это
  // При смене вкладки прокручиваем контент в самое начало. Профиль часто открыт
  // внизу (кнопка «Настройки» там), и без сброса новая вкладка могла показаться
  // не с заголовка. Скроллим и внутренний контейнер, и сам webview.
  useEffect(() => {
    const host = document.querySelector('[data-app-scroll]') as HTMLElement | null
    if (host) host.scrollTop = 0
    try { window.scrollTo(0, 0) } catch { /* нет window */ }
  }, [tab])

  // главный экран. Отдельной подсказки-коуча про кнопку Σ больше нет — всё
  // объясняет единый пошаговый тур (SigmaOnboarding) ниже.

  // Приветственный тур: строго один раз на аккаунт. «Виден ли» хранится в
  // профиле (в облаке), а не в localStorage — поэтому не всплывает при каждом
  // входе и переносится между устройствами. Число onboardSeen — это «эпоха»
  // тура, которую видел аккаунт; глобальный onboardEpoch поднимается кнопкой
  // «показать всем заново».
  const [showOnboard, setShowOnboard] = useState(false)
  useEffect(() => {
    // Ждём, пока закроется приветственное окно, чтобы не наложиться.
    if (!authUser || showWelcome) return
    if ((currentProfile.onboardSeen ?? 0) < onboardEpoch) {
      const t = setTimeout(() => setShowOnboard(true), 350)
      return () => clearTimeout(t)
    }
  }, [authUser, showWelcome, currentProfile.onboardSeen, onboardEpoch])
  // Показать тур ещё раз вручную (доступно всем). Отметку «видел» не трогаем —
  // после закрытия она просто выставится в текущую эпоху.
  const replayOnboard = () => setShowOnboard(true)
  const closeOnboard = () => {
    setShowOnboard(false)
    if ((currentProfile.onboardSeen ?? 0) < onboardEpoch) {
      updateProfile({ ...currentProfile, onboardSeen: onboardEpoch })
    }
  }
  return (
    <AuthCtx.Provider value={{ user: authUser, login: handleLogin, logout: handleLogout }}>
    <ThemeCtx.Provider value={{ theme, toggle: toggleTheme }}>
      <div data-theme={theme} style={{ maxWidth: '430px', margin: '0 auto', height: '100dvh', background: 'var(--bg-base)', display: 'flex', flexDirection: 'column', position: 'relative', overflow: 'hidden' }}>
        {!authUser ? <LoginScreen onLogin={handleLogin} /> : (
          <>
            {/* Top bar — горизонтальный фиолетовый градиент как у карточки Sigma Club,
                с мягким «дымком»-свечением слева */}
            <div style={{ position: 'relative', overflow: 'hidden', padding: '9px 14px', background: 'linear-gradient(90deg, var(--ss-brand-wash, rgba(124,58,237,0.16)) 0%, var(--top-bar-bg) 42%, var(--top-bar-bg) 58%, var(--ss-brand-wash, rgba(124,58,237,0.16)) 100%)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0, backdropFilter: 'blur(14px)', borderBottom: '1px solid var(--ss-brand-edge, var(--border))', zIndex: 10 }}>
              {/* ровная горизонтальная фиолетовая полоса свечения вдоль всего бара */}
              <div aria-hidden style={{ position: 'absolute', inset: 0, background: 'linear-gradient(90deg, transparent 0%, var(--ss-brand-glow, rgba(168,85,247,0.16)) 50%, transparent 100%)', opacity: 0.5, pointerEvents: 'none' }} />
              <div aria-hidden style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 1, background: 'linear-gradient(90deg, transparent, var(--ss-brand-hi, #a855f7), transparent)', opacity: 0.5, pointerEvents: 'none' }} />
              <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: '9px', minWidth: 0, overflow: 'hidden' }}>
                {/* Логотип загружается в CRM; у стандартного лого тёмная подложка уже
                    вырезана в прозрачность, поэтому ни screen, ни фильтр не нужны. */}
                {(() => { const ls = brandCfg.logoSize || 48; return (
                <img src={resolveBrandLogo(brandCfg.logo)} alt="" width={ls} height={ls}
                  style={{ width: `${ls}px`, height: `${ls}px`, borderRadius: '13px', objectFit: 'contain', flexShrink: 0 }} />
                ) })()}
                <div style={{ lineHeight: 1, minWidth: 0, overflow: 'hidden' }}>
                  <p style={{ margin: 0, color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 300, letterSpacing: '0.07em', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{brandCfg.title.toUpperCase()}</p>
                  <p style={{ margin: '4px 0 0', color: 'var(--ss-brand-hi, #a855f7)', fontSize: '7.5px', fontWeight: 500, letterSpacing: '0.08em', textTransform: 'uppercase', whiteSpace: 'nowrap', textShadow: '0 0 10px var(--ss-brand-glow)' }}>{brandCfg.subtitle}</p>
                </div>
              </div>
              <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: '6px', flexShrink: 0, marginLeft: '8px' }}>
                {isAdmin && <span style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', fontSize: '9px', fontWeight: 700, padding: '3px 8px', borderRadius: '20px', background: 'rgba(127,0,0,0.35)', color: '#f87171', textTransform: 'uppercase', border: '1px solid rgba(180,30,30,0.55)' }}><Icon name="gear" size={9} color="#f87171" /> admin</span>}
                {/* Колокольчик: открывает выпадающую ленту уведомлений */}
                <button onClick={() => setShowNotif(v => !v)} title="Уведомления" aria-label={notifCount > 0 ? `Уведомления: ${notifCount}` : 'Уведомления'}
                  style={{ position: 'relative', width: '30px', height: '30px', borderRadius: '8px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', boxSizing: 'border-box', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Icon name="bell" size={14} color={notifCount > 0 ? 'var(--ss-brand-hi, var(--accent))' : 'var(--text-secondary)'} />
                  {notifCount > 0 && (
                    <span style={{ position: 'absolute', top: '-5px', right: '-5px', minWidth: '16px', height: '16px', padding: '0 4px', boxSizing: 'border-box', borderRadius: '8px', background: 'var(--accent-grad)', border: '2px solid var(--top-bar-bg, var(--bg-base))', color: '#fff', fontSize: '9px', fontWeight: 800, lineHeight: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 0 10px -2px var(--ss-brand-glow, rgba(168,85,247,0.7))' }}>
                      {notifCount > 99 ? '99+' : notifCount}
                    </span>
                  )}
                </button>
                <button onClick={toggleTheme} style={{ width: '30px', height: '30px', borderRadius: '8px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Icon name={theme === 'dark' ? 'sun' : 'moon'} size={14} color="var(--text-secondary)" />
                </button>
                {topBarName && !isAdmin && <span style={{ fontSize: '10px', fontWeight: 600, color: 'var(--text-secondary)', maxWidth: '72px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{topBarName}</span>}
                {/* Avatar with online dot — открывает профиль по нажатию */}
                <button onClick={() => setTab('profile')} title="Профиль" aria-label="Открыть профиль" style={{ position: 'relative', width: '30px', height: '30px', padding: 0, border: 'none', background: 'none', cursor: 'pointer', borderRadius: '50%' }}>
                  <div style={{ width: '30px', height: '30px', borderRadius: '50%', overflow: 'hidden', background: isAdmin ? 'linear-gradient(135deg,#ef4444,#b91c1c)' : 'linear-gradient(135deg,var(--accent),#6d28d9)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '13px', fontWeight: 700, color: '#fff', boxShadow: tab === 'profile' ? '0 0 0 2px var(--accent)' : 'none', transition: 'box-shadow 0.2s' }}>
                    {currentProfile.avatarUrl ? <img src={currentProfile.avatarUrl} alt="av" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : authUser.avatar}
                  </div>
                  <OnlineDot isAdmin={isAdmin} size={9} />
                </button>
              </div>
            </div>

            {/* Выпадающая лента уведомлений — раскрывается из-под верхней панели */}
            {showNotif && (
              <>
                <div onClick={() => setShowNotif(false)} className="overlay-fade"
                  style={{ position: 'absolute', inset: 0, background: 'rgba(3,3,8,0.5)', backdropFilter: 'blur(2px)', zIndex: 90 }} />
                <div className="ss-notif-drop" style={{ position: 'absolute', top: '52px', right: '10px', left: '10px', maxWidth: '330px', marginLeft: 'auto', zIndex: 91, background: 'var(--bg-card)', border: '1px solid var(--ss-hairline-lo, var(--border))', borderRadius: '16px', boxShadow: '0 20px 50px -12px rgba(0,0,0,0.75), 0 0 0 1px rgba(255,255,255,0.02)', overflow: 'hidden' }}>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 14px', borderBottom: '1px solid var(--border)' }}>
                    <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: 0 }}>Уведомления</p>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                      {notifCount > 0 && (
                        <button onClick={markAllRead} style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', color: 'var(--ss-brand-hi, var(--accent))', fontSize: '11.5px', fontWeight: 600 }}>Прочитать все</button>
                      )}
                      {notifications.length > 0 && (
                        <button onClick={clearAllNotif} style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', color: 'var(--text-muted)', fontSize: '11.5px', fontWeight: 600 }}>Очистить всё</button>
                      )}
                    </div>
                  </div>
                  <div style={{ maxHeight: '54vh', overflowY: 'auto' }}>
                    {notifications.length === 0 ? (
                      <div style={{ padding: '28px 18px', textAlign: 'center' }}>
                        <Icon name="bell" size={22} color="var(--text-muted)" />
                        <p style={{ color: 'var(--text-secondary)', fontSize: '13px', fontWeight: 600, margin: '9px 0 3px' }}>Пока тихо</p>
                        <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Здесь появятся новости по вашим заказам</p>
                      </div>
                    ) : notifications.map((n, i, arr) => (
                      <NotifRow key={n.key} n={n} last={i === arr.length - 1}
                        onOpen={() => { setNotifRead(prev => prev.includes(n.key) ? prev : [...prev, n.key]); setShowNotif(false); setTab('orders') }}
                        onDismiss={() => dismissNotif(n.key)} />
                    ))}
                  </div>
                </div>
              </>
            )}

            {sbpPay && (() => {
              const rows = [
                { label: 'Получатель', val: sbpInfo.fio },
                { label: 'Банк', val: sbpInfo.bank },
                { label: 'Номер карты', val: sbpInfo.card },
                ...(sbpInfo.phone ? [{ label: 'Телефон (СБП)', val: sbpInfo.phone }] : []),
              ].filter(r => r.val)

            return (
                <div className="overlay-fade" style={{ position: 'absolute', inset: 0, zIndex: 400, background: 'rgba(0,0,0,0.72)', backdropFilter: 'blur(6px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
                  <div className="sheet-enter" style={{ width: '100%', maxWidth: '430px', background: 'var(--bg-card)', borderRadius: '22px 22px 0 0', padding: '16px', maxHeight: '92vh', overflowY: 'auto' }}>
                    <div style={{ width: '36px', height: '4px', borderRadius: '2px', background: 'var(--border)', margin: '0 auto 16px' }} />
                    <div style={{ display: 'flex', alignItems: 'center', gap: '9px', marginBottom: '4px' }}>
                      <Icon name="send" size={18} color="var(--accent)" />
                      <p style={{ color: 'var(--text-primary)', fontSize: '16px', fontWeight: 700, margin: 0 }}>Оплата по СБП</p>
                    </div>
                    <p style={{ color: 'var(--text-muted)', fontSize: '11.5px', margin: '0 0 14px' }}>Заказ {sbpPay.order.id} будет создан после подтверждения перевода.</p>

                    <div style={{ background: 'var(--accent-glow)', border: '1px solid var(--accent)', borderRadius: '14px', padding: '14px', marginBottom: '12px', textAlign: 'center' }}>
                      <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', margin: '0 0 3px', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Сумма перевода</p>
                      <p style={{ color: 'var(--accent)', fontSize: '30px', fontWeight: 800, margin: 0, lineHeight: 1.1 }}>{sbpPay.amount.toLocaleString()} ₽</p>
                    </div>

                    <div style={{ background: 'var(--bg-elevated)', borderRadius: '14px', padding: '12px', marginBottom: '12px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
                      {rows.map(r => (
                        <div key={r.label} style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <div style={{ flex: 1, minWidth: 0 }}>
                            <p style={{ color: 'var(--text-muted)', fontSize: '9.5px', margin: '0 0 2px', textTransform: 'uppercase', letterSpacing: '0.04em' }}>{r.label}</p>
                            <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: 0, wordBreak: 'break-all' }}>{r.val}</p>
                          </div>
                          <button onClick={() => { try { navigator.clipboard.writeText(r.val) } catch {} ; setToast('Скопировано'); setTimeout(() => setToast(''), 1500) }}
                            style={{ width: '30px', height: '30px', borderRadius: '9px', background: 'var(--bg-card)', border: '1px solid var(--border)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                            <Icon name="save" size={13} color="var(--accent)" />
                          </button>
                        </div>
                      ))}
                    </div>

                    <div style={{ display: 'flex', gap: '9px', padding: '11px 12px', background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.28)', borderRadius: '12px', marginBottom: '14px' }}>
                      <Icon name="info" size={15} color="var(--danger)" strokeWidth={2} />
                      <p style={{ color: 'var(--text-secondary)', fontSize: '11.5px', margin: 0, lineHeight: 1.5 }}>
                        <span style={{ color: 'var(--text-primary)', fontWeight: 700 }}>Оплата производится переводом на указанные реквизиты. Сумма должна быть точной — до рубля.</span>{' '}
                        {sbpInfo.note}
                      </p>
                    </div>

                    <button className="btn-primary" onClick={() => confirmSbpPaid()} style={{ marginBottom: '8px' }}>Я уже оплатил</button>
                    <button className="btn-secondary" onClick={() => { setSbpPay(null); setToast('Заказ не создан'); setTimeout(() => setToast(''), 2000) }}>Нет</button>
                    <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', margin: '10px 0 0', textAlign: 'center', lineHeight: 1.5 }}>Заказ создаётся только после нажатия «Я уже оплатил». Если мастер не подтвердит оплату в течение 12 часов, заказ автоматически отменяется.</p>
                  </div>
                </div>
              )
            })()}

            {/* Запрос адреса доставки перед оплатой по СБП */}
            {addrPrompt && (
              <div className="overlay-fade" style={{ position: 'absolute', inset: 0, zIndex: 410, background: 'rgba(0,0,0,0.72)', backdropFilter: 'blur(6px)', display: 'flex', alignItems: 'flex-end', justifyContent: 'center' }}>
                <div className="sheet-enter" style={{ width: '100%', maxWidth: '430px', background: 'var(--bg-card)', borderRadius: '22px 22px 0 0', padding: '16px', maxHeight: '92vh', overflowY: 'auto' }}>
                  <div style={{ width: '36px', height: '4px', borderRadius: '2px', background: 'var(--border)', margin: '0 auto 16px' }} />
                  <div style={{ display: 'flex', alignItems: 'center', gap: '9px', marginBottom: '4px' }}>
                    <Icon name="truck" size={18} color="var(--accent)" />
                    <p style={{ color: 'var(--text-primary)', fontSize: '16px', fontWeight: 700, margin: 0 }}>Укажите адрес доставки</p>
                  </div>
                  <p style={{ color: 'var(--text-muted)', fontSize: '11.5px', margin: '0 0 14px' }}>Адрес нужен для отправки заказа. Он сохранится в вашем профиле и подставится автоматически в следующий раз.</p>

                  <p style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 600, margin: '0 0 8px' }}>Служба доставки</p>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginBottom: '12px' }}>
                    {DELIVERY_OPTIONS.map(opt => (
                      <button key={opt.key} onClick={() => setAddrPromptDraft(p => ({ ...p, deliveryService: opt.key }))}
                        style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 14px', background: addrPromptDraft.deliveryService === opt.key ? 'var(--accent-2-wash)' : 'var(--bg-elevated)', border: `1px solid ${addrPromptDraft.deliveryService === opt.key ? 'var(--accent-2)' : 'var(--border)'}`, borderRadius: '12px', cursor: 'pointer', textAlign: 'left' }}>
                        <Icon name={opt.icon} size={18} color={addrPromptDraft.deliveryService === opt.key ? 'var(--accent-2-hi)' : 'var(--text-muted)'} />
                        <div style={{ flex: 1 }}>
                          <p style={{ color: addrPromptDraft.deliveryService === opt.key ? 'var(--accent-2-hi)' : 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: 0 }}>{opt.label}</p>
                          <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>{opt.sub}</p>
                        </div>
                        {addrPromptDraft.deliveryService === opt.key && <Icon name="check" size={15} color="var(--accent-2-hi)" />}
                      </button>
                    ))}
                  </div>

                  <p style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 600, margin: '0 0 8px' }}>Адрес / пункт выдачи</p>
                  <textarea value={addrPromptDraft.address} onChange={e => setAddrPromptDraft(p => ({ ...p, address: e.target.value }))}
                    placeholder="Город, улица, пункт выдачи, индекс…" rows={3}
                    style={{ width: '100%', boxSizing: 'border-box', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '12px', padding: '12px', color: 'var(--text-primary)', fontSize: '13px', resize: 'vertical', marginBottom: '14px', fontFamily: 'inherit' }} />

                  <button className="btn-primary" disabled={!addrPromptDraft.address.trim() || !addrPromptDraft.deliveryService} style={{ marginBottom: '8px', opacity: (!addrPromptDraft.address.trim() || !addrPromptDraft.deliveryService) ? 0.55 : 1 }}
                    onClick={() => {
                      updateProfile({ ...currentProfile, address: addrPromptDraft.address.trim(), deliveryService: addrPromptDraft.deliveryService })
                      setSbpPay(addrPrompt)
                      setAddrPrompt(null)
                    }}>Сохранить и продолжить оплату</button>
                  <button className="btn-secondary" onClick={() => { setAddrPrompt(null); setToast('Заказ не создан'); setTimeout(() => setToast(''), 2000) }}>Отмена</button>
                </div>
              </div>
            )}

            {toast && <div className="toast-enter" style={{ position: 'absolute', top: '56px', left: '50%', transform: 'translateX(-50%)', background: 'var(--success)', color: '#0e1621', borderRadius: '10px', padding: '8px 18px', fontSize: '12px', fontWeight: 600, zIndex: 100, whiteSpace: 'nowrap', boxShadow: '0 4px 18px rgba(52,201,125,0.3)', maxWidth: '90%', textAlign: 'center' }}>{toast}</div>}
            {!online && <div className="toast-enter" style={{ position: 'absolute', top: '14px', left: '50%', transform: 'translateX(-50%)', display: 'flex', alignItems: 'center', gap: '7px', background: 'var(--top-bar-bg)', border: '1px solid var(--ss-brand-edge)', color: 'var(--ss-ink-2, #c8c2dd)', borderRadius: '999px', padding: '7px 14px', fontSize: '11.5px', fontWeight: 600, zIndex: 200, whiteSpace: 'nowrap', boxShadow: '0 6px 22px -8px var(--ss-brand-glow)', backdropFilter: 'blur(10px)', maxWidth: '92%' }}><span style={{ width: '7px', height: '7px', borderRadius: '50%', background: '#f5c842', boxShadow: '0 0 8px #f5c842', flexShrink: 0 }} />Нет сети — показываем сохранённый каталог</div>}
            {orderToast && <div className={`toast-br${orderToast.leaving ? ' leaving' : ''}`} style={{ position: 'absolute', bottom: '78px', right: '14px', display: 'flex', alignItems: 'center', gap: '9px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderLeft: '3px solid var(--success)', borderRadius: '12px', padding: '11px 14px', zIndex: 120, maxWidth: '80%', boxShadow: '0 10px 34px rgba(0,0,0,0.35)' }}>
              <div style={{ width: '26px', height: '26px', borderRadius: '50%', background: 'var(--success)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><Icon name="check" size={15} color="#0e1621" strokeWidth={2.4} /></div>
              <span style={{ color: 'var(--text-primary)', fontSize: '12px', fontWeight: 600, lineHeight: 1.35 }}>{orderToast.text}</span>
            </div>}

            <MasterHint progress={sigmaHold.progress} />
            {showOnboard && !masterTransition && <SigmaOnboarding isAdmin={canCRM} onClose={closeOnboard} />}
            {masterTransition && <MasterTransition onDone={() => { setMasterTransition(false); setTab('crm') }} />}
            {gamesOpen && (
              <GamesView
                points={currentProfile?.points ?? 0}
                coins={currentProfile?.coins ?? 0}
                dailyWheelAt={currentProfile?.dailyWheelAt ?? 0}
                dailyBetAt={currentProfile?.dailyBetAt ?? 0}
                onPatch={patch => updateProfile({ ...currentProfile, ...patch })}
                onClose={() => setGamesOpen(false)}
              />
            )}

            {/* Баннер «магазин на паузе» — виден клиентам над любым разделом (кроме CRM) */}
            {shopStatus.on && tab !== 'crm' && (
              <div style={{ flexShrink: 0, display: 'flex', gap: '10px', alignItems: 'flex-start', margin: '8px 10px 0', padding: '11px 13px', background: 'linear-gradient(135deg, rgba(245,200,66,0.14), rgba(245,158,11,0.08))', border: '1px solid rgba(245,200,66,0.34)', borderRadius: '14px', boxShadow: '0 6px 20px -10px rgba(245,158,11,0.5)' }}>
                <div style={{ width: '30px', height: '30px', borderRadius: '9px', background: 'rgba(245,200,66,0.18)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Icon name="info" size={17} color="#f5c842" />
                </div>
                <div style={{ minWidth: 0 }}>
                  <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, margin: '1px 0 2px' }}>{shopStatus.title || 'Магазин на паузе'}</p>
                  {(shopStatus.text || '').trim() && <p style={{ color: 'var(--text-muted)', fontSize: '11.5px', lineHeight: 1.4, margin: 0 }}>{shopStatus.text}</p>}
                </div>
              </div>
            )}

            {/* Content */}
            <div key={tab} data-app-scroll className={isFull ? undefined : 'view-swap'} style={{ flex: 1, overflowY: isFull ? 'hidden' : 'auto', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
              {tab === 'home' && (openCollection
                ? <CollectionView collection={openCollection} onBack={() => setOpenCollection(null)} onOrder={handleOrder} products={visibleProducts} orders={orders} reviews={reviews} setReviews={setReviewsCloud} authUser={authUser} favorites={favorites} setFavorites={setFavorites} activeDiscount={activeDiscount} activePromoCode={activePromo?.code} payEnabled={payEnabled} allFavorites={allFavorites} waitlist={waitlist} onToggleWaitlist={toggleWaitlist} />
                : <HomeView home={home} onOpenCollection={setOpenCollection} sections={sections} materials={materials} customOrder={customOrder} onOrder={handleOrder} products={visibleProducts} orders={orders} reviews={reviews} setReviews={setReviewsCloud} authUser={authUser} favorites={favorites} setFavorites={setFavorites} activeDiscount={activeDiscount} activePromoCode={activePromo?.code} payEnabled={payEnabled} allFavorites={allFavorites} featuredPromo={featuredPromo} promoApplied={promoApplied} onActivatePromo={activateFeaturedPromo} loyalty={loyaltyCfg(loyalty)} bonusPoints={currentProfile?.points ?? 0} onGoFaq={(id) => { setFaqTarget(id ?? null); setTab('faq') }} onGoCatalog={(f) => { setCatalogInitFilter(f); setTab('catalog') }} onOpenGames={() => setGamesOpen(true)} waitlist={waitlist} onToggleWaitlist={toggleWaitlist} />)}
              {tab === 'catalog'  && <CatalogView onOrder={handleOrder} products={visibleProducts} sections={sections} orders={orders} reviews={reviews} setReviews={setReviewsCloud} authUser={authUser} favorites={favorites} setFavorites={setFavorites} activeDiscount={activeDiscount} activePromoCode={activePromo?.code} promoExpiresAt={activePromo?.expiresAt ?? 0} payEnabled={payEnabled} allFavorites={allFavorites} featuredPromo={featuredPromo} promoApplied={promoApplied} onActivatePromo={activateFeaturedPromo} catalogFilters={catalogFilters} initialFilter={catalogInitFilter} waitlist={waitlist} onToggleWaitlist={toggleWaitlist} />}
              {tab === 'profile'  && <ProfileView orders={isAdmin ? orders : myOrders} profile={currentProfile} onProfileChange={updateProfile} onGoOrders={() => setTab('orders')} onGoSettings={() => setTab('settings')} onGoFaq={() => setTab('faq')} onGoCrm={canCRM ? () => setMasterTransition(true) : undefined} onGoCatalog={() => { setCatalogInitFilter('all'); setTab('catalog') }} products={visibleProducts} favorites={favorites} setFavorites={setFavorites} reviews={reviews} setReviews={setReviewsCloud} onOrder={handleOrder} promocodes={promocodes} authLogin={authUser.login} activeDiscount={activeDiscount} activePromoCode={activePromo?.code} payEnabled={payEnabled} canEditCover={canEditCover} coverUrl={coverUrl} loyalty={loyaltyCfg(loyalty)} appVersion={appVersion} onVersionChange={isAdmin ? setAppVersionCloud : undefined} waitlist={waitlist} onToggleWaitlist={toggleWaitlist} />}
              {tab === 'orders'   && <OrdersView orders={isAdmin ? orders : myOrders} isAdmin={isAdmin} shopContact={sbpInfo.contact || OWNER_TG} onShopContactChange={v => setSbpCloud(prev => ({ ...prev, contact: v }))} />}
              {tab === 'faq'      && <FAQView sections={faqSections} initialOpen={faqTarget} supportTg={sbpInfo.support || sbpInfo.contact || OWNER_TG} />}
              {tab === 'crm'      && canCRM && <div data-surface="crm" style={{ display: 'contents' }}><CRMView products={products} setProducts={setProducts} sections={sections} setSections={setSections} orders={orders} onOrderStatus={handleOrderStatus} onOrderTrack={handleOrderTrack} onOrderDelete={handleOrderDelete} onOrderCreate={handleOrderCreate} onPayVerify={handlePayVerify} roles={roles} setRoles={setRolesCloud} sbpInfo={sbpInfo} setSbpInfo={setSbpCloud} allowedTabs={crmAllowed} registeredUsers={registeredUsers} onUserDelete={handleUserDelete} onWipeClients={wipeClients} onWipeStats={wipeStats} onMigrateImages={migrateImages} faqSections={faqSections} setFaqSections={setFaqCloud} materials={materials} setMaterials={setMaterialsCloud} reviews={reviews} setReviews={setReviewsCloud} profiles={profiles} lastSeenTimes={lastSeenTimes} notice={notice} setNotice={setNoticeCloud} banner={banner} setBanner={setBannerCloud} home={home} setHome={setHomeCloud} customOrder={customOrder} setCustomOrder={setCustomOrderCloud} promocodes={promocodes} setPromocodes={setPromosCloud} payEnabled={payEnabled} setPayEnabled={setPayEnabledCloud} shopStatus={shopStatus} setShopStatus={setShopStatusCloud} onProductsChange={pushProductsToCloud} onSectionsChange={pushSectionsToCloud} allFavorites={allFavorites} waitlist={waitlist} crmOrder={crmOrder} setCrmOrder={setCrmOrderCloud} crmLeft={crmLeft} setCrmLeft={setCrmLeftCloud} isOwner={isOwner} coverMode={coverMode} setCoverMode={setCoverModeCloud} loyalty={loyaltyCfg(loyalty)} setLoyalty={setLoyaltyCloud} catalogFilters={catalogFilters} setCatalogFilters={setCatalogFiltersCloud} onAdjustPoints={onAdjustPoints} /></div>}
              {tab === 'settings' && <SettingsView profile={currentProfile} onProfileChange={updateProfile} promocodes={promocodes} authLogin={authUser.login} onReplayOnboard={replayOnboard} onResetOnboardAll={isAdmin ? resetOnboardForAll : undefined} />}
            </div>

            {/* Tab bar — фиксированная раскладка: слева Каталог/Профиль, по центру портал Σ,
                справа Заказы/Настройки. CRM снизу нет — открывается удержанием Σ. */}
            {(() => {
              const TabBtn = (t: { key: Tab; label: string; icon: IconName; badge?: number }) => {
                const active = tab === t.key
                return (
                  <button key={t.key} data-nav={t.key} onClick={() => { if (t.key === 'catalog') setCatalogInitFilter('all'); setTab(t.key) }} className="ss-press" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px', background: 'none', border: 'none', cursor: 'pointer', padding: '3px 0', transition: 'color var(--ss-t-base) var(--ss-ease)' }}>
                    <span style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      {/* Свечение только за иконкой активного раздела — текст не трогаем */}
                      {active && <span aria-hidden style={{ position: 'absolute', width: '38px', height: '38px', borderRadius: '50%', background: 'radial-gradient(circle, var(--ss-brand-glow) 0%, transparent 70%)', filter: 'blur(2px)', pointerEvents: 'none' }} />}
                      <Icon name={t.icon} size={20} color={active ? 'var(--tab-active)' : 'var(--tab-inactive)'} strokeWidth={active ? 2 : 1.6} />
                      {t.badge && t.badge > 0 ? <span style={{ position: 'absolute', top: '-5px', right: '-8px', minWidth: '15px', height: '15px', borderRadius: '8px', background: 'var(--ss-brand)', border: '2px solid var(--bg-base)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '8px', fontWeight: 700, color: '#fff', padding: '0 3px', boxSizing: 'border-box', boxShadow: '0 0 10px -2px var(--ss-brand-glow)' }}>{t.badge}</span> : null}
                    </span>
                    <span style={{ fontSize: '9px', fontWeight: 500, color: active ? 'var(--tab-active)' : 'var(--tab-inactive)', lineHeight: 1 }}>{t.label}</span>
                    <span className="tab-pip" style={{ width: active ? '16px' : '0' }} />
                  </button>
                )
              }
              return (
                <div style={{ position: 'relative', background: 'var(--tab-bar-bg)', backdropFilter: 'blur(22px) saturate(1.4)', borderTop: '1px solid var(--tab-bar-border)', display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', alignItems: 'center', padding: '8px 0 max(8px, env(safe-area-inset-bottom))', flexShrink: 0, zIndex: 70, boxShadow: '0 -12px 34px rgba(0,0,0,0.55)' }}>
                  {/* Дым, поднимающийся из-под центральной кнопки Σ */}
                  <div aria-hidden style={{ position: 'absolute', left: '50%', top: 0, transform: 'translate(-50%, -100%)', width: '96px', height: '84px', pointerEvents: 'none', overflow: 'visible', zIndex: 1 }}>
                    <span className="ss-smoke ss-smoke-1" />
                    <span className="ss-smoke ss-smoke-2" />
                    <span className="ss-smoke ss-smoke-3" />
                  </div>
                  {leftTabs.map(TabBtn)}
                  {/* Центральная колонка-держатель под Σ — отдельная кнопка, под ней ничего нет */}
                  <div aria-hidden style={{ height: 1 }} />
                  {rightTabs.map(TabBtn)}

                  {/* Центральная кнопка бренда Σ: тап — каталог, удержание — панель мастера */}
                  <button
                    data-nav="home"
                    onClick={() => { if (!sigmaHold.consumed()) { setOpenCollection(null); setTab('home') } }}
                    {...sigmaHold.handlers}
                    aria-label={canCRM ? 'Главная, удержание — панель мастера' : 'Главная'}
                    className="ss-press" style={{
                    position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -70%)',
                    boxSizing: 'border-box',
                    width: '64px', height: '64px', borderRadius: '50%', display: 'grid', placeItems: 'center', cursor: 'pointer', zIndex: 2,
                    background: 'radial-gradient(circle at 50% 32%, #1a1430, #05060a)',
                    border: '1px solid var(--ss-brand-edge)',
                    boxShadow: tab === 'home'
                      ? '0 10px 26px rgba(0,0,0,0.6), 0 0 32px -6px var(--ss-brand-glow), inset 0 1px 0 rgba(255,255,255,0.10)'
                      : '0 10px 22px rgba(0,0,0,0.55), 0 0 18px -10px var(--ss-brand-glow), inset 0 1px 0 rgba(255,255,255,0.07)',
                  }}>
                    <svg viewBox="0 0 54 54" style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', display: 'block', animation: 'ss-ring-spin 14s linear infinite', transformOrigin: '50% 50%' }}>
                      <defs>
                        <linearGradient id="sigma-ring-duo" x1="0" y1="0" x2="1" y2="1">
                          <stop offset="0%" stopColor="var(--ss-brand-hi, #a855f7)" />
                          <stop offset="100%" stopColor="var(--ss-blue-hi, #4f8dff)" />
                        </linearGradient>
                      </defs>
                      <circle cx="27" cy="27" r="24.5" fill="none" stroke="url(#sigma-ring-duo)" strokeWidth="1.3" strokeDasharray="24 11" strokeLinecap="round" opacity="0.8" />
                    </svg>
                    <HoldRing progress={sigmaHold.progress} />
                    <span style={{ position: 'relative', color: 'var(--ss-brand-hi)', fontSize: '30px', fontWeight: 700, lineHeight: 1, fontFamily: '"Georgia","Times New Roman",serif', textShadow: '0 0 12px var(--ss-brand-glow)' }}>Σ</span>
                  </button>
                </div>
              )
            })()}
          </>
        )}

        {/* Welcome notice modal */}
        {showWelcome && (
          <div data-theme="dark" className={`welcome-overlay${welcomeLeaving ? ' out' : ''}`} style={{
            // Нижняя навигация остаётся видимой и не затемняется — как на референсе
            position: 'absolute', top: 0, left: 0, right: 0,
            bottom: 'calc(52px + max(6px, env(safe-area-inset-bottom)))',
            zIndex: 500, display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
            padding: '0 6px 6px', background: 'rgba(2,4,9,0.72)', backdropFilter: 'blur(6px)', overflowY: 'auto',
          }}>
            {/* Масштабирующая обёртка: уменьшает всю панель целиком (рамку, кольца,
                треугольник) единым коэффициентом, сохраняя пропорции. Не анимируется,
                поэтому scale держится (в отличие от .welcome-wrap, чья анимация с
                fill:both перезаписала бы inline-transform). Origin снизу — панель
                остаётся прижата к нижней кромке. */}
            <div style={{ width: '100%', display: 'flex', justifyContent: 'center', transform: 'scale(0.84)', transformOrigin: 'bottom center' }}>
            {/* Обёртка: рамка обрезана, а бейдж и угловой декор рисуются поверх и
                могут выходить за края */}
            <div className={`welcome-wrap${welcomeLeaving ? ' out' : ''}`} style={{ position: 'relative', width: '100%', maxWidth: '352px', marginTop: 'auto' }}>

              {/* Кибер-рамка: срезанные углы + боковые HUD-скобы (форма задана clip-path) */}
              <div className="welcome-frame" style={{
                position: 'relative', padding: '3.5px',
                background: 'linear-gradient(160deg,#6d82a3 0%,#33445c 26%,#1c2634 52%,#48607f 74%,#232f3f 100%)',
              }}>
                <div className="welcome-fill" style={{
                  position: 'relative', padding: '62px 12px 12px',
                  background: 'linear-gradient(175deg, rgba(9,13,20,0.97) 0%, rgba(6,9,15,0.98) 52%, rgba(3,5,10,1) 100%)',
                }}>
                  {/* Заголовок */}
                  <div style={{ textAlign: 'center' }}>
                    <h2 style={{ color: '#ff1f35', fontSize: '26px', fontWeight: 900, letterSpacing: '0.02em', lineHeight: 1, margin: 0, textShadow: '0 0 22px rgba(255,31,53,0.55)' }}>{notice.title || 'ВАЖНО'}</h2>
                    <p style={{ color: '#fff', fontSize: '13px', fontWeight: 700, margin: '6px 0 0', letterSpacing: '0.01em' }}>{notice.subtitle}</p>
                  </div>

                  {/* Пунктирный разделитель: штрихи разной длины и яркости */}
                  <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '6px', margin: '9px 0 11px' }}>
                    {[[14, 0.35], [9, 0.55], [6, 0.85], [9, 1], [6, 0.85], [9, 0.55], [14, 0.35]].map(([w, op], k) => (
                      <span key={k} style={{
                        width: `${w}px`, height: '3px', borderRadius: '2px', background: '#ff1f35', opacity: op,
                        boxShadow: op >= 0.85 ? '0 0 8px rgba(255,31,53,0.9)' : 'none',
                      }} />
                    ))}
                  </div>

                  {/* карточки-информация (редактируются в CRM → «Важное») */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginBottom: '16px' }}>
                    {notice.items.map((c, idx) => (
                      <div key={c.id} className="welcome-item" style={{
                        ['--wi-delay' as string]: `${0.18 + idx * 0.08}s`, position: 'relative',
                        display: 'flex', gap: '10px', alignItems: 'center', padding: '9px 19px 9px 9px', borderRadius: '12px',
                        background: 'linear-gradient(150deg, rgba(255,31,53,0.05), rgba(255,255,255,0.014))',
                        border: '1px solid rgba(255,31,53,0.16)',
                      }}>
                        <div style={{
                          width: '36px', height: '36px', borderRadius: '11px', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                          background: 'rgba(255,31,53,0.07)', border: '1px solid rgba(255,31,53,0.18)',
                        }}><Icon name={c.icon} size={17} color="#ff4256" /></div>
                        <div style={{ minWidth: 0 }}>
                          <p style={{ color: '#fff', fontSize: '12.5px', fontWeight: 700, lineHeight: 1.3, margin: 0, whiteSpace: 'pre-line' }}>{c.text}</p>
                          {c.sub && <p style={{ color: '#7b8498', fontSize: '10.5px', lineHeight: 1.35, margin: '2px 0 0' }}>{c.sub}</p>}
                        </div>
                        {/* красный квадратный маркер справа */}
                        <span style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', width: '5px', height: '5px', background: '#ff1f35', boxShadow: '0 0 8px rgba(255,31,53,0.9)' }} />
                      </div>
                    ))}
                  </div>

                  {/* CTA с угловыми скобами и колонками штрихов по бокам */}
                  <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 22px' }}>
                    {([['left', 'flex-start'], ['right', 'flex-end']] as const).map(([side]) => (
                      <div key={side} style={{ position: 'absolute', [side]: '2px', display: 'flex', flexDirection: 'column', gap: '5px', pointerEvents: 'none' }}>
                        {[0.9, 0.6, 0.6, 0.9].map((op, k) => (
                          <span key={k} style={{ width: '4px', height: '9px', background: '#ff1f35', opacity: op, boxShadow: op > 0.8 ? '0 0 7px rgba(255,31,53,0.9)' : 'none' }} />
                        ))}
                      </div>
                    ))}
                    <div style={{ position: 'relative', flex: 1 }}>
                      {/* угловые скобы кнопки */}
                      {([[0, 0], [0, 1], [1, 0], [1, 1]] as const).map(([b, r], k) => (
                        <span key={k} style={{
                          position: 'absolute', width: '16px', height: '13px', pointerEvents: 'none',
                          [b ? 'bottom' : 'top']: '-5px', [r ? 'right' : 'left']: '-5px',
                          [b ? 'borderBottom' : 'borderTop']: '2px solid #ff1f35',
                          [r ? 'borderRight' : 'borderLeft']: '2px solid #ff1f35',
                        }} />
                      ))}
                      <button className="welcome-cta" onClick={closeWelcome}
                        style={{
                          width: '100%', padding: '15px', borderRadius: '10px', border: 'none', cursor: 'pointer', position: 'relative', overflow: 'hidden',
                          background: 'linear-gradient(180deg, #ff4256 0%, #ec1c30 46%, #b3101f 100%)',
                          color: '#fff', fontSize: '16px', fontWeight: 700, letterSpacing: '0.01em',
                        }}>
                        <span className="welcome-cta-sheen" />
                        <span style={{ position: 'relative' }}>{notice.buttonText || 'Понятно, продолжить'}</span>
                      </button>
                    </div>
                  </div>

                  {/* «Больше не показывать» — серым, без акцента */}
                  <button onClick={() => setWelcomeNoShow(v => !v)} style={{
                    display: 'block', width: '100%', marginTop: '13px', padding: 0, background: 'none', border: 'none',
                    cursor: 'pointer', fontFamily: 'inherit', fontSize: '13px',
                    color: welcomeNoShow ? '#ff1f35' : '#7b8498',
                    textDecoration: welcomeNoShow ? 'underline' : 'none', transition: 'color 0.15s ease',
                  }}>Больше не показывать</button>
                </div>
              </div>

              {/* Угловые HUD-скобки на четырёх срезах */}
              <CyberCorner rot={0}   style={{ top: '-2px', right: '-2px' }} />
              <CyberCorner rot={90}  style={{ bottom: '-2px', right: '-2px' }} />
              <CyberCorner rot={180} style={{ bottom: '-2px', left: '-2px' }} />
              <CyberCorner rot={270} style={{ top: '-2px', left: '-2px' }} />

              {/* Красные диагональные насечки по бокам — в зоне HUD-скоб */}
              {([['left', 'left'], ['right', 'right']] as const).map(([side]) => (
                <div key={side} style={{
                  position: 'absolute', top: '104px', [side]: '18px',
                  display: 'flex', flexDirection: 'column', gap: '6px', pointerEvents: 'none',
                }}>
                  {[1, 0.75, 0.5, 0.3].map((op, k) => (
                    <span key={k} style={{
                      width: '18px', height: '3px', background: '#ff1f35', opacity: op,
                      transform: `skewX(${side === 'left' ? '-40deg' : '40deg'})`,
                      boxShadow: op === 1 ? '0 0 8px rgba(255,31,53,0.8)' : 'none',
                    }} />
                  ))}
                </div>
              ))}
              {/* Штрихи у верхней кромки справа */}
              <div style={{ position: 'absolute', top: '-1px', right: '26px', display: 'flex', gap: '5px', pointerEvents: 'none' }}>
                {[16, 12, 8, 5].map((w, k) => (
                  <span key={k} style={{ width: `${w}px`, height: '3px', background: '#ff1f35', opacity: 0.9 - k * 0.16 }} />
                ))}
              </div>

              {/* Бейдж-предупреждение: сканирующее кольцо + неоновый треугольник, вынесен
                  выше панели. Центр поднят над кромкой (translateY −64%), чтобы нижняя
                  дуга колец и треугольник не наезжали на заголовок «ВАЖНО». */}
              <div style={{ position: 'absolute', top: 0, left: '50%', width: '138px', height: '138px', transform: 'translate(-50%, -64%)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <div style={{
                  position: 'absolute', width: '96px', height: '96px', borderRadius: '50%',
                  background: 'radial-gradient(circle, rgba(255,31,53,0.20) 0%, transparent 70%)',
                }} />
                {/* внешнее кольцо — вращается */}
                <svg className="welcome-ring" viewBox="0 0 138 138" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
                  <circle cx="69" cy="69" r="67" fill="none" stroke="rgba(255,31,53,0.55)" strokeWidth="1.4" strokeDasharray="16 9" />
                  <circle cx="69" cy="69" r="67" fill="none" stroke="rgba(255,31,53,0.9)" strokeWidth="3" strokeDasharray="11 20" strokeLinecap="round" />
                </svg>
                {/* дополнительное кольцо — вращается в обратную сторону */}
                <svg className="welcome-ring-ccw" viewBox="0 0 138 138" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
                  <circle cx="69" cy="69" r="58" fill="none" stroke="rgba(255,31,53,0.5)" strokeWidth="1.2" strokeDasharray="4 14" strokeLinecap="round" />
                </svg>
                {/* ещё одно маленькое кольцо — крутится по часовой, короткая дуга */}
                <svg className="welcome-ring-cw2" viewBox="0 0 138 138" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
                  <circle cx="69" cy="69" r="44" fill="none" stroke="rgba(255,31,53,0.32)" strokeWidth="0.8" strokeDasharray="2 8" />
                  <circle cx="69" cy="69" r="44" fill="none" stroke="rgba(255,80,95,0.9)" strokeWidth="2.2" strokeDasharray="7 15" strokeLinecap="round" />
                </svg>
                {/* внутренние кольца — неподвижные */}
                <svg viewBox="0 0 138 138" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
                  <circle cx="69" cy="69" r="50" fill="none" stroke="rgba(255,31,53,0.30)" strokeWidth="0.7" strokeDasharray="1 5" />
                  {/* тики на 12 / 3 / 6 / 9 часов */}
                  {[0, 90, 180, 270].map(a => (
                    <rect key={a} x="66.5" y="0" width="5" height="10" fill="#ff1f35"
                          transform={`rotate(${a} 69 69)`} opacity="0.95" />
                  ))}
                </svg>
                {/* треугольник */}
                <svg viewBox="0 0 100 100" width="82" height="82" style={{ position: 'relative', filter: 'drop-shadow(0 0 16px rgba(255,31,53,0.9))' }}>
                  <path d="M50 16 L88 82 H12 Z" fill="rgba(255,31,53,0.10)" stroke="#ff1f35" strokeWidth="5"
                        strokeLinejoin="round" />
                  <line x1="50" y1="42" x2="50" y2="62" stroke="#ff1f35" strokeWidth="6" strokeLinecap="round" />
                  <circle cx="50" cy="71" r="3.4" fill="#ff1f35" />
                </svg>
              </div>
            </div>
            </div>
          </div>
        )}
      </div>
    </ThemeCtx.Provider>
    </AuthCtx.Provider>
  )
}
