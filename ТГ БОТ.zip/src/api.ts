import { projectId, publicAnonKey } from "../utils/supabase/info"

const BASE = `https://${projectId}.supabase.co/functions/v1/make-server-f6480290`
const STORAGE = `https://${projectId}.supabase.co/storage/v1/object`
const BUCKET = "product-images"

// Прямой доступ к таблице kv_store через PostgREST. Используется, пока edge-
// функция с серверной фильтрацией не развёрнута (RLS на таблице должен быть
// ВЫКЛЮЧЕН, иначе анонимный ключ получит 401/42501). Это временное решение без
// защиты PII — данные видны всем клиентам, фильтрация только на клиенте.
const REST = `https://${projectId}.supabase.co/rest/v1`
const KV_TABLE = "kv_store_dee2fafb"
function restHeaders(extra?: Record<string, string>): Record<string, string> {
  return {
    apikey: publicAnonKey,
    Authorization: `Bearer ${publicAnonKey}`,
    "Content-Type": "application/json",
    ...(extra || {}),
  }
}

// Данные личности для сервера: подписанные данные Telegram (подделать нельзя)
// и «ключ разработчика» для веб-превью (задаётся вручную, не зашит в бандл).
// Личность и права проверяет сервер — клиент лишь предъявляет доказательство.
//
// ВАЖНО: передаём их в ТЕЛЕ запроса, а не в кастомных заголовках. Кастомные
// заголовки (X-Init-Data и т.п.) заставляют браузер делать CORS-preflight, а
// если развёрнутая функция их не перечислила в Access-Control-Allow-Headers —
// браузер молча режет запрос («Failed to fetch»). Тело же не требует preflight
// при обычном Content-Type: application/json + Authorization.
interface AuthProof { initData?: string; devKey?: string }
function authProof(): AuthProof {
  const p: AuthProof = {}
  try {
    const tg = (window as unknown as { Telegram?: { WebApp?: { initData?: string } } }).Telegram?.WebApp
    if (tg?.initData) p.initData = tg.initData
  } catch { /* нет Telegram */ }
  try {
    const dev = localStorage.getItem("fs_devKey")
    if (dev) p.devKey = dev
  } catch { /* нет localStorage */ }
  return p
}

// ─────────────────────────────────────────────────────────────
// Защита от злоупотреблений / флуда запросами
// ─────────────────────────────────────────────────────────────
// Настоящая защита от DDoS работает только на уровне инфраструктуры (Cloudflare,
// WAF, rate-limit на стороне Supabase). Здесь — клиентский слой, который не даёт
// приложению самому положить бэкенд: ограничивает частоту запросов, схлопывает
// дубли, отменяет зависшие запросы и корректно отступает при 429/5xx.

// Token bucket: не более BURST запросов разом, восполнение RATE в секунду.
const RATE = 6, BURST = 12
let tokens = BURST
let lastRefill = Date.now()
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms))

async function takeToken(): Promise<void> {
  for (;;) {
    const now = Date.now()
    tokens = Math.min(BURST, tokens + ((now - lastRefill) / 1000) * RATE)
    lastRefill = now
    if (tokens >= 1) { tokens -= 1; return }
    await sleep(Math.ceil(((1 - tokens) / RATE) * 1000))
  }
}

// Пауза после ответа 429/503: пока «остываем», новые запросы не уходят.
let cooldownUntil = 0

// Квота проекта исчерпана (402 exceed_egress_quota и т.п.). Пока «блокировка»
// активна, нет смысла долбить бэкенд новыми запросами — это только жжёт остаток
// квоты и плодит ошибки. Держим паузу и даём приложению узнать об этом.
let quotaBlockedUntil = 0
const QUOTA_COOLDOWN_MS = 10 * 60 * 1000
export function cloudQuotaActive(): boolean { return Date.now() < quotaBlockedUntil }
export class CloudQuotaError extends Error {
  constructor(message = "Облако временно недоступно: превышена квота проекта") {
    super(message)
    this.name = "CloudQuotaError"
  }
}
function isQuotaBody(body: string): boolean {
  return /exceed_egress_quota|egress|quota|restricted|violation/i.test(body)
}

// Схлопывание одинаковых GET-запросов, летящих одновременно.
const inflight = new Map<string, Promise<Response>>()

const MAX_ATTEMPTS = 3
const TIMEOUT_MS = 15000

// Единая точка выхода в сеть: лимит частоты, таймаут, повтор с экспоненциальной
// задержкой и джиттером, дедупликация одинаковых GET.
async function guardedFetch(url: string, init: RequestInit = {}, dedupeKey?: string): Promise<Response> {
  const key = dedupeKey ?? ((init.method ?? "GET").toUpperCase() === "GET" ? url : null)
  if (key && inflight.has(key)) return (await inflight.get(key)!).clone()

  const run = (async () => {
    let lastErr: unknown
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      const wait = cooldownUntil - Date.now()
      if (wait > 0) await sleep(wait)
      await takeToken()

      const ctrl = new AbortController()
      const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS)
      try {
        const res = await fetch(url, { ...init, signal: ctrl.signal })
        clearTimeout(timer)
        // Квота проекта исчерпана — уходим в длинную паузу и не повторяем.
        if (res.status === 402) {
          quotaBlockedUntil = Date.now() + QUOTA_COOLDOWN_MS
          return res
        }
        // Сервер просит притормозить или временно недоступен — отступаем.
        if (res.status === 429 || res.status === 503) {
          const retryAfter = Number(res.headers.get("Retry-After")) * 1000
          const backoff = retryAfter > 0 ? retryAfter : Math.min(8000, 2 ** attempt * 500) + Math.random() * 300
          cooldownUntil = Date.now() + backoff
          if (attempt < MAX_ATTEMPTS) { await sleep(backoff); continue }
        }
        return res
      } catch (e) {
        clearTimeout(timer)
        lastErr = e
        if (attempt < MAX_ATTEMPTS) await sleep(Math.min(6000, 2 ** attempt * 400) + Math.random() * 250)
      }
    }
    throw lastErr instanceof Error ? lastErr : new Error("network error")
  })()

  if (key) {
    inflight.set(key, run)
    run.finally(() => inflight.delete(key)).catch(() => {})
    return (await run).clone()
  }
  return run
}

// Ограничение размера загружаемого файла — защита от заливки гигабайтов.
// У фото лимит небольшой (их всегда сжимаем перед загрузкой), у видео — крупнее:
// ролик с телефона легко весит несколько десятков МБ, а сжать его в браузере
// надёжно нельзя. Тип определяем по MIME файла.
const MAX_IMAGE_BYTES = 8 * 1024 * 1024
const MAX_VIDEO_BYTES = 50 * 1024 * 1024

// Загрузка изображения в Supabase Storage. Возвращает публичную ссылку.
export const storage = {
  upload: async (file: File): Promise<string> => {
    const isVideo = (file.type || "").startsWith("video/")
    const limit = isVideo ? MAX_VIDEO_BYTES : MAX_IMAGE_BYTES
    if (file.size > limit) throw new Error(`Файл слишком большой (${(file.size / 1048576).toFixed(1)} МБ, максимум ${(limit / 1048576).toFixed(0)} МБ)`)
    const ext = (file.name.split(".").pop() || "jpg").toLowerCase()
    const path = `products/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`
    const res = await guardedFetch(`${STORAGE}/${BUCKET}/${path}`, {
      method: "POST",
      headers: {
        apikey: publicAnonKey,
        Authorization: `Bearer ${publicAnonKey}`,
        "Content-Type": file.type || "application/octet-stream",
        // Путь файла уникален и никогда не переиспользуется, поэтому картинку можно
        // кэшировать на год. По умолчанию Storage ставит всего час — из-за этого
        // одни и те же фото каждый день скачивались заново.
        "cache-control": "public, max-age=31536000, immutable",
        // Без upsert: путь всегда уникален, а upsert потребовал бы SELECT-политику.
      },
      body: file,
    })
    if (!res.ok) {
      const body = await res.text().catch(() => "")
      throw new Error(`upload ${res.status}: ${body.slice(0, 160) || res.statusText}`)
    }
    return `${STORAGE}/public/${BUCKET}/${path}`
  },
}

// Базовые заголовки любого обращения к edge-функции: только анонимный ключ (для
// допуска к самой функции) и Content-Type. Никаких кастомных заголовков — чтобы
// не провоцировать CORS-preflight. «Кто ты и что тебе можно» решают данные
// личности в теле запроса (_auth) + проверка на сервере.
function fnHeaders(extra?: Record<string, string>): Record<string, string> {
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${publicAnonKey}`,
    ...(extra || {}),
  }
}

// Подмешивает доказательство личности в тело POST-запроса.
function withAuth(bodyObj: Record<string, any> = {}): string {
  return JSON.stringify({ ...bodyObj, _auth: authProof() })
}

async function call(path: string, options: RequestInit = {}) {
  // В любое обращение к функции добавляем _auth в тело (кроме GET без тела).
  let body = options.body
  const method = (options.method ?? "GET").toUpperCase()
  if (method !== "GET") {
    let parsed: Record<string, any> = {}
    if (typeof body === "string" && body) {
      try { parsed = JSON.parse(body) } catch { parsed = {} }
    }
    body = withAuth(parsed)
  }
  const res = await guardedFetch(BASE + path, {
    ...options,
    body,
    headers: fnHeaders(options.headers as Record<string, string> | undefined),
  })
  if (!res.ok) throw new Error(`API ${path} failed: ${res.status}`)
  return res.json()
}

export interface ServerState {
  orders: any[]
  users: any[]
}

// Доступ к kv_store ТОЛЬКО через edge-функцию: сервер под service_role сам решает,
// что вернуть и что разрешить записать (см. supabase/functions/server/index.tsx).
// Прямой доступ к таблице закрыт (RLS включена, anon-ключ к таблице не пускают).
export const kv = {
  get: async (key: string): Promise<any> => {
    const url = `${REST}/${KV_TABLE}?key=eq.${encodeURIComponent(key)}&select=value`
    const res = await guardedFetch(url, { headers: restHeaders() }, `read:${key}`)
    if (!res.ok) throw new Error(`kvGet ${res.status}`)
    const rows = await res.json()
    return Array.isArray(rows) && rows.length ? rows[0].value : null
  },

  set: async (key: string, value: any): Promise<void> => {
    // Пока держится блокировка по квоте — не тратим остаток квоты на заведомо
    // провальную запись. Даём тихую типизированную ошибку.
    if (cloudQuotaActive()) throw new CloudQuotaError()
    // Upsert по первичному ключу key (INSERT ... ON CONFLICT DO UPDATE).
    const res = await guardedFetch(`${REST}/${KV_TABLE}`, {
      method: "POST",
      headers: restHeaders({ Prefer: "resolution=merge-duplicates,return=minimal" }),
      body: JSON.stringify({ key, value }),
    })
    if (!res.ok) {
      const body = await res.text().catch(() => "")
      if (res.status === 402 || isQuotaBody(body)) throw new CloudQuotaError()
      throw new Error(`kvSet ${res.status}: ${body.slice(0, 160) || res.statusText}`)
    }
  },

  mget: async (keys: string[]): Promise<Record<string, any>> => {
    if (!keys.length) return {}
    const list = keys.map(k => `"${encodeURIComponent(k)}"`).join(",")
    const url = `${REST}/${KV_TABLE}?key=in.(${list})&select=key,value`
    const res = await guardedFetch(url, { headers: restHeaders() }, `read:${keys.join(",")}`)
    if (!res.ok) throw new Error(`kvMget ${res.status}`)
    const rows = await res.json()
    const out: Record<string, any> = {}
    if (Array.isArray(rows)) for (const r of rows) out[r.key] = r.value
    return out
  },
}

export type PayProvider = "card" | "sbp" | "yookassa" | "tinkoff" | "skins" | "crypto"

export const payments = {
  // Создаёт платёж на сервере и возвращает ссылку на страницу оплаты.
  create: (args: { provider: PayProvider; orderId: string; amount: number; description?: string; returnUrl?: string }): Promise<{ confirmationUrl: string; orderId: string; status: string }> =>
    call("/payments/create", { method: "POST", body: JSON.stringify(args) }),

  // Опрос статуса оплаты: "pending" | "paid" | "failed" | "unknown".
  status: (orderId: string): Promise<{ status: string; provider?: PayProvider }> =>
    call(`/payments/status/${encodeURIComponent(orderId)}`),
}

// Сообщение владельцу магазина в Telegram (токен бота — только на сервере).
export const notify = (text: string): Promise<{ ok: boolean; error?: string }> =>
  call("/notify", { method: "POST", body: JSON.stringify({ text }) })

// Публикация поста в Telegram-канал. channelId и текст кнопки задаются в CRM →
// «Публикация» и хранятся в kv, сервер подставит их сам, если не переданы.
export const publishPost = (args: {
  photoUrl?: string
  photos?: string[]      // альбом из 2-3 фото (Telegram media group)
  videoUrl?: string
  width?: number
  height?: number
  caption: string
  buttonText?: string
  channelId?: string
}): Promise<{ ok: boolean; error?: string }> =>
  call("/publish", { method: "POST", body: JSON.stringify(args) })

// Публикация в сообщество ВКонтакте. Ключ доступа сообщества и его ID задаются в
// CRM → Публикации → Настройки. Всё общение с VK API идёт через сервер (иначе
// CORS + ключ светился бы в браузере). Видео VK пока не поддерживается.
export const publishVk = (args: {
  token: string
  groupId: string
  message: string
  photoUrl?: string
  photos?: string[]      // до 3 фото — вложениями к посту
  linkUrl?: string
}): Promise<{ ok: boolean; error?: string }> =>
  call("/publish-vk", { method: "POST", body: JSON.stringify(args) })

export const api = {
  register: (login: string, name?: string, joinedAt?: string) =>
    call("/register", { method: "POST", body: JSON.stringify({ login, name, joinedAt }) }),

  getState: (): Promise<ServerState> => call("/state"),

  createOrder: (order: any) =>
    call("/orders", { method: "POST", body: JSON.stringify(order) }),

  updateOrder: (id: string, patch: any) =>
    call(`/orders/${encodeURIComponent(id)}`, { method: "PUT", body: JSON.stringify(patch) }),

  deleteOrder: (id: string) =>
    call(`/orders/${encodeURIComponent(id)}`, { method: "DELETE" }),
}
