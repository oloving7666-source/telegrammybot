import { Icon, STATUS_META, type IconName, type OrderStatus, type Order } from '../../shared'
import type { CrmCtx } from '../state'

const rub = (n: number) => n.toLocaleString('ru') + ' ₽'
const orderSum = (o: Order) => (o.painted ? o.price : o.priceUnpainted) || 0
const DAY = 86400000

export default function DashboardSection(ctx: CrmCtx) {
  const { orders, products, registeredUsers, reviews, promocodes, waitlist, isOwner, onWipeStats } = ctx
  const now = Date.now()

  // Дата заказа: берём createdAt, иначе пытаемся разобрать поле date (запасной вариант).
  const orderTime = (o: Order) => o.createdAt ?? 0

  const revenue = orders.reduce((s, o) => s + orderSum(o), 0)
  const paidRevenue = orders.filter(o => o.paid).reduce((s, o) => s + orderSum(o), 0)
  const avgCheck = orders.length ? Math.round(revenue / orders.length) : 0

  // Себестоимость заказа: сначала снимок cost, сохранённый в момент заказа; если его
  // нет (старые заказы) — ищем по названию товара и варианта в текущем каталоге.
  const costOf = (o: Order): number | null => {
    if (typeof o.cost === 'number' && o.cost > 0) return o.cost
    const p = products.find(pr => pr.name === o.name)
    const v = p?.variants?.find(x => x.name === o.variantName) ?? p?.variants?.[0]
    return typeof v?.cost === 'number' && v.cost > 0 ? v.cost : null
  }
  // Прибыль считаем только по заказам с известной себестоимостью — иначе цифра врёт.
  const costedOrders = orders.filter(o => costOf(o) !== null)
  const costedRevenue = costedOrders.reduce((s, o) => s + orderSum(o), 0)
  const totalCost = costedOrders.reduce((s, o) => s + (costOf(o) ?? 0), 0)
  const profit = costedRevenue - totalCost
  const margin = costedRevenue > 0 ? Math.round((profit / costedRevenue) * 100) : 0

  const monthAgo = now - 30 * DAY
  const monthOrders = orders.filter(o => orderTime(o) >= monthAgo)
  const monthRevenue = monthOrders.reduce((s, o) => s + orderSum(o), 0)

  // Сравнение с предыдущими 30 днями — рост/падение выручки и числа заказов.
  const prevFrom = now - 60 * DAY
  const prevOrders = orders.filter(o => { const t = orderTime(o); return t >= prevFrom && t < monthAgo })
  const prevRevenue = prevOrders.reduce((s, o) => s + orderSum(o), 0)
  // Процент изменения: null, если сравнивать не с чем (в прошлом периоде было 0).
  const pct = (cur: number, prev: number): number | null => (prev > 0 ? Math.round(((cur - prev) / prev) * 100) : null)
  const revDelta = pct(monthRevenue, prevRevenue)
  const orderDelta = pct(monthOrders.length, prevOrders.length)

  const awaiting = orders.filter(o => o.payStatus === 'awaiting').length
  const activeOrders = orders.filter(o => o.status !== 'delivered').length

  // Выручка по дням за 14 дней — компактный столбчатый график.
  const days = 14
  const buckets = Array.from({ length: days }, (_, i) => {
    const start = now - (days - 1 - i) * DAY
    const d0 = new Date(start); d0.setHours(0, 0, 0, 0)
    const from = d0.getTime(); const to = from + DAY
    const sum = orders.filter(o => { const t = orderTime(o); return t >= from && t < to }).reduce((s, o) => s + orderSum(o), 0)
    return { label: d0.toLocaleDateString('ru', { day: 'numeric' }), sum }
  })
  const maxBucket = Math.max(1, ...buckets.map(b => b.sum))

  // Разбивка по статусам заказов.
  const statusOrder: OrderStatus[] = ['new', 'printing', 'painting', 'ready', 'delivered']
  const byStatus = statusOrder.map(st => ({ st, count: orders.filter(o => o.status === st).length, meta: STATUS_META[st] }))
  const maxStatus = Math.max(1, ...byStatus.map(s => s.count))

  // Топ товаров по продажам.
  const topProducts = [...products].filter(p => (p.sold ?? 0) > 0).sort((a, b) => (b.sold ?? 0) - (a.sold ?? 0)).slice(0, 5)
  const maxSold = Math.max(1, ...topProducts.map(p => p.sold ?? 0))

  // Спрос из листа ожидания: кого клиенты просят открыть/допечатать.
  const demand = Object.entries(waitlist ?? {})
    .map(([pid, logins]) => ({ product: products.find(p => String(p.id) === pid), count: (logins ?? []).length }))
    .filter(d => d.product && d.count > 0)
    .sort((a, b) => b.count - a.count)
    .slice(0, 5)
  const maxDemand = Math.max(1, ...demand.map(d => d.count))
  const waitingTotal = Object.values(waitlist ?? {}).reduce((s, l) => s + (l?.length ?? 0), 0)

  // Отзывы.
  const avgRating = reviews.length ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length) : 0
  const activePromos = promocodes.filter(p => !p.deleted && (!p.expiresAt || p.expiresAt > now) && p.uses < p.maxUses).length

  const kpis: Array<{ label: string; value: string; sub?: string; icon: IconName; color: string; delta?: number | null }> = [
    { label: 'Выручка всего', value: rub(revenue), sub: `оплачено ${rub(paidRevenue)}`, icon: 'card', color: '#5ba172' },
    { label: 'За 30 дней', value: rub(monthRevenue), sub: `${monthOrders.length} заказов${orderDelta !== null ? ` (${orderDelta >= 0 ? '+' : ''}${orderDelta}%)` : ''}`, icon: 'document', color: '#4d9bff', delta: revDelta },
    { label: 'Средний чек', value: rub(avgCheck), sub: `${orders.length} заказов всего`, icon: 'calculator', color: '#a78bfa' },
    { label: 'Клиентов', value: String(registeredUsers.length), sub: `${activeOrders} активных заказов`, icon: 'users', color: '#cbb149' },
  ]

  // Выгрузка всех заказов в CSV — открывается в Excel / Google Таблицах.
  const exportCsv = () => {
    const esc = (v: string | number) => {
      const s = String(v ?? '')
      return /[",;\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
    }
    const head = ['ID', 'Дата', 'Клиент', 'Товар', 'Вариант', 'Статус', 'Цена', 'Себестоимость', 'Прибыль', 'Оплачен', 'Промокод', 'Бонусов списано', 'Трек']
    const fmtDate = (o: Order) => o.createdAt ? new Date(o.createdAt).toLocaleString('ru-RU') : (o.date || '')
    const rows = [...orders]
      .sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0))
      .map(o => {
        const c = costOf(o)
        const sum = orderSum(o)
        return [o.id, fmtDate(o), o.userId, o.name, o.variantName ?? '', STATUS_META[o.status]?.label ?? o.status,
          sum, c ?? '', c !== null ? sum - c : '', o.paid ? 'да' : 'нет', o.promoCode ?? '', o.bonusSpent ?? 0, o.track ?? ''].map(esc).join(';')
      })
    // BOM, чтобы Excel правильно распознал кириллицу в UTF-8.
    const csv = '﻿' + [head.map(esc).join(';'), ...rows].join('\r\n')
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `sigmaspace-orders-${new Date().toISOString().slice(0, 10)}.csv`
    document.body.appendChild(a); a.click(); a.remove()
    setTimeout(() => URL.revokeObjectURL(url), 1000)
  }

  const card: React.CSSProperties = { padding: '13px 14px', display: 'flex', flexDirection: 'column', gap: '10px' }
  const title = (t: string) => <p style={{ color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 700, margin: 0 }}>{t}</p>

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '10px' }}>
        <div>
          <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: '0 0 4px' }}>Аналитика магазина</p>
          <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Живая сводка по заказам, выручке и товарам.</p>
        </div>
        <button onClick={exportCsv} disabled={orders.length === 0} title="Выгрузить все заказы в CSV"
          style={{ flexShrink: 0, display: 'flex', alignItems: 'center', gap: '6px', padding: '8px 11px', borderRadius: '10px', background: 'var(--bg-input)', border: '1px solid var(--border)', color: orders.length === 0 ? 'var(--text-muted)' : 'var(--text-primary)', fontSize: '11.5px', fontWeight: 600, cursor: orders.length === 0 ? 'default' : 'pointer', opacity: orders.length === 0 ? 0.5 : 1 }}>
          <Icon name="save" size={13} color="var(--accent)" /> CSV
        </button>
      </div>

      {/* KPI-плитки */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
        {kpis.map(k => (
          <div key={k.label} className="glass-card" style={{ padding: '12px', display: 'flex', flexDirection: 'column', gap: '7px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '6px' }}>
              <span style={{ width: '30px', height: '30px', borderRadius: '9px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: `${k.color}1f`, border: `1px solid ${k.color}44` }}>
                <Icon name={k.icon} size={15} color={k.color} />
              </span>
              {k.delta !== undefined && k.delta !== null && (
                <span title="К предыдущим 30 дням" style={{ display: 'inline-flex', alignItems: 'center', gap: '2px', fontSize: '10px', fontWeight: 700, color: k.delta >= 0 ? '#5ba172' : '#e06b66', background: k.delta >= 0 ? '#5ba17222' : '#e06b6622', border: `1px solid ${k.delta >= 0 ? '#5ba17244' : '#e06b6644'}`, borderRadius: '999px', padding: '2px 7px' }}>
                  <Icon name={k.delta >= 0 ? 'chevron-up' : 'chevron-down'} size={11} color={k.delta >= 0 ? '#5ba172' : '#e06b66'} />
                  {k.delta >= 0 ? '+' : ''}{k.delta}%
                </span>
              )}
            </div>
            <div>
              <p style={{ color: 'var(--text-primary)', fontSize: '17px', fontWeight: 800, margin: 0, lineHeight: 1.1, letterSpacing: '-0.01em' }}>{k.value}</p>
              <p style={{ color: 'var(--text-muted)', fontSize: '9.5px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', margin: '3px 0 0' }}>{k.label}</p>
              {k.sub && <p style={{ color: 'var(--text-secondary)', fontSize: '10px', margin: '2px 0 0' }}>{k.sub}</p>}
            </div>
          </div>
        ))}
      </div>

      {/* Прибыль (выручка − себестоимость) */}
      <div className="glass-card" style={card}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' }}>
          {title('Прибыль')}
          <span style={{ fontSize: '10px', fontWeight: 700, color: profit >= 0 ? '#5ba172' : '#e06b66', background: profit >= 0 ? '#5ba17222' : '#e06b6622', border: `1px solid ${profit >= 0 ? '#5ba17244' : '#e06b6644'}`, borderRadius: '999px', padding: '3px 9px' }}>маржа {margin}%</span>
        </div>
        {costedOrders.length === 0 ? (
          <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0, lineHeight: 1.5 }}>
            Укажите себестоимость в вариантах товаров (поле «Себест., ₽») — и здесь появится прибыль по заказам.
          </p>
        ) : (
          <>
            <div style={{ display: 'flex', gap: '8px' }}>
              <div style={{ flex: 1 }}>
                <p style={{ color: profit >= 0 ? '#5ba172' : '#e06b66', fontSize: '19px', fontWeight: 800, margin: 0, lineHeight: 1.1, letterSpacing: '-0.01em' }}>{rub(profit)}</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '9.5px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', margin: '3px 0 0' }}>чистыми</p>
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ color: 'var(--text-secondary)', fontSize: '14px', fontWeight: 700, margin: 0, lineHeight: 1.1 }}>{rub(totalCost)}</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '9.5px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', margin: '3px 0 0' }}>себестоимость</p>
              </div>
            </div>
            {costedOrders.length < orders.length && (
              <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0, lineHeight: 1.4 }}>
                Расчёт по {costedOrders.length} из {orders.length} заказов — у остальных не задана себестоимость.
              </p>
            )}
          </>
        )}
      </div>

      {/* График выручки по дням */}
      <div className="glass-card" style={card}>
        {title('Выручка за 14 дней')}
        <div style={{ display: 'flex', alignItems: 'flex-end', gap: '4px', height: '92px' }}>
          {buckets.map((b, i) => (
            <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px', height: '100%', justifyContent: 'flex-end' }} title={`${b.label}: ${rub(b.sum)}`}>
              <div style={{ width: '100%', height: `${Math.max(3, (b.sum / maxBucket) * 100)}%`, borderRadius: '4px 4px 2px 2px', background: b.sum ? 'linear-gradient(180deg, var(--accent-2-hi), var(--accent-2))' : 'var(--bg-elevated)', transition: 'height 0.3s' }} />
              <span style={{ color: 'var(--text-muted)', fontSize: '8px' }}>{b.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Статусы заказов */}
      <div className="glass-card" style={card}>
        {title('Заказы по стадиям')}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '7px' }}>
          {byStatus.map(s => (
            <div key={s.st} style={{ display: 'flex', alignItems: 'center', gap: '9px' }}>
              <span style={{ width: '76px', flexShrink: 0, color: 'var(--text-secondary)', fontSize: '11px' }}>{s.meta.label}</span>
              <div style={{ flex: 1, height: '8px', borderRadius: '4px', background: 'var(--bg-elevated)', overflow: 'hidden' }}>
                <div style={{ width: `${(s.count / maxStatus) * 100}%`, height: '100%', background: s.meta.dot, borderRadius: '4px', transition: 'width 0.3s' }} />
              </div>
              <span style={{ width: '24px', textAlign: 'right', flexShrink: 0, color: 'var(--text-primary)', fontSize: '12px', fontWeight: 700 }}>{s.count}</span>
            </div>
          ))}
        </div>
        {awaiting > 0 && (
          <p style={{ color: 'var(--danger)', fontSize: '11px', margin: 0, fontWeight: 600 }}>⏳ Ждут подтверждения оплаты: {awaiting}</p>
        )}
      </div>

      {/* Топ товаров */}
      <div className="glass-card" style={card}>
        {title('Топ товаров по продажам')}
        {topProducts.length === 0 ? (
          <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0, fontStyle: 'italic' }}>Пока нет продаж</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {topProducts.map((p, i) => (
              <div key={p.id} style={{ display: 'flex', alignItems: 'center', gap: '9px' }}>
                <span style={{ flexShrink: 0, width: '20px', height: '20px', borderRadius: '6px', background: 'var(--accent-glow)', color: 'var(--accent)', fontSize: '10px', fontWeight: 800, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{i + 1}</span>
                <img src={p.img} alt="" style={{ width: '30px', height: '30px', borderRadius: '7px', objectFit: 'cover', flexShrink: 0 }} onError={e => (e.currentTarget.style.visibility = 'hidden')} />
                <div style={{ minWidth: 0, flex: 1 }}>
                  <p style={{ color: 'var(--text-primary)', fontSize: '11.5px', fontWeight: 600, margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</p>
                  <div style={{ height: '5px', borderRadius: '3px', background: 'var(--bg-elevated)', overflow: 'hidden', marginTop: '3px' }}>
                    <div style={{ width: `${((p.sold ?? 0) / maxSold) * 100}%`, height: '100%', background: 'var(--accent)', borderRadius: '3px' }} />
                  </div>
                </div>
                <span style={{ flexShrink: 0, color: 'var(--accent-2-hi)', fontSize: '12px', fontWeight: 700 }}>{p.sold}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Спрос из листа ожидания — что клиенты просят открыть/допечатать */}
      {demand.length > 0 && (
        <div className="glass-card" style={card}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px' }}>
            {title('Ждут открытия')}
            <span style={{ fontSize: '10px', fontWeight: 700, color: 'var(--accent)', background: 'var(--accent-glow)', borderRadius: '999px', padding: '3px 9px' }}>{waitingTotal} заявок</span>
          </div>
          <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', margin: '-2px 0 2px', lineHeight: 1.4 }}>Клиенты подписались на уведомление — чем длиннее строка, тем выше спрос на допечатку.</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {demand.map(d => (
              <div key={d.product!.id} style={{ display: 'flex', alignItems: 'center', gap: '9px' }}>
                <img src={d.product!.img} alt="" style={{ width: '30px', height: '30px', borderRadius: '7px', objectFit: 'cover', flexShrink: 0 }} onError={e => (e.currentTarget.style.visibility = 'hidden')} />
                <div style={{ minWidth: 0, flex: 1 }}>
                  <p style={{ color: 'var(--text-primary)', fontSize: '11.5px', fontWeight: 600, margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.product!.name}</p>
                  <div style={{ height: '5px', borderRadius: '3px', background: 'var(--bg-elevated)', overflow: 'hidden', marginTop: '3px' }}>
                    <div style={{ width: `${(d.count / maxDemand) * 100}%`, height: '100%', background: 'var(--accent-2, var(--accent))', borderRadius: '3px' }} />
                  </div>
                </div>
                <span style={{ flexShrink: 0, display: 'inline-flex', alignItems: 'center', gap: '3px', color: 'var(--accent-2-hi, var(--accent))', fontSize: '12px', fontWeight: 700 }}>
                  <Icon name="bell" size={11} color="var(--accent-2-hi, var(--accent))" />{d.count}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Мелкие метрики */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
        <div className="glass-card" style={{ padding: '12px', display: 'flex', alignItems: 'center', gap: '9px' }}>
          <Icon name="star-fill" size={17} color="#f0a742" />
          <div>
            <p style={{ color: 'var(--text-primary)', fontSize: '15px', fontWeight: 800, margin: 0, lineHeight: 1 }}>{avgRating ? avgRating.toFixed(1) : '—'}</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '2px 0 0' }}>{reviews.length} отзывов</p>
          </div>
        </div>
        <div className="glass-card" style={{ padding: '12px', display: 'flex', alignItems: 'center', gap: '9px' }}>
          <Icon name="gift" size={17} color="#cbb149" />
          <div>
            <p style={{ color: 'var(--text-primary)', fontSize: '15px', fontWeight: 800, margin: 0, lineHeight: 1 }}>{activePromos}</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '2px 0 0' }}>активных промокодов</p>
          </div>
        </div>
      </div>

      {/* Опасная зона: сброс статистики перед публичным запуском (только владелец) */}
      {isOwner && onWipeStats && (
        <div className="glass-card" style={{ padding: '13px 14px', display: 'flex', flexDirection: 'column', gap: '9px', border: '1px solid #d9534f55', background: 'linear-gradient(180deg, rgba(217,83,79,0.07), transparent)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '7px' }}>
            <Icon name="trash" size={14} color="#e06b66" />
            <p style={{ color: '#e06b66', fontSize: '12.5px', fontWeight: 700, margin: 0 }}>Сброс перед запуском</p>
          </div>
          <p style={{ color: 'var(--text-muted)', fontSize: '11px', lineHeight: 1.5, margin: 0 }}>
            Обнуляет всю тестовую историю: заказы, выручку, счётчики продаж, использования
            промокодов, начисленные бонусы, отзывы и журнал действий. Каталог товаров,
            разделы, настройки и аккаунты клиентов останутся на месте. Действие необратимо.
          </p>
          <button
            onClick={() => {
              if (!confirm('Обнулить ВСЮ статистику и историю продаж?\n\nБудут стёрты: все заказы, выручка, счётчики продаж, использования промокодов, бонусы клиентов, отзывы и журнал действий.\n\nКаталог, разделы, настройки и клиенты сохранятся. Отменить будет нельзя.')) return
              if (!confirm('Точно? Это финальная очистка перед запуском — восстановить данные будет невозможно.')) return
              onWipeStats()
            }}
            style={{ alignSelf: 'flex-start', display: 'flex', alignItems: 'center', gap: '6px', padding: '9px 13px', borderRadius: '10px', background: 'rgba(217,83,79,0.14)', border: '1px solid #d9534f66', color: '#e88a86', fontSize: '12px', fontWeight: 700, cursor: 'pointer' }}>
            <Icon name="trash" size={13} color="#e88a86" /> Обнулить статистику
          </button>
        </div>
      )}
    </div>
  )
}
