import { useSyncExternalStore } from 'react'
import { Icon, type IconName } from '../../shared'
import { getLogs, subscribeLogs, clearLogs, type LogKind } from '../../log'
import type { CrmCtx } from '../state'

const KIND_META: Record<LogKind, { icon: IconName; color: string; label: string }> = {
  order:   { icon: 'document', color: '#4d9bff', label: 'Заказы' },
  product: { icon: 'layers',   color: '#a78bfa', label: 'Товары' },
  promo:   { icon: 'gift',     color: '#cbb149', label: 'Промокоды' },
  review:  { icon: 'star',     color: '#f0a742', label: 'Отзывы' },
  user:    { icon: 'users',    color: '#5ba172', label: 'Клиенты' },
  loyalty: { icon: 'heart',    color: '#c76b6b', label: 'Лояльность' },
  system:  { icon: 'gear',     color: '#8b90a0', label: 'Система' },
}

function ago(ts: number): string {
  const s = Math.max(0, Math.round((Date.now() - ts) / 1000))
  if (s < 60) return 'только что'
  const m = Math.round(s / 60)
  if (m < 60) return `${m} мин назад`
  const h = Math.round(m / 60)
  if (h < 24) return `${h} ч назад`
  return new Date(ts).toLocaleDateString('ru', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })
}

export default function LogsSection(ctx: CrmCtx) {
  const logs = useSyncExternalStore(subscribeLogs, getLogs, getLogs)
  const canClear = ctx.isOwner

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '10px' }}>
        <div>
          <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: '0 0 4px' }}>Журнал действий</p>
          <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Кто и что менял в панели. Последние {logs.length} записей.</p>
        </div>
        {canClear && logs.length > 0 && (
          <button onClick={() => { if (confirm('Очистить весь журнал действий?')) clearLogs() }}
            style={{ flexShrink: 0, display: 'flex', alignItems: 'center', gap: '5px', padding: '7px 10px', borderRadius: '9px', background: 'var(--bg-input)', border: '1px solid var(--border)', color: 'var(--text-muted)', fontSize: '11px', fontWeight: 600, cursor: 'pointer' }}>
            <Icon name="trash" size={13} color="var(--text-muted)" /> Очистить
          </button>
        )}
      </div>

      {logs.length === 0 ? (
        <p style={{ color: 'var(--text-muted)', fontSize: '12px', textAlign: 'center', padding: '20px 0', fontStyle: 'italic' }}>Пока пусто — действия появятся здесь</p>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
          {logs.map(e => {
            const m = KIND_META[e.kind] ?? KIND_META.system
            return (
              <div key={e.id} className="glass-card" style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '9px 11px' }}>
                <span style={{ flexShrink: 0, width: '30px', height: '30px', borderRadius: '9px', display: 'flex', alignItems: 'center', justifyContent: 'center', background: `${m.color}1f`, border: `1px solid ${m.color}44` }}>
                  <Icon name={m.icon} size={14} color={m.color} />
                </span>
                <div style={{ minWidth: 0, flex: 1 }}>
                  <p style={{ color: 'var(--text-primary)', fontSize: '12px', fontWeight: 600, margin: 0, lineHeight: 1.35 }}>{e.action}</p>
                  <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '2px 0 0' }}>
                    <span style={{ color: 'var(--accent-2-hi)', fontWeight: 600 }}>{e.actor}</span> · {ago(e.ts)}
                  </p>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
