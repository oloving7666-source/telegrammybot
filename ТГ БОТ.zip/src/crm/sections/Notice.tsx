import { EmojiPicker, Icon, IconName, Toggle } from '../../shared'
import type { CrmCtx } from '../state'

/**
 * Раздел «Важное» — редактор приветственного окна, которое видит клиент при
 * первом входе (кибер-панель «ВАЖНО»). Поля и превью соответствуют тому, что
 * реально показывается на экране: заголовок, подзаголовок, карточки-пункты
 * (иконка + заголовок + подпись) и кнопка.
 */
export default function NoticeSection(ctx: CrmCtx) {
  const { notice, setNotice, shopStatus, setShopStatus } = ctx
  const input = { width: '100%', padding: '9px 12px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' as const, fontFamily: 'inherit' }
  const lbl = { color: 'var(--text-muted)', fontSize: '11px', fontWeight: 500, margin: '0 0 5px' } as const
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
      {/* Магазин на паузе — баннер клиентам + блокировка новых заказов */}
      <div className="glass-card" style={{ padding: '14px', border: shopStatus.on ? '1px solid rgba(245,200,66,0.4)' : undefined }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px', marginBottom: shopStatus.on ? '12px' : 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '9px', minWidth: 0 }}>
            <div style={{ width: '30px', height: '30px', borderRadius: '9px', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: shopStatus.on ? 'rgba(245,200,66,0.16)' : 'var(--bg-input)' }}>
              <Icon name="info" size={16} color={shopStatus.on ? '#f5c842' : 'var(--text-muted)'} />
            </div>
            <div style={{ minWidth: 0 }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, margin: 0 }}>Магазин на паузе</p>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '2px 0 0', lineHeight: 1.35 }}>{shopStatus.on ? 'Заказы приостановлены, клиенты видят баннер' : 'Приём заказов работает как обычно'}</p>
            </div>
          </div>
          <Toggle on={shopStatus.on} onToggle={() => setShopStatus(s => ({ ...s, on: !s.on }))} />
        </div>
        {shopStatus.on && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
            <div>
              <p style={lbl}>Заголовок баннера</p>
              <input value={shopStatus.title} onChange={e => setShopStatus(s => ({ ...s, title: e.target.value }))} placeholder="Магазин на паузе" style={{ ...input, fontWeight: 700 }} />
            </div>
            <div>
              <p style={lbl}>Текст для клиентов</p>
              <textarea value={shopStatus.text} onChange={e => setShopStatus(s => ({ ...s, text: e.target.value }))} rows={2} placeholder="Временно не принимаем новые заказы — скоро вернёмся!"
                style={{ ...input, lineHeight: 1.45, resize: 'vertical' }} />
            </div>
          </div>
        )}
      </div>

      <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0, lineHeight: 1.5 }}>Приветственное окно, которое клиент видит при входе. Всё, что здесь указано, сразу отражается в окне на главном экране.</p>

      {/* Шапка окна */}
      <div className="glass-card" style={{ padding: '14px' }}>
        <p style={{ color: 'var(--accent)', fontSize: '11px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.7px', margin: '0 0 12px', display: 'flex', alignItems: 'center', gap: '6px' }}><Icon name="bell" size={12} color="var(--accent)" /> Шапка окна</p>
        <div style={{ marginBottom: '10px' }}>
          <p style={lbl}>Крупный заголовок</p>
          <input value={notice.title} onChange={e => setNotice(n => ({ ...n, title: e.target.value }))} style={{ ...input, fontWeight: 700 }} />
        </div>
        <div>
          <p style={lbl}>Подзаголовок</p>
          <input value={notice.subtitle} onChange={e => setNotice(n => ({ ...n, subtitle: e.target.value }))} style={input} />
        </div>
      </div>

      {/* Пункты */}
      <p style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.7px', margin: '4px 0 0' }}>Пункты списка</p>
      {notice.items.map((item, idx) => (
        <div key={item.id} className="glass-card" style={{ padding: '14px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
            <span style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 600 }}>Пункт {idx + 1}</span>
            <button onClick={() => setNotice(n => ({ ...n, items: n.items.filter(x => x.id !== item.id) }))}
              style={{ display: 'flex', alignItems: 'center', padding: '5px', borderRadius: '8px', background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.18)', cursor: 'pointer' }}>
              <Icon name="trash" size={13} color="var(--danger)" />
            </button>
          </div>
          <div style={{ display: 'flex', gap: '8px' }}>
            <div style={{ flex: '0 0 72px' }}>
              <p style={lbl}>Иконка</p>
              <EmojiPicker value={item.icon} onChange={ic => setNotice(n => ({ ...n, items: n.items.map(x => x.id === item.id ? { ...x, icon: ic as IconName } : x) }))} />
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <div>
                <p style={lbl}>Заголовок</p>
                <input value={item.text} onChange={e => setNotice(n => ({ ...n, items: n.items.map(x => x.id === item.id ? { ...x, text: e.target.value } : x) }))} style={{ ...input, fontSize: '12px' }} />
              </div>
              <div>
                <p style={lbl}>Подпись</p>
                <input value={item.sub ?? ''} onChange={e => setNotice(n => ({ ...n, items: n.items.map(x => x.id === item.id ? { ...x, sub: e.target.value } : x) }))} style={{ ...input, fontSize: '12px' }} />
              </div>
            </div>
          </div>
        </div>
      ))}

      <button className="btn-primary" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}
        onClick={() => setNotice(n => ({ ...n, items: [...n.items, { id: Date.now().toString(), icon: 'info', text: '', sub: '' }] }))}>
        <Icon name="plus" size={14} color="#fff" /> Добавить пункт
      </button>

      {/* Кнопка */}
      <div className="glass-card" style={{ padding: '14px' }}>
        <p style={lbl}>Текст кнопки</p>
        <input value={notice.buttonText} onChange={e => setNotice(n => ({ ...n, buttonText: e.target.value }))} style={input} />
      </div>

      {/* Превью — в стиле реального окна «ВАЖНО» */}
      <p style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.7px', margin: '4px 0 0' }}>Предпросмотр</p>
      <div style={{ borderRadius: '16px', overflow: 'hidden', padding: '3px', background: 'linear-gradient(160deg,#6d82a3,#1c2634 52%,#232f3f)' }}>
        <div style={{ background: 'linear-gradient(175deg, #090d14, #03050a)', padding: '18px 14px 16px' }}>
          <div style={{ textAlign: 'center' }}>
            <p style={{ color: '#ff1f35', fontSize: '26px', fontWeight: 900, margin: 0, textShadow: '0 0 18px rgba(255,31,53,0.55)' }}>{notice.title || 'ВАЖНО'}</p>
            <p style={{ color: '#fff', fontSize: '12px', fontWeight: 700, margin: '6px 0 0' }}>{notice.subtitle || '—'}</p>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', margin: '14px 0' }}>
            {notice.items.map(item => (
              <div key={item.id} style={{ display: 'flex', gap: '10px', alignItems: 'center', padding: '10px', borderRadius: '12px', background: 'linear-gradient(150deg, rgba(255,31,53,0.05), rgba(255,255,255,0.014))', border: '1px solid rgba(255,31,53,0.16)' }}>
                <div style={{ width: '38px', height: '38px', borderRadius: '11px', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(255,31,53,0.07)', border: '1px solid rgba(255,31,53,0.18)' }}>
                  <Icon name={item.icon} size={17} color="#ff4256" />
                </div>
                <div style={{ minWidth: 0 }}>
                  <p style={{ color: '#fff', fontSize: '12.5px', fontWeight: 700, lineHeight: 1.25, margin: 0 }}>{item.text || <span style={{ fontStyle: 'italic', opacity: 0.5 }}>заголовок</span>}</p>
                  {item.sub && <p style={{ color: '#7b8498', fontSize: '11px', lineHeight: 1.3, margin: '3px 0 0' }}>{item.sub}</p>}
                </div>
              </div>
            ))}
          </div>
          <div style={{ padding: '13px', borderRadius: '10px', textAlign: 'center', background: 'linear-gradient(180deg, #ff4256, #b3101f)' }}>
            <span style={{ color: '#fff', fontSize: '14px', fontWeight: 700 }}>{notice.buttonText || '—'}</span>
          </div>
        </div>
      </div>
    </div>
  )
}
