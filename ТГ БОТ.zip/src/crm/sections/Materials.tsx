import { FormField, Icon, Toggle } from '../../shared'
import type { CrmCtx } from '../state'

export default function MaterialsSection(ctx: CrmCtx) {
  const { addMat, materials, newMat, setAddMat, setMaterials, setNewMat } = ctx
  return (<>
      {(
          <div>
            <p style={{ color: 'var(--text-secondary)', fontSize: '12px', margin: '0 0 12px' }}>Недоступные материалы скрыты в калькуляторе.</p>
            <button className="btn-primary" style={{ marginBottom: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }} onClick={() => setAddMat(true)}>
              <Icon name="plus" size={14} color="#fff" /> Добавить материал
            </button>
            {addMat && (
              <div className="glass-card" style={{ padding: '12px', marginBottom: '10px' }}>
                <FormField label="Название материала" value={newMat.name} onChange={v => setNewMat(p=>({...p,name:v}))} placeholder="Например: Нейлон" />
                <FormField label="Коэффициент цены" type="number" value={newMat.priceMultiplier} onChange={v => setNewMat(p=>({...p,priceMultiplier:Number(v)}))} />
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button className="btn-primary" style={{ flex: 1 }} onClick={() => { if(newMat.name){setMaterials(prev=>[...prev,{id:Date.now().toString(),name:newMat.name,available:true,priceMultiplier:newMat.priceMultiplier}]);setNewMat({name:'',priceMultiplier:1.0});setAddMat(false)} }}>Добавить</button>
                  <button className="btn-secondary" style={{ flex: 1 }} onClick={() => setAddMat(false)}>Отмена</button>
                </div>
              </div>
            )}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {materials.map(m => (
                <div key={m.id} className="glass-card" style={{ padding: '12px 14px', display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <div style={{ flex: 1 }}>
                    <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: '0 0 2px' }}>{m.name}</p>
                    <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0 }}>×{m.priceMultiplier}</p>
                  </div>
                  <span style={{ fontSize: '11px', fontWeight: 600, padding: '3px 9px', borderRadius: '8px', background: m.available ? 'rgba(52,201,125,0.1)' : 'rgba(239,68,68,0.07)', color: m.available ? 'var(--status-ready-color)' : 'var(--danger)', border: `1px solid ${m.available ? 'var(--status-ready-color)' : 'var(--danger)'}` }}>{m.available ? 'Есть' : 'Нет'}</span>
                  <Toggle on={m.available} onToggle={() => setMaterials(prev => prev.map(x => x.id===m.id ? {...x,available:!x.available} : x))} />
                  <button onClick={() => setMaterials(prev=>prev.filter(x=>x.id!==m.id))} style={{ display: 'flex', alignItems: 'center', padding: '6px', borderRadius: '8px', background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.18)', cursor: 'pointer', marginLeft: '4px' }}><Icon name="trash" size={13} color="var(--danger)" /></button>
                </div>
              ))}
            </div>
          </div>
        )
      }
  </>)
}
