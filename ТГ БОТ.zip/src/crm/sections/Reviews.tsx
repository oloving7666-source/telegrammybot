import { Icon, MaskedId, ReviewPhotos, StarRating } from '../../shared'
import type { CrmCtx } from '../state'

export default function ReviewsSection(ctx: CrmCtx) {
  const { addReviewPhotos, createReview, products, revDraft, revFileRef, revMsg, revUploading, reviews, setRevDraft, setRevMsg, setReviews } = ctx
  return (<>
      {(
          <div>
            <div className="glass-card" style={{ padding: '12px', marginBottom: '12px' }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, margin: '0 0 10px' }}>Новый отзыв</p>
              <div style={{ marginBottom: '10px' }}>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 4px', fontWeight: 500 }}>Товар</p>
                <select value={revDraft.productId || ''} onChange={e => { setRevDraft(d => ({ ...d, productId: Number(e.target.value) })); setRevMsg('') }}
                  style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '9px 12px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box', appearance: 'none' }}>
                  <option value="">— Выберите товар —</option>
                  {products.map(p => <option key={p.id} value={p.id}>{p.name} · {p.series}</option>)}
                </select>
              </div>
              <div style={{ marginBottom: '10px' }}>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 4px', fontWeight: 500 }}>Telegram ID автора</p>
                <div style={{ position: 'relative' }}>
                  <span style={{ position: 'absolute', left: '11px', top: '50%', transform: 'translateY(-50%)', color: 'var(--accent)', fontSize: '14px', pointerEvents: 'none' }}>@</span>
                  <input value={revDraft.userId} onChange={e => { setRevDraft(d => ({ ...d, userId: e.target.value.replace(/^@/, '') })); setRevMsg('') }} placeholder="username"
                    style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '9px 12px 9px 26px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
                </div>
                <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '4px 0 0' }}>Клиентам ник показывается частично — хвост скрыт блюром.</p>
              </div>
              <div style={{ marginBottom: '10px' }}>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 4px', fontWeight: 500 }}>Оценка</p>
                <StarRating value={revDraft.rating} onChange={v => setRevDraft(d => ({ ...d, rating: v }))} size={22} />
              </div>
              <div style={{ marginBottom: '10px' }}>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 4px', fontWeight: 500 }}>Текст отзыва</p>
                <textarea value={revDraft.text} onChange={e => { setRevDraft(d => ({ ...d, text: e.target.value })); setRevMsg('') }} rows={3} placeholder="Что понравилось клиенту…"
                  style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '9px 12px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box', resize: 'vertical', fontFamily: 'inherit' }} />
              </div>
              <input ref={revFileRef} type="file" accept="image/*" multiple onChange={e => { addReviewPhotos(e.target.files); e.target.value = '' }} style={{ display: 'none' }} />
              <button className="btn-secondary" disabled={revUploading} onClick={() => revFileRef.current?.click()}
                style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }}>
                <Icon name="camera" size={14} color="var(--text-secondary)" /> {revUploading ? 'Загрузка…' : 'Добавить фото'}
              </button>
              <ReviewPhotos photos={revDraft.photos} onRemove={url => setRevDraft(d => ({ ...d, photos: d.photos.filter(u => u !== url) }))} />
              {revMsg && <p style={{ color: revMsg === 'Отзыв опубликован' ? 'var(--accent)' : 'var(--danger)', fontSize: '11.5px', fontWeight: 600, margin: '8px 0 0' }}>{revMsg}</p>}
              <button className="btn-primary" onClick={createReview} disabled={revUploading} style={{ marginTop: '10px' }}>Опубликовать отзыв</button>
            </div>
            <p style={{ color: 'var(--text-secondary)', fontSize: '12px', margin: '0 0 12px' }}>{reviews.length} отзывов всего</p>
            {reviews.length === 0 && <p style={{ color: 'var(--text-muted)', fontSize: '13px', textAlign: 'center', marginTop: '32px', fontStyle: 'italic' }}>Отзывов пока нет</p>}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              {reviews.map(r => {
                const prod = products.find(p => p.id === r.productId)
                return (
                  <div key={r.id} className="glass-card" style={{ padding: '12px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '6px' }}>
                      <div>
                        <p style={{ margin: '0 0 1px' }}><MaskedId value={r.userName} reveal /></p>
                        <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0 }}>{prod?.name ?? 'Товар'} · {r.date}</p>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <StarRating value={r.rating} size={12} />
                        <button onClick={() => setReviews(prev=>prev.filter(x=>x.id!==r.id))} style={{ display: 'flex', alignItems: 'center', padding: '5px', borderRadius: '8px', background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.18)', cursor: 'pointer' }}><Icon name="trash" size={13} color="var(--danger)" /></button>
                      </div>
                    </div>
                    <p style={{ color: 'var(--text-secondary)', fontSize: '12px', margin: 0, lineHeight: 1.5 }}>{r.text}</p>
                    <ReviewPhotos photos={r.photos} />
                  </div>
                )
              })}
            </div>
          </div>
        )
      }
  </>)
}
