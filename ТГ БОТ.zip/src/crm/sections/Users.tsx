import { DELIVERY_LABELS, Icon, OnlineDot, Order, Product, StatusBadge, readProfile, relativeTime } from '../../shared'
import type { CrmCtx } from '../state'

export default function UsersSection(ctx: CrmCtx) {
  const { allFavorites, expandedUser, isOwner, lastSeenTimes, onMigrateImages, onUserDelete, onWipeClients, orders, products, profiles, promocodes, setExpandedUser, setShowDoneOrders, setShowFavorites, setShowUserPromos, showDoneOrders, showFavorites, showUserPromos, sortedClients } = ctx
  return (<>
      {(
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {sortedClients.map(u => {
              const uOrders = orders.filter(o => o.userId === u.login)
              const total = uOrders.reduce((s,o)=>s+(o.painted?o.price:o.priceUnpainted),0)
              const uProfile = readProfile(profiles, u.login)
              const isExp = expandedUser === u.login
              const displayN = uProfile?.nickname || u.name
              const ts = lastSeenTimes[u.login]
              const isOn = ts ? (Date.now() - ts) < 5 * 60 * 1000 : false
              return (
                <div key={u.login} className="glass-card" style={{ overflow: 'hidden' }}>
                  <button onClick={() => { setExpandedUser(isExp ? null : u.login); setShowDoneOrders(false); setShowFavorites(false); setShowUserPromos(false) }} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: '10px', padding: '12px', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left' }}>
                    <div style={{ position: 'relative', width: '40px', height: '40px', flexShrink: 0 }}>
                      <div style={{ width: '40px', height: '40px', borderRadius: '50%', overflow: 'hidden', background: 'linear-gradient(135deg,var(--accent),#6d28d9)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '14px', fontWeight: 700, color: '#fff' }}>
                        {uProfile?.avatarUrl ? <img src={uProfile.avatarUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : u.name[1]?.toUpperCase() ?? 'U'}
                      </div>
                      <OnlineDot isAdmin={false} size={11} />
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: '0 0 1px' }}>{displayN}</p>
                      <p style={{ color: isOn ? 'var(--status-ready-color)' : 'var(--text-muted)', fontSize: '10px', margin: '0 0 1px', fontWeight: isOn ? 600 : 400 }}>{isOn ? '● онлайн' : ts ? `был(а) ${relativeTime(ts)}` : `с ${u.joinedAt}`}</p>
                      <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0 }}>{uOrders.length} заказов · {total.toLocaleString()} ₽</p>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                      {uOrders.length > 0 && <span style={{ fontSize: '9px', fontWeight: 700, padding: '2px 7px', borderRadius: '8px', background: 'var(--accent-2-wash)', color: 'var(--accent-2-hi)' }}>{uOrders.length}</span>}
                      <div style={{ transform: isExp ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}><Icon name="chevron-down" size={15} color="var(--text-muted)" /></div>
                    </div>
                  </button>
                  {isExp && (
                    <div style={{ borderTop: '1px solid var(--border)', padding: '10px 12px' }}>
                      <div style={{ background: 'var(--bg-elevated)', borderRadius: '10px', padding: '10px', marginBottom: '10px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                        {[
                          { label: 'Telegram ID', val: u.login },
                          uProfile?.nickname ? { label: 'Ник / Имя', val: uProfile.nickname } : null,
                          uProfile?.email ? { label: 'Email', val: uProfile.email } : null,
                        ].filter(Boolean).map(item => item && (
                          <div key={item.label}>
                            <p style={{ color: 'var(--text-muted)', fontSize: '9px', margin: '0 0 2px' }}>{item.label}</p>
                            <p style={{ color: 'var(--text-primary)', fontSize: '11px', fontWeight: 600, margin: 0 }}>{item.val}</p>
                          </div>
                        ))}
                      </div>
                      <div style={{ background: 'var(--bg-elevated)', borderRadius: '10px', padding: '10px', marginBottom: '10px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
                          <Icon name="truck" size={13} color="var(--accent-2-hi)" />
                          <p style={{ color: 'var(--text-primary)', fontSize: '11px', fontWeight: 700, margin: 0 }}>Доставка</p>
                        </div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '7px' }}>
                          <div>
                            <p style={{ color: 'var(--text-muted)', fontSize: '9px', margin: '0 0 2px' }}>Служба</p>
                            <p style={{ color: uProfile?.deliveryService ? 'var(--text-primary)' : 'var(--text-muted)', fontSize: '11.5px', fontWeight: 600, margin: 0, fontStyle: uProfile?.deliveryService ? 'normal' : 'italic' }}>{uProfile?.deliveryService ? DELIVERY_LABELS[uProfile.deliveryService] : 'Не выбрана'}</p>
                          </div>
                          <div>
                            <p style={{ color: 'var(--text-muted)', fontSize: '9px', margin: '0 0 2px' }}>Адрес пункта выдачи</p>
                            <p style={{ color: (uProfile?.city || uProfile?.address) ? 'var(--text-primary)' : 'var(--text-muted)', fontSize: '11.5px', fontWeight: 600, margin: 0, lineHeight: 1.45, fontStyle: (uProfile?.city || uProfile?.address) ? 'normal' : 'italic', wordBreak: 'break-word' }}>{[uProfile?.city, uProfile?.address].filter(Boolean).join(', ') || 'Не указан'}</p>
                          </div>
                        </div>
                      </div>
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '6px', marginBottom: '10px' }}>
                        {[{ label: 'Заказов', value: uOrders.length }, { label: 'Потрачено', value: `${(total/1000).toFixed(1)}к ₽` }, { label: 'Активных', value: uOrders.filter(o=>o.status!=='delivered').length }].map(s => (
                          <div key={s.label} style={{ background: 'var(--bg-elevated)', borderRadius: '8px', padding: '6px', textAlign: 'center' }}>
                            <p style={{ color: 'var(--accent-2-hi)', fontSize: '14px', fontWeight: 700, margin: '0 0 1px' }}>{s.value}</p>
                            <p style={{ color: 'var(--text-muted)', fontSize: '9px', margin: 0 }}>{s.label}</p>
                          </div>
                        ))}
                      </div>
                      {(() => {
                        const OrderRow = (o: Order) => (
                          <div key={o.id} style={{ display: 'flex', gap: '8px', alignItems: 'center', padding: '8px', background: 'var(--bg-elevated)', borderRadius: '10px' }}>
                            <img src={o.thumb} alt="" style={{ width: '36px', height: '36px', borderRadius: '7px', objectFit: 'cover', flexShrink: 0 }} />
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <p style={{ color: 'var(--text-primary)', fontSize: '11px', fontWeight: 600, margin: '0 0 2px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{o.name}</p>
                              <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0 }}>{o.date} · {(o.painted?o.price:o.priceUnpainted).toLocaleString()} ₽ · {o.variantName ?? (o.painted ? 'Окрашен' : 'Без покраски')}</p>
                            </div>
                            <StatusBadge status={o.status} />
                          </div>
                        )
                        const active = uOrders.filter(o => o.status !== 'delivered')
                        const done = uOrders.filter(o => o.status === 'delivered')
                        return (
                          <>
                            <p style={{ color: 'var(--text-muted)', fontSize: '9px', margin: '0 0 6px', fontWeight: 600, letterSpacing: '0.03em', textTransform: 'uppercase' }}>Активные заказы · {active.length}</p>
                            {active.length === 0
                              ? <p style={{ color: 'var(--text-muted)', fontSize: '11px', textAlign: 'center', margin: '6px 0' }}>Нет активных заказов</p>
                              : <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>{active.map(OrderRow)}</div>
                            }
                            {done.length > 0 && (
                              <div style={{ marginTop: '8px' }}>
                                <button onClick={() => setShowDoneOrders(v => !v)}
                                  style={{ width: '100%', display: 'flex', alignItems: 'center', gap: '8px', padding: '9px 10px', borderRadius: '10px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', cursor: 'pointer' }}>
                                  <Icon name="document" size={13} color="var(--status-ready-color)" />
                                  <span style={{ flex: 1, textAlign: 'left', color: 'var(--text-secondary)', fontSize: '11px', fontWeight: 600 }}>Выполненные заказы · {done.length}</span>
                                  <div style={{ transform: showDoneOrders ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}><Icon name="chevron-down" size={14} color="var(--text-muted)" /></div>
                                </button>
                                {showDoneOrders && <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginTop: '6px' }}>{done.map(OrderRow)}</div>}
                              </div>
                            )}
                          </>
                        )
                      })()}
                      {(() => {
                        const favIds = allFavorites[u.login] ?? []
                        const favProducts = favIds
                          .map(id => products.find(p => p.id === id))
                          .filter((p): p is Product => !!p)
                        return (
                          <div style={{ marginTop: '8px' }}>
                            <button onClick={() => setShowFavorites(v => !v)}
                              style={{ width: '100%', display: 'flex', alignItems: 'center', gap: '8px', padding: '9px 10px', borderRadius: '10px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', cursor: 'pointer' }}>
                              <Icon name="heart" size={13} color="var(--danger)" />
                              <span style={{ flex: 1, textAlign: 'left', color: 'var(--text-secondary)', fontSize: '11px', fontWeight: 600 }}>Избранное · {favProducts.length}</span>
                              <div style={{ transform: showFavorites ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}><Icon name="chevron-down" size={14} color="var(--text-muted)" /></div>
                            </button>
                            {showFavorites && (
                              favProducts.length === 0
                                ? <p style={{ color: 'var(--text-muted)', fontSize: '11px', textAlign: 'center', margin: '8px 0' }}>Пусто</p>
                                : <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginTop: '6px' }}>
                                    {favProducts.map(p => (
                                      <div key={p.id} style={{ display: 'flex', gap: '8px', alignItems: 'center', padding: '8px', background: 'var(--bg-elevated)', borderRadius: '10px' }}>
                                        <img src={p.img} alt="" style={{ width: '36px', height: '36px', borderRadius: '7px', objectFit: 'cover', flexShrink: 0 }} />
                                        <div style={{ flex: 1, minWidth: 0 }}>
                                          <p style={{ color: 'var(--text-primary)', fontSize: '11px', fontWeight: 600, margin: '0 0 2px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.name}</p>
                                          <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0 }}>{p.series} · {p.price.toLocaleString()} ₽</p>
                                        </div>
                                      </div>
                                    ))}
                                  </div>
                            )}
                          </div>
                        )
                      })()}
                      {(() => {
                        // Все промики клиента: адресные (его ID) + общие, не удалённые.
                        // Истёкшие/исчерпанные не прячем, а помечаем — чтобы список был полным.
                        const userPromos = promocodes.filter(p =>
                          !p.deleted &&
                          (!p.targetUser || p.targetUser.toLowerCase() === u.login.toLowerCase()))
                        return (
                          <div style={{ marginTop: '8px' }}>
                            <button onClick={() => setShowUserPromos(v => !v)}
                              style={{ width: '100%', display: 'flex', alignItems: 'center', gap: '8px', padding: '9px 10px', borderRadius: '10px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', cursor: 'pointer' }}>
                              <Icon name="gift" size={13} color="var(--accent-2-hi)" />
                              <span style={{ flex: 1, textAlign: 'left', color: 'var(--text-secondary)', fontSize: '11px', fontWeight: 600 }}>Промики · {userPromos.length}</span>
                              <div style={{ transform: showUserPromos ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}><Icon name="chevron-down" size={14} color="var(--text-muted)" /></div>
                            </button>
                            {showUserPromos && (
                              userPromos.length === 0
                                ? <p style={{ color: 'var(--text-muted)', fontSize: '11px', textAlign: 'center', margin: '8px 0' }}>Нет промиков</p>
                                : <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', marginTop: '6px' }}>
                                    {userPromos.map(p => {
                                      const daysLeft = p.expiresAt ? Math.max(0, Math.ceil((p.expiresAt - Date.now()) / 86400000)) : null
                                      const expired = p.expiresAt > 0 && Date.now() > p.expiresAt
                                      const usedUp = p.uses >= p.maxUses
                                      const dead = expired || usedUp
                                      return (
                                        <div key={p.id} style={{ display: 'flex', gap: '8px', alignItems: 'center', padding: '8px 10px', background: 'var(--bg-elevated)', borderRadius: '10px', opacity: dead ? 0.55 : 1 }}>
                                          <div style={{ flex: 1, minWidth: 0 }}>
                                            <p style={{ color: 'var(--text-primary)', fontSize: '12px', fontWeight: 700, margin: '0 0 2px', letterSpacing: '1px', fontFamily: 'monospace' }}>
                                              {p.code}{dead && <span style={{ marginLeft: '6px', fontFamily: 'inherit', fontSize: '9px', fontWeight: 700, textTransform: 'uppercase', color: 'var(--danger)' }}>{expired ? 'истёк' : 'исчерпан'}</span>}
                                            </p>
                                            <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0 }}>
                                              {p.targetUser ? '🎁 розыгрыш' : 'для всех'} · {p.maxUses === 1 ? 'одноразовый' : `${p.uses}/${p.maxUses} исп.`}
                                            </p>
                                          </div>
                                          <div style={{ textAlign: 'right', flexShrink: 0 }}>
                                            <p style={{ color: 'var(--accent-2-hi)', fontSize: '14px', fontWeight: 800, margin: '0 0 1px' }}>−{p.discount}%</p>
                                            <p style={{ color: daysLeft !== null && daysLeft <= 3 ? 'var(--danger)' : 'var(--text-muted)', fontSize: '10px', margin: 0, fontWeight: 600 }}>
                                              {daysLeft === null ? 'бессрочно' : daysLeft === 0 ? 'сегодня' : `${daysLeft} дн.`}
                                            </p>
                                          </div>
                                        </div>
                                      )
                                    })}
                                  </div>
                            )}
                          </div>
                        )
                      })()}
                      <button onClick={() => { if (confirm(`Удалить клиента ${displayN}? Это действие необратимо.`)) onUserDelete(u.login) }}
                        style={{ marginTop: '12px', width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '10px', borderRadius: '10px', background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.18)', color: 'var(--danger)', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}>
                        <Icon name="trash" size={13} color="var(--danger)" /> Удалить клиента
                      </button>
                    </div>
                  )}
                </div>
              )
            })}
            {isOwner && onMigrateImages && (
              <div className="glass-card" style={{ padding: '12px', marginTop: '6px' }}>
                <p style={{ color: 'var(--text-primary)', fontSize: '12px', fontWeight: 700, margin: '0 0 3px' }}>Оптимизация трафика</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 10px' }}>Перенести старые картинки из базы в файловое хранилище (CDN + кэш). Резко снижает трафик синхронизации. Безопасно, можно запускать повторно.</p>
                <button onClick={() => onMigrateImages()}
                  style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '11px', borderRadius: '10px', background: 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', color: 'var(--accent-2-hi)', fontSize: '12px', fontWeight: 700, cursor: 'pointer' }}>
                  <Icon name="image" size={13} color="var(--accent-2-hi)" /> Перенести картинки в хранилище
                </button>
              </div>
            )}
            {isOwner && onWipeClients && (
              <div className="glass-card" style={{ padding: '12px', marginTop: '6px', border: '1px solid rgba(239,68,68,0.25)' }}>
                <p style={{ color: 'var(--danger)', fontSize: '12px', fontWeight: 700, margin: '0 0 3px' }}>Опасная зона</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 10px' }}>Полностью очистит клиентскую базу: клиентов, заказы, профили, отзывы и избранное — локально и в облаке. Отменить нельзя.</p>
                <button onClick={() => { if (confirm('Очистить ВСЮ клиентскую базу? Клиенты, заказы, отзывы и избранное будут удалены безвозвратно.')) onWipeClients() }}
                  style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '11px', borderRadius: '10px', background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.35)', color: 'var(--danger)', fontSize: '12px', fontWeight: 700, cursor: 'pointer' }}>
                  <Icon name="trash" size={13} color="var(--danger)" /> Очистить клиентскую базу
                </button>
              </div>
            )}
          </div>
        )
      }
  </>)
}
