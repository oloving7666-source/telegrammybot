import { Icon, OrderStatus, OrderTrackEditor, STATUS_META, StatusBadge, statusAccent } from '../../shared'
import type { CrmCtx } from '../state'

export default function OrdersSection(ctx: CrmCtx) {
  const { onOrderDelete, onOrderStatus, onOrderTrack, orders } = ctx
  return (<>
      {(
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {orders.map(order => (
              <div key={order.id} className="glass-card cv-row" style={{ padding: '10px' }}>
                <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '8px' }}>
                  <img src={order.thumb} alt="" style={{ width: '40px', height: '40px', borderRadius: '8px', objectFit: 'cover', flexShrink: 0 }} />
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <p style={{ color: 'var(--text-primary)', fontSize: '12px', fontWeight: 600, margin: '0 0 1px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{order.name}</p>
                    <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '0 0 1px' }}>{order.id} · {order.userId} · {order.variantName ?? (order.painted ? 'С покраской' : 'Без покраски')}</p>
                    <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0 }}>{order.date} · {(order.painted ? order.price : order.priceUnpainted).toLocaleString()} ₽</p>
                  </div>
                  <StatusBadge status={order.status} />
                  <button onClick={() => { if (confirm(`Удалить заказ ${order.id}?`)) onOrderDelete(order.id) }}
                    style={{ display: 'flex', alignItems: 'center', padding: '6px', borderRadius: '8px', background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.18)', cursor: 'pointer', flexShrink: 0 }}
                    title="Удалить заказ">
                    <Icon name="trash" size={13} color="var(--danger)" />
                  </button>
                </div>
                <div style={{ display: 'flex', gap: '5px', flexWrap: 'wrap' }}>
                  {(['new','printing','painting','ready','delivered'] as OrderStatus[]).map(s => {
                    const isActive = order.status === s
                    const c = statusAccent(s)
                    // Красочные кнопки в гамме раздела «Заказы»: у активной — заливка,
                    // свечение и пульсирующее кольцо вокруг прямоугольника; у остальных —
                    // цветной контур в своём цвете статуса.
                    return (
                      <button key={s} onClick={() => onOrderStatus(order.id, s)}
                        className={isActive ? 'ss-btn-pulse' : 'ss-press'}
                        style={{
                          position: 'relative', padding: '4px 9px', borderRadius: '9px',
                          border: `1px solid color-mix(in srgb, ${c} ${isActive ? '75%' : '38%'}, transparent)`,
                          background: isActive ? `color-mix(in srgb, ${c} 20%, transparent)` : `color-mix(in srgb, ${c} 7%, transparent)`,
                          color: isActive ? c : `color-mix(in srgb, ${c} 78%, var(--text-muted))`,
                          fontSize: '10px', fontWeight: isActive ? 700 : 550, cursor: 'pointer',
                          boxShadow: isActive ? `0 0 14px -4px ${c}` : 'none',
                          ['--ss-pulse-c' as string]: c,
                          transition: 'background 0.25s var(--ss-ease, ease), color 0.25s var(--ss-ease, ease), border-color 0.25s var(--ss-ease, ease)',
                        }}>
                        {STATUS_META[s].label}
                      </button>
                    )
                  })}
                </div>
                <OrderTrackEditor order={order} onSave={onOrderTrack} />
              </div>
            ))}
          </div>
        )
      }
  </>)
}
