import type { CrmCtx } from '../state'

export default function CustomOrderSection(ctx: CrmCtx) {
  const { customOrder, setCustomOrder } = ctx
  return (<>
      {(
          <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
            <div>
              <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: '0 0 4px' }}>Индивидуальный заказ</p>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Настройте окно «Фигурка по вашей идее», которое открывается кнопкой на главной под калькулятором.</p>
            </div>

            <div>
              <label style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px' }}>Заголовок окна</label>
              <input value={customOrder.title ?? ''} onChange={e => setCustomOrder(c => ({ ...c, title: e.target.value }))} placeholder="Фигурка по вашей идее"
                style={{ width: '100%', marginTop: '5px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '9px', padding: '9px 11px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
            </div>

            <div>
              <label style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px' }}>Подзаголовок</label>
              <textarea value={customOrder.subtitle ?? ''} onChange={e => setCustomOrder(c => ({ ...c, subtitle: e.target.value }))} rows={2} placeholder="Согласуем модель, материал и размер с мастером…"
                style={{ width: '100%', marginTop: '5px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '9px 11px', color: 'var(--text-primary)', fontSize: '13px', lineHeight: 1.5, outline: 'none', resize: 'vertical', boxSizing: 'border-box', fontFamily: 'inherit' }} />
            </div>

            <div>
              <label style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px' }}>Метки (через запятую)</label>
              <input value={(customOrder.chips ?? []).join(', ')} onChange={e => setCustomOrder(c => ({ ...c, chips: e.target.value.split(',').map(s => s.trim()).filter(Boolean) }))} placeholder="Своя 3D-модель, Персонаж, Бюст"
                style={{ width: '100%', marginTop: '5px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '9px', padding: '9px 11px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
            </div>

            <div>
              <label style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px' }}>Текст (каждая строка — отдельный шаг)</label>
              <textarea value={customOrder.text} onChange={e => setCustomOrder(c => ({ ...c, text: e.target.value }))} rows={6}
                style={{ width: '100%', marginTop: '5px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '10px 12px', color: 'var(--text-primary)', fontSize: '13px', lineHeight: 1.5, outline: 'none', resize: 'vertical', boxSizing: 'border-box', fontFamily: 'inherit' }} />
            </div>

            <div>
              <label style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px' }}>Текст кнопки</label>
              <input value={customOrder.buttonText} onChange={e => setCustomOrder(c => ({ ...c, buttonText: e.target.value }))} placeholder="Написать мастеру"
                style={{ width: '100%', marginTop: '5px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '9px', padding: '9px 11px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
            </div>

            <div>
              <label style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px' }}>Ссылка на профиль мастера</label>
              <input value={customOrder.link} onChange={e => setCustomOrder(c => ({ ...c, link: e.target.value }))} placeholder="https://t.me/username"
                style={{ width: '100%', marginTop: '5px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '9px', padding: '9px 11px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
            </div>
          </div>
        )
      }
  </>)
}
