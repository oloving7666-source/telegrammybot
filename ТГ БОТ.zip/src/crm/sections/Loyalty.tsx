import { useState } from 'react'
import { Icon, readProfile, clubTiersOf, genTierKey } from '../../shared'
import type { ClubTier } from '../../shared'
import type { CrmCtx } from '../state'

export default function LoyaltySection(ctx: CrmCtx) {
  const { loyalty, setLoyalty, onAdjustPoints, sortedClients, profiles, registeredUsers } = ctx
  const [saved, setSaved] = useState(false)
  const [adjust, setAdjust] = useState<Record<string, string>>({})

  const patch = (p: Partial<typeof loyalty>) => { setLoyalty(l => ({ ...l, ...p })); setSaved(true); setTimeout(() => setSaved(false), 1500) }

  const tiers = clubTiersOf(loyalty)
  const setTiers = (list: ClubTier[]) => patch({ clubTiers: list })
  const patchTier = (i: number, p: Partial<ClubTier>) => setTiers(tiers.map((t, j) => j === i ? { ...t, ...p } : t))
  const addTier = () => {
    const last = tiers[tiers.length - 1]
    setTiers([...tiers, { key: genTierKey(), name: 'Новый уровень', from: (last?.from ?? 0) + 50000, discount: 0, color: '#8b93a7', perks: ['Опишите привилегию'] }])
  }
  const removeTier = (i: number) => setTiers(tiers.filter((_, j) => j !== i))

  // Клиенты с ненулевым балансом — сверху; остальные ниже.
  const clients = (sortedClients.length ? sortedClients : registeredUsers)
    .map(u => ({ u, pts: readProfile(profiles, u.login)?.points ?? 0 }))
    .sort((a, b) => b.pts - a.pts)
  const totalPoints = clients.reduce((s, c) => s + c.pts, 0)

  const numField = (label: string, value: number, onChange: (n: number) => void, suffix: string, hint?: string) => (
    <div style={{ flex: 1 }}>
      <label style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px' }}>{label}</label>
      <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginTop: '5px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '9px', padding: '0 11px' }}>
        <input type="number" inputMode="numeric" min={0} value={value || ''} onChange={e => onChange(Math.max(0, Number(e.target.value)))}
          style={{ flex: 1, background: 'none', border: 'none', padding: '9px 0', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', minWidth: 0 }} />
        <span style={{ color: 'var(--text-muted)', fontSize: '11px', flexShrink: 0 }}>{suffix}</span>
      </div>
      {hint && <p style={{ color: 'var(--text-muted)', fontSize: '9.5px', margin: '3px 0 0' }}>{hint}</p>}
    </div>
  )

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
      <div>
        <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 700, margin: '0 0 4px' }}>Программа лояльности</p>
        <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0 }}>Кешбэк бонусами за доставленные заказы, приветственные бонусы и рефералы. Бонусы = рубли, списываются при оформлении.</p>
      </div>

      {/* Настройки */}
      <div className="glass-card" style={{ padding: '14px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
        <button onClick={() => patch({ enabled: !loyalty.enabled })}
          style={{ display: 'flex', alignItems: 'center', gap: '11px', padding: '11px 12px', borderRadius: '11px', cursor: 'pointer', textAlign: 'left',
            background: loyalty.enabled ? 'var(--accent-2-wash)' : 'var(--bg-input)', border: `1px solid ${loyalty.enabled ? 'var(--accent-2)' : 'var(--border)'}` }}>
          <span style={{ fontSize: '18px', lineHeight: 1, flexShrink: 0 }}>💎</span>
          <span style={{ flex: 1, minWidth: 0 }}>
            <span style={{ display: 'block', color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 650 }}>Программа {loyalty.enabled ? 'включена' : 'выключена'}</span>
            <span style={{ display: 'block', color: 'var(--text-muted)', fontSize: '10.5px', marginTop: '1px' }}>{loyalty.enabled ? 'Клиенты копят и тратят бонусы' : 'Начисление и списание приостановлены'}</span>
          </span>
          <span style={{ flexShrink: 0, width: '38px', height: '22px', borderRadius: '999px', position: 'relative', transition: 'background 0.2s', background: loyalty.enabled ? 'var(--accent-2)' : 'var(--border)' }}>
            <span style={{ position: 'absolute', top: '2px', left: loyalty.enabled ? '18px' : '2px', width: '18px', height: '18px', borderRadius: '50%', background: '#fff', transition: 'left 0.2s' }} />
          </span>
        </button>

        <div style={{ display: 'flex', gap: '10px' }}>
          {numField('Кешбэк', loyalty.cashback, n => patch({ cashback: Math.min(100, n) }), '%', 'возврат с заказа')}
          {numField('Лимит списания', loyalty.maxRedeemPct, n => patch({ maxRedeemPct: Math.min(100, n) }), '%', 'от суммы заказа')}
        </div>
        {numField('Реферальный бонус', loyalty.referral, n => patch({ referral: n }), '₽', 'пригласившему + приветственный приглашённому за первый доставленный заказ')}

        {saved && <p style={{ color: 'var(--status-ready-color)', fontSize: '11px', margin: 0, fontWeight: 600 }}>✓ Сохранено</p>}
      </div>

      {/* Sigma Club — борд привилегий */}
      <div className="glass-card" style={{ padding: '14px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
        <div>
          <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, margin: '0 0 3px' }}>Sigma Club</p>
          <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: 0, lineHeight: 1.4 }}>Борд привилегий с уровнями (Космонавт → Легенда) по сумме заказов. Пока выключено — клиенты видят экран «Скоро». Включите, когда решите запустить.</p>
        </div>
        <button onClick={() => patch({ clubEnabled: !loyalty.clubEnabled })}
          style={{ display: 'flex', alignItems: 'center', gap: '11px', padding: '11px 12px', borderRadius: '11px', cursor: 'pointer', textAlign: 'left',
            background: loyalty.clubEnabled ? 'var(--ss-brand-wash, var(--accent-2-wash))' : 'var(--bg-input)', border: `1px solid ${loyalty.clubEnabled ? 'var(--ss-brand-edge, var(--accent-2))' : 'var(--border)'}` }}>
          <span style={{ fontSize: '18px', lineHeight: 1, flexShrink: 0 }}>⭐</span>
          <span style={{ flex: 1, minWidth: 0 }}>
            <span style={{ display: 'block', color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 650 }}>Борд привилегий {loyalty.clubEnabled ? 'включён' : 'выключен'}</span>
            <span style={{ display: 'block', color: 'var(--text-muted)', fontSize: '10.5px', marginTop: '1px' }}>{loyalty.clubEnabled ? 'Клиенты видят уровни и льготы' : 'Клиенты видят экран «Скоро»'}</span>
          </span>
          <span style={{ flexShrink: 0, width: '38px', height: '22px', borderRadius: '999px', position: 'relative', transition: 'background 0.2s', background: loyalty.clubEnabled ? 'var(--ss-brand, var(--accent-2))' : 'var(--border)' }}>
            <span style={{ position: 'absolute', top: '2px', left: loyalty.clubEnabled ? '18px' : '2px', width: '18px', height: '18px', borderRadius: '50%', background: '#fff', transition: 'left 0.2s' }} />
          </span>
        </button>

        {/* Заголовок и вступление борда */}
        <div>
          <label style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px' }}>Заголовок клуба</label>
          <input value={loyalty.clubTitle} onChange={e => patch({ clubTitle: e.target.value })} placeholder="Sigma Club"
            style={{ width: '100%', marginTop: '5px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '9px', padding: '9px 11px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
        </div>
        <div>
          <label style={{ color: 'var(--text-muted)', fontSize: '10px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.6px' }}>Вступительный текст</label>
          <textarea value={loyalty.clubIntro} onChange={e => patch({ clubIntro: e.target.value })} rows={2} placeholder="Короткое описание под уровнем"
            style={{ width: '100%', marginTop: '5px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '9px', padding: '9px 11px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', resize: 'vertical', boxSizing: 'border-box', lineHeight: 1.4 }} />
        </div>

        {/* Уровни */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '2px' }}>
          <span style={{ color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 700 }}>Уровни ({tiers.length})</span>
          <button onClick={addTier} style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '6px 10px', borderRadius: '8px', border: '1px solid var(--accent-2)', background: 'var(--accent-2-wash)', color: 'var(--accent-2-hi)', fontSize: '11.5px', fontWeight: 700, cursor: 'pointer' }}>
            <Icon name="plus" size={12} color="var(--accent-2-hi)" /> Уровень
          </button>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          {tiers.map((t, i) => (
            <div key={t.key} style={{ borderRadius: '13px', padding: '12px', background: 'var(--bg-input)', border: `1px solid ${t.color}` }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '9px' }}>
                <input type="color" value={/^#[0-9a-fA-F]{6}$/.test(t.color) ? t.color : '#8b93a7'} onChange={e => patchTier(i, { color: e.target.value })}
                  style={{ width: '30px', height: '30px', flexShrink: 0, padding: 0, border: '1px solid var(--border)', borderRadius: '8px', background: 'none', cursor: 'pointer' }} />
                <input value={t.name} onChange={e => patchTier(i, { name: e.target.value })} placeholder="Название"
                  style={{ flex: 1, minWidth: 0, background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '8px', padding: '8px 10px', color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, outline: 'none' }} />
                <button onClick={() => removeTier(i)} disabled={tiers.length <= 1} title="Удалить уровень"
                  style={{ width: '30px', height: '30px', flexShrink: 0, display: 'grid', placeItems: 'center', borderRadius: '8px', border: '1px solid var(--danger)', background: 'rgba(239,68,68,0.1)', cursor: tiers.length <= 1 ? 'default' : 'pointer', opacity: tiers.length <= 1 ? 0.35 : 1 }}>
                  <Icon name="trash" size={13} color="var(--danger)" />
                </button>
              </div>

              <div style={{ display: 'flex', gap: '8px', marginBottom: '9px' }}>
                <div style={{ flex: 1 }}>
                  <label style={{ color: 'var(--text-muted)', fontSize: '9.5px' }}>Порог, ₽</label>
                  <input type="number" inputMode="numeric" min={0} value={t.from || (t.from === 0 ? 0 : '')} onChange={e => patchTier(i, { from: Math.max(0, Number(e.target.value)) })}
                    style={{ width: '100%', marginTop: '3px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '8px', padding: '7px 9px', color: 'var(--text-primary)', fontSize: '12.5px', outline: 'none', boxSizing: 'border-box' }} />
                </div>
                <div style={{ flex: 1 }}>
                  <label style={{ color: 'var(--text-muted)', fontSize: '9.5px' }}>Скидка, %</label>
                  <input type="number" inputMode="numeric" min={0} max={100} value={t.discount || ''} onChange={e => patchTier(i, { discount: Math.max(0, Math.min(100, Number(e.target.value))) })}
                    style={{ width: '100%', marginTop: '3px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '8px', padding: '7px 9px', color: 'var(--text-primary)', fontSize: '12.5px', outline: 'none', boxSizing: 'border-box' }} />
                </div>
                <div style={{ flex: 1.4, minWidth: 0 }}>
                  <label style={{ color: 'var(--text-muted)', fontSize: '9.5px' }}>ID уровня</label>
                  <input value={t.key} onChange={e => patchTier(i, { key: e.target.value.trim() })} placeholder="id"
                    style={{ width: '100%', marginTop: '3px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '8px', padding: '7px 9px', color: 'var(--text-muted)', fontSize: '12px', fontFamily: 'monospace', outline: 'none', boxSizing: 'border-box' }} />
                </div>
              </div>

              <label style={{ color: 'var(--text-muted)', fontSize: '9.5px' }}>Привилегии (по одной на строку)</label>
              <textarea value={t.perks.join('\n')} onChange={e => patchTier(i, { perks: e.target.value.split('\n').map(s => s.trimStart()).filter((s, k, a) => s !== '' || k === a.length - 1) })}
                rows={Math.max(2, t.perks.length)} placeholder="Скидка 5% на все заказы"
                style={{ width: '100%', marginTop: '3px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '8px', padding: '8px 10px', color: 'var(--text-primary)', fontSize: '12px', outline: 'none', resize: 'vertical', boxSizing: 'border-box', lineHeight: 1.45 }} />
            </div>
          ))}
        </div>
        <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: 0, lineHeight: 1.4 }}>Уровни автоматически сортируются по порогу. Первый уровень (порог 0 ₽) — стартовый для всех клиентов.</p>
      </div>

      {/* Сводка */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
        <div className="glass-card" style={{ padding: '12px', display: 'flex', alignItems: 'center', gap: '9px' }}>
          <Icon name="heart" size={17} color="#c76b6b" />
          <div>
            <p style={{ color: 'var(--text-primary)', fontSize: '15px', fontWeight: 800, margin: 0, lineHeight: 1 }}>{totalPoints.toLocaleString('ru')} ₽</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '2px 0 0' }}>бонусов у клиентов</p>
          </div>
        </div>
        <div className="glass-card" style={{ padding: '12px', display: 'flex', alignItems: 'center', gap: '9px' }}>
          <Icon name="users" size={17} color="#5ba172" />
          <div>
            <p style={{ color: 'var(--text-primary)', fontSize: '15px', fontWeight: 800, margin: 0, lineHeight: 1 }}>{clients.filter(c => c.pts > 0).length}</p>
            <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '2px 0 0' }}>с бонусами</p>
          </div>
        </div>
      </div>

      {/* Балансы клиентов + ручная корректировка */}
      <div>
        <p style={{ color: 'var(--text-primary)', fontSize: '12.5px', fontWeight: 700, margin: '0 0 8px' }}>Балансы клиентов</p>
        {clients.length === 0 ? (
          <p style={{ color: 'var(--text-muted)', fontSize: '12px', textAlign: 'center', padding: '10px 0', fontStyle: 'italic' }}>Клиентов пока нет</p>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {clients.map(({ u, pts }) => {
              const amt = adjust[u.login] ?? ''
              const delta = parseInt(amt) || 0
              const apply = (sign: 1 | -1) => {
                if (!delta) return
                onAdjustPoints(u.login, sign * Math.abs(delta), 'ручная корректировка')
                setAdjust(a => ({ ...a, [u.login]: '' }))
              }
              return (
                <div key={u.login} className="glass-card" style={{ padding: '11px 12px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <div style={{ minWidth: 0, flex: 1 }}>
                      <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{u.name || u.login}</p>
                      <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', margin: '1px 0 0' }}>{u.login}</p>
                    </div>
                    <span style={{ flexShrink: 0, color: pts > 0 ? 'var(--accent-2-hi)' : 'var(--text-muted)', fontSize: '14px', fontWeight: 800 }}>{pts.toLocaleString('ru')} ₽</span>
                  </div>
                  <div style={{ display: 'flex', gap: '6px' }}>
                    <input type="number" inputMode="numeric" value={amt} placeholder="сумма ₽" onChange={e => setAdjust(a => ({ ...a, [u.login]: e.target.value }))}
                      style={{ flex: 1, background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '8px', padding: '7px 10px', color: 'var(--text-primary)', fontSize: '12px', outline: 'none', minWidth: 0 }} />
                    <button onClick={() => apply(1)} disabled={!delta} title="Начислить"
                      style={{ padding: '0 12px', borderRadius: '8px', border: '1px solid var(--status-ready-color)', background: 'rgba(52,201,125,0.12)', color: 'var(--status-ready-color)', fontSize: '13px', fontWeight: 800, cursor: delta ? 'pointer' : 'default', opacity: delta ? 1 : 0.4 }}>+</button>
                    <button onClick={() => apply(-1)} disabled={!delta} title="Списать"
                      style={{ padding: '0 12px', borderRadius: '8px', border: '1px solid var(--danger)', background: 'rgba(239,68,68,0.1)', color: 'var(--danger)', fontSize: '13px', fontWeight: 800, cursor: delta ? 'pointer' : 'default', opacity: delta ? 1 : 0.4 }}>−</button>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
