import { EmojiPicker, Icon, IconName, OWNER_TG, PATHS } from '../../shared'
import type { CrmCtx } from '../state'

export default function FaqSection(ctx: CrmCtx) {
  const { addFaq, editingFaq, faqDraft, faqSections, isOwner, newFaq, sbpInfo, setAddFaq, setEditingFaq, setFaqDraft, setFaqSections, setNewFaq, setSbpInfo } = ctx
  return (<>
      {(
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
            {/* Контакт техподдержки (кнопка внизу FAQ) — менять может только создатель */}
            {isOwner && (
              <div className="glass-card" style={{ padding: '12px', marginBottom: '2px' }}>
                <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: '0 0 3px' }}>Техподдержка (кнопка в FAQ)</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 8px' }}>Telegram мастера, куда пишут клиенты из раздела FAQ.</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '0 12px' }}>
                  <span style={{ color: 'var(--text-muted)', fontSize: '13px' }}>@</span>
                  <input value={(sbpInfo.support ?? sbpInfo.contact ?? OWNER_TG).replace(/^https?:\/\/t\.me\//, '').replace(/^@/, '')}
                    onChange={e => setSbpInfo(i => ({ ...i, support: e.target.value.replace(/^@/, '') }))}
                    placeholder="username"
                    style={{ flex: 1, padding: '9px 0', background: 'none', border: 'none', color: 'var(--text-primary)', fontSize: '13px', outline: 'none' }} />
                </div>
              </div>
            )}
            <button className="btn-primary" style={{ marginBottom: '2px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px' }} onClick={() => setAddFaq(true)}>
              <Icon name="plus" size={14} color="#fff" /> Добавить раздел
            </button>
            {addFaq && (
              <div className="glass-card" style={{ padding: '12px', marginBottom: '2px' }}>
                <div style={{ display: 'flex', gap: '8px', marginBottom: '8px' }}>
                  <div style={{ flex: '0 0 72px' }}>
                    <p style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 500, margin: '0 0 5px' }}>Эмодзи</p>
                    <EmojiPicker value={newFaq.emoji} onChange={em => setNewFaq(p => ({ ...p, emoji: em }))} />
                  </div>
                  <div style={{ flex: 1 }}>
                    <p style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 500, margin: '0 0 5px' }}>Заголовок</p>
                    <input value={newFaq.title} onChange={e => setNewFaq(p => ({ ...p, title: e.target.value }))} placeholder="Название раздела"
                      style={{ width: '100%', padding: '9px 12px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
                  </div>
                </div>
                <p style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 500, margin: '0 0 5px' }}>Содержимое</p>
                <textarea value={newFaq.content} onChange={e => setNewFaq(p => ({ ...p, content: e.target.value }))} rows={5} placeholder="Текст раздела..."
                  style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '10px 12px', color: 'var(--text-primary)', fontSize: '12px', lineHeight: 1.6, outline: 'none', resize: 'vertical', boxSizing: 'border-box', fontFamily: 'inherit' }} />
                <div style={{ display: 'flex', gap: '8px', marginTop: '10px' }}>
                  <button className="btn-primary" style={{ flex: 1 }} onClick={() => {
                    if (!newFaq.title.trim()) return
                    setFaqSections(prev => [...prev, { id: Date.now().toString(), title: newFaq.title.trim(), emoji: newFaq.emoji || '📄', content: newFaq.content }])
                    setNewFaq({ title: '', emoji: 'document', content: '' })
                    setAddFaq(false)
                  }}>Добавить</button>
                  <button className="btn-secondary" style={{ flex: 1 }} onClick={() => { setAddFaq(false); setNewFaq({ title: '', emoji: 'document', content: '' }) }}>Отмена</button>
                </div>
              </div>
            )}
            {faqSections.map(sec => {
              const crmIcon: IconName = (sec.emoji && sec.emoji in PATHS) ? sec.emoji as IconName : 'question'
              return (
                <div key={sec.id} className="glass-card" style={{ overflow: 'hidden' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '12px' }}>
                    <div style={{ width: '32px', height: '32px', borderRadius: '8px', background: 'var(--accent-2-wash)', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <Icon name={crmIcon} size={15} color="var(--accent-2-hi)" />
                    </div>
                    <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: 0, flex: 1 }}>{sec.title}</p>
                    {editingFaq === sec.id
                      ? <button onClick={() => { setFaqSections(prev=>prev.map(s=>s.id===sec.id?{...s,content:faqDraft}:s)); setEditingFaq(null) }} style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '5px 10px', borderRadius: '8px', background: 'rgba(52,201,125,0.1)', border: '1px solid var(--status-ready-color)', color: 'var(--status-ready-color)', fontSize: '11px', fontWeight: 600, cursor: 'pointer' }}><Icon name="save" size={12} color="var(--status-ready-color)" /> Сохранить</button>
                      : <button onClick={() => { setEditingFaq(sec.id); setFaqDraft(sec.content) }} style={{ display: 'flex', alignItems: 'center', gap: '4px', padding: '5px 10px', borderRadius: '8px', background: 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', color: 'var(--accent-2-hi)', fontSize: '11px', fontWeight: 600, cursor: 'pointer' }}><Icon name="pencil" size={12} color="var(--accent-2-hi)" /> Изменить</button>}
                    <button onClick={() => setFaqSections(prev => prev.filter(s => s.id !== sec.id))} style={{ display: 'flex', alignItems: 'center', padding: '6px', borderRadius: '8px', background: 'rgba(239,68,68,0.07)', border: '1px solid rgba(239,68,68,0.18)', cursor: 'pointer', flexShrink: 0 }}><Icon name="trash" size={13} color="var(--danger)" /></button>
                  </div>
                  {editingFaq === sec.id
                    ? <div style={{ padding: '0 12px 12px' }}><textarea value={faqDraft} onChange={e => setFaqDraft(e.target.value)} rows={8} style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '10px 12px', color: 'var(--text-primary)', fontSize: '12px', lineHeight: 1.6, outline: 'none', resize: 'vertical', boxSizing: 'border-box', fontFamily: 'inherit' }} /></div>
                    : <div style={{ padding: '0 12px 12px', borderTop: '1px solid var(--border)' }}><p style={{ color: 'var(--text-secondary)', fontSize: '12px', lineHeight: 1.6, margin: '10px 0 0', whiteSpace: 'pre-wrap' }}>{sec.content.slice(0,120)}...</p></div>}
                </div>
              )
            })}
          </div>
        )
      }
  </>)
}
