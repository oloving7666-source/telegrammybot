import { useState, useRef, useEffect } from 'react'
import { kv, storage, publishPost } from '../api'
import { getCroppedFile, getCroppedRectFile, getCroppedVideoFile, canCropVideo, readVideoMeta, type PixelCrop } from '../cropImage'
import { BannerConfig, CatalogSection, CatalogFilterButton, CoverMode, CustomOrderConfig, DeliveryService, FaqSection, FormField, HomeConfig, INIT_BANNER, Icon, IconName, LoyaltyConfig, Material, NoticeContent, Order, OrderStatus, Product, ProductVariant, PromoCode, RegisteredUser, Review, Role, SbpInfo, ShopStatus, UserProfile, compressImage, normLogin, normTag, allProductTags, readProfile, genVariantId, variantCover } from '../shared'
import { logAction } from '../log'

export interface CrmProps {
  products: Product[]; setProducts: React.Dispatch<React.SetStateAction<Product[]>>
  sections: CatalogSection[]; setSections: React.Dispatch<React.SetStateAction<CatalogSection[]>>
  orders: Order[]; onOrderStatus: (id: string, status: OrderStatus) => void
  onOrderTrack: (id: string, track: string, carrier: DeliveryService) => void
  onOrderDelete: (id: string) => void
  onOrderCreate: (o: Order) => void
  onPayVerify: (id: string, ok: boolean) => void
  roles: Record<string, Role>; setRoles: React.Dispatch<React.SetStateAction<Record<string, Role>>>
  sbpInfo: SbpInfo; setSbpInfo: React.Dispatch<React.SetStateAction<SbpInfo>>
  allowedTabs: string[] | null
  registeredUsers: RegisteredUser[]
  onUserDelete: (login: string) => void
  /** Полная очистка клиентской базы — только для владельца. */
  onWipeClients?: () => void
  /** Обнуление всей статистики и истории продаж перед запуском — только для владельца. */
  onWipeStats?: () => void
  /** Разовый перенос старых base64-картинок из БД в хранилище — только для владельца. */
  onMigrateImages?: () => void
  faqSections: FaqSection[]; setFaqSections: React.Dispatch<React.SetStateAction<FaqSection[]>>
  materials: Material[]; setMaterials: React.Dispatch<React.SetStateAction<Material[]>>
  reviews: Review[]; setReviews: React.Dispatch<React.SetStateAction<Review[]>>
  profiles: Record<string, UserProfile>
  lastSeenTimes: Record<string, number>
  notice: NoticeContent; setNotice: React.Dispatch<React.SetStateAction<NoticeContent>>
  banner: BannerConfig; setBanner: React.Dispatch<React.SetStateAction<BannerConfig>>
  home: HomeConfig; setHome: React.Dispatch<React.SetStateAction<HomeConfig>>
  customOrder: CustomOrderConfig; setCustomOrder: React.Dispatch<React.SetStateAction<CustomOrderConfig>>
  promocodes: PromoCode[]; setPromocodes: React.Dispatch<React.SetStateAction<PromoCode[]>>
  payEnabled: Record<string, boolean>; setPayEnabled: React.Dispatch<React.SetStateAction<Record<string, boolean>>>
  /** Режим «магазин на паузе»: баннер клиентам + блокировка новых заказов. */
  shopStatus: ShopStatus; setShopStatus: React.Dispatch<React.SetStateAction<ShopStatus>>
  onProductsChange: (p: Product[]) => void
  onSectionsChange: (s: CatalogSection[]) => void
  allFavorites: Record<string, number[]>
  /** Лист ожидания: productId → логины, ждущие открытия окна/нового тиража. */
  waitlist: Record<string, string[]>
  /** Порядок разделов панели, заданный владельцем (список ключей вкладок). */
  crmOrder: string[]; setCrmOrder: React.Dispatch<React.SetStateAction<string[]>>
  /** Ключи разделов, вынесенных на левый рельс (остальные — на правом). */
  crmLeft: string[]; setCrmLeft: React.Dispatch<React.SetStateAction<string[]>>
  /** Владелец магазина — только он может менять расположение разделов. */
  isOwner: boolean
  /** Кому разрешено ставить свою обложку профиля (владельцу — всегда). */
  coverMode: CoverMode; setCoverMode: React.Dispatch<React.SetStateAction<CoverMode>>
  /** Настройки программы лояльности (кешбэк, рефералы, лимит списания). */
  loyalty: LoyaltyConfig; setLoyalty: React.Dispatch<React.SetStateAction<LoyaltyConfig>>
  /** Настраиваемые кнопки-фильтры каталога (состав и порядок). */
  catalogFilters: CatalogFilterButton[]; setCatalogFilters: React.Dispatch<React.SetStateAction<CatalogFilterButton[]>>
  /** Ручная корректировка бонусного баланса клиента администратором. */
  onAdjustPoints: (login: string, delta: number, reason: string) => void
}

export type CRMTab = 'dashboard' | 'orders' | 'neworder' | 'payverify' | 'roles' | 'products' | 'sections' | 'home' | 'users' | 'faq' | 'materials' | 'reviews' | 'notice' | 'custom' | 'promos' | 'loyalty' | 'payments' | 'pubhub' | 'logs'
export type PostMedia = { kind: 'photo' | 'video'; url: string; width?: number; height?: number }
export type CropJob = { src: string; isEdit: boolean; vid: string; replaceIdx?: number }

export function useCrmState(props: CrmProps) {
  const { products, setProducts, sections, setSections, orders, onOrderStatus, onOrderTrack, onOrderDelete, onOrderCreate, onPayVerify, roles, setRoles, sbpInfo, setSbpInfo, allowedTabs, registeredUsers, onUserDelete, faqSections, setFaqSections, materials, setMaterials, reviews, setReviews, profiles, lastSeenTimes, notice, setNotice, banner, setBanner, customOrder, setCustomOrder, promocodes, setPromocodes, payEnabled, setPayEnabled, onProductsChange, onSectionsChange, allFavorites, crmOrder, setCrmOrder, crmLeft, setCrmLeft, loyalty, setLoyalty, catalogFilters, setCatalogFilters, onAdjustPoints } = props
  // Wrappers that also push to cloud after each mutation
  const setProductsCloud: React.Dispatch<React.SetStateAction<Product[]>> = (action) => {
    setProducts(prev => {
      const next = typeof action === 'function' ? (action as (p: Product[]) => Product[])(prev) : action
      onProductsChange(next)
      return next
    })
  }
  const setSectionsCloud: React.Dispatch<React.SetStateAction<CatalogSection[]>> = (action) => {
    setSections(prev => {
      const next = typeof action === 'function' ? (action as (s: CatalogSection[]) => CatalogSection[])(prev) : action
      onSectionsChange(next)
      return next
    })
  }
  const [crmTab, setCrmTab] = useState<CRMTab>('orders')
  const [editProd, setEditProd] = useState<Product | null>(null)
  const [addProd, setAddProd] = useState(false)
  const EMPTY_PROD = (): Partial<Product> => ({ name: '', series: '', price: 0, priceUnpainted: 0, inStock: true, rating: 0, sold: 0, img: '', images: [], imagesPainted: [], imagesUnpainted: [], variants: [{ id: genVariantId(), name: 'С покраской', price: 0, images: [], cover: '' }], baseSize: 20, description: '' })
  const [newProd, setNewProd] = useState<Partial<Product>>(EMPTY_PROD())
  const [tagDraft, setTagDraft] = useState('')
  // Хештеги текущего редактируемого/создаваемого товара.
  const curTags = (): string[] => (editProd ? editProd.tags : newProd.tags) ?? []
  const setCurTags = (tags: string[]) => { if (editProd) setEditProd({ ...editProd, tags }); else setNewProd(p => ({ ...p, tags })) }
  const addProdTag = (raw: string) => {
    const t = normTag(raw)
    if (!t) return
    const cur = curTags()
    if (!cur.some(x => x.toLowerCase() === t.toLowerCase())) setCurTags([...cur, t])
    setTagDraft('')
  }
  const removeProdTag = (t: string) => setCurTags(curTags().filter(x => x !== t))
  const [showImport, setShowImport] = useState(false)
  const [importText, setImportText] = useState('')
  const [importMsg, setImportMsg] = useState('')
  // Ручное создание заказа (индивидуальные заказы под конкретный Telegram ID).
  const EMPTY_MANUAL = () => ({ userId: '', name: '', figure: '', price: '', painted: true, paid: false, thumb: '' })
  const [manualOrder, setManualOrder] = useState(EMPTY_MANUAL())
  const [manualMsg, setManualMsg] = useState('')
  // Отзыв от имени клиента, созданный админом.
  const EMPTY_REVIEW = () => ({ productId: 0, userId: '', rating: 5, text: '', photos: [] as string[] })
  const [revDraft, setRevDraft] = useState(EMPTY_REVIEW())
  const [revMsg, setRevMsg] = useState('')
  const [revUploading, setRevUploading] = useState(false)
  const revFileRef = useRef<HTMLInputElement>(null)
  const addReviewPhotos = async (files: FileList | null) => {
    if (!files || !files.length) return
    setRevUploading(true)
    try {
      const urls: string[] = []
      for (const f of Array.from(files)) urls.push(await storage.upload(await compressImage(f, 1200, 0.85)))
      setRevDraft(d => ({ ...d, photos: [...d.photos, ...urls] }))
      setRevMsg('')
    } catch (e) { setRevMsg((e as Error).message || 'Не удалось загрузить фото') }
    setRevUploading(false)
  }
  const createReview = () => {
    const uid = '@' + revDraft.userId.trim().replace(/^@/, '')
    if (!revDraft.productId) { setRevMsg('Выберите товар'); return }
    if (uid.length < 2) { setRevMsg('Укажите Telegram ID автора'); return }
    if (!revDraft.text.trim()) { setRevMsg('Напишите текст отзыва'); return }
    setReviews(prev => [...prev, {
      id: 'rv' + Date.now().toString(36),
      userId: uid, userName: uid,
      productId: revDraft.productId,
      rating: revDraft.rating,
      text: revDraft.text.trim(),
      date: new Date().toLocaleDateString('ru', { day: 'numeric', month: 'short', year: 'numeric' }),
      photos: revDraft.photos.length ? revDraft.photos : undefined,
    }])
    logAction('review', `Добавлен отзыв от имени ${uid} (${revDraft.rating}★)`)
    setRevDraft(EMPTY_REVIEW()); setRevMsg('Отзыв опубликован')
  }
  // Публикация поста в Telegram-канал
  const [postCaption, setPostCaption] = useState('')
  // Медиа поста: одно фото или одно видео (уже загруженное в Storage).
  const [postMedia, setPostMedia] = useState<PostMedia | null>(null)
  const [postUploading, setPostUploading] = useState(false)
  const [postPublishing, setPostPublishing] = useState(false)
  const [postMsg, setPostMsg] = useState<{ ok: boolean; text: string } | null>(null)
  const postFileRef = useRef<HTMLInputElement>(null)
  // Настройки публикации: ID канала указывается один раз и хранится в облаке.
  const DEFAULT_BTN = '🛍 Открыть магазин'
  const [channelId, setChannelId] = useState('')
  const [channelDraft, setChannelDraft] = useState('')
  const [channelSaved, setChannelSaved] = useState(false)
  const [postButton, setPostButton] = useState(DEFAULT_BTN)
  useEffect(() => {
    let alive = true
    kv.mget(['channelId', 'publishButtonText']).then(res => {
      if (!alive) return
      const id = typeof res.channelId === 'string' ? res.channelId : ''
      setChannelId(id); setChannelDraft(id)
      if (typeof res.publishButtonText === 'string' && res.publishButtonText) setPostButton(res.publishButtonText)
    }).catch(() => { /* offline */ })
    return () => { alive = false }
  }, [])
  const saveChannel = async () => {
    const id = channelDraft.trim()
    setChannelId(id); setChannelSaved(true); setPostMsg(null)
    setTimeout(() => setChannelSaved(false), 2000)
    try { await kv.set('channelId', id) } catch { setPostMsg({ ok: false, text: 'Не удалось сохранить ID канала' }) }
  }
  // Редактор кадра для поста: тот же принцип, что у аватарки и товаров, но
  // с выбором пропорций — и для фото, и для видео.
  const PUB_ASPECTS: Array<{ label: string; value: number }> = [
    { label: '1:1', value: 1 },
    { label: '4:5', value: 4 / 5 },
    { label: '16:9', value: 16 / 9 },
    { label: '9:16', value: 9 / 16 },
  ]
  const [pubJob, setPubJob] = useState<{ kind: 'photo' | 'video'; src: string; file: File } | null>(null)
  const [pubAspect, setPubAspect] = useState(1)
  const [pubPos, setPubPos] = useState({ x: 0, y: 0 })
  const [pubZoom, setPubZoom] = useState(1)
  const pubPixelsRef = useRef<PixelCrop | null>(null)
  const [pubProgress, setPubProgress] = useState<number | null>(null)

  const openPubEditor = (kind: 'photo' | 'video', file: File) => {
    setPubPos({ x: 0, y: 0 }); setPubZoom(1); pubPixelsRef.current = null; setPubProgress(null)
    setPubJob({ kind, src: URL.createObjectURL(file), file })
  }
  const closePubEditor = () => {
    if (pubJob) URL.revokeObjectURL(pubJob.src)
    setPubJob(null); setPubProgress(null)
  }

  const handlePostFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; e.target.value = ''
    if (!file) return
    setPostMsg(null)
    const isVideo = file.type.startsWith('video/')
    if (isVideo && !canCropVideo()) {
      // Браузер не умеет пересобирать mp4 — грузим ролик как есть.
      setPostUploading(true)
      try {
        const src = URL.createObjectURL(file)
        const meta = await readVideoMeta(src).catch(() => null)
        URL.revokeObjectURL(src)
        const url = await storage.upload(file)
        setPostMedia({ kind: 'video', url, width: meta?.width, height: meta?.height })
      } catch (err) { setPostMsg({ ok: false, text: (err as Error).message || 'Ошибка загрузки' }) }
      setPostUploading(false)
      return
    }
    openPubEditor(isVideo ? 'video' : 'photo', file)
  }

  // «Готово» в редакторе: обрезаем по выбранной области и грузим в Storage.
  const applyPubCrop = async () => {
    if (!pubJob || !pubPixelsRef.current) return
    setPostUploading(true); setPostMsg(null)
    try {
      if (pubJob.kind === 'photo') {
        const cropped = await getCroppedRectFile(pubJob.src, pubPixelsRef.current, 1280)
        const url = await storage.upload(cropped)
        setPostMedia({ kind: 'photo', url })
      } else {
        setPubProgress(0)
        const { file, width, height } = await getCroppedVideoFile(pubJob.src, pubPixelsRef.current, 1280, setPubProgress)
        const url = await storage.upload(file)
        setPostMedia({ kind: 'video', url, width, height })
      }
      closePubEditor()
    } catch (err) { setPostMsg({ ok: false, text: (err as Error).message || 'Ошибка обработки' }) }
    setPubProgress(null)
    setPostUploading(false)
  }

  // «Пропустить»: публикуем оригинал без изменения кадра.
  const skipPubCrop = async () => {
    if (!pubJob) return
    setPostUploading(true); setPostMsg(null)
    try {
      if (pubJob.kind === 'photo') {
        const url = await storage.upload(await compressImage(pubJob.file, 1280, 0.88))
        setPostMedia({ kind: 'photo', url })
      } else {
        const meta = await readVideoMeta(pubJob.src).catch(() => null)
        const url = await storage.upload(pubJob.file)
        setPostMedia({ kind: 'video', url, width: meta?.width, height: meta?.height })
      }
      closePubEditor()
    } catch (err) { setPostMsg({ ok: false, text: (err as Error).message || 'Ошибка загрузки' }) }
    setPostUploading(false)
  }

  const handlePublish = async () => {
    if (!postCaption.trim() && !postMedia) { setPostMsg({ ok: false, text: 'Добавьте фото, видео или текст поста' }); return }
    if (!channelId.trim()) { setPostMsg({ ok: false, text: 'Сначала укажите ID канала в настройках выше' }); return }
    setPostPublishing(true); setPostMsg(null)
    try {
      const btn = postButton.trim() || DEFAULT_BTN
      kv.set('publishButtonText', btn).catch(() => { /* offline */ })
      const res = await publishPost({
        photoUrl: postMedia?.kind === 'photo' ? postMedia.url : undefined,
        videoUrl: postMedia?.kind === 'video' ? postMedia.url : undefined,
        width: postMedia?.width, height: postMedia?.height,
        caption: postCaption.trim(), buttonText: btn, channelId: channelId.trim(),
      })
      if (res.ok) {
        setPostMsg({ ok: true, text: 'Пост опубликован в канале!' })
        setPostCaption(''); setPostMedia(null)
      } else {
        setPostMsg({ ok: false, text: res.error || 'Не удалось опубликовать' })
      }
    } catch (err) { setPostMsg({ ok: false, text: (err as Error).message || 'Ошибка публикации' }) }
    setPostPublishing(false)
  }

  const [roleForm, setRoleForm] = useState<{ login: string; role: Role }>({ login: '', role: 'moderator' })
  // Поиск по ожидающим подтверждения переводам: ID клиента или номер заказа.
  const [paySearch, setPaySearch] = useState('')
  const [roleMsg, setRoleMsg] = useState('')
  // Одно фото для ручного заказа — с тем же редактором кадрирования.
  const manualFileRef = useRef<HTMLInputElement>(null)
  const [manualPhotoSrc, setManualPhotoSrc] = useState<string | null>(null)
  const [manualCrop, setManualCrop] = useState({ x: 0, y: 0 })
  const [manualZoom, setManualZoom] = useState(1)
  const manualPixelsRef = useRef<PixelCrop | null>(null)
  const [manualUploading, setManualUploading] = useState(false)
  const handleManualFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file || !file.type.startsWith('image/')) return
    const r = new FileReader()
    r.onload = () => { setManualCrop({ x: 0, y: 0 }); setManualZoom(1); manualPixelsRef.current = null; setManualPhotoSrc(String(r.result)) }
    r.readAsDataURL(file)
  }
  const applyManualPhoto = async () => {
    if (!manualPhotoSrc || !manualPixelsRef.current) return
    setManualUploading(true)
    try {
      const cropped = await getCroppedFile(manualPhotoSrc, manualPixelsRef.current)
      const compressed = await compressImage(cropped, 600, 0.85)
      const url = await storage.upload(compressed)
      setManualOrder(m => ({ ...m, thumb: url }))
      setManualPhotoSrc(null)
    } catch (err) {
      alert(`Не удалось загрузить фото: ${(err as Error)?.message ?? 'ошибка'}`)
    } finally {
      setManualUploading(false)
    }
  }
  const createManualOrder = () => {
    const uid = manualOrder.userId.trim()
    const nm = manualOrder.name.trim()
    const price = parseInt(manualOrder.price) || 0
    if (!uid) { setManualMsg('Укажите Telegram ID клиента'); return }
    if (!nm) { setManualMsg('Укажите название заказа'); return }
    if (price <= 0) { setManualMsg('Укажите стоимость'); return }
    // Привязываем заказ к клиенту. Если такой уже заходил в приложение — берём его
    // ТОЧНЫЙ сохранённый login (байт в байт), иначе нормализуем ввод. Это убирает
    // расхождения по регистру/собачке/пробелам, из-за которых заказ мог «не дойти».
    const wanted = normLogin(uid)
    const known = registeredUsers.find(u => normLogin(u.login) === wanted)
    const login = known ? known.login : (uid.startsWith('@') ? uid : '@' + uid)
    const today = new Date().toLocaleDateString('ru', { day: 'numeric', month: 'short', year: 'numeric' })
    const order: Order = {
      id: `#M${Date.now().toString(36).toUpperCase()}`,
      name: nm,
      figure: manualOrder.figure.trim() || 'Индивидуальный заказ',
      price,
      priceUnpainted: price,
      date: today,
      status: 'new',
      thumb: manualOrder.thumb || 'https://images.unsplash.com/photo-1614732414444-096e5f1122d5?w=300&h=300&fit=crop&auto=format',
      userId: login,
      painted: manualOrder.painted,
      paid: manualOrder.paid,
      variantName: manualOrder.painted ? 'С покраской' : 'Без покраски',
    }
    onOrderCreate(order)
    logAction('order', `Создан ручной заказ ${order.id} для ${login} на ${price.toLocaleString('ru')} ₽`)
    setManualOrder(EMPTY_MANUAL())
    setManualMsg(`Заказ ${order.id} создан для ${login}`)
  }
  const [addSec, setAddSec] = useState(false)
  const [newSec, setNewSec] = useState({ name: '', emoji: 'grid' })
  const [editingSecId, setEditingSecId] = useState<number | null>(null)
  const [editingSecName, setEditingSecName] = useState('')
  const dragIdx = useRef<number | null>(null)
  const [dragOverIdx, setDragOverIdx] = useState<number | null>(null)
  // Сортировка списка товаров в CRM: 'desc' — новые сверху (по умолчанию), 'asc' — старые сверху,
  // 'manual' включается автоматически после ручного перетаскивания
  const [prodSort, setProdSort] = useState<'desc' | 'asc' | 'manual'>('desc')
  // Фильтр списка товаров по видимости: все / показанные клиентам / скрытые
  const [prodFilter, setProdFilter] = useState<'all' | 'active' | 'hidden'>('all')
  // Разом снять скрытие со всех товаров (удобно после массового импорта)
  const unhideAll = () => setProductsCloud(prev => prev.map(p => p.hidden ? { ...p, hidden: false } : p))
  const secDragIdx = useRef<number | null>(null)
  const [secDragOverIdx, setSecDragOverIdx] = useState<number | null>(null)
  const [expandedUser, setExpandedUser] = useState<string | null>(null)
  const [showDoneOrders, setShowDoneOrders] = useState(false)
  const [showFavorites, setShowFavorites] = useState(false)
  const [showUserPromos, setShowUserPromos] = useState(false)
  const [editingFaq, setEditingFaq] = useState<string | null>(null)
  const [faqDraft, setFaqDraft] = useState('')
  const [addFaq, setAddFaq] = useState(false)
  const [newFaq, setNewFaq] = useState({ title: '', emoji: 'document', content: '' })
  const [addMat, setAddMat] = useState(false)
  const [newMat, setNewMat] = useState({ name: '', priceMultiplier: 1.0 })

  // ── Промокоды ──
  const EMPTY_PROMO = () => ({ code: '', discount: 10, maxUses: 1, expiryDays: 30, targetUser: '', multi: false, featured: false })
  const [promoForm, setPromoForm] = useState(EMPTY_PROMO())
  const savePromo = () => {
    const code = promoForm.code.trim().toUpperCase()
    if (!code || promoForm.discount <= 0) return
    const featured = !!promoForm.featured
    const promo: PromoCode = {
      id: `promo-${Date.now()}`,
      code,
      discount: Math.max(1, Math.min(100, Math.round(promoForm.discount))),
      // Публичный анонс — для всех и практически без лимита активаций.
      maxUses: featured ? 1_000_000 : (promoForm.multi ? Math.max(1, Math.round(promoForm.maxUses)) : 1),
      uses: 0,
      expiresAt: promoForm.expiryDays > 0 ? Date.now() + promoForm.expiryDays * 86400000 : 0,
      targetUser: featured ? '' : promoForm.targetUser.trim(),
      createdAt: Date.now(),
      featured,
    }
    setPromocodes(prev => [promo, ...prev.filter(p => p.code.toUpperCase() !== code)])
    logAction('promo', `Создан промокод ${code} (−${promo.discount}%)${featured ? ' · для всех' : ''}`)
    setPromoForm(EMPTY_PROMO())
  }
  const deletePromo = (id: string) => setPromocodes(prev => {
    const p = prev.find(x => x.id === id)
    if (p) logAction('promo', `Удалён промокод ${p.code}`)
    return prev.map(x => x.id === id ? { ...x, deleted: true } : x)
  })

  // ── Варианты товара (свои название, цена, фото у каждого) ──
  // Изменить один вариант через функцию-мутатор.
  const mutateVariant = (isEdit: boolean, vid: string, fn: (v: ProductVariant) => ProductVariant) => {
    const map = (p: Partial<Product>): Partial<Product> => ({ ...p, variants: (p.variants ?? []).map(v => v.id === vid ? fn(v) : v) })
    if (isEdit) setEditProd(prev => prev ? (map(prev) as Product) : prev)
    else setNewProd(p => map(p))
  }
  const patchVariant = (isEdit: boolean, vid: string, patch: Partial<ProductVariant>) => mutateVariant(isEdit, vid, v => ({ ...v, ...patch }))
  const addVariant = (isEdit: boolean) => {
    const nv: ProductVariant = { id: genVariantId(), name: 'Новый вариант', price: 0, images: [], cover: '' }
    const map = (p: Partial<Product>): Partial<Product> => ({ ...p, variants: [...(p.variants ?? []), nv] })
    if (isEdit) setEditProd(prev => prev ? (map(prev) as Product) : prev)
    else setNewProd(p => map(p))
  }
  const removeVariant = (isEdit: boolean, vid: string) => {
    const map = (p: Partial<Product>): Partial<Product> => {
      const vs = (p.variants ?? []).filter(v => v.id !== vid)
      return { ...p, variants: vs.length ? vs : [{ id: genVariantId(), name: 'Стандарт', price: 0, images: [], cover: '' }] }
    }
    if (isEdit) setEditProd(prev => prev ? (map(prev) as Product) : prev)
    else setNewProd(p => map(p))
  }

  // Итоговые legacy-поля из вариантов: обложка, все фото, диапазон цен.
  const buildFromVariants = (p: Partial<Product>) => {
    const vs = (p.variants ?? []).map(v => ({ ...v, images: (v.images ?? []).filter(Boolean) }))
    const all = Array.from(new Set(vs.flatMap(v => v.images)))
    const firstCover = vs.map(v => (v.cover && v.images.includes(v.cover)) ? v.cover : v.images[0]).find(Boolean)
    const thumb = firstCover || all[0] || p.img || 'https://images.unsplash.com/photo-1614732414444-096e5f1122d5?w=300&h=300&fit=crop&auto=format'
    const prices = vs.map(v => v.price).filter(n => n > 0)
    return { variants: vs, img: thumb, images: all.length ? all : [thumb], imagesPainted: undefined, imagesUnpainted: undefined, price: prices.length ? Math.max(...prices) : 0, priceUnpainted: prices.length ? Math.min(...prices) : 0 }
  }

  const saveProd = () => {
    if (editProd) {
      const merged = { ...editProd, ...buildFromVariants(editProd) }
      setProductsCloud(prev => prev.map(p => p.id === editProd.id ? merged : p)); setEditProd(null)
      logAction('product', `Изменён товар «${merged.name}»`)
    }
    else {
      const built = buildFromVariants(newProd)
      setProductsCloud(prev => [...prev, { id: Date.now(), name: newProd.name||'', series: newProd.series||'', rating: 0, sold: 0, inStock: true, baseSize: newProd.baseSize||20, description: newProd.description||'', isNew: !!newProd.isNew, tags: newProd.tags ?? [], orderDeadline: newProd.orderDeadline, edition: newProd.edition, ...built }])
      logAction('product', `Добавлен товар «${newProd.name || 'без названия'}»`)
      setAddProd(false); setNewProd(EMPTY_PROD())
    }
  }

  // Массовый импорт товаров из текстового списка. Формат одной строки:
  //   Название | Серия | цены | размер(см) | описание
  // Цены: «3200/1900» → С покраской/Без покраски; «Стандарт:2500, В купальнике:2800» →
  // произвольные варианты; «2500» → один вариант. Фото добавляются позже в карточке.
  const runImport = () => {
    const lines = importText.split('\n').map(l => l.trim()).filter(Boolean)
    const created: Product[] = []
    const errors: string[] = []
    lines.forEach((line, i) => {
      const parts = line.split('|').map(s => s.trim())
      const name = parts[0]
      if (!name) { errors.push(`Строка ${i + 1}: нет названия`); return }
      const series = parts[1] || ''
      const priceSpec = parts[2] || ''
      const size = parseInt(parts[3]) || 20
      const description = parts[4] || ''
      let variants: ProductVariant[]
      if (priceSpec.includes(':')) {
        variants = priceSpec.split(',').map(seg => {
          const [vn, vp] = seg.split(':').map(s => s.trim())
          return { id: genVariantId(), name: vn || 'Вариант', price: parseInt(vp) || 0, images: [], cover: '' }
        })
      } else if (priceSpec.includes('/')) {
        const [a, b] = priceSpec.split('/').map(s => parseInt(s.trim()) || 0)
        variants = [
          { id: genVariantId(), name: 'С покраской', price: a, images: [], cover: '' },
          { id: genVariantId(), name: 'Без покраски', price: b, images: [], cover: '' },
        ]
      } else {
        variants = [{ id: genVariantId(), name: 'С покраской', price: parseInt(priceSpec) || 0, images: [], cover: '' }]
      }
      const built = buildFromVariants({ variants })
      created.push({ id: Date.now() + i, name, series, rating: 0, sold: 0, inStock: true, baseSize: size, description, ...built })
    })
    // Автоматически создаём недостающие разделы из указанных серий.
    const existing = new Set(sections.map(s => s.name.toLowerCase()))
    const newSecs: CatalogSection[] = []
    created.forEach((p, i) => {
      const key = p.series.trim().toLowerCase()
      if (p.series && !existing.has(key)) { existing.add(key); newSecs.push({ id: Date.now() + 100000 + i, name: p.series.trim(), emoji: '' }) }
    })
    if (newSecs.length) setSectionsCloud(prev => [...prev, ...newSecs])
    if (created.length) { setProductsCloud(prev => [...prev, ...created]); setImportText('') }
    setImportMsg(`Добавлено товаров: ${created.length}${newSecs.length ? ` · новых разделов: ${newSecs.length}` : ''}${errors.length ? ` · ошибок: ${errors.length} (${errors.slice(0, 3).join('; ')})` : ''}`)
  }

  // ── Быстрый импорт обложек (только владелец) ──────────────────
  // Владелец выбирает сразу пачку фото (по одной обложке на фигурку). Каждый файл
  // превращается в отдельный товар с названием-номером: если товаров уже N, новые
  // получают N+1, N+2, … Остальное владелец редактирует потом вручную.
  const photoImportRef = useRef<HTMLInputElement>(null)
  const [photoImporting, setPhotoImporting] = useState(false)
  const [photoImportProgress, setPhotoImportProgress] = useState<{ done: number; total: number } | null>(null)
  // Раздел для быстрого импорта: '' = без раздела (по умолчанию)
  const [photoImportSection, setPhotoImportSection] = useState('')
  const runPhotoImport = async (files: FileList | null) => {
    const list = Array.from(files ?? []).filter(f => f.type.startsWith('image/'))
    if (!list.length) return
    const section = photoImportSection.trim()
    setPhotoImporting(true); setPhotoImportProgress({ done: 0, total: list.length }); setImportMsg('')
    let startNum = 0
    setProductsCloud(prev => { startNum = prev.length; return prev })
    const created: Product[] = []
    const errors: string[] = []
    for (let i = 0; i < list.length; i++) {
      try {
        // Сильнее сжимаем обложки при массовом импорте: меньше сторона и качество —
        // это главный способ экономить egress-квоту (у каталога сотни фото).
        const compressed = await compressImage(list[i], 1000, 0.72)
        const url = await storage.upload(compressed)
        const variants: ProductVariant[] = [
          { id: genVariantId(), name: 'С покраской', price: 4000, images: [url], cover: url },
          { id: genVariantId(), name: 'Без покраски', price: 1500, images: [url], cover: url },
        ]
        const built = buildFromVariants({ variants })
        created.push({ id: Date.now() + i, name: String(startNum + i + 1), series: section, rating: 0, sold: 0, inStock: true, baseSize: 20, description: '', hidden: true, ...built })
      } catch (e) {
        errors.push(`Фото ${i + 1}: ${(e as Error).message || 'ошибка'}`)
      }
      setPhotoImportProgress({ done: i + 1, total: list.length })
    }
    if (created.length) setProductsCloud(prev => [...prev, ...created])
    setPhotoImporting(false); setPhotoImportProgress(null)
    setImportMsg(`Создано товаров из обложек: ${created.length} (скрыты от клиентов, отредактируйте и включите показ)${errors.length ? ` · ошибок: ${errors.length} (${errors.slice(0, 2).join('; ')})` : ''}`)
  }

  // Записать готовую ссылку в вариант: заменить фото по индексу либо добавить.
  const putImage = (isEdit: boolean, vid: string, url: string, replaceIdx?: number) => mutateVariant(isEdit, vid, v => {
    const arr = [...(v.images ?? [])]
    if (replaceIdx == null) arr.push(url); else arr[replaceIdx] = url
    return { ...v, images: arr, cover: v.cover || url }
  })

  const removeImage = (idx: number, isEdit: boolean, vid: string) => mutateVariant(isEdit, vid, v => {
    const arr = (v.images ?? []).filter((_, i) => i !== idx)
    return { ...v, images: arr, cover: (v.cover && arr.includes(v.cover)) ? v.cover : arr[0] }
  })

  // Переставить фото внутри варианта (перетаскивание вверх/вниз). Обложка привязана
  // к ссылке, поэтому после перестановки она сохраняется автоматически.
  const moveImage = (from: number, to: number, isEdit: boolean, vid: string) => mutateVariant(isEdit, vid, v => {
    const arr = [...(v.images ?? [])]
    if (from < 0 || to < 0 || from >= arr.length || to >= arr.length || from === to) return v
    const [moved] = arr.splice(from, 1)
    arr.splice(to, 0, moved)
    return { ...v, images: arr }
  })
  // Индекс перетаскиваемого фото и вариант, в котором идёт перетаскивание.
  const photoDrag = useRef<{ vid: string; idx: number } | null>(null)
  const [photoDragOver, setPhotoDragOver] = useState<{ vid: string; idx: number } | null>(null)

  // Назначить фото обложкой конкретного варианта.
  const setCover = (url: string, isEdit: boolean, vid: string) => patchVariant(isEdit, vid, { cover: url })

  // ── Редактор обрезки/зума ──
  // Всё, что добавляется (файл, ссылка, повторное редактирование), проходит через
  // окно кадрирования: админ двигает и приближает фото, выбирает квадрат, и уже
  // обрезанный вариант грузится в Storage. replaceIdx задаётся при редактировании.
  const [cropQueue, setCropQueue] = useState<CropJob[]>([])
  const [crop, setCrop] = useState({ x: 0, y: 0 })
  const [zoom, setZoom] = useState(1)
  const cropPixelsRef = useRef<PixelCrop | null>(null)
  const [imgUploading, setImgUploading] = useState(false)
  const cropJob = cropQueue[0] ?? null

  const enqueueCrop = (jobs: CropJob[]) => { if (jobs.length) { setCrop({ x: 0, y: 0 }); setZoom(1); setCropQueue(q => [...q, ...jobs]) } }
  const skipCrop = () => { setCrop({ x: 0, y: 0 }); setZoom(1); setCropQueue(q => q.slice(1)) }

  const applyCrop = async () => {
    if (!cropJob || !cropPixelsRef.current) return
    setImgUploading(true)
    try {
      const file = await getCroppedFile(cropJob.src, cropPixelsRef.current)
      const url = await storage.upload(file)
      putImage(cropJob.isEdit, cropJob.vid, url, cropJob.replaceIdx)
      skipCrop()
    } catch (err) {
      alert(`Не удалось обработать фото: ${(err as Error)?.message ?? 'ошибка'}`)
    } finally {
      setImgUploading(false)
    }
  }

  // Открыть кадрирование для уже добавленного фото (кнопка «✎» на карточке).
  const editImage = (idx: number, isEdit: boolean, vid: string, src: string) =>
    enqueueCrop([{ src, isEdit, vid, replaceIdx: idx }])

  // Загрузка с устройства — каждый выбранный файл ставится в очередь кадрирования.
  const imgFileRef = useRef<HTMLInputElement>(null)
  const uploadFieldRef = useRef<string>('')
  // Загрузка баннера — отдельный input, фото уходит в Storage лёгкой ссылкой.
  const bannerFileRef = useRef<HTMLInputElement>(null)
  const [bannerUploading, setBannerUploading] = useState(false)
  const bannerCfg = { ...INIT_BANNER, ...(banner ?? {}) }
  const uploadBanner = async (file: File | undefined) => {
    if (!file || !file.type.startsWith('image/')) return
    setBannerUploading(true)
    try { const compressed = await compressImage(file, 1280, 0.85); const url = await storage.upload(compressed); setBanner(b => ({ ...b, url })) }
    catch (err) { alert(`Не удалось загрузить баннер: ${(err as Error)?.message ?? 'ошибка'}`) }
    finally { setBannerUploading(false) }
  }
  const addImageFiles = (files: FileList | null, isEdit: boolean, vid: string) => {
    if (!files || files.length === 0) return
    const readers = Array.from(files)
      .filter(f => f.type.startsWith('image/'))
      .map(f => new Promise<CropJob>(resolve => {
        const r = new FileReader()
        r.onload = () => resolve({ src: String(r.result), isEdit, vid })
        r.readAsDataURL(f)
      }))
    Promise.all(readers).then(enqueueCrop)
  }

  const totalRevenue = orders.reduce((s,o) => s + (o.painted ? o.price : o.priceUnpainted), 0)

  // Сортировка клиентов: сперва по числу активных заказов (3 активных выше 1),
  // затем по «весу» клиента — всего заказов и потрачено за всё время, плюс бонусы
  // за поставленный аватар и наличие промокодов.
  // Схлопываем дубли клиентов по нормализованному логину (@doken62 == doken62),
  // оставляя самую «богатую» запись (с именем/аватаром/данными).
  const dedupClients = (() => {
    const byLogin = new Map<string, RegisteredUser>()
    for (const u of registeredUsers) {
      const key = normLogin(u.login)
      const prev = byLogin.get(key)
      if (!prev) { byLogin.set(key, u); continue }
      const weight = (x: RegisteredUser) =>
        (x.name ? 2 : 0) + (readProfile(profiles, x.login)?.avatarUrl ? 1 : 0) + orders.filter(o => o.userId === x.login).length
      byLogin.set(key, weight(u) > weight(prev) ? u : prev)
    }
    return Array.from(byLogin.values())
  })()
  const sortedClients = [...dedupClients].sort((a, b) => {
    const ordersOf = (login: string) => orders.filter(o => o.userId === login)
    const oa = ordersOf(a.login), ob = ordersOf(b.login)
    const activeA = oa.filter(o => o.status !== 'delivered').length
    const activeB = ob.filter(o => o.status !== 'delivered').length
    if (activeA !== activeB) return activeB - activeA
    const spent = (os: Order[]) => os.reduce((s, o) => s + (o.painted ? o.price : o.priceUnpainted), 0)
    const hasPromo = (login: string) => promocodes.some(p => !p.deleted && p.targetUser && p.targetUser.toLowerCase() === login.toLowerCase())
    const score = (login: string, os: Order[]) =>
      os.length * 100000 + spent(os) + (readProfile(profiles, login)?.avatarUrl ? 30000 : 0) + (hasPromo(login) ? 15000 : 0)
    return score(b.login, ob) - score(a.login, oa)
  })
  const crmTabs: Array<{ key: CRMTab; label: string; icon: IconName; badge?: number }> = [
    { key: 'dashboard', label: 'Аналитика', icon: 'grid' },
    { key: 'orders',    label: 'Заказы',    icon: 'document' },
    { key: 'neworder',  label: 'Новый',     icon: 'plus' },
    { key: 'payverify', label: 'Оплаты',    icon: 'check', badge: orders.filter(o => o.payStatus === 'awaiting').length },
    { key: 'roles',     label: 'Роли',      icon: 'users' },
    { key: 'products',  label: 'Товары',    icon: 'layers' },
    { key: 'sections',  label: 'Разделы',   icon: 'grid' },
    { key: 'home',      label: 'Главная',   icon: 'layers' },
    { key: 'users',     label: 'Клиенты',   icon: 'users' },
    { key: 'faq',       label: 'FAQ',       icon: 'question' },
    { key: 'materials', label: 'Материалы', icon: 'package' },
    { key: 'reviews',   label: 'Отзывы',    icon: 'star' },
    { key: 'notice',    label: 'Важное',    icon: 'bell' },
    { key: 'custom',    label: 'Индив.',    icon: 'star' },
    { key: 'promos',    label: 'Промокоды', icon: 'gift' },
    { key: 'loyalty',   label: 'Лояльность', icon: 'heart' },
    { key: 'payments',  label: 'Оплата',    icon: 'card' },
    { key: 'pubhub',    label: 'Публикации', icon: 'chat' },
    { key: 'logs',      label: 'Журнал',    icon: 'document' },
  ]

  // Порядок разделов, заданный владельцем. Неизвестные/новые ключи добавляем
  // в хвост в исходном порядке, чтобы ничего не пропало после обновлений.
  const orderedTabs = (() => {
    if (!crmOrder || !crmOrder.length) return crmTabs
    const byKey = new Map(crmTabs.map(t => [t.key, t]))
    const out: typeof crmTabs = []
    for (const k of crmOrder) { const t = byKey.get(k as CRMTab); if (t) { out.push(t); byKey.delete(k as CRMTab) } }
    for (const t of crmTabs) if (byKey.has(t.key)) out.push(t)
    return out
  })()

  // Сдвинуть раздел вверх (-1) или вниз (+1) и сохранить порядок в облако.
  const moveCrmTab = (key: string, dir: -1 | 1) => {
    const keys = orderedTabs.map(t => t.key as string)
    const i = keys.indexOf(key)
    const j = i + dir
    if (i < 0 || j < 0 || j >= keys.length) return
    ;[keys[i], keys[j]] = [keys[j], keys[i]]
    setCrmOrder(keys)
  }

  // Перенести раздел на другой рельс (левый ↔ правый). Только владелец.
  const toggleCrmSide = (key: string) => {
    setCrmLeft(prev => prev.includes(key) ? prev.filter(k => k !== key) : [...prev, key])
  }

  // Роли: модератор и редактор видят только разрешённый набор вкладок.
  const visibleTabs = allowedTabs ? orderedTabs.filter(t => allowedTabs.includes(t.key)) : orderedTabs
  const leftSet = new Set(crmLeft)
  const leftTabs = visibleTabs.filter(t => leftSet.has(t.key))
  const rightTabs = visibleTabs.filter(t => !leftSet.has(t.key))
  useEffect(() => {
    if (visibleTabs.length && !visibleTabs.some(t => t.key === crmTab)) setCrmTab(visibleTabs[0].key)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [allowedTabs])
  const tabAllowed = (k: CRMTab) => !allowedTabs || allowedTabs.includes(k)

  // Фото + обложка одного варианта (внутри карточки варианта).
  const variantPhotos = (isEdit: boolean, v: ProductVariant) => (
    <div>
      {(v.images ?? []).map((url, idx) => {
        const isCover = variantCover(v) === url
        const over = photoDragOver?.vid === v.id && photoDragOver.idx === idx
        const imgs = v.images ?? []
        return (
          <div key={idx}
            draggable
            onDragStart={() => { photoDrag.current = { vid: v.id, idx } }}
            onDragOver={e => { e.preventDefault(); if (photoDrag.current?.vid === v.id) setPhotoDragOver({ vid: v.id, idx }) }}
            onDrop={e => {
              e.preventDefault()
              const d = photoDrag.current
              if (d && d.vid === v.id) moveImage(d.idx, idx, isEdit, v.id)
              photoDrag.current = null; setPhotoDragOver(null)
            }}
            onDragEnd={() => { photoDrag.current = null; setPhotoDragOver(null) }}
            style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px', background: 'var(--bg-elevated)', borderRadius: '8px', padding: '6px 8px', border: over ? '1px solid var(--accent)' : (isCover ? '1px solid var(--accent)' : '1px solid transparent'), opacity: over ? 0.55 : 1, transition: 'opacity 0.15s' }}>
            {/* Ручка перетаскивания: тянуть вверх/вниз, чтобы поменять порядок фото. */}
            <div title="Перетащите, чтобы изменить порядок" style={{ display: 'flex', flexDirection: 'column', gap: '2px', flexShrink: 0, cursor: 'grab', opacity: 0.4, padding: '0 1px' }}>
              {[0,1,2].map(i => <div key={i} style={{ width: '11px', height: '2px', background: 'var(--text-secondary)', borderRadius: '2px' }} />)}
            </div>
            <img src={url} alt="" style={{ width: '36px', height: '36px', borderRadius: '6px', objectFit: 'cover', flexShrink: 0 }} onError={e => (e.currentTarget.style.display='none')} />
            <p style={{ color: 'var(--text-secondary)', fontSize: '10px', flex: 1, margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{isCover ? '⭐ ' : ''}{url.startsWith('data:') ? '📱 Фото с устройства' : url}</p>
            {/* Стрелки — запасной способ для тех, кому неудобно перетаскивать (в т.ч. на телефоне). */}
            <button onClick={() => moveImage(idx, idx - 1, isEdit, v.id)} disabled={idx === 0} title="Выше" style={{ background: 'none', border: 'none', cursor: idx === 0 ? 'default' : 'pointer', padding: '2px', flexShrink: 0, opacity: idx === 0 ? 0.25 : 1 }}><Icon name="chevron-up" size={13} color="var(--text-secondary)" /></button>
            <button onClick={() => moveImage(idx, idx + 1, isEdit, v.id)} disabled={idx === imgs.length - 1} title="Ниже" style={{ background: 'none', border: 'none', cursor: idx === imgs.length - 1 ? 'default' : 'pointer', padding: '2px', flexShrink: 0, opacity: idx === imgs.length - 1 ? 0.25 : 1 }}><Icon name="chevron-down" size={13} color="var(--text-secondary)" /></button>
            <button onClick={() => setCover(url, isEdit, v.id)} title="Сделать обложкой" style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px', flexShrink: 0, color: isCover ? 'var(--accent)' : 'var(--text-muted)', fontSize: '13px' }}>{isCover ? '★' : '☆'}</button>
            <button onClick={() => editImage(idx, isEdit, v.id, url)} title="Обрезать / приблизить" style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px', flexShrink: 0, color: 'var(--accent)', fontSize: '13px' }}>✎</button>
            <button onClick={() => removeImage(idx, isEdit, v.id)} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px', flexShrink: 0 }}><Icon name="close" size={13} color="var(--danger)" /></button>
          </div>
        )
      })}
      <button onClick={() => { uploadFieldRef.current = v.id; imgFileRef.current?.click() }} disabled={imgUploading}
        style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '9px', marginTop: '4px', background: 'var(--bg-elevated)', border: '1px dashed var(--accent)', borderRadius: '8px', color: 'var(--accent)', fontSize: '12px', fontWeight: 600, cursor: imgUploading ? 'default' : 'pointer', opacity: imgUploading ? 0.6 : 1 }}>
        <Icon name="camera" size={14} color="var(--accent)" /> {imgUploading ? 'Загрузка…' : 'Загрузить фото'}
      </button>
    </div>
  )

  // Редактор вариантов: у каждого своё название, цена и фото.
  const imgFormSection = (isEdit: boolean, src: Partial<Product>) => {
    const variants = src.variants ?? []
    return (
      <div style={{ marginBottom: '10px' }}>
        <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 8px', fontWeight: 500 }}>Варианты — у каждого своё название, цена и фото. Покупатель переключает их в карточке товара.</p>
        <input ref={imgFileRef} type="file" accept="image/*" multiple onChange={e => { addImageFiles(e.target.files, isEdit, uploadFieldRef.current); e.target.value = '' }} style={{ display: 'none' }} />
        {variants.map((v, vi) => (
          <div key={v.id} style={{ marginBottom: '12px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '12px', padding: '10px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '8px' }}>
              <span style={{ width: '20px', height: '20px', borderRadius: '6px', background: 'var(--accent-glow)', color: 'var(--accent)', fontSize: '10px', fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{vi + 1}</span>
              <input value={v.name} onChange={e => patchVariant(isEdit, v.id, { name: e.target.value })} placeholder="Название варианта"
                style={{ flex: 1, background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '8px', padding: '7px 10px', color: 'var(--text-primary)', fontSize: '12px', fontWeight: 600, outline: 'none', minWidth: 0 }} />
              <button onClick={() => { if (variants.length <= 1 || confirm(`Удалить вариант «${v.name}»?`)) removeVariant(isEdit, v.id) }} disabled={variants.length <= 1}
                style={{ background: 'none', border: 'none', cursor: variants.length <= 1 ? 'default' : 'pointer', padding: '4px', flexShrink: 0, opacity: variants.length <= 1 ? 0.3 : 1 }} title="Удалить вариант"><Icon name="trash" size={14} color="var(--danger)" /></button>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '6px' }}>
              <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: '6px', minWidth: 0 }}>
                <span style={{ color: 'var(--text-muted)', fontSize: '11px', flexShrink: 0 }}>Цена, ₽</span>
                <input type="number" inputMode="numeric" value={v.price || ''} placeholder="0" onChange={e => patchVariant(isEdit, v.id, { price: Number(e.target.value) })}
                  style={{ flex: 1, background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '8px', padding: '7px 10px', color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, outline: 'none', minWidth: 0 }} />
              </div>
              <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: '6px', minWidth: 0 }} title="Себестоимость — не видна клиентам, нужна для расчёта прибыли в отчётах">
                <span style={{ color: 'var(--text-muted)', fontSize: '11px', flexShrink: 0 }}>Себест., ₽</span>
                <input type="number" inputMode="numeric" value={v.cost || ''} placeholder="0" onChange={e => patchVariant(isEdit, v.id, { cost: Number(e.target.value) })}
                  style={{ flex: 1, background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '8px', padding: '7px 10px', color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, outline: 'none', minWidth: 0 }} />
              </div>
            </div>
            {(v.cost ?? 0) > 0 && (v.price ?? 0) > 0 && (
              <p style={{ color: v.price > (v.cost ?? 0) ? 'var(--success)' : 'var(--danger)', fontSize: '10.5px', margin: '0 0 8px', fontWeight: 600 }}>
                Прибыль с продажи: {(v.price - (v.cost ?? 0)).toLocaleString('ru-RU')} ₽ · маржа {Math.round((1 - (v.cost ?? 0) / v.price) * 100)}%
              </p>
            )}
            <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '0 0 6px' }}>Фото <span style={{ opacity: 0.7 }}>({(v.images ?? []).length}) · ★ — обложка</span></p>
            {variantPhotos(isEdit, v)}
          </div>
        ))}
        <button onClick={() => addVariant(isEdit)}
          style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', padding: '10px', background: 'var(--accent-glow)', border: '1px dashed var(--accent)', borderRadius: '10px', color: 'var(--accent)', fontSize: '12px', fontWeight: 700, cursor: 'pointer' }}>
          <Icon name="plus" size={14} color="var(--accent)" /> Добавить вариант
        </button>
      </div>
    )
  }

  // Форма товара — одна и та же для создания и редактирования. При правке
  // она рендерится прямо под карточкой, чтобы не листать в начало списка.
  const prodForm = (
      <div className="glass-card" style={{ padding: '12px', marginBottom: '10px' }}>
        <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: '0 0 10px' }}>{editProd ? 'Редактировать' : 'Новый товар'}</p>
        <FormField label="Название" value={editProd ? editProd.name : newProd.name||''} onChange={v => editProd ? setEditProd({...editProd,name:v}) : setNewProd(p=>({...p,name:v}))} />
        <div style={{ marginBottom: '10px' }}>
          <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 4px', fontWeight: 500 }}>Серия</p>
          <select
            value={editProd ? editProd.series : newProd.series || ''}
            onChange={e => editProd ? setEditProd({...editProd, series: e.target.value}) : setNewProd(p => ({...p, series: e.target.value}))}
            style={{ width: '100%', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '9px 12px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box', appearance: 'none' }}>
            <option value="">— Выберите серию —</option>
            {sections.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
          </select>
        </div>
        <FormField label="Описание" value={editProd ? editProd.description : newProd.description||''} onChange={v => editProd ? setEditProd({...editProd,description:v}) : setNewProd(p=>({...p,description:v}))} placeholder="Краткое описание фигурки..." />
        <FormField label="Базовый размер (см)" type="number" value={editProd ? editProd.baseSize : newProd.baseSize||20} onChange={v => editProd ? setEditProd({...editProd,baseSize:Number(v)}) : setNewProd(p=>({...p,baseSize:Number(v)}))} />
        {/* Окно приёма заказов — до дедлайна товар заказывают, после — уходит в «Архив» */}
        {(() => {
          const dl = editProd ? editProd.orderDeadline : newProd.orderDeadline
          const setDl = (ms: number | undefined) => editProd ? setEditProd({ ...editProd, orderDeadline: ms }) : setNewProd(p => ({ ...p, orderDeadline: ms }))
          // datetime-local хочет локальное время без таймзоны: YYYY-MM-DDTHH:mm
          const toInput = (ms?: number) => { if (!ms) return ''; const d = new Date(ms - new Date(ms).getTimezoneOffset() * 60000); return d.toISOString().slice(0, 16) }
          return (
            <div style={{ marginBottom: '10px' }}>
              <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 4px', fontWeight: 500 }}>Окно заказа — приём закрывается</p>
              <div style={{ display: 'flex', gap: '6px' }}>
                <input type="datetime-local" value={toInput(dl)}
                  onChange={e => setDl(e.target.value ? new Date(e.target.value).getTime() : undefined)}
                  style={{ flex: 1, minWidth: 0, background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '9px 12px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box', colorScheme: 'dark' }} />
                {dl ? <button className="btn-secondary" style={{ flexShrink: 0, padding: '0 14px' }} onClick={() => setDl(undefined)}>Сброс</button> : null}
              </div>
              <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '5px 0 0', lineHeight: 1.4 }}>Пусто — приём бессрочный. После дедлайна на карточке появится «Приём закрыт» и заказ будет недоступен.</p>
            </div>
          )
        })()}
        {/* Лимитированный тираж — нумерованные экземпляры (0 = без лимита) */}
        {(() => {
          const ed = (editProd ? editProd.edition : newProd.edition) ?? 0
          const sold = (editProd ? editProd.sold : newProd.sold) ?? 0
          return (
            <div style={{ marginBottom: '10px' }}>
              <FormField label="Лимит тиража, шт (0 — без лимита)" type="number" value={ed}
                onChange={v => { const n = Math.max(0, Math.floor(Number(v) || 0)); editProd ? setEditProd({ ...editProd, edition: n }) : setNewProd(p => ({ ...p, edition: n })) }} />
              {ed > 0 && (
                <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '-4px 0 0', lineHeight: 1.4 }}>Выпущено {Math.min(sold, ed)} из {ed} · осталось {Math.max(0, ed - sold)}. Каждый покупатель получает свой номер «№{Math.min(sold + 1, ed)} из {ed}».</p>
              )}
            </div>
          )
        })()}
        {/* Хештеги — для поиска и фильтров в каталоге */}
        <div style={{ marginBottom: '10px' }}>
          <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '0 0 4px', fontWeight: 500 }}>Хештеги</p>
          {curTags().length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px', marginBottom: '7px' }}>
              {curTags().map(t => (
                <span key={t} style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', padding: '4px 6px 4px 9px', borderRadius: '999px', background: 'var(--accent-2-wash)', border: '1px solid var(--accent-2)', color: 'var(--accent-2-hi)', fontSize: '11.5px', fontWeight: 600 }}>
                  #{t}
                  <button onClick={() => removeProdTag(t)} style={{ display: 'grid', placeItems: 'center', width: '15px', height: '15px', borderRadius: '50%', background: 'rgba(0,0,0,0.18)', border: 'none', cursor: 'pointer', color: 'inherit' }}><Icon name="close" size={9} color="currentColor" /></button>
                </span>
              ))}
            </div>
          )}
          <div style={{ display: 'flex', gap: '6px' }}>
            <input value={tagDraft} onChange={e => setTagDraft(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); addProdTag(tagDraft) } }}
              placeholder="напр. аниме, лимитка"
              style={{ flex: 1, background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: '10px', padding: '9px 12px', color: 'var(--text-primary)', fontSize: '13px', outline: 'none', boxSizing: 'border-box' }} />
            <button className="btn-secondary" style={{ flexShrink: 0, padding: '0 14px' }} onClick={() => addProdTag(tagDraft)}>Добавить</button>
          </div>
          {(() => {
            const cur = curTags().map(x => x.toLowerCase())
            const sugg = allProductTags(products).filter(t => !cur.includes(t.toLowerCase())).slice(0, 8)
            return sugg.length > 0 ? (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px', marginTop: '7px' }}>
                {sugg.map(t => (
                  <button key={t} onClick={() => addProdTag(t)} style={{ padding: '3px 9px', borderRadius: '999px', background: 'var(--bg-input)', border: '1px solid var(--border)', color: 'var(--text-secondary)', fontSize: '11px', fontWeight: 500, cursor: 'pointer' }}>#{t}</button>
                ))}
              </div>
            ) : null
          })()}
        </div>
        {/* Плашка NEW на миниатюре — включается вручную; в ряду «Новинки» появляется сама */}
        {(() => { const on = editProd ? !!editProd.isNew : !!newProd.isNew; return (
          <button onClick={() => editProd ? setEditProd({ ...editProd, isNew: !on }) : setNewProd(p => ({ ...p, isNew: !on }))}
            style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%', marginBottom: '10px', padding: '9px 12px', borderRadius: '10px', background: on ? 'rgba(56,132,255,0.12)' : 'var(--bg-input)', border: `1px solid ${on ? 'rgba(56,132,255,0.5)' : 'var(--border)'}`, cursor: 'pointer' }}>
            <span style={{ color: on ? '#4d9bff' : 'var(--text-secondary)', fontSize: '12px', fontWeight: 600 }}>Плашка «NEW» на миниатюре</span>
            <span style={{ width: '38px', height: '22px', borderRadius: '999px', background: on ? '#4d9bff' : 'var(--border)', position: 'relative', flexShrink: 0, transition: 'background 0.15s' }}>
              <span style={{ position: 'absolute', top: '2px', left: on ? '18px' : '2px', width: '18px', height: '18px', borderRadius: '50%', background: '#fff', transition: 'left 0.15s' }} />
            </span>
          </button>
        ) })()}
        {imgFormSection(!!editProd, editProd ? editProd : newProd)}
        <div style={{ display: 'flex', gap: '8px', marginTop: '4px' }}>
          <button className="btn-primary" style={{ flex: 1 }} onClick={saveProd}>Сохранить</button>
          <button className="btn-secondary" style={{ flex: 1 }} onClick={() => { setEditProd(null); setAddProd(false) }}>Отмена</button>
        </div>
      </div>
  )

  return { ...props, loyalty, setLoyalty, catalogFilters, setCatalogFilters, onAdjustPoints, moveCrmTab, toggleCrmSide, leftTabs, rightTabs, crmLeft, setCrmLeft, DEFAULT_BTN, EMPTY_MANUAL, EMPTY_PROD, EMPTY_PROMO, EMPTY_REVIEW, PUB_ASPECTS, addFaq, addImageFiles, addMat, addProd, addReviewPhotos, addSec, addVariant, allFavorites, allowedTabs, applyCrop, applyManualPhoto, applyPubCrop, banner, bannerCfg, bannerFileRef, bannerUploading, buildFromVariants, channelDraft, channelId, channelSaved, closePubEditor, createManualOrder, createReview, crmTab, crmTabs, crop, cropJob, cropPixelsRef, cropQueue, customOrder, deletePromo, dragIdx, dragOverIdx, editImage, editProd, editingFaq, editingSecId, editingSecName, enqueueCrop, expandedUser, faqDraft, faqSections, handleManualFile, handlePostFile, handlePublish, imgFileRef, imgFormSection, imgUploading, importMsg, importText, lastSeenTimes, manualCrop, manualFileRef, manualMsg, manualOrder, manualPhotoSrc, manualPixelsRef, manualUploading, manualZoom, materials, mutateVariant, newFaq, newMat, newProd, newSec, notice, onOrderCreate, onOrderDelete, onOrderStatus, onOrderTrack, onPayVerify, onProductsChange, onSectionsChange, onUserDelete, openPubEditor, orders, patchVariant, payEnabled, paySearch, postButton, postCaption, postFileRef, postMedia, postMsg, postPublishing, postUploading, prodForm, prodFilter, prodSort, products, profiles, promoForm, promocodes, pubAspect, pubJob, pubPixelsRef, pubPos, pubProgress, pubZoom, photoImportRef, photoImporting, photoImportProgress, photoImportSection, setPhotoImportSection, runPhotoImport, putImage, registeredUsers, removeImage, removeVariant, revDraft, revFileRef, revMsg, revUploading, reviews, roleForm, roleMsg, roles, runImport, saveChannel, saveProd, savePromo, sbpInfo, secDragIdx, secDragOverIdx, sections, setAddFaq, setAddMat, setAddProd, setAddSec, setBanner, setBannerUploading, setChannelDraft, setChannelId, setChannelSaved, setCover, setCrmTab, setCrop, setCropQueue, setCustomOrder, setDragOverIdx, setEditProd, setEditingFaq, setEditingSecId, setEditingSecName, setExpandedUser, setFaqDraft, setFaqSections, setImgUploading, setImportMsg, setImportText, setManualCrop, setManualMsg, setManualOrder, setManualPhotoSrc, setManualUploading, setManualZoom, setMaterials, setNewFaq, setNewMat, setNewProd, setNewSec, setNotice, setPayEnabled, setProdFilter, unhideAll, setPaySearch, setPostButton, setPostCaption, setPostMedia, setPostMsg, setPostPublishing, setPostUploading, setProdSort, setProducts, setProductsCloud, setPromoForm, setPromocodes, setPubAspect, setPubJob, setPubPos, setPubProgress, setPubZoom, setRevDraft, setRevMsg, setRevUploading, setReviews, setRoleForm, setRoleMsg, setRoles, setSbpInfo, setSecDragOverIdx, setSections, setSectionsCloud, setShowDoneOrders, setShowFavorites, setShowImport, setShowUserPromos, setZoom, showDoneOrders, showFavorites, showImport, showUserPromos, skipCrop, skipPubCrop, sortedClients, tabAllowed, totalRevenue, uploadBanner, uploadFieldRef, variantPhotos, visibleTabs, zoom }
}

export type CrmCtx = ReturnType<typeof useCrmState>
