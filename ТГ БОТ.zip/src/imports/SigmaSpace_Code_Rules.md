# SigmaSpace Code Rules

## General Rules

Do not: - rewrite backend - break APIs - remove features

------------------------------------------------------------------------

## Frontend Rules

Use: - reusable components - clean architecture - consistent naming -
scalable structure

------------------------------------------------------------------------

## Design Rules

Keep: - shared components - unified styles - animation system

------------------------------------------------------------------------

## Performance

Optimize: - images - animations - loading - mobile performance

------------------------------------------------------------------------

## Telegram

Preserve: - Telegram WebApp integration - authentication - existing
flows

------------------------------------------------------------------------

## Quality Standard

Code should be: - clean - maintainable - production ready
