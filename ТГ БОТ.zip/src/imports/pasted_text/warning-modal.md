You are a Senior Product Designer and UI Engineer specializing in premium Telegram Mini Apps.

Your task is to recreate the provided reference image as a production-ready Sigma Space interface inside Figma.

Do not redesign it.
Do not simplify it.
Do not create your own interpretation.

The reference image is the source of truth.

You must analyze every visual detail and reproduce the same design language.

==================================================
PROJECT CONTEXT
==================================================

Product name:
Sigma Space

Platform:
Telegram Mini App

Category:
Premium collectible figures marketplace + custom manufacturing ecosystem.

Brand feeling:
- futuristic
- cyberpunk
- premium
- dark luxury
- collectible culture
- technology mixed with craftsmanship

The application should feel like:
- a premium gaming interface
- a futuristic collector platform
- a luxury digital showroom

==================================================
MAIN SCREEN TYPE
==================================================

Create:

IMPORTANT WARNING / INTRODUCTION MODAL SCREEN

Purpose:
Before entering the catalog, users see important information about ordering collectible figures.

This is not a normal popup.
It is a premium full-screen experience layer.

==================================================
CANVAS
==================================================

Target device:

iPhone mobile format

Recommended:
390 x 844 px

Telegram Mini App environment.

Safe areas:
Respect iOS top and bottom areas.

==================================================
GLOBAL VISUAL STYLE
==================================================

Background:

Use:
#020409

Almost black futuristic background.

Add:

- subtle blue gradients
- dark atmospheric lighting
- cinematic shadows
- minimal futuristic particles

Do NOT make it colorful.

The design must feel expensive.

==================================================
COLOR SYSTEM
==================================================

Primary accent:

Sigma Blue:

#0066FF

Secondary:

Cyber Red:

#FF1F35

White:

#FFFFFF

Muted text:

#7B8498


Red is used only for:
- warnings
- important actions
- danger states

Blue is used for:
- navigation
- brand identity
- system elements

==================================================
TOP HEADER
==================================================

Create fixed Telegram-style header.

Left:

Sigma Space logo icon.

Logo:
- blue glowing square
- Sigma mathematical symbol inside
- minimal futuristic style

Next to logo:

Text:

Sigma Space

Subtitle:

авторские фигурки


Typography:
Clean modern sans-serif.

==================================================
TOP RIGHT
==================================================

Create:

Notification icon.

Profile avatar:

Circular futuristic avatar with blue border glow.

Small online/status indicator.

==================================================
BACKGROUND HERO
==================================================

Behind the warning card:

Show a dark collectible figure silhouette.

The figure should look like:

- futuristic samurai
- cyber warrior
- premium collectible statue

Visibility:
30-40% opacity.

It should feel like a background hologram.

Do not make it dominant.

==================================================
MAIN WARNING PANEL
==================================================

Create a large centered futuristic card.

Position:
Middle of screen.

Shape:

- rounded futuristic corners
- cyber frame
- thin blue metallic border
- glass effect
- dark transparent surface

Style:

Cyber UI panel from a premium game interface.

==================================================
WARNING ICON
==================================================

At the top center:

Create glowing warning triangle.

Style:

Red neon hologram.

Inside:
white exclamation mark.

Add:

- circular scanner ring
- red glow
- futuristic HUD details

==================================================
TITLE
==================================================

Large title:

ВАЖНО

Color:

Cyber Red

Font:

Bold futuristic.

Below:

ПЕРЕД ИСПОЛЬЗОВАНИЕМ

Color:

White

Smaller size.

==================================================
CONTENT CARDS
==================================================

Create four information blocks.

Each block:

Dark glass rectangle.

Border:

subtle red line.

Left:

futuristic red outline icon.

Right:

Text.

==================================================
BLOCK 1

Icon:
3D cube / package

Title:

Все фигурки коллекционные
под заказ.

Subtitle:

Срок изготовления 20–45 дней.


==================================================
BLOCK 2

Icon:
painting palette

Title:

Фигурки требуют бережного
обращения.

Subtitle:

Избегайте падений и ударов.


==================================================
BLOCK 3

Icon:
delivery truck

Title:

Доставка по всему миру.

Subtitle:

Срок зависит от вашего региона.


==================================================
BLOCK 4

Icon:
shield check

Title:

Возврат и обмен
не предусмотрены.

Subtitle:

Пожалуйста, ознакомьтесь со
всеми деталями.


==================================================
PRIMARY BUTTON
==================================================

Large bottom CTA.

Text:

Понятно, продолжить


Style:

Bright cyber red gradient.

Shape:

Rounded rectangle.

Add:

- glowing edges
- futuristic frame corners
- subtle animation-ready effect

This is the main action.

==================================================
SECONDARY ACTION
==================================================

Below button:

Text:

Больше не показывать


Color:

Gray.

No strong emphasis.

==================================================
BOTTOM NAVIGATION
==================================================

IMPORTANT:

Use the Sigma Space global navigation system.

It must stay identical on all screens.

Five items:

Каталог

Избранное

Sigma button

Заказы

Профиль


Style:

Dark glass navigation bar.

Active:

Blue glow.

Center Sigma button:

Main brand element.

No character head.

Only Sigma symbol.

==================================================
TYPOGRAPHY
==================================================

Use:

Inter / SF Pro / modern geometric sans-serif.

Hierarchy:

Large:
48-56 px

Headers:
28-36 px

Body:
16-18 px

Small:
13-14 px


==================================================
ANIMATION NOTES
==================================================

Prepare components for:

- warning icon pulse
- red glow breathing effect
- background figure parallax
- card appearing animation
- button hover/tap effect

==================================================
FIGMA STRUCTURE
==================================================

Create clean layers:

01 Background

02 Header

03 Hero Figure

04 Warning Modal

05 Information Cards

06 CTA Button

07 Bottom Navigation


Use components:

- Button component
- Card component
- Icon component
- Navigation component


==================================================
IMPORTANT RESTRICTIONS
==================================================

DO NOT:

- make it look like a normal ecommerce app
- use white backgrounds
- use cartoon style
- use excessive neon colors
- change the navigation
- remove cyber atmosphere
- simplify the HUD details


The final result must look like:

"Luxury Cyberpunk Collector Platform"

not:

"simple online store"


The reference image is the exact visual direction.
Recreate it with production quality.