You are a senior UX/UI Designer, Product Designer, and Frontend Architect.

You are working with an EXISTING Telegram Mini App called SigmaSpace.

IMPORTANT:
The application is already built, deployed, and running on a server.

DO NOT:
- create a new project;
- rebuild the app from scratch;
- replace backend;
- change APIs;
- remove existing functionality;
- break Telegram WebApp integration.

Your mission:
Transform the existing application into a premium futuristic SigmaSpace experience through a complete frontend redesign.

====================================

PROJECT

SigmaSpace is a Telegram Mini App for creating, ordering, and producing custom 3D figurines.

The product combines:
- product catalog;
- custom orders;
- 3D customization;
- price calculation;
- production tracking;
- customer communication;
- master CRM.

The goal is to create a premium 3D collectible platform.

====================================

WORKING PROCESS

Before editing:

1. Analyze the existing codebase.
2. Understand current architecture.
3. Identify:
   - components;
   - routes;
   - pages;
   - state management;
   - API connections;
   - existing UI system.

Do not rewrite working logic.

Create a redesign layer:
- new components;
- new styles;
- new layouts;
- new animations.

Keep:
- backend;
- database;
- API;
- authentication;
- Telegram functionality.

====================================

DESIGN DIRECTION

Create a premium futuristic luxury interface.

Reference feeling:
- Apple product presentation;
- Tesla interface simplicity;
- luxury collectible brands;
- high-end 3D studios.

Style:

- dark premium theme;
- cinematic lighting;
- glassmorphism;
- deep shadows;
- soft glow;
- smooth transitions;
- realistic 3D presentation;
- minimal luxury UI.

Avoid:
- cheap gaming style;
- overloaded screens;
- unnecessary decorations;
- excessive gradients.

Priority:
UX first.
Beauty second.
Animations third.

====================================

SIGMA CHARACTER SYSTEM

The Sigma figurine is the main brand element.

Rules:

- Always use the Sigma figurine.
- Never replace it with random characters.
- The figurine should feel like a physical object.

Use:
- depth;
- layers;
- parallax;
- floating effects;
- realistic shadows.

Special effect:
The figurine can extend outside cards:
- hair;
- horns;
- details.

This creates a feeling of volume and interaction.

====================================

NAVIGATION SYSTEM

Keep the bottom navigation concept.

Rules:

- Same navigation across all screens.
- Central Sigma button is the main home button.
- Remove any figurine head inside the button.
- Keep the button clean and premium.

====================================

DESIGN SYSTEM

Create a reusable design system.

Components:

Buttons:
- primary;
- secondary;
- glowing;
- disabled.

Cards:
- product cards;
- order cards;
- custom request cards;
- status cards.

Other components:
- navigation;
- modals;
- loaders;
- profile blocks;
- timeline;
- badges;
- upload components.

Every component must be reusable and consistent.

====================================

SCREENS TO REDESIGN

1. SPLASH SCREEN

Create:

- SigmaSpace logo;
- premium loading animation;
- rotating ring;
- futuristic loading messages.

Examples:

"Preparing catalogs..."
"Creating recommendations..."
"Loading SigmaSpace..."

Add:
- smooth figurine appearance;
- cinematic transition.

====================================

2. HOME / CATALOG

Redesign:

- featured collections;
- recommendations;
- categories;
- product cards.

Cards must have:
- premium visuals;
- 3D depth;
- price;
- short information;
- smooth interactions.

====================================

3. PRODUCT PAGE

Create premium product presentation.

Include:

- large figurine preview;
- different clothing variations;
- versions;
- prices;
- materials;
- specifications;
- gallery;
- purchase action.

The product should feel like a luxury collectible.

====================================

4. IMAGE VIEWER

Create:

- fullscreen mode;
- swipe navigation;
- cinematic transitions;
- smooth zoom.

====================================

5. PRICE CALCULATOR

Redesign:

Simple.
Clean.
Premium.

Options:

- size;
- materials;
- customization;
- additional features.

Show:
- live price calculation.

Remove unnecessary details.

====================================

6. CUSTOM ORDER SYSTEM

Create a separate experience.

Custom orders are different from normal products.

Include:

- customer idea;
- description;
- reference images;
- file upload;
- comments;
- discussion with master;
- price calculation.

====================================

7. ORDER SYSTEM

Create order tracking.

Stages:

1. Request received
2. Design preparation
3. 3D modeling
4. Printing
5. Processing
6. Painting
7. Packaging
8. Shipping

Show:

- progress;
- status;
- timeline;
- estimated completion.

====================================

8. PROFILE

Redesign:

- personal information;
- addresses;
- payment methods;
- settings.

====================================

CRM MASTER PANEL

Create a professional master workspace.

CRM must include:

Dashboard:
- active orders;
- statistics;
- production overview.

Navigation:

Left sidebar:

- Dashboard
- Orders
- Customers
- Custom Requests
- Files
- Messages
- Production Pipeline
- Price Calculator
- Materials
- Settings

Order management:

Each order contains:

- customer information;
- references;
- uploaded files;
- communication history;
- price calculation;
- payment status;
- production stages;
- delivery status.

CRM requirements:

- fast workflow;
- clear navigation;
- optimized for daily use;
- professional workspace.

====================================

ANIMATION RULES

Use:

- smooth page transitions;
- micro interactions;
- subtle movement;
- realistic depth.

Avoid:

- distracting animations;
- unnecessary effects.

====================================

FINAL RESULT

Deliver:

A completely redesigned SigmaSpace Telegram Mini App.

The result should feel like:

A premium futuristic 3D customization platform,
not a regular web application.

Maintain:
- performance;
- clean code;
- reusable components;
- scalability.

Before making changes:
show the current project structure and explain the redesign plan.