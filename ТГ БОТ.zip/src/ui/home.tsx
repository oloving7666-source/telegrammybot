import React, { useEffect, useState } from 'react'
import { type BoardStyle, AutoVideo, boardGlow, boardStyle, storageThumb } from '../shared'

/**
 * SigmaSpace — элементы главной страницы.
 * Палитра: чёрный фон, холодный неоновый фиолетовый как единственный акцент,
 * белый текст. Синего в интерфейсе нет — только как отблеск в свечении фона.
 */

/** Логотип Σ — зеркальные грани с неоновой подсветкой. */
export function SigmaLogo({ size = 64 }: { size?: number }) {
  return (
    <svg viewBox="0 0 64 64" width={size} height={size} aria-label="Sigma Space"
         style={{ filter: 'drop-shadow(0 0 14px var(--ss-brand-glow))', flexShrink: 0 }}>
      <defs>
        <linearGradient id="ss-logo-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="var(--ss-blue-hi, #4f8dff)" />
          <stop offset="52%" stopColor="var(--ss-brand)" />
          <stop offset="100%" stopColor="#4c1d95" />
        </linearGradient>
      </defs>
      <path d="M50 8H16l17 24-17 24h34" fill="none" stroke="url(#ss-logo-g)" strokeWidth="7"
            strokeLinecap="round" strokeLinejoin="round" />
      <path d="M50 8H16l17 24" fill="none" stroke="#d8b4fe" strokeWidth="2" strokeLinecap="round"
            strokeLinejoin="round" opacity="0.55" />
    </svg>
  )
}

/** Словесный знак: SIGMA белым, SPACE — разрядкой фиолетовым. */
export function SigmaWordmark() {
  return (
    <div style={{ lineHeight: 1 }}>
      <div style={{ color: '#fff', fontSize: 27, fontWeight: 300, letterSpacing: '0.30em' }}>SIGMA</div>
      <div style={{
        marginTop: 8, color: 'var(--ss-brand-hi)', fontSize: 14, fontWeight: 400,
        letterSpacing: '0.42em', textShadow: '0 0 12px var(--ss-brand-glow)',
      }}>SPACE</div>
    </div>
  )
}

/**
 * Верхний борд главной: логотип слева, фигурка справа, колокольчик в углу.
 * Фигурка растворяется в чёрном фоне — жёсткой границы у борда нет.
 */
export function HeroBoard({
  image, imageAlt = 'Коллекционная фигурка Sigma Space', height = 300,
  objectPosition = '50% 30%', scale = 1, notifications = 0, onBell, showBrand = true,
}: {
  image?: string
  imageAlt?: string
  height?: number
  objectPosition?: string
  scale?: number
  notifications?: number
  onBell?: () => void
  /** false — когда логотип уже есть в верхней панели приложения */
  showBrand?: boolean
}) {
  return (
    <header
      className="ss-aurora"
      style={{ position: 'relative', height, flexShrink: 0, overflow: 'hidden' }}
    >
      <BoardImg
        src={image} alt={imageAlt} objectPosition={objectPosition} scale={scale} eager
        mask="radial-gradient(118% 92% at 62% 34%, #000 42%, transparent 88%)"
      />
      {/* растворение в фон снизу */}
      <div style={{
        position: 'absolute', inset: 0, pointerEvents: 'none',
        background: 'linear-gradient(180deg, transparent 34%, rgba(5,6,10,0.55) 74%, var(--ss-void) 100%)',
      }} />

      {showBrand && <div style={{
        position: 'relative', height: '100%', display: 'flex', alignItems: 'flex-start',
        justifyContent: 'space-between', padding: '52px 20px 0',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <SigmaLogo />
          <SigmaWordmark />
        </div>

        <button
          onClick={onBell} aria-label="Уведомления" className="ss-press"
          style={{
            position: 'relative', width: 40, height: 40, borderRadius: '50%', flexShrink: 0,
            display: 'grid', placeItems: 'center', cursor: 'pointer',
            background: 'rgba(10,12,18,0.42)', border: '1px solid var(--ss-hairline-lo)',
            backdropFilter: 'blur(10px)', WebkitBackdropFilter: 'blur(10px)',
          }}
        >
          <svg viewBox="0 0 24 24" width={20} height={20} fill="none" stroke="#fff"
               strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
            <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
            <path d="M13.7 21a2 2 0 0 1-3.4 0" />
          </svg>
          {notifications > 0 && (
            <span style={{
              position: 'absolute', top: -3, right: -3, minWidth: 19, height: 19, padding: '0 5px',
              borderRadius: 'var(--ss-r-pill)', display: 'grid', placeItems: 'center',
              background: 'var(--ss-brand)', color: '#fff', fontSize: 11, fontWeight: 700,
              boxShadow: '0 0 12px -1px var(--ss-brand-glow)',
            }}>{notifications}</span>
          )}
        </button>
      </div>}
    </header>
  )
}

/** Пилюли разделов: активная — фиолетовая обводка и подсветка, не заливка. */
export function CategoryTabs({
  items, active, onSelect,
}: { items: string[]; active: string; onSelect: (v: string) => void }) {
  return (
    <div
      ref={el => { if (el) el.onwheel = e => { e.preventDefault(); el.scrollLeft += e.deltaY + e.deltaX } }}
      style={{
        display: 'flex', gap: 4, overflowX: 'auto', scrollbarWidth: 'none', flexShrink: 0,
        padding: '8px 10px', background: 'var(--top-bar-bg)',
        borderTop: '1px solid var(--ss-hairline-lo)', borderBottom: '1px solid var(--ss-hairline-lo)',
        backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)',
      }}
    >
      {items.map(it => {
        const on = it === active
        return (
          <button
            key={it} onClick={() => onSelect(it)} className="ss-press"
            style={{
              flexShrink: 0, padding: '9px 16px', borderRadius: 'var(--ss-r-sm)', cursor: 'pointer',
              fontFamily: 'inherit', fontSize: 13, fontWeight: on ? 620 : 500, whiteSpace: 'nowrap',
              color: on ? 'var(--ss-ink)' : 'var(--ss-ink-2)',
              background: on ? 'var(--ss-brand-wash)' : 'transparent',
              border: `1px solid ${on ? 'var(--ss-brand-edge)' : 'transparent'}`,
              boxShadow: on ? '0 0 18px -6px var(--ss-brand-glow)' : undefined,
              transition: 'color var(--ss-t-base) var(--ss-ease), background var(--ss-t-base) var(--ss-ease)',
            }}
          >{it}</button>
        )
      })}
    </div>
  )
}

/** Аккуратная заглушка-Σ на случай, если фон борда/баннера не загрузился —
 *  тот же приём, что и на карточках товара, чтобы не зиял пустой прямоугольник. */
function BoardFallback() {
  return (
    <div aria-hidden style={{
      position: 'absolute', inset: 0, display: 'grid', placeItems: 'center',
      background: 'radial-gradient(120% 90% at 62% 30%, #150c2b 0%, #0a0810 60%, #05060a 100%)',
    }}>
      <span style={{ fontSize: 46, fontWeight: 800, lineHeight: 1, color: 'var(--ss-brand-hi, #b79bff)', opacity: 0.5, textShadow: '0 0 26px var(--ss-brand-glow)' }}>Σ</span>
    </div>
  )
}

/** Фоновая картинка борда: превью из Storage, фолбэк на оригинал, затем Σ-заглушка.
 *  Σ-подложка отрисована всегда ПОД картинкой — поэтому пока фото грузится или
 *  если оно не загрузилось совсем, пользователь видит красивую заглушку, а не
 *  пустой прямоугольник. */
function BoardImg({ src, alt = '', objectPosition = 'right center', scale = 1, eager, mask }: {
  src?: string; alt?: string; objectPosition?: string; scale?: number; eager?: boolean; mask?: string
}) {
  const [err, setErr] = useState(false)
  useEffect(() => { setErr(false) }, [src])
  return (
    <>
      <BoardFallback />
      {src && !err && (
        <img
          key={src} src={storageThumb(src, 900)} alt={alt} decoding="async"
          {...(eager ? { fetchPriority: 'high' as const } : { loading: 'lazy' as const })}
          onError={e => { const el = e.currentTarget; if (!el.dataset.full) { el.dataset.full = '1'; el.src = src } else setErr(true) }}
          style={{
            position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover',
            objectPosition, transform: scale !== 1 ? `scale(${scale})` : undefined,
            ...(mask ? { maskImage: mask, WebkitMaskImage: mask } : null),
            animation: 'ss-fade var(--ss-t-scene) var(--ss-ease-out) both',
          }}
        />
      )}
    </>
  )
}

export type PromoSlide = {
  title: string
  subtitle?: string
  eyebrow?: string
  cta?: string
  image?: string
  video?: string
  style?: Partial<BoardStyle>
  onClick?: () => void
}

/** Промо-карусель: смена настроения композицией, палитра остаётся одна. */
export function PromoCarousel({ slides, interval = 6000 }: { slides: PromoSlide[]; interval?: number }) {
  const [i, setI] = useState(0)
  useEffect(() => {
    if (slides.length < 2) return
    const t = setInterval(() => setI(v => (v + 1) % slides.length), interval)
    return () => clearInterval(t)
  }, [slides.length, interval])

  const s = slides[Math.min(i, slides.length - 1)]
  if (!s) return null
  const st = boardStyle(s.style)
  const glow = boardGlow(st.glow)
  const showText = st.showText && (s.title || s.subtitle)

  return (
    <div
      className="ss-press"
      onClick={s.onClick}
      style={{
        position: 'relative', overflow: 'hidden', borderRadius: 'var(--ss-r-lg)',
        minHeight: 190, cursor: s.onClick ? 'pointer' : 'default',
        background: 'linear-gradient(135deg, #120c22 0%, #0a0810 58%, #05060a 100%)',
        border: `1px solid ${glow.border}`, boxShadow: glow.shadow,
      }}
    >
      {s.video ? (
        <AutoVideo
          key={s.video} src={s.video}
          style={{
            position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover',
            objectPosition: 'right center',
            animation: 'ss-fade var(--ss-t-scene) var(--ss-ease-out) both',
          }}
        />
      ) : (
        <BoardImg src={s.image} eager />
      )}
      {/* Затемнение слева — чтобы текст читался поверх фигурки, как на референсе */}
      {showText && (
        <div aria-hidden style={{
          position: 'absolute', inset: 0, pointerEvents: 'none',
          background: 'linear-gradient(90deg, rgba(6,5,12,0.94) 0%, rgba(6,5,12,0.82) 34%, rgba(6,5,12,0.42) 62%, transparent 84%)',
        }} />
      )}

      {(showText || (st.showCta && s.cta)) && (
        <div key={s.title} className="ss-rise" style={{
          position: 'relative', height: '100%', minHeight: 190, boxSizing: 'border-box',
          display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start',
          padding: '16px 12px 22px 12px', maxWidth: '90%',
        }}>
          {s.eyebrow && (
            <p style={{ margin: '0 0 5px', color: 'var(--ss-brand-hi)', fontSize: 8.5, fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', textShadow: '0 0 14px var(--ss-brand-glow)', textAlign: 'left' }}>{s.eyebrow}</p>
          )}
          {showText && (
            <>
              <h3 style={{ margin: 0, color: '#fff', fontSize: 16, fontWeight: 800, lineHeight: 1.08, letterSpacing: '-0.01em', whiteSpace: 'pre-line', textShadow: '0 2px 16px rgba(0,0,0,0.8)', textAlign: 'left' }}>{s.title}</h3>
              {s.subtitle && (
                <p style={{ margin: '6px 0 0', color: 'var(--ss-ink-2)', fontSize: 10.5, lineHeight: 1.4, whiteSpace: 'pre-line', maxWidth: 200, textAlign: 'left' }}>{s.subtitle}</p>
              )}
            </>
          )}
          {st.showCta && s.cta && (
            <span style={{
              display: 'inline-flex', alignItems: 'center', gap: 6, marginTop: showText ? 11 : 0,
              padding: '8px 13px', borderRadius: 11,
              background: 'var(--ss-brand-wash)', border: '1px solid var(--ss-brand-edge)',
              color: 'var(--ss-brand-hi)', fontSize: 11, fontWeight: 600,
              boxShadow: '0 0 26px -8px var(--ss-brand-glow)',
            }}>
              {s.cta}
              <svg viewBox="0 0 24 24" width={13} height={13} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h13M13 6l6 6-6 6" /></svg>
            </span>
          )}
        </div>
      )}

      {slides.length > 1 && (
        <div style={{
          position: 'absolute', bottom: 14, left: 0, right: 0,
          display: 'flex', justifyContent: 'center', gap: 7,
        }}>
          {slides.map((_, n) => (
            <button
              key={n} onClick={e => { e.stopPropagation(); setI(n) }} aria-label={`Слайд ${n + 1}`}
              style={{
                width: n === i ? 9 : 7, height: n === i ? 9 : 7, padding: 0, borderRadius: '50%',
                border: 'none', cursor: 'pointer',
                background: n === i ? 'var(--ss-brand-hi)' : 'var(--ss-ink-4)',
                boxShadow: n === i ? '0 0 10px var(--ss-brand-glow)' : undefined,
                transition: 'all var(--ss-t-base) var(--ss-ease)',
              }}
            />
          ))}
        </div>
      )}
    </div>
  )
}

/** Мелкие иконки-преимущества коллекции. */
function PerkGlyph({ kind }: { kind: 'sigma' | 'trophy' | 'shield' }) {
  const common = { width: 17, height: 17, viewBox: '0 0 24 24', fill: 'none', stroke: 'var(--ss-brand-hi)', strokeWidth: 1.7, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const }
  if (kind === 'trophy') return <svg {...common}><path d="M8 21h8M12 17v4M7 4h10v4a5 5 0 0 1-10 0V4zM7 6H4v2a3 3 0 0 0 3 3M17 6h3v2a3 3 0 0 1-3 3" /></svg>
  if (kind === 'shield') return <svg {...common}><path d="M12 3l7 3v5c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6l7-3zM9.5 12l1.8 1.8L15 10" /></svg>
  return <svg {...common} strokeWidth={2}><path d="M17 5H8l5 7-5 7h9" /></svg>
}

/** Борд коллекции — кинематографичная карточка в стиле «Cyber Collection». */
export function CollectionBoard({
  title, subtitle, eyebrow, cta, image, style, height = 300, index, total, onClick,
}: {
  title: string; subtitle?: string; eyebrow?: string; cta?: string; image?: string
  style?: Partial<BoardStyle>; height?: number; index?: number; total?: number; onClick?: () => void
}) {
  const st = boardStyle(style)
  const glow = boardGlow(st.glow)
  const lines = (title || '').split('\n')
  const pad = (n?: number) => (n != null && n < 10 ? `0${n}` : `${n ?? ''}`)
  return (
    <button
      onClick={onClick} className="ss-press ss-lift-hover"
      style={{
        position: 'relative', width: '100%', height, padding: 0, textAlign: 'left',
        borderRadius: 'var(--ss-r-lg)', overflow: 'hidden', cursor: onClick ? 'pointer' : 'default',
        border: `1px solid ${glow.border}`, boxShadow: glow.shadow, fontFamily: 'inherit',
        background: 'linear-gradient(135deg, #120c22 0%, #0a0810 58%, #05060a 100%)',
      }}
    >
      <BoardImg src={image} />
      {/* Затемнение слева под текст */}
      <div aria-hidden style={{ position: 'absolute', inset: 0, pointerEvents: 'none', background: 'linear-gradient(90deg, rgba(6,5,12,0.95) 0%, rgba(6,5,12,0.85) 34%, rgba(6,5,12,0.45) 62%, transparent 86%)' }} />
      {/* Угловые «технические» акценты */}
      <span aria-hidden style={{ position: 'absolute', top: 12, right: 12, width: 34, height: 34, borderTop: '1.5px solid var(--ss-brand-edge)', borderRight: '1.5px solid var(--ss-brand-edge)', borderRadius: '0 8px 0 0', opacity: 0.7 }} />
      <span aria-hidden style={{ position: 'absolute', bottom: 12, left: 12, width: 34, height: 34, borderBottom: '1.5px solid var(--ss-brand-edge)', borderLeft: '1.5px solid var(--ss-brand-edge)', borderRadius: '0 0 0 8px', opacity: 0.5 }} />

      <div className="ss-rise" style={{ position: 'relative', height: '100%', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', padding: '18px 18px 16px', maxWidth: '86%' }}>
        {/* Брендовая строка сверху */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
          <span style={{ display: 'grid', placeItems: 'center', width: 30, height: 30, borderRadius: 8, border: '1px solid var(--ss-brand-edge)', background: 'var(--ss-brand-wash)', color: 'var(--ss-brand-hi)' }}>
            <svg viewBox="0 0 24 24" width={13} height={13} fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round"><path d="M17 5H8l5 7-5 7h9" /></svg>
          </span>
          <span style={{ color: 'var(--ss-ink-2)', fontSize: 10.5, fontWeight: 700, letterSpacing: '0.28em', textTransform: 'uppercase' }}>{eyebrow || 'SIGMA SPACE'}</span>
        </div>

        {/* Заголовок: первая строка белая, остальные — фиолетовые */}
        <div style={{ marginTop: 14 }}>
          {lines.map((ln, k) => (
            <h3 key={k} style={{ margin: 0, fontSize: 28, fontWeight: 800, lineHeight: 1.02, letterSpacing: '-0.01em', textTransform: 'uppercase', color: k === 0 ? '#fff' : 'var(--ss-brand-hi)', textShadow: k === 0 ? '0 2px 14px rgba(0,0,0,0.7)' : '0 0 22px var(--ss-brand-glow)' }}>{ln}</h3>
          ))}
        </div>

        {subtitle && (
          <p style={{ margin: '11px 0 0', color: 'var(--ss-ink-2)', fontSize: 13, lineHeight: 1.45, whiteSpace: 'pre-line', maxWidth: 240 }}>{subtitle}</p>
        )}

        {st.showCta && cta && (
          <span style={{ display: 'inline-flex', alignSelf: 'flex-start', alignItems: 'center', gap: 9, marginTop: 16, padding: '12px 20px', borderRadius: 13, background: 'var(--ss-brand-wash)', border: '1px solid var(--ss-brand-edge)', color: 'var(--ss-brand-hi)', fontSize: 13.5, fontWeight: 600, boxShadow: '0 0 24px -8px var(--ss-brand-glow)' }}>
            {cta}
            <svg viewBox="0 0 24 24" width={16} height={16} fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h13M13 6l6 6-6 6" /></svg>
          </span>
        )}

        <div style={{ flex: 1 }} />

        {/* Преимущества */}
        <div style={{ display: 'flex', gap: 16 }}>
          {([['sigma', 'Авторские\nдизайны'], ['trophy', 'Премиальное\nкачество'], ['shield', 'Ограниченные\nтиражи']] as const).map(([kind, label]) => (
            <span key={kind} style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
              <span style={{ display: 'grid', placeItems: 'center', width: 30, height: 30, borderRadius: 9, border: '1px solid var(--ss-hairline-lo)', background: 'var(--ss-glass-1)' }}><PerkGlyph kind={kind} /></span>
              <span style={{ color: 'var(--ss-ink-3)', fontSize: 9.5, lineHeight: 1.2, whiteSpace: 'pre-line', fontWeight: 500 }}>{label}</span>
            </span>
          ))}
        </div>

        {/* Прогресс-индикатор коллекций */}
        {index != null && total != null && total > 1 && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 14 }}>
            <span style={{ color: '#fff', fontSize: 12, fontWeight: 700, letterSpacing: '0.05em' }}>{pad(index)}</span>
            <span style={{ position: 'relative', flex: 1, maxWidth: 120, height: 2, borderRadius: 1, background: 'var(--ss-ink-4)' }}>
              <span style={{ position: 'absolute', left: 0, top: 0, height: '100%', width: `${(index / total) * 100}%`, borderRadius: 1, background: 'var(--ss-brand-hi)', boxShadow: '0 0 8px var(--ss-brand-glow)' }} />
            </span>
            <span style={{ color: 'var(--ss-ink-3)', fontSize: 12, fontWeight: 700, letterSpacing: '0.05em' }}>{pad(total)}</span>
          </div>
        )}
      </div>
    </button>
  )
}

/** Плитка преимущества: крупная контурная иконка, шеврон справа. */
export function PerkTile({
  icon, title, text, onClick,
}: { icon: React.ReactNode; title: string; text: React.ReactNode; onClick?: () => void }) {
  return (
    <button
      onClick={onClick} className="ss-press ss-lift-hover"
      style={{
        display: 'flex', alignItems: 'center', gap: 10, width: '100%', textAlign: 'left',
        padding: '13px 11px', borderRadius: 'var(--ss-r-md)', cursor: onClick ? 'pointer' : 'default',
        fontFamily: 'inherit',
        background: 'linear-gradient(150deg, var(--ss-glass-2), var(--ss-glass-1))',
        border: '1px solid var(--ss-hairline-lo)', boxShadow: 'var(--ss-e2), var(--ss-lift)',
      }}
    >
      <span style={{ display: 'inline-flex', flexShrink: 0, color: 'var(--ss-brand-hi)',
                     filter: 'drop-shadow(0 0 10px var(--ss-brand-glow))' }}>{icon}</span>
      <span style={{ flex: 1, minWidth: 0 }}>
        <span style={{ display: 'block', color: 'var(--ss-ink)', fontSize: 13.5, fontWeight: 620, lineHeight: 1.2 }}>{title}</span>
        <span style={{ display: 'block', marginTop: 4, color: 'var(--ss-ink-3)', fontSize: 11, lineHeight: 1.35 }}>{text}</span>
      </span>
      <svg viewBox="0 0 24 24" width={14} height={14} fill="none" stroke="var(--ss-ink-3)"
           strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0 }}>
        <path d="M9 5l7 7-7 7" />
      </svg>
    </button>
  )
}
