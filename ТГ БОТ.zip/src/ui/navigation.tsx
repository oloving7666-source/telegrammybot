import React from 'react'

/**
 * SigmaSpace UI — навигация.
 * Нижний бар постоянен на всех экранах клиентской части, сайдбар — только CRM.
 */

export type NavItem = {
  key: string
  label: React.ReactNode
  icon: React.ReactNode
  badge?: number | string
}

/**
 * Нижняя навигация: стекло, мягкая подсветка, по центру — портальная
 * Σ-кнопка. Внутри кнопки только символ, без головы фигурки.
 */
export function BottomNav({
  items, active, onSelect, onHome, homeActive = false,
}: {
  /** Ровно 4 пункта: два слева, два справа от центральной кнопки. */
  items: [NavItem, NavItem, NavItem, NavItem]
  active: string
  onSelect: (key: string) => void
  onHome: () => void
  homeActive?: boolean
}) {
  const left = items.slice(0, 2)
  const right = items.slice(2)

  const cell = (it: NavItem) => {
    const on = active === it.key
    return (
      <button
        key={it.key}
        onClick={() => onSelect(it.key)}
        className="ss-press"
        style={{
          flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
          padding: '8px 2px', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'inherit',
          color: on ? 'var(--ss-brand-hi)' : 'var(--ss-ink-4)',
          transition: 'color var(--ss-t-base) var(--ss-ease)',
        }}
      >
        <span style={{ position: 'relative', display: 'inline-flex' }}>
          {it.icon}
          {it.badge != null && (
            <span style={{
              position: 'absolute', top: -5, right: -8, minWidth: 15, height: 15, padding: '0 4px',
              borderRadius: 'var(--ss-r-pill)', display: 'grid', placeItems: 'center',
              background: 'var(--ss-brand)', color: '#fff', fontSize: 9.5, fontWeight: 700,
              boxShadow: '0 0 10px -2px var(--ss-brand-glow)',
            }}>{it.badge}</span>
          )}
        </span>
        <span style={{ fontSize: 10, fontWeight: on ? 650 : 500, letterSpacing: '0.01em' }}>{it.label}</span>
      </button>
    )
  }

  return (
    <nav
      style={{
        position: 'relative', display: 'flex', alignItems: 'flex-end',
        padding: '6px 10px calc(6px + env(safe-area-inset-bottom, 0px))',
        background: 'linear-gradient(180deg, rgba(10,12,18,0.72), rgba(5,6,10,0.94))',
        borderTop: '1px solid var(--ss-hairline-lo)',
        backdropFilter: 'blur(22px) saturate(1.4)',
        WebkitBackdropFilter: 'blur(22px) saturate(1.4)',
        boxShadow: '0 -12px 34px rgba(0,0,0,0.55)',
      }}
    >
      {left.map(cell)}

      {/* Центральный портал */}
      <div style={{ width: 74, flexShrink: 0, display: 'grid', placeItems: 'center' }}>
        <button
          onClick={onHome}
          aria-label="Главная"
          className="ss-press"
          style={{
            position: 'relative', width: 58, height: 58, marginTop: -26, borderRadius: '50%',
            display: 'grid', placeItems: 'center', cursor: 'pointer',
            background: 'radial-gradient(circle at 50% 34%, var(--ss-slate), var(--ss-void))',
            border: '1px solid var(--ss-brand-edge)',
            boxShadow: homeActive
              ? '0 10px 28px rgba(0,0,0,0.6), 0 0 34px -6px var(--ss-brand-glow), inset 0 1px 0 rgba(255,255,255,0.10)'
              : '0 10px 24px rgba(0,0,0,0.55), 0 0 20px -10px var(--ss-brand-glow), inset 0 1px 0 rgba(255,255,255,0.08)',
          }}
        >
          {/* вращающееся энергокольцо */}
          <svg viewBox="0 0 58 58" width="58" height="58" style={{
            position: 'absolute', inset: 0,
            animation: 'ss-ring-spin 14s linear infinite', transformOrigin: '50% 50%',
          }}>
            <circle cx="29" cy="29" r="27" fill="none" stroke="var(--ss-brand)" strokeWidth="1.4"
                    strokeDasharray="26 12" strokeLinecap="round" opacity="0.75" />
          </svg>
          <SigmaMark size={25} />
        </button>
      </div>

      {right.map(cell)}
    </nav>
  )
}

/** Символ Σ — единственное содержимое центральной кнопки. */
export function SigmaMark({ size = 24, color = 'var(--ss-brand-hi)' }: { size?: number; color?: string }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} aria-hidden
         style={{ position: 'relative', filter: `drop-shadow(0 0 7px ${color})` }}>
      <path d="M18 4H6.4l6.1 8-6.1 8H18" fill="none" stroke={color} strokeWidth="2.1"
            strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

/* ──────────────────────────────  CRM sidebar  ───────────────────────────── */

/** Боковая навигация рабочего пространства мастера. */
export function Sidebar({
  items, active, onSelect, header, footer, width = 214, collapsed = false, style, side = 'left',
  editing = false, onMove, onSide, emptyHint,
}: {
  items: NavItem[]
  active: string
  onSelect: (key: string) => void
  header?: React.ReactNode
  footer?: React.ReactNode
  width?: number
  /** С какой стороны экрана стоит рельс — от этого зависит разделительная линия. */
  side?: 'left' | 'right'
  /** Узкий рельс: только иконки, подписи скрыты (мобильная CRM). */
  collapsed?: boolean
  style?: React.CSSProperties
  /** Режим перестановки разделов (только владелец, только в раскрытом виде). */
  editing?: boolean
  /** Сдвинуть раздел вверх/вниз в режиме перестановки. */
  onMove?: (key: string, dir: -1 | 1) => void
  /** Перенести раздел на другой рельс (левый ↔ правый) в режиме перестановки. */
  onSide?: (key: string) => void
  /** Подсказка, когда рельс пуст (в раскрытом виде). */
  emptyHint?: React.ReactNode
}) {
  const reordering = editing && !collapsed
  return (
    <aside
      data-surface="crm"
      style={{
        width, flexShrink: 0, display: 'flex', flexDirection: 'column',
        background: 'linear-gradient(180deg, var(--ss-graphite), var(--ss-void))',
        [side === 'right' ? 'borderLeft' : 'borderRight']: '1px solid var(--ss-hairline-lo)',
        padding: collapsed ? '14px 6px 12px' : '18px 12px 14px',
        ...style,
      }}
    >
      {header}
      <div style={{ flex: 1, minHeight: 0, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 2, marginTop: 14 }}>
        {items.length === 0 && !collapsed && emptyHint && (
          <div style={{ padding: '14px 10px', textAlign: 'center', color: 'var(--ss-ink-4)', fontSize: 11, lineHeight: 1.5 }}>{emptyHint}</div>
        )}
        {items.map((it, i) => {
          const on = active === it.key
          if (reordering) {
            const arrow = (dir: -1 | 1, disabled: boolean) => (
              <button
                onClick={() => !disabled && onMove?.(it.key, dir)}
                disabled={disabled}
                aria-label={dir === -1 ? 'Вверх' : 'Вниз'}
                className="ss-press"
                style={{
                  width: 26, height: 26, flexShrink: 0, display: 'grid', placeItems: 'center',
                  borderRadius: 'var(--ss-r-sm)', cursor: disabled ? 'default' : 'pointer',
                  background: disabled ? 'transparent' : 'var(--ss-blue-wash)',
                  border: '1px solid var(--ss-hairline-lo)', color: disabled ? 'var(--ss-ink-4)' : 'var(--ss-blue-ink)',
                  fontSize: 13, fontWeight: 700, opacity: disabled ? 0.4 : 1,
                }}
              >{dir === -1 ? '↑' : '↓'}</button>
            )
            return (
              <div
                key={it.key}
                style={{
                  display: 'flex', alignItems: 'center', gap: 8, width: '100%',
                  padding: '7px 8px', borderRadius: 'var(--ss-r-sm)',
                  background: 'var(--ss-blue-wash)', border: '1px dashed var(--ss-blue-edge)',
                }}
              >
                <span style={{ display: 'inline-flex', flexShrink: 0, opacity: 0.85 }}>{it.icon}</span>
                <span style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 12.5, fontWeight: 560, color: 'var(--ss-ink-2)' }}>{it.label}</span>
                {onSide && (
                  <button
                    onClick={() => onSide(it.key)}
                    aria-label={side === 'right' ? 'На левый рельс' : 'На правый рельс'}
                    title={side === 'right' ? 'Перенести влево' : 'Перенести вправо'}
                    className="ss-press"
                    style={{
                      width: 26, height: 26, flexShrink: 0, display: 'grid', placeItems: 'center',
                      borderRadius: 'var(--ss-r-sm)', cursor: 'pointer',
                      background: 'var(--ss-blue-wash)', border: '1px solid var(--ss-hairline-lo)',
                      color: 'var(--ss-blue-ink)', fontSize: 13, fontWeight: 700,
                    }}
                  >{side === 'right' ? '⇤' : '⇥'}</button>
                )}
                {arrow(-1, i === 0)}
                {arrow(1, i === items.length - 1)}
              </div>
            )
          }
          return (
            <button
              key={it.key}
              onClick={() => onSelect(it.key)}
              title={typeof it.label === 'string' ? it.label : undefined}
              aria-label={typeof it.label === 'string' ? it.label : undefined}
              className="ss-press"
              style={{
                position: 'relative',
                display: 'flex', alignItems: 'center', justifyContent: collapsed ? 'center' : 'flex-start',
                gap: 9, width: '100%',
                padding: collapsed ? '9px 0' : '9px 10px', borderRadius: 'var(--ss-r-sm)', cursor: 'pointer',
                fontFamily: 'inherit', fontSize: 12.5, fontWeight: on ? 640 : 520, textAlign: 'left',
                color: on ? '#fff' : 'var(--ss-ink-2)',
                background: on ? 'linear-gradient(180deg, var(--ss-brand-hi), var(--ss-brand-lo))' : 'transparent',
                border: `1px solid ${on ? 'var(--ss-brand-edge)' : 'transparent'}`,
                boxShadow: on ? '0 6px 18px -6px var(--ss-brand-glow), inset 0 1px 0 rgba(255,255,255,0.18)' : undefined,
                transition: 'background var(--ss-t-base) var(--ss-ease), color var(--ss-t-base) var(--ss-ease)',
              }}
            >
              <span style={{ display: 'inline-flex', flexShrink: 0, opacity: on ? 1 : 0.8 }}>{it.icon}</span>
              {!collapsed && (
                <span style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {it.label}
                </span>
              )}
              {it.badge != null && (
                <span style={{
                  ...(collapsed ? { position: 'absolute' as const, top: 2, right: 2 } : null),
                  minWidth: collapsed ? 14 : 20, padding: collapsed ? '0 4px' : '1px 6px',
                  borderRadius: 'var(--ss-r-pill)', textAlign: 'center',
                  fontSize: collapsed ? 9 : 11, fontWeight: 700,
                  background: on ? 'rgba(255,255,255,0.22)' : 'var(--ss-brand-wash)',
                  color: on ? '#fff' : 'var(--ss-brand-ink)',
                }}>{it.badge}</span>
              )}
            </button>
          )
        })}
      </div>
      {footer && <div style={{ marginTop: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>{footer}</div>}
    </aside>
  )
}
