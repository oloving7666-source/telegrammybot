// ── Журнал действий администраторов ───────────────────────────────
// Лёгкий синглтон: держим последние действия в памяти, дублируем в
// localStorage (мгновенный старт) и подтягиваем/сохраняем в облако (kv),
// чтобы журнал был общим для всех устройств владельца и персонала.
import { kv } from "./api"

export interface LogEntry {
  id: string
  ts: number
  actor: string          // логин администратора (@doken62, @moder …)
  action: string         // человекочитаемое описание
  kind: LogKind          // категория для иконки/цвета
}

export type LogKind =
  | "order" | "product" | "promo" | "review"
  | "user" | "loyalty" | "system"

const CAP = 300                    // храним максимум последних N записей
const LS_KEY = "actionLogs"
const KV_KEY = "actionLogs"

let entries: LogEntry[] = []
let actor = "@—"
let loaded = false
const listeners = new Set<() => void>()
let saveTimer: ReturnType<typeof setTimeout> | null = null

function emit() { for (const fn of listeners) fn() }

function persistLocal() {
  try { localStorage.setItem(LS_KEY, JSON.stringify(entries)) } catch { /* приватный режим */ }
}

function persistCloud() {
  if (saveTimer) clearTimeout(saveTimer)
  saveTimer = setTimeout(() => { kv.set(KV_KEY, entries).catch(() => { /* офлайн/квота */ }) }, 800)
}

/** Кто сейчас в панели — проставляется в каждую новую запись. */
export function setLogActor(login: string | null | undefined) {
  actor = login && login.trim() ? login : "@—"
}

/** Первичная загрузка журнала: сперва локально, потом мягко из облака. */
export function initLogs() {
  if (loaded) return
  loaded = true
  try {
    const raw = localStorage.getItem(LS_KEY)
    if (raw) entries = JSON.parse(raw)
  } catch { /* пусто */ }
  emit()
  kv.get(KV_KEY).then((cloud: LogEntry[] | null) => {
    if (Array.isArray(cloud) && cloud.length) {
      // Объединяем локальные и облачные по id, свежие — сверху.
      const byId = new Map<string, LogEntry>()
      for (const e of [...cloud, ...entries]) byId.set(e.id, e)
      entries = Array.from(byId.values()).sort((a, b) => b.ts - a.ts).slice(0, CAP)
      persistLocal(); emit()
    }
  }).catch(() => { /* офлайн */ })
}

/** Записать действие в журнал. */
export function logAction(kind: LogKind, action: string) {
  const entry: LogEntry = {
    id: `lg${Date.now().toString(36)}${Math.floor(Math.random() * 1e4).toString(36)}`,
    ts: Date.now(), actor, action, kind,
  }
  entries = [entry, ...entries].slice(0, CAP)
  persistLocal(); persistCloud(); emit()
}

export function getLogs(): LogEntry[] { return entries }

export function clearLogs() {
  entries = []
  persistLocal()
  kv.set(KV_KEY, []).catch(() => { /* офлайн */ })
  emit()
}

/** Подписка для React-компонента (useSyncExternalStore). */
export function subscribeLogs(fn: () => void): () => void {
  listeners.add(fn)
  return () => { listeners.delete(fn) }
}
