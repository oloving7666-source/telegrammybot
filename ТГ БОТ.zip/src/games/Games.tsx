import { useEffect, useMemo, useRef, useState } from "react"

/**
 * SigmaSpace — Игровая зона («Сигма-Аркада»).
 *
 * ДВЕ ВАЛЮТЫ:
 *  • Коины 🪙 — игровая «топливная» валюта. Ими играют в мини-игры. Их дают
 *    бесплатно: ежедневное колесо, ежедневная бесплатная ставка, приглашение
 *    друга и выигрыши. Сами по себе коины ничего не стоят.
 *  • Баллы Σ (в ₽) — реальная скидка на заказ. Копятся с покупок и обменом
 *    коинов по курсу CONVERT_RATE:1. Их тоже можно ставить в играх (риск на
 *    реальную скидку), выигрыш возвращается той же валютой, что и ставка.
 *
 * АНТИ-АБУЗ (почему нельзя «нафармить» бесплатный товар):
 *  1) HOUSE_EDGE < 1 — на дистанции игры уводят баланс в минус, бесконечно
 *     расти нельзя.
 *  2) Обмен только пачками по CONVERT_RATE коинов и с дневным лимитом
 *     DAILY_CONVERT_CAP — большой скидочный «фонтан» невозможен.
 *  3) Скидка баллами всё равно ограничена лимитом лояльности на стороне заказа
 *     (баллы покрывают лишь часть суммы) — бесплатных товаров не бывает.
 *  4) Бесплатные коины выдаются раз в 24 часа — пассивный доход ограничен.
 *
 * СТИМУЛ ВОЗВРАЩАТЬСЯ / РЕКЛАМИРОВАТЬ: ежедневное колесо и бесплатная ставка
 * дают повод заходить каждый день, а крупный коин-бонус за друга — повод
 * делиться ссылкой.
 *
 * ⚠️ ЧЕСТНОСТЬ: сейчас RNG считается на клиенте. Раз коины конвертируются в
 * скидку, финальную версию логики (розыгрыш + атомарное изменение баланса)
 * нужно перенести в Supabase edge function; клиент оставит только анимацию.
 */

const HOUSE_EDGE = 0.96
const MIN_BET = 10
const CONVERT_RATE = 100 // 100 коинов = 1 балл (₽ скидки)
const DAILY_MS = 24 * 60 * 60 * 1000
const clampInt = (n: number) => Math.max(0, Math.round(n))
const fmt = (n: number) => n.toLocaleString("ru")

type Cur = "coins" | "points"
type Bank = {
  cur: Cur; setCur: (c: Cur) => void
  bal: number; setBal: (fn: (b: number) => number) => void
  coins: number; points: number
}

/* ═══════════════════════ ИКОНКИ (SVG) ═══════════════════════ */
function IcoBack() {
  return <svg viewBox="0 0 24 24" width={20} height={20} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 5l-7 7 7 7" /></svg>
}
function IcoChevron() {
  return <svg viewBox="0 0 24 24" width={16} height={16} fill="none" stroke="var(--ss-ink-3)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 5l7 7-7 7" /></svg>
}
/** Балл Σ — фиолетово-синяя монета (реальная скидка). */
function IcoPoint({ size = 15 }: { size?: number }) {
  const id = useMemo(() => "pt-g-" + Math.random().toString(36).slice(2, 7), [])
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" aria-hidden>
      <defs><linearGradient id={id} x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#c4a2ff" /><stop offset="100%" stopColor="#6aa0ff" /></linearGradient></defs>
      <circle cx="12" cy="12" r="9" fill={`url(#${id})`} stroke="var(--ss-brand-hi)" strokeWidth="1.2" />
      <text x="12" y="16.2" textAnchor="middle" fontSize="11" fontWeight="800" fill="#fff" fontFamily="Georgia, serif">Σ</text>
    </svg>
  )
}
/** Коин 🪙 — золотая игровая монета со звездой. */
function IcoCoin({ size = 15 }: { size?: number }) {
  const id = useMemo(() => "cn-g-" + Math.random().toString(36).slice(2, 7), [])
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" aria-hidden>
      <defs><linearGradient id={id} x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#ffe08a" /><stop offset="100%" stopColor="#f5a623" /></linearGradient></defs>
      <circle cx="12" cy="12" r="9" fill={`url(#${id})`} stroke="#ffcf5c" strokeWidth="1.2" />
      <circle cx="12" cy="12" r="6.3" fill="none" stroke="rgba(120,70,0,0.25)" strokeWidth="0.8" />
      <path d="M12 7.6l1.2 2.6 2.8.3-2.1 1.9.6 2.8L12 13.8 9.5 15.2l.6-2.8-2.1-1.9 2.8-.3z" fill="#8a5300" />
    </svg>
  )
}
const CurIco = ({ cur, size }: { cur: Cur; size?: number }) => cur === "coins" ? <IcoCoin size={size} /> : <IcoPoint size={size} />
function IcoRocket({ size = 26, crashed }: { size?: number; crashed?: boolean }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" aria-hidden>
      <path d="M12 2c3.4 1.4 5 4.6 5 8.2 0 2.1-.7 4-2 5.6l-.5.6-.5-2.9h-4l-.5 2.9-.5-.6C7.2 14.2 6.5 12.3 6.5 10.2 6.5 6.6 8.1 3.4 12 2Z" fill={crashed ? "#6b7280" : "var(--ss-brand-hi)"} stroke={crashed ? "#4b5563" : "#e9dcff"} strokeWidth="0.8" />
      <circle cx="12" cy="9.4" r="2" fill="#0a0810" stroke="#7de3ff" strokeWidth="1" />
      {!crashed && <path d="M9 17c-.6 1.4-.6 2.8 0 4M12 17.5c-.7 1.8-.7 3.2 0 5M15 17c.6 1.4.6 2.8 0 4" stroke="#ff9a3d" strokeWidth="1.4" strokeLinecap="round" />}
    </svg>
  )
}
function IcoGem({ size = 22 }: { size?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" aria-hidden>
      <path d="M6 3h12l3.2 5L12 21 2.8 8 6 3Z" fill="#7de3ff" stroke="#c9f6ff" strokeWidth="0.8" />
      <path d="M6 3l3 5-6.2 0M18 3l-3 5 6.2 0M9 8h6M12 21l-3-13M12 21l3-13" stroke="rgba(10,20,30,0.4)" strokeWidth="0.7" />
    </svg>
  )
}
function IcoBomb({ size = 22 }: { size?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" aria-hidden>
      <circle cx="10.5" cy="14" r="6.2" fill="#2b2f3a" stroke="#4b5563" strokeWidth="0.8" />
      <circle cx="8.5" cy="12" r="1.6" fill="rgba(255,255,255,0.28)" />
      <path d="M15 8.6l1.7-1.7" stroke="#9aa3b2" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M18.3 5.3l1.2-1.2 1 1-1.2 1.2 1.1.2-.8 1.1-1.3-.2-.2 1.3-1.1-.8.2-1.1-1.1-.2.8-1.1 1.3.2Z" fill="#ff7a3d" />
    </svg>
  )
}
function IcoDie({ n, size = 26 }: { n: number; size?: number }) {
  const pips: Record<number, [number, number][]> = {
    1: [[12, 12]], 2: [[8, 8], [16, 16]], 3: [[8, 8], [12, 12], [16, 16]],
    4: [[8, 8], [16, 8], [8, 16], [16, 16]], 5: [[8, 8], [16, 8], [12, 12], [8, 16], [16, 16]],
    6: [[8, 7], [16, 7], [8, 12], [16, 12], [8, 17], [16, 17]],
  }
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" aria-hidden>
      <rect x="3" y="3" width="18" height="18" rx="4.5" fill="#f4efff" stroke="#c9b8ff" strokeWidth="0.8" />
      {(pips[n] || pips[1]).map(([x, y], i) => <circle key={i} cx={x} cy={y} r="1.7" fill="#4a2f8f" />)}
    </svg>
  )
}
function IcoTower({ size = 24 }: { size?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" aria-hidden>
      <path d="M7 21V8l2-2V3h6v3l2 2v13H7Z" fill="var(--ss-brand-hi)" stroke="#e9dcff" strokeWidth="0.8" />
      <path d="M10 9h4v3h-4zM10 14h4v3h-4z" fill="#0a0810" />
      <path d="M9 3h6" stroke="#7de3ff" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  )
}
function IcoWheel({ size = 24 }: { size?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" aria-hidden>
      <circle cx="12" cy="12" r="9" fill="#150c2b" stroke="var(--ss-brand-hi)" strokeWidth="1.4" />
      <path d="M12 3v18M3 12h18M5.6 5.6l12.8 12.8M18.4 5.6L5.6 18.4" stroke="var(--ss-brand-hi)" strokeWidth="1" opacity="0.7" />
      <circle cx="12" cy="12" r="2.2" fill="#7de3ff" />
    </svg>
  )
}
function IcoGift({ size = 22 }: { size?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" aria-hidden>
      <rect x="4" y="9" width="16" height="12" rx="2" fill="var(--ss-brand-hi)" stroke="#e9dcff" strokeWidth="0.7" />
      <rect x="3" y="6.5" width="18" height="3.5" rx="1.2" fill="#7de3ff" />
      <path d="M12 6.5V21" stroke="#0a0810" strokeWidth="1.4" />
      <path d="M12 6.5C10.5 3.5 7 3.8 7.6 6c.4 1.5 3 .8 4.4.5Zm0 0c1.5-3 5-2.7 4.4-.5-.4 1.5-3 .8-4.4.5Z" fill="#ffcf5c" stroke="#8a5300" strokeWidth="0.4" />
    </svg>
  )
}

/* ═══════════════════════ ПАРТИКЛЫ ═══════════════════════ */
function Burst({ color = "var(--ss-brand-hi)", n = 16, spread = 90 }: { color?: string; n?: number; spread?: number }) {
  const parts = useMemo(() => Array.from({ length: n }).map(() => {
    const a = Math.random() * Math.PI * 2
    const d = spread * (0.4 + Math.random() * 0.6)
    return { dx: Math.cos(a) * d, dy: Math.sin(a) * d, s: 3 + Math.random() * 5, delay: Math.random() * 0.1 }
  }), [n, spread])
  return (
    <div aria-hidden style={{ position: "absolute", left: "50%", top: "50%", pointerEvents: "none", zIndex: 6 }}>
      {parts.map((p, i) => (
        <span key={i} className="ss-burst-p" style={{ width: p.s, height: p.s, marginLeft: -p.s / 2, marginTop: -p.s / 2, background: color, color, ["--dx" as string]: `${p.dx}px`, ["--dy" as string]: `${p.dy}px`, animationDelay: `${p.delay}s` } as React.CSSProperties} />
      ))}
    </div>
  )
}

/* ═══════════════════════ ОБЩИЕ UI-ДЕТАЛИ ═══════════════════════ */
function useNow(ms = 1000) {
  const [now, setNow] = useState(() => Date.now())
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), ms); return () => clearInterval(t) }, [ms])
  return now
}
const hhmmss = (ms: number) => {
  const s = Math.max(0, Math.floor(ms / 1000))
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`
}

function CurrencySwitch({ bank }: { bank: Bank }) {
  return (
    <div style={{ display: "flex", gap: 8 }}>
      {(["coins", "points"] as Cur[]).map(c => {
        const active = bank.cur === c
        const val = c === "coins" ? bank.coins : bank.points
        return (
          <button key={c} onClick={() => bank.setCur(c)} className="ss-press"
            style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 7, padding: "9px 10px", borderRadius: 12, cursor: "pointer", fontSize: 13, fontWeight: 800, background: active ? "var(--ss-brand-wash)" : "var(--ss-glass-1)", border: `1px solid ${active ? "var(--ss-brand-edge)" : "var(--ss-hairline-lo)"}`, color: active ? "var(--ss-ink)" : "var(--ss-ink-3)" }}>
            <CurIco cur={c} size={16} />
            <span>{c === "coins" ? "Коины" : "Баллы"}</span>
            <span style={{ opacity: 0.7, fontWeight: 700 }}>{fmt(val)}</span>
          </button>
        )
      })}
    </div>
  )
}

function BetControls({ bet, setBet, max, cur, disabled }: { bet: number; setBet: (n: number) => void; max: number; cur: Cur; disabled?: boolean }) {
  const set = (n: number) => setBet(Math.max(MIN_BET, Math.min(max, Math.round(n))))
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 8, padding: "10px 12px", borderRadius: 14, background: "var(--ss-glass-1)", border: "1px solid var(--ss-hairline-lo)" }}>
        <CurIco cur={cur} size={16} />
        <input type="number" inputMode="numeric" value={bet} disabled={disabled}
          onChange={e => set(Number(e.target.value) || MIN_BET)}
          style={{ flex: 1, minWidth: 0, background: "none", border: "none", color: "var(--ss-ink)", fontSize: 16, fontWeight: 700, outline: "none" }} />
      </div>
      {([["½", () => set(bet / 2)], ["×2", () => set(bet * 2)], ["MAX", () => set(max)]] as [string, () => void][]).map(([lbl, fn]) => (
        <button key={lbl} onClick={fn} disabled={disabled} className="ss-press"
          style={{ padding: "10px 12px", borderRadius: 12, background: "var(--ss-glass-2)", border: "1px solid var(--ss-hairline-lo)", color: "var(--ss-ink-2)", fontSize: 12, fontWeight: 700, cursor: "pointer" }}>
          {lbl}
        </button>
      ))}
    </div>
  )
}

function PlayButton({ onClick, disabled, children, tone = "brand" }: { onClick: () => void; disabled?: boolean; children: React.ReactNode; tone?: "brand" | "cash" }) {
  const bg = disabled ? "var(--ss-glass-2)" : tone === "cash" ? "linear-gradient(135deg, #34d399, #059669)" : "var(--accent-grad)"
  const col = disabled ? "var(--ss-ink-3)" : tone === "cash" ? "#04150e" : "#fff"
  const shadow = disabled ? "none" : tone === "cash" ? "0 10px 28px -8px rgba(52,211,153,0.6)" : "0 10px 28px -8px var(--ss-brand-glow)"
  return (
    <button onClick={onClick} disabled={disabled} className="ss-press"
      style={{ padding: "16px", borderRadius: 16, border: "none", cursor: disabled ? "default" : "pointer", background: bg, color: col, fontSize: 16, fontWeight: 800, opacity: disabled ? 0.55 : 1, boxShadow: shadow }}>
      {children}
    </button>
  )
}
function ResetButton({ onClick }: { onClick: () => void }) {
  return <button onClick={onClick} className="ss-press" style={{ padding: "16px", borderRadius: 16, border: "1px solid var(--ss-hairline)", cursor: "pointer", background: "var(--ss-glass-2)", color: "var(--ss-ink)", fontSize: 16, fontWeight: 800 }}>Играть снова</button>
}
const hint = (t: string) => <p style={{ margin: 0, textAlign: "center", color: "var(--ss-ink-4)", fontSize: 11, lineHeight: 1.5 }}>{t}</p>

/* ═══════════════════════ РАКЕТКА (Crash, авто-цикл) ═══════════════════════ */
function genCrash(): number {
  const r = Math.random()
  if (r < 0.025) return 1
  return Math.max(1.01, Math.floor((HOUSE_EDGE / (1 - r)) * 100) / 100)
}
const crashColor = (m: number) => m < 1.4 ? "var(--ss-bad)" : m < 2.5 ? "var(--ss-brand-hi)" : m < 6 ? "#7de3ff" : "#ffb347"

// История раундов сохраняется и «доигрывается» офлайн: пока приложение закрыто,
// ракетка условно продолжает летать, поэтому при заходе уже видна свежая история.
const CRASH_KEY = "ss.crash.history"
const ROUND_MS = 18000
function loadCrashHistory(): number[] {
  try {
    const raw = localStorage.getItem(CRASH_KEY)
    const now = Date.now()
    let hist: number[] = [], last = now
    if (raw) { const p = JSON.parse(raw); if (Array.isArray(p.h)) hist = p.h; if (typeof p.t === "number") last = p.t }
    if (hist.length === 0) { hist = Array.from({ length: 24 }, genCrash); last = now - ROUND_MS }
    const missed = Math.min(24, Math.floor((now - last) / ROUND_MS))
    if (missed > 0) hist = [...Array.from({ length: missed }, genCrash), ...hist].slice(0, 24)
    saveCrashHistory(hist)
    return hist
  } catch { return Array.from({ length: 24 }, genCrash) }
}
function saveCrashHistory(h: number[]) {
  try { localStorage.setItem(CRASH_KEY, JSON.stringify({ h, t: Date.now() })) } catch { /* noop */ }
}

function CrashGame({ bank }: { bank: Bank }) {
  const { bal, setBal, cur } = bank
  const BET_MS = 12000, HOLD_MS = 2800
  const [bet, setBet] = useState(Math.min(50, Math.max(MIN_BET, bal)))
  const [phase, setPhase] = useState<"betting" | "flying" | "crashed">("betting")
  const [mult, setMult] = useState(1)
  const [countdown, setCountdown] = useState(BET_MS)
  const [history, setHistory] = useState<number[]>(() => loadCrashHistory())
  const [placed, setPlaced] = useState(false)
  const [cashedAt, setCashedAt] = useState<number | null>(null)
  const [lastWin, setLastWin] = useState<number | null>(null)
  const [autoCash, setAutoCash] = useState(0)
  const [fx, setFx] = useState(0)

  const raf = useRef<number>(0)
  const phaseRef = useRef(phase); phaseRef.current = phase
  const placedRef = useRef(placed); placedRef.current = placed
  const cashedRef = useRef(cashedAt); cashedRef.current = cashedAt
  const betRef = useRef(bet); betRef.current = bet
  const autoRef = useRef(autoCash); autoRef.current = autoCash
  const crashAt = useRef(genCrash())
  const t0 = useRef(performance.now())
  const maxBet = Math.max(MIN_BET, bal)

  useEffect(() => {
    const loop = (t: number) => {
      const el = t - t0.current
      const ph = phaseRef.current
      if (ph === "betting") {
        setCountdown(Math.max(0, BET_MS - el))
        if (el >= BET_MS) { t0.current = t; crashAt.current = genCrash(); setPhase("flying"); setMult(1) }
      } else if (ph === "flying") {
        const s = el / 1000
        const m = Math.exp(0.085 * s * (1 + s * 0.28))
        if (m >= crashAt.current) { const cp = crashAt.current; setMult(cp); setPhase("crashed"); setHistory(h => { const nh = [cp, ...h].slice(0, 24); saveCrashHistory(nh); return nh }); t0.current = t }
        else { setMult(m); const ac = autoRef.current; if (ac >= 1.1 && placedRef.current && !cashedRef.current && m >= ac) finishCash(ac) }
      } else if (el >= HOLD_MS) { t0.current = t; setPhase("betting"); setCountdown(BET_MS); setPlaced(false); setCashedAt(null); setLastWin(null) }
      raf.current = requestAnimationFrame(loop)
    }
    raf.current = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf.current)
  }, [])

  const place = () => { if (phase === "betting" && !placed && bet <= bal && bet >= MIN_BET) { setBal(b => b - bet); setPlaced(true) } }
  const unplace = () => { if (phase === "betting" && placed) { setBal(b => b + betRef.current); setPlaced(false) } }
  const finishCash = (atMult: number) => {
    if (!placedRef.current || cashedRef.current) return
    cashedRef.current = atMult
    const win = Math.round(betRef.current * atMult)
    setBal(b => b + win); setCashedAt(atMult); setLastWin(win - betRef.current); setFx(f => f + 1)
  }
  const cashOut = () => { if (phaseRef.current === "flying") finishCash(mult) }
  const color = phase === "crashed" ? "var(--ss-bad)" : cashedAt ? "var(--ss-ok)" : "var(--ss-brand-hi)"
  const px = Math.min(84, 8 + mult * 14), py = Math.min(80, 6 + mult * 13)

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      <CurrencySwitch bank={bank} />
      <div style={{ display: "flex", gap: 6, overflowX: "auto", padding: "2px 0" }}>
        {history.length === 0 && <span style={{ color: "var(--ss-ink-4)", fontSize: 11 }}>История раундов появится здесь…</span>}
        {history.map((m, i) => (
          <span key={i} style={{ flexShrink: 0, padding: "4px 9px", borderRadius: 999, fontSize: 11.5, fontWeight: 800, color: crashColor(m), background: "var(--ss-glass-2)", border: `1px solid ${crashColor(m)}33` }}>{m.toFixed(2)}×</span>
        ))}
      </div>
      <div className={phase === "crashed" ? "ss-shake" : undefined} style={{ position: "relative", height: 232, borderRadius: 20, overflow: "hidden", border: "1px solid var(--ss-hairline-lo)", background: "radial-gradient(120% 90% at 50% 120%, rgba(124,58,237,0.22), transparent 60%), linear-gradient(180deg, #0b0714, #05060a)" }}>
        <div aria-hidden style={{ position: "absolute", inset: 0, opacity: 0.35, backgroundImage: "linear-gradient(var(--ss-hairline-lo) 1px, transparent 1px), linear-gradient(90deg, var(--ss-hairline-lo) 1px, transparent 1px)", backgroundSize: "34px 34px", maskImage: "radial-gradient(80% 80% at 50% 60%, #000 40%, transparent 100%)" }} />
        {phase !== "betting" && (
          <>
            <div aria-hidden style={{ position: "absolute", left: 0, bottom: 0, width: `${Math.min(94, 12 + mult * 16)}%`, height: `${Math.min(88, 8 + mult * 15)}%`, background: `linear-gradient(60deg, transparent, ${phase === "crashed" ? "rgba(240,82,79,0.5)" : "rgba(168,85,247,0.5)"})`, clipPath: "polygon(0 100%, 100% 0, 100% 100%)" }} />
            <div aria-hidden style={{ position: "absolute", left: `${px}%`, bottom: `${py}%`, transform: phase === "crashed" ? "rotate(38deg) scale(0.85)" : "rotate(38deg)", filter: phase === "crashed" ? "none" : "drop-shadow(0 0 12px var(--ss-brand-glow))" }}>
              <IcoRocket size={34} crashed={phase === "crashed"} />
            </div>
          </>
        )}
        <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", pointerEvents: "none" }}>
          <div style={{ textAlign: "center", position: "relative" }}>
            {fx > 0 && cashedAt && <Burst key={fx} color="#34d399" spread={110} />}
            {phase === "betting" ? (
              <>
                <div style={{ fontSize: 44, fontWeight: 900, color: "var(--ss-brand-hi)", lineHeight: 1 }}>{(countdown / 1000).toFixed(1)}с</div>
                <div style={{ marginTop: 8, color: "var(--ss-ink-3)", fontSize: 12, fontWeight: 600 }}>{placed ? "Ставка принята — ждём старт" : "Приём ставок"}</div>
              </>
            ) : (
              <>
                <div style={{ fontSize: 52, fontWeight: 900, color, textShadow: `0 0 30px ${color}`, letterSpacing: "-0.02em", lineHeight: 1 }}>{mult.toFixed(2)}×</div>
                {phase === "crashed" && <div style={{ marginTop: 6, color: cashedAt ? "var(--ss-ok)" : "var(--ss-bad)", fontSize: 13, fontWeight: 700 }}>{cashedAt ? `Успел на ${cashedAt.toFixed(2)}×` : placed ? `Улетела! −${bet}` : "Улетела"}</div>}
                {phase === "flying" && cashedAt && lastWin !== null && <div style={{ marginTop: 6, color: "var(--ss-ok)", fontSize: 13, fontWeight: 700 }}>Забрано +{lastWin}</div>}
              </>
            )}
          </div>
        </div>
      </div>
      {phase === "flying" && placed && !cashedAt ? (
        <PlayButton onClick={cashOut} tone="cash">Забрать {Math.round(bet * mult)}</PlayButton>
      ) : phase === "betting" ? (
        <>
          <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 14, background: "var(--ss-glass-1)", border: "1px solid var(--ss-hairline-lo)" }}>
            <span style={{ color: "var(--ss-ink-3)", fontSize: 12.5, fontWeight: 700, flexShrink: 0 }}>Авто-вывод</span>
            <div style={{ display: "flex", gap: 5 }}>
              {[1.5, 2, 3, 5].map(v => (
                <button key={v} onClick={() => setAutoCash(a => a === v ? 0 : v)} className="ss-press" style={{ padding: "5px 9px", borderRadius: 9, fontSize: 12, fontWeight: 800, cursor: "pointer", border: `1px solid ${autoCash === v ? "var(--ss-brand-edge)" : "var(--ss-hairline-lo)"}`, background: autoCash === v ? "var(--ss-brand-wash)" : "var(--ss-glass-2)", color: autoCash === v ? "var(--ss-brand-hi)" : "var(--ss-ink-3)" }}>{v}×</button>
              ))}
            </div>
            <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 4 }}>
              <input type="number" inputMode="decimal" min={1.1} step={0.1} value={autoCash || ""} placeholder="выкл" onChange={e => { const n = parseFloat(e.target.value); setAutoCash(isNaN(n) ? 0 : Math.max(0, n)) }} style={{ width: 58, padding: "6px 8px", borderRadius: 9, border: "1px solid var(--ss-hairline-lo)", background: "var(--ss-void)", color: "var(--ss-ink)", fontSize: 13, fontWeight: 800, textAlign: "center", fontVariantNumeric: "tabular-nums" }} />
              <span style={{ color: "var(--ss-ink-4)", fontSize: 12, fontWeight: 800 }}>×</span>
            </div>
          </div>
          <BetControls bet={bet} setBet={setBet} max={maxBet} cur={cur} disabled={placed} />
          {placed ? (
            <button onClick={unplace} className="ss-press" style={{ padding: "16px", borderRadius: 16, border: "1px solid var(--ss-bad)", background: "rgba(240,82,79,0.12)", color: "var(--ss-bad)", fontSize: 16, fontWeight: 800, cursor: "pointer" }}>Отменить ставку</button>
          ) : (
            <PlayButton onClick={place} disabled={bet > bal || bal < MIN_BET}>{bal < MIN_BET ? "Недостаточно средств" : `Поставить ${bet} на след. раунд`}</PlayButton>
          )}
        </>
      ) : (
        <button disabled className="ss-press" style={{ padding: "16px", borderRadius: 16, border: "1px solid var(--ss-hairline-lo)", background: "var(--ss-glass-2)", color: "var(--ss-ink-3)", fontSize: 15, fontWeight: 800, opacity: 0.7 }}>
          {phase === "flying" && !placed ? "Раунд идёт — жди приёма ставок" : cashedAt ? "Забрано ✓" : "Следующий раунд скоро…"}
        </button>
      )}
      {hint("Раунды идут автоматически. Ставь в окне приёма и забирай до взрыва — чем дольше ждёшь, тем выше множитель и риск.")}
    </div>
  )
}

/* ═══════════════════════ САПЁР (Mines) ═══════════════════════ */
const GRID = 25
function mineMultiplier(m: number, k: number): number { let x = HOUSE_EDGE; for (let i = 0; i < k; i++) x *= (GRID - i) / (GRID - m - i); return x }

function MinesGame({ bank }: { bank: Bank }) {
  const { bal, setBal, cur } = bank
  const [bet, setBet] = useState(Math.min(50, Math.max(MIN_BET, bal)))
  const [mines, setMines] = useState(3)
  const [phase, setPhase] = useState<"idle" | "run" | "over">("idle")
  const [mineSet, setMineSet] = useState<Set<number>>(new Set())
  const [opened, setOpened] = useState<Set<number>>(new Set())
  const [dead, setDead] = useState(false)
  const [fx, setFx] = useState(0)
  const maxBet = Math.max(MIN_BET, bal)
  const safeOpen = opened.size
  const curMult = mineMultiplier(mines, safeOpen)
  const nextMult = mineMultiplier(mines, safeOpen + 1)
  const cashValue = Math.round(bet * curMult)

  const start = () => {
    if (bet > bal || bet < MIN_BET) return
    setBal(b => b - bet)
    const s = new Set<number>(); while (s.size < mines) s.add(Math.floor(Math.random() * GRID))
    setMineSet(s); setOpened(new Set()); setDead(false); setPhase("run")
  }
  const reveal = (i: number) => {
    if (phase !== "run" || opened.has(i)) return
    if (mineSet.has(i)) { setDead(true); setPhase("over"); return }
    const nx = new Set(opened); nx.add(i); setOpened(nx)
    if (nx.size === GRID - mines) { setBal(b => b + Math.round(bet * mineMultiplier(mines, nx.size))); setPhase("over"); setFx(f => f + 1) }
  }
  const cashOut = () => { if (phase === "run" && safeOpen > 0) { setBal(b => b + cashValue); setPhase("over"); setFx(f => f + 1) } }
  const reset = () => { setPhase("idle"); setOpened(new Set()); setMineSet(new Set()); setDead(false) }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <CurrencySwitch bank={bank} />
      {phase !== "idle" && (
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 14px", borderRadius: 14, background: "var(--ss-glass-1)", border: "1px solid var(--ss-hairline-lo)" }}>
          <span style={{ color: "var(--ss-ink-3)", fontSize: 12 }}>Множитель <b style={{ color: "var(--ss-brand-hi)", fontSize: 15 }}>{curMult.toFixed(2)}×</b></span>
          {phase === "run" && safeOpen > 0 && <span style={{ color: "var(--ss-ink-3)", fontSize: 12 }}>Дальше <b style={{ color: "var(--ss-ink-2)" }}>{nextMult.toFixed(2)}×</b></span>}
          {phase === "over" && dead && <span style={{ color: "var(--ss-bad)", fontSize: 13, fontWeight: 700 }}>Подрыв! −{bet}</span>}
          {phase === "over" && !dead && <span style={{ color: "var(--ss-ok)", fontSize: 13, fontWeight: 700 }}>Забрано +{cashValue - bet}</span>}
        </div>
      )}
      <div style={{ position: "relative", display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 7 }}>
        {fx > 0 && <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", pointerEvents: "none" }}><Burst key={fx} color="#7de3ff" spread={130} n={20} /></div>}
        {Array.from({ length: GRID }).map((_, i) => {
          const isOpen = opened.has(i)
          const showMine = phase === "over" && mineSet.has(i)
          const bg = isOpen ? "linear-gradient(150deg, var(--ss-brand-wash), rgba(255,255,255,0.02))" : showMine ? "rgba(240,82,79,0.16)" : "var(--ss-glass-2)"
          const border = isOpen ? "var(--ss-brand-edge)" : showMine ? "rgba(240,82,79,0.5)" : "var(--ss-hairline-lo)"
          return (
            <button key={i} onClick={() => reveal(i)} disabled={phase !== "run"} className="ss-press"
              style={{ position: "relative", aspectRatio: "1", borderRadius: 12, border: `1px solid ${border}`, background: bg, cursor: phase === "run" && !isOpen ? "pointer" : "default", display: "grid", placeItems: "center", boxShadow: isOpen ? "inset 0 0 14px -6px var(--ss-brand-glow)" : "none" }}>
              {isOpen ? <span className="ss-pop"><IcoGem size={22} /></span> : showMine ? <span className="ss-pop"><IcoBomb size={22} /></span> : null}
            </button>
          )
        })}
      </div>
      {phase === "idle" ? (
        <>
          <div style={{ display: "flex", gap: 8 }}>
            {[3, 5, 7].map(m => (
              <button key={m} onClick={() => setMines(m)} className="ss-press"
                style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6, padding: "10px", borderRadius: 12, cursor: "pointer", fontSize: 13, fontWeight: 700, background: mines === m ? "var(--ss-brand-wash)" : "var(--ss-glass-1)", border: `1px solid ${mines === m ? "var(--ss-brand-edge)" : "var(--ss-hairline-lo)"}`, color: mines === m ? "var(--ss-brand-hi)" : "var(--ss-ink-2)" }}>
                <IcoBomb size={15} /> {m}
              </button>
            ))}
          </div>
          <BetControls bet={bet} setBet={setBet} max={maxBet} cur={cur} />
          <PlayButton onClick={start} disabled={bet > bal || bal < MIN_BET}>{bal < MIN_BET ? "Недостаточно средств" : `Играть · ставка ${bet}`}</PlayButton>
        </>
      ) : phase === "run" ? (
        <PlayButton onClick={cashOut} disabled={safeOpen === 0} tone="cash">{safeOpen === 0 ? "Открой хотя бы одну клетку" : `Забрать ${cashValue}`}</PlayButton>
      ) : <ResetButton onClick={reset} />}
      {hint("Открывай кристаллы и множь ставку. Наткнёшься на мину — сгорает всё. Больше мин — выше множитель.")}
    </div>
  )
}

/* ═══════════════════════ БАШНЯ (Tower) ═══════════════════════ */
const TOWER_ROWS = 8
type Diff = { key: string; label: string; cols: number; safe: number }
const DIFFS: Diff[] = [
  { key: "easy", label: "Лёгкая", cols: 4, safe: 3 },
  { key: "med", label: "Средняя", cols: 3, safe: 2 },
  { key: "hard", label: "Сложная", cols: 2, safe: 1 },
]
const towerStep = (d: Diff) => d.cols / d.safe
const towerMult = (d: Diff, lv: number) => HOUSE_EDGE * Math.pow(towerStep(d), lv)

function TowerGame({ bank }: { bank: Bank }) {
  const { bal, setBal, cur } = bank
  const [bet, setBet] = useState(Math.min(50, Math.max(MIN_BET, bal)))
  const [diff, setDiff] = useState<Diff>(DIFFS[1])
  const [phase, setPhase] = useState<"idle" | "run" | "over">("idle")
  const [traps, setTraps] = useState<number[]>([])
  const [level, setLevel] = useState(0)
  const [picks, setPicks] = useState<number[]>([])
  const [dead, setDead] = useState(false)
  const [fx, setFx] = useState(0)
  const maxBet = Math.max(MIN_BET, bal)
  const curMult = towerMult(diff, level), nextMult = towerMult(diff, level + 1)
  const cashValue = Math.round(bet * curMult)

  const start = () => {
    if (bet > bal || bet < MIN_BET) return
    setBal(b => b - bet)
    setTraps(Array.from({ length: TOWER_ROWS }, () => Math.floor(Math.random() * diff.cols)))
    setLevel(0); setPicks([]); setDead(false); setPhase("run")
  }
  const pick = (col: number) => {
    if (phase !== "run") return
    const np = [...picks, col]
    if (traps[level] === col) { setPicks(np); setDead(true); setPhase("over"); return }
    setPicks(np)
    if (level + 1 >= TOWER_ROWS) { setBal(b => b + Math.round(bet * towerMult(diff, TOWER_ROWS))); setLevel(TOWER_ROWS); setPhase("over"); setFx(f => f + 1) }
    else setLevel(level + 1)
  }
  const cashOut = () => { if (phase === "run" && level > 0) { setBal(b => b + cashValue); setPhase("over"); setFx(f => f + 1) } }
  const reset = () => { setPhase("idle"); setLevel(0); setPicks([]); setTraps([]); setDead(false) }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <CurrencySwitch bank={bank} />
      {phase !== "idle" && (
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 14px", borderRadius: 14, background: "var(--ss-glass-1)", border: "1px solid var(--ss-hairline-lo)" }}>
          <span style={{ color: "var(--ss-ink-3)", fontSize: 12 }}>Этаж <b style={{ color: "var(--ss-ink)" }}>{Math.min(level, TOWER_ROWS)}/{TOWER_ROWS}</b> · <b style={{ color: "var(--ss-brand-hi)", fontSize: 15 }}>{curMult.toFixed(2)}×</b></span>
          {phase === "run" && <span style={{ color: "var(--ss-ink-3)", fontSize: 12 }}>Дальше <b style={{ color: "var(--ss-ink-2)" }}>{nextMult.toFixed(2)}×</b></span>}
          {phase === "over" && dead && <span style={{ color: "var(--ss-bad)", fontSize: 13, fontWeight: 700 }}>Провал! −{bet}</span>}
          {phase === "over" && !dead && <span style={{ color: "var(--ss-ok)", fontSize: 13, fontWeight: 700 }}>Забрано +{cashValue - bet}</span>}
        </div>
      )}
      <div style={{ position: "relative", display: "flex", flexDirection: "column", gap: 6, padding: "6px 0" }}>
        {fx > 0 && <div style={{ position: "absolute", inset: 0, display: "grid", placeItems: "center", pointerEvents: "none" }}><Burst key={fx} color="var(--ss-brand-hi)" spread={130} n={20} /></div>}
        {Array.from({ length: TOWER_ROWS }).map((_, r) => {
          const row = TOWER_ROWS - 1 - r
          const isCurrent = phase === "run" && row === level
          const isPast = row < level
          const isFuture = row > level && phase !== "over"
          const revealRow = phase === "over" && row <= level
          return (
            <div key={row} style={{ display: "grid", gridTemplateColumns: `repeat(${diff.cols}, 1fr)`, gap: 6, opacity: isCurrent || isPast || phase === "over" ? 1 : 0.4, transition: "opacity 0.2s" }}>
              {Array.from({ length: diff.cols }).map((_, c) => {
                const picked = picks[row] === c
                const isTrap = traps[row] === c
                const showTrap = revealRow && isTrap
                const showGem = isPast && picked || revealRow && picked && !isTrap
                let bg = "var(--ss-glass-2)", border = "var(--ss-hairline-lo)"
                if (isCurrent) { bg = "linear-gradient(150deg, var(--ss-brand-wash), rgba(255,255,255,0.03))"; border = "var(--ss-brand-edge)" }
                if (showGem) { bg = "linear-gradient(150deg, rgba(52,211,153,0.2), rgba(255,255,255,0.02))"; border = "rgba(52,211,153,0.5)" }
                if (showTrap) { bg = "rgba(240,82,79,0.18)"; border = "rgba(240,82,79,0.5)" }
                return (
                  <button key={c} onClick={() => isCurrent && pick(c)} disabled={!isCurrent} className={isCurrent ? "ss-press" : undefined}
                    style={{ height: 34, borderRadius: 10, border: `1px solid ${border}`, background: bg, cursor: isCurrent ? "pointer" : "default", display: "grid", placeItems: "center", boxShadow: isCurrent ? "0 0 16px -8px var(--ss-brand-glow)" : "none", animation: isCurrent ? "ss-glow-pulse 1.6s ease-in-out infinite" : undefined }}>
                    {showGem ? <span className="ss-pop"><IcoGem size={17} /></span> : showTrap ? <span className="ss-pop"><IcoBomb size={17} /></span> : isFuture ? <span style={{ width: 5, height: 5, borderRadius: 999, background: "var(--ss-ink-4)" }} /> : null}
                  </button>
                )
              })}
            </div>
          )
        })}
      </div>
      {phase === "idle" ? (
        <>
          <div style={{ display: "flex", gap: 8 }}>
            {DIFFS.map(d => (
              <button key={d.key} onClick={() => setDiff(d)} className="ss-press"
                style={{ flex: 1, padding: "10px 6px", borderRadius: 12, cursor: "pointer", fontSize: 12, fontWeight: 700, lineHeight: 1.3, background: diff.key === d.key ? "var(--ss-brand-wash)" : "var(--ss-glass-1)", border: `1px solid ${diff.key === d.key ? "var(--ss-brand-edge)" : "var(--ss-hairline-lo)"}`, color: diff.key === d.key ? "var(--ss-brand-hi)" : "var(--ss-ink-2)" }}>
                {d.label}<br /><span style={{ fontSize: 10, opacity: 0.8 }}>×{towerStep(d).toFixed(2)}/этаж</span>
              </button>
            ))}
          </div>
          <BetControls bet={bet} setBet={setBet} max={maxBet} cur={cur} />
          <PlayButton onClick={start} disabled={bet > bal || bal < MIN_BET}>{bal < MIN_BET ? "Недостаточно средств" : `Играть · ставка ${bet}`}</PlayButton>
        </>
      ) : phase === "run" ? (
        <PlayButton onClick={cashOut} disabled={level === 0} tone="cash">{level === 0 ? "Пройди хотя бы один этаж" : `Забрать ${cashValue}`}</PlayButton>
      ) : <ResetButton onClick={reset} />}
      {hint("Поднимайся по этажам, выбирая безопасную плитку. За каждый этаж — рост множителя. Ловушка обнуляет ставку.")}
    </div>
  )
}

/* ═══════════════════════ КУБИК (Dice) ═══════════════════════ */
function DiceGame({ bank }: { bank: Bank }) {
  const { bal, setBal, cur } = bank
  const [bet, setBet] = useState(Math.min(50, Math.max(MIN_BET, bal)))
  const [target, setTarget] = useState(50)
  const [phase, setPhase] = useState<"idle" | "rolling" | "over">("idle")
  const [roll, setRoll] = useState<number | null>(null)
  const [won, setWon] = useState(false)
  const [fx, setFx] = useState(0)
  const [display, setDisplay] = useState(50)
  const raf = useRef<number>(0)
  const maxBet = Math.max(MIN_BET, bal)
  const chance = target
  const mult = Math.floor((HOUSE_EDGE * 100 / chance) * 100) / 100
  const potential = Math.round(bet * mult)

  useEffect(() => () => cancelAnimationFrame(raf.current), [])
  const play = () => {
    if (bet > bal || bet < MIN_BET || phase === "rolling") return
    setBal(b => b - bet); setPhase("rolling"); setRoll(null)
    const final = Math.random() * 100, t0 = performance.now()
    const spin = (t: number) => {
      if (t - t0 < 900) { setDisplay(Math.random() * 100); raf.current = requestAnimationFrame(spin) }
      else { setDisplay(final); const win = final < target; setRoll(final); setWon(win); setPhase("over"); if (win) { setBal(b => b + Math.round(bet * mult)); setFx(f => f + 1) } }
    }
    raf.current = requestAnimationFrame(spin)
  }
  const reset = () => { setPhase("idle"); setRoll(null) }
  const shown = phase === "over" && roll !== null ? roll : display
  const col = phase === "over" ? (won ? "var(--ss-ok)" : "var(--ss-bad)") : "var(--ss-brand-hi)"
  const dieN = Math.min(6, Math.max(1, Math.ceil((shown / 100) * 6) || 1))

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <CurrencySwitch bank={bank} />
      <div style={{ position: "relative", height: 200, borderRadius: 20, overflow: "hidden", border: "1px solid var(--ss-hairline-lo)", background: "radial-gradient(120% 90% at 50% 20%, rgba(124,58,237,0.2), transparent 60%), linear-gradient(180deg, #0b0714, #05060a)", display: "grid", placeItems: "center" }}>
        {fx > 0 && phase === "over" && won && <Burst key={fx} color="#34d399" spread={120} />}
        <div style={{ textAlign: "center" }}>
          <div style={{ display: "inline-block", animation: phase === "rolling" ? "ss-dieroll 0.5s linear infinite" : undefined, filter: "drop-shadow(0 6px 18px var(--ss-brand-glow))" }}><IcoDie n={dieN} size={60} /></div>
          <div style={{ marginTop: 10, fontSize: 32, fontWeight: 900, color: col, textShadow: `0 0 22px ${col}`, lineHeight: 1 }}>{shown.toFixed(2)}</div>
          {phase === "over" && <div style={{ marginTop: 6, fontSize: 13, fontWeight: 700, color: col }}>{won ? `Победа! +${Math.round(bet * mult) - bet}` : `Мимо · нужно < ${target}`}</div>}
        </div>
      </div>
      {phase !== "rolling" && (
        <div style={{ padding: "12px 14px", borderRadius: 14, background: "var(--ss-glass-1)", border: "1px solid var(--ss-hairline-lo)" }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 12, color: "var(--ss-ink-3)" }}>
            <span>Выигрыш если <b style={{ color: "var(--ss-ink)" }}>&lt; {target}</b></span>
            <span>Шанс <b style={{ color: "var(--ss-ink-2)" }}>{chance}%</b> · <b style={{ color: "var(--ss-brand-hi)" }}>{mult.toFixed(2)}×</b></span>
          </div>
          <input type="range" min={2} max={95} value={target} disabled={phase === "over"} onChange={e => setTarget(Number(e.target.value))} style={{ width: "100%", accentColor: "var(--ss-brand-hi)" }} />
        </div>
      )}
      {phase === "idle" ? (
        <>
          <BetControls bet={bet} setBet={setBet} max={maxBet} cur={cur} />
          <PlayButton onClick={play} disabled={bet > bal || bal < MIN_BET}>{bal < MIN_BET ? "Недостаточно средств" : `Бросить · возможно ${potential}`}</PlayButton>
        </>
      ) : phase === "rolling" ? <PlayButton onClick={() => {}} disabled>Бросок…</PlayButton>
        : <ResetButton onClick={reset} />}
      {hint("Двигай ползунок: чем ниже порог, тем реже победа, но выше множитель. Бросок должен оказаться меньше порога.")}
    </div>
  )
}

/* ═══════════════════════ КОЛЕСО (Wheel) ═══════════════════════ */
const WHEEL_SHAPE = [0, 1, 0, 1.5, 0, 1, 0, 2, 0, 1, 0, 3]
const WHEEL_SCALE = HOUSE_EDGE / (WHEEL_SHAPE.reduce((a, b) => a + b, 0) / WHEEL_SHAPE.length)
const WHEEL = WHEEL_SHAPE.map(v => Math.round(v * WHEEL_SCALE * 100) / 100)
const SEG = 360 / WHEEL.length

function WheelGame({ bank }: { bank: Bank }) {
  const { bal, setBal, cur } = bank
  const [bet, setBet] = useState(Math.min(50, Math.max(MIN_BET, bal)))
  const [phase, setPhase] = useState<"idle" | "spin" | "over">("idle")
  const [rot, setRot] = useState(0)
  const [landed, setLanded] = useState<number | null>(null)
  const [fx, setFx] = useState(0)
  const maxBet = Math.max(MIN_BET, bal)
  const conic = useMemo(() => `conic-gradient(from 0deg, ${WHEEL.map((v, i) => `${v === 0 ? "#241a3d" : v >= 2.5 ? "#e0872b" : v >= 1.8 ? "#2f6fd6" : "var(--ss-brand-hi)"} ${i * SEG}deg ${(i + 1) * SEG}deg`).join(", ")})`, [])
  const spin = () => {
    if (bet > bal || bet < MIN_BET || phase === "spin") return
    setBal(b => b - bet)
    const idx = Math.floor(Math.random() * WHEEL.length), turns = 5 + Math.floor(Math.random() * 3)
    const target = turns * 360 + (360 - (idx * SEG + SEG / 2)), base = rot - (rot % 360)
    setRot(base + target); setLanded(null); setPhase("spin")
    window.setTimeout(() => { const p = WHEEL[idx]; setLanded(idx); setPhase("over"); if (p > 0) { setBal(b => b + Math.round(bet * p)); setFx(f => f + 1) } }, 4100)
  }
  const reset = () => { setPhase("idle"); setLanded(null) }
  const result = landed !== null ? WHEEL[landed] : null

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <CurrencySwitch bank={bank} />
      <div style={{ position: "relative", display: "grid", placeItems: "center", padding: "8px 0 4px" }}>
        {fx > 0 && phase === "over" && <Burst key={fx} color="#ffb347" spread={140} n={22} />}
        <div aria-hidden style={{ position: "absolute", top: 0, zIndex: 3, width: 0, height: 0, borderLeft: "11px solid transparent", borderRight: "11px solid transparent", borderTop: "18px solid var(--ss-brand-hi)", filter: "drop-shadow(0 0 8px var(--ss-brand-glow))" }} />
        <div style={{ position: "relative", width: 250, height: 250, borderRadius: "50%", padding: 8, background: "radial-gradient(circle, #150c2b, #05060a)", border: "2px solid var(--ss-brand-edge)", boxShadow: "0 0 40px -12px var(--ss-brand-glow)" }}>
          <div style={{ position: "relative", width: "100%", height: "100%", borderRadius: "50%", background: conic, transition: phase === "spin" ? "transform 4s cubic-bezier(0.15, 0.6, 0.15, 1)" : "none", transform: `rotate(${rot}deg)`, boxShadow: "inset 0 0 0 2px rgba(255,255,255,0.08)" }}>
            {WHEEL.map((v, i) => {
              const a = (i * SEG + SEG / 2) * Math.PI / 180, rad = 88
              const x = Math.sin(a) * rad, y = -Math.cos(a) * rad
              return (
                <span key={i} style={{ position: "absolute", left: "50%", top: "50%", transform: `translate(-50%,-50%) translate(${x}px, ${y}px) rotate(${i * SEG + SEG / 2}deg)` }}>
                  <span style={{ display: "inline-block", padding: v === 0 ? 0 : "2px 5px", borderRadius: 7, fontSize: 12, fontWeight: 900, letterSpacing: "-0.02em", whiteSpace: "nowrap", color: v === 0 ? "rgba(255,255,255,0.45)" : "#fff", background: v === 0 ? "transparent" : "rgba(6,4,16,0.7)", boxShadow: v === 0 ? "none" : "0 1px 3px rgba(0,0,0,0.55)" }}>{v === 0 ? "—" : `${v}×`}</span>
                </span>
              )
            })}
          </div>
          <div style={{ position: "absolute", left: "50%", top: "50%", transform: "translate(-50%,-50%)", width: 46, height: 46, borderRadius: "50%", background: "radial-gradient(circle at 40% 30%, #2a1c52, #0a0810)", border: "2px solid var(--ss-brand-hi)", display: "grid", placeItems: "center", zIndex: 2 }}>
            <span style={{ fontSize: 20, fontWeight: 800, color: "var(--ss-brand-hi)" }}>Σ</span>
          </div>
        </div>
        {phase === "over" && result !== null && (
          <div style={{ marginTop: 12, fontSize: 15, fontWeight: 800, color: result > 0 ? "var(--ss-ok)" : "var(--ss-bad)" }}>{result > 0 ? `${result}× · +${Math.round(bet * result) - bet}` : `Пусто · −${bet}`}</div>
        )}
      </div>
      {phase === "idle" ? (
        <>
          <BetControls bet={bet} setBet={setBet} max={maxBet} cur={cur} />
          <PlayButton onClick={spin} disabled={bet > bal || bal < MIN_BET}>{bal < MIN_BET ? "Недостаточно средств" : `Крутить · ставка ${bet}`}</PlayButton>
        </>
      ) : phase === "spin" ? <PlayButton onClick={() => {}} disabled>Крутится…</PlayButton>
        : <ResetButton onClick={reset} />}
      {hint("Крути колесо и лови множитель. Сектор «—» — пусто. Крупные множители выпадают реже.")}
    </div>
  )
}

/* ═══════════════════════ ЕЖЕДНЕВНОЕ КОЛЕСО (фарм коинов) ═══════════════════════ */
const DAILY_REWARDS = [50, 100, 150, 250, 100, 400, 150, 700, 100, 300, 200, 1000]
const DSEG = 360 / DAILY_REWARDS.length

function DailyWheel({ available, nextInMs, onClaim }: { available: boolean; nextInMs: number; onClaim: (coins: number) => void }) {
  const [phase, setPhase] = useState<"ready" | "spin" | "done">(available ? "ready" : "done")
  const [rot, setRot] = useState(0)
  const [won, setWon] = useState<number | null>(null)
  const [fx, setFx] = useState(0)
  useEffect(() => { if (available && phase === "done" && won === null) setPhase("ready") }, [available]) // eslint-disable-line
  const conic = useMemo(() => `conic-gradient(from 0deg, ${DAILY_REWARDS.map((v, i) => `${v >= 700 ? "#e0872b" : v >= 300 ? "#2f6fd6" : i % 2 ? "var(--ss-brand-hi)" : "#6b4fd6"} ${i * DSEG}deg ${(i + 1) * DSEG}deg`).join(", ")})`, [])
  const spin = () => {
    if (phase !== "ready") return
    const idx = Math.floor(Math.random() * DAILY_REWARDS.length), turns = 5 + Math.floor(Math.random() * 3)
    const target = turns * 360 + (360 - (idx * DSEG + DSEG / 2)), base = rot - (rot % 360)
    setRot(base + target); setPhase("spin")
    window.setTimeout(() => { const r = DAILY_REWARDS[idx]; setWon(r); setPhase("done"); setFx(f => f + 1); onClaim(r) }, 4100)
  }
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14, padding: "6px 0" }}>
      <div style={{ position: "relative", display: "grid", placeItems: "center" }}>
        {fx > 0 && <Burst key={fx} color="#ffcf5c" spread={150} n={24} />}
        <div aria-hidden style={{ position: "absolute", top: -4, zIndex: 3, width: 0, height: 0, borderLeft: "12px solid transparent", borderRight: "12px solid transparent", borderTop: "20px solid #ffcf5c", filter: "drop-shadow(0 0 8px rgba(245,166,35,0.6))" }} />
        <div style={{ position: "relative", width: 260, height: 260, borderRadius: "50%", padding: 8, background: "radial-gradient(circle, #221434, #05060a)", border: "2px solid #ffcf5c66", boxShadow: "0 0 44px -12px rgba(245,166,35,0.5)" }}>
          <div style={{ position: "relative", width: "100%", height: "100%", borderRadius: "50%", background: conic, transition: phase === "spin" ? "transform 4s cubic-bezier(0.15, 0.6, 0.15, 1)" : "none", transform: `rotate(${rot}deg)` }}>
            {DAILY_REWARDS.map((v, i) => {
              const a = (i * DSEG + DSEG / 2) * Math.PI / 180, rad = 92
              const x = Math.sin(a) * rad, y = -Math.cos(a) * rad
              return <span key={i} style={{ position: "absolute", left: "50%", top: "50%", transform: `translate(-50%,-50%) translate(${x}px, ${y}px) rotate(${i * DSEG + DSEG / 2}deg)` }}><span style={{ display: "inline-block", padding: "2px 5px", borderRadius: 7, fontSize: 11.5, fontWeight: 900, whiteSpace: "nowrap", color: "#fff", background: "rgba(6,4,16,0.72)", boxShadow: "0 1px 3px rgba(0,0,0,0.55)" }}>{v}</span></span>
            })}
          </div>
          <div style={{ position: "absolute", left: "50%", top: "50%", transform: "translate(-50%,-50%)", width: 46, height: 46, borderRadius: "50%", background: "radial-gradient(circle at 40% 30%, #3a2a10, #0a0810)", border: "2px solid #ffcf5c", display: "grid", placeItems: "center", zIndex: 2 }}><IcoCoin size={24} /></div>
        </div>
      </div>
      {phase === "ready" ? (
        <PlayButton onClick={spin}>Крутить бесплатно</PlayButton>
      ) : phase === "spin" ? (
        <PlayButton onClick={() => {}} disabled>Крутится…</PlayButton>
      ) : (
        <div style={{ textAlign: "center" }}>
          {won !== null && <div style={{ fontSize: 18, fontWeight: 900, color: "#ffcf5c", marginBottom: 8 }}>+{won} коинов!</div>}
          <div style={{ color: "var(--ss-ink-3)", fontSize: 13 }}>Следующий бесплатный спин через</div>
          <div style={{ color: "var(--ss-ink)", fontSize: 22, fontWeight: 800, fontVariantNumeric: "tabular-nums" }}>{hhmmss(nextInMs)}</div>
        </div>
      )}
      {hint("Раз в 24 часа — бесплатный спин на коины. Коины можно ставить в играх или обменять на скидочные баллы.")}
    </div>
  )
}

/* ═══════════════════════ ОБМЕН КОИНОВ → БАЛЛЫ ═══════════════════════ */
function ExchangePanel({ coins, onConvert }: { coins: number; onConvert: (spendCoins: number, gainPoints: number) => void }) {
  const maxPoints = Math.floor(coins / CONVERT_RATE)
  const [pts, setPts] = useState(Math.min(1, maxPoints))
  useEffect(() => { setPts(p => Math.min(Math.max(1, p), Math.max(1, maxPoints))) }, [maxPoints])
  const spend = pts * CONVERT_RATE
  const can = maxPoints >= 1 && spend <= coins
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 14, padding: "18px", borderRadius: 18, background: "linear-gradient(135deg, var(--ss-brand-wash), rgba(245,166,35,0.06))", border: "1px solid var(--ss-brand-edge)" }}>
        <span style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}><IcoCoin size={30} /><b style={{ color: "var(--ss-ink)", fontSize: 15 }}>{fmt(spend)}</b><span style={{ color: "var(--ss-ink-4)", fontSize: 10 }}>коинов</span></span>
        <svg viewBox="0 0 24 24" width={26} height={26} fill="none" stroke="var(--ss-ink-3)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
        <span style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}><IcoPoint size={30} /><b style={{ color: "var(--ss-brand-hi)", fontSize: 15 }}>{fmt(pts)}</b><span style={{ color: "var(--ss-ink-4)", fontSize: 10 }}>баллов (₽)</span></span>
      </div>
      <div style={{ padding: "12px 14px", borderRadius: 14, background: "var(--ss-glass-1)", border: "1px solid var(--ss-hairline-lo)" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8, fontSize: 12, color: "var(--ss-ink-3)" }}>
          <span>Обменять баллов</span><span><b style={{ color: "var(--ss-ink)" }}>{pts}</b> из {maxPoints || 0}</span>
        </div>
        <input type="range" min={1} max={Math.max(1, maxPoints)} value={pts} disabled={maxPoints < 1} onChange={e => setPts(Number(e.target.value))} style={{ width: "100%", accentColor: "var(--ss-brand-hi)" }} />
      </div>
      <PlayButton onClick={() => can && onConvert(spend, pts)} disabled={!can}>{maxPoints < 1 ? `Нужно ${CONVERT_RATE} коинов` : `Обменять на ${pts} ₽ скидки`}</PlayButton>
      {hint(`Курс ${CONVERT_RATE} коинов = 1 балл (1 ₽ скидки). Баллы копятся и уменьшают сумму заказа, но всегда в пределах лимита лояльности — на бесплатный товар обменять нельзя.`)}
    </div>
  )
}

/* ═══════════════════════ ХАБ ═══════════════════════ */
type GameId = "crash" | "mines" | "tower" | "dice" | "wheel"
type Screen = GameId | "daily" | "freebet" | "exchange" | null
const GAMES: { id: GameId; title: string; tag: string; desc: string; Ico: () => React.ReactNode }[] = [
  { id: "crash", title: "Ракетка", tag: "CRASH", desc: "Забери множитель до взрыва", Ico: () => <IcoRocket size={28} /> },
  { id: "mines", title: "Сапёр", tag: "MINES", desc: "Собери кристаллы, минуя мины", Ico: () => <IcoBomb size={26} /> },
  { id: "tower", title: "Башня", tag: "TOWER", desc: "Поднимайся по безопасным плиткам", Ico: () => <IcoTower size={26} /> },
  { id: "dice", title: "Кубик", tag: "DICE", desc: "Угадай бросок под порогом", Ico: () => <IcoDie n={5} size={28} /> },
  { id: "wheel", title: "Колесо", tag: "WHEEL", desc: "Крути и лови множитель", Ico: () => <IcoWheel size={26} /> },
]
const FREE_BET_COINS = 100
const TITLES: Record<string, string> = { daily: "Ежедневное колесо", freebet: "Бесплатная ставка", exchange: "Обмен коинов", crash: "Ракетка", mines: "Сапёр", tower: "Башня", dice: "Кубик", wheel: "Колесо" }

function AmbientSparks() {
  const sparks = useMemo(() => Array.from({ length: 18 }, (_, i) => ({ left: Math.random() * 100, delay: -Math.random() * 8, dur: 6 + Math.random() * 6, size: 2 + Math.random() * 3, color: ["#a855f7", "#7de3ff", "#ffcf5c"][i % 3] })), [])
  return (
    <div aria-hidden style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none", zIndex: 0 }}>
      {sparks.map((s, i) => <span key={i} className="ss-spark" style={{ left: `${s.left}%`, bottom: -10, width: s.size, height: s.size, color: s.color, animationDelay: `${s.delay}s`, animationDuration: `${s.dur}s` }} />)}
    </div>
  )
}

export function GamesView({ points, coins, dailyWheelAt, dailyBetAt, onPatch, onClose }: {
  points: number; coins: number; dailyWheelAt: number; dailyBetAt: number
  onPatch: (patch: { coins: number; points: number; dailyWheelAt: number; dailyBetAt: number }) => void
  onClose: () => void
}) {
  const wallet = useRef({ coins: clampInt(coins), points: clampInt(points), dailyWheelAt, dailyBetAt })
  const [, force] = useState(0)
  const commit = (patch: Partial<typeof wallet.current>) => {
    wallet.current = { ...wallet.current, ...patch }
    onPatch({ ...wallet.current })
    force(n => n + 1)
  }
  const [screen, setScreen] = useState<Screen>(null)
  const [cur, setCur] = useState<Cur>("coins")
  const now = useNow(1000)

  const setCoins = (fn: (b: number) => number) => commit({ coins: clampInt(fn(wallet.current.coins)) })
  const setPoints = (fn: (b: number) => number) => commit({ points: clampInt(fn(wallet.current.points)) })
  const bank: Bank = { cur, setCur, bal: cur === "coins" ? wallet.current.coins : wallet.current.points, setBal: cur === "coins" ? setCoins : setPoints, coins: wallet.current.coins, points: wallet.current.points }

  const wheelReady = now - wallet.current.dailyWheelAt >= DAILY_MS
  const wheelNext = Math.max(0, wallet.current.dailyWheelAt + DAILY_MS - now)
  const betReady = now - wallet.current.dailyBetAt >= DAILY_MS
  const betNext = Math.max(0, wallet.current.dailyBetAt + DAILY_MS - now)

  const claimWheel = (amount: number) => commit({ coins: wallet.current.coins + amount, dailyWheelAt: Date.now() })
  const claimBet = () => commit({ coins: wallet.current.coins + FREE_BET_COINS, dailyBetAt: Date.now() })
  const convert = (spendCoins: number, gainPoints: number) => commit({ coins: wallet.current.coins - spendCoins, points: wallet.current.points + gainPoints })

  const isGame = screen && ["crash", "mines", "tower", "dice", "wheel"].includes(screen)

  return (
    <div data-theme="dark" style={{ position: "absolute", inset: 0, zIndex: 400, display: "flex", flexDirection: "column", background: "var(--ss-void)", overflow: "hidden" }}>
      <div aria-hidden className="ss-aurora" style={{ position: "absolute", inset: 0, zIndex: 0 }} />
      <AmbientSparks />

      {/* Шапка + кошелёк */}
      <div style={{ position: "relative", zIndex: 2, padding: "14px 16px 10px", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 }}>
          <button onClick={() => (screen ? setScreen(null) : onClose())} aria-label="Назад" className="ss-press" style={{ width: 40, height: 40, borderRadius: 12, display: "grid", placeItems: "center", background: "var(--ss-glass-2)", border: "1px solid var(--ss-hairline-lo)", color: "var(--ss-ink)", cursor: "pointer" }}><IcoBack /></button>
          <div style={{ textAlign: "center", lineHeight: 1.1 }}>
            <div style={{ color: "var(--ss-brand-hi)", fontSize: 9, fontWeight: 800, letterSpacing: "0.22em", textTransform: "uppercase" }}>Сигма-Аркада</div>
            <div style={{ color: "var(--ss-ink)", fontSize: 16, fontWeight: 800 }}>{screen ? TITLES[screen] : "Игры на баллы"}</div>
          </div>
          <div style={{ width: 40 }} />
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
          <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 8, padding: "9px 12px", borderRadius: 14, background: "linear-gradient(135deg, rgba(245,166,35,0.12), var(--ss-glass-1))", border: "1px solid #ffcf5c33" }}>
            <IcoCoin size={20} /><b style={{ color: "var(--ss-ink)", fontSize: 15, fontWeight: 800 }}>{fmt(wallet.current.coins)}</b><span style={{ color: "var(--ss-ink-4)", fontSize: 11 }}>коинов</span>
          </div>
          <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 8, padding: "9px 12px", borderRadius: 14, background: "var(--ss-brand-wash)", border: "1px solid var(--ss-brand-edge)" }}>
            <IcoPoint size={20} /><b style={{ color: "var(--ss-ink)", fontSize: 15, fontWeight: 800 }}>{fmt(wallet.current.points)}</b><span style={{ color: "var(--ss-ink-4)", fontSize: 11 }}>₽ скидки</span>
          </div>
        </div>
      </div>

      {/* Контент */}
      <div data-app-scroll style={{ position: "relative", zIndex: 1, flex: 1, overflowY: "auto", padding: "6px 16px 28px" }}>
        {screen === null ? (
          <>
            {/* Ежедневные бонусы */}
            <div style={{ display: "flex", gap: 10, marginBottom: 14 }}>
              <button onClick={() => setScreen("daily")} className="ss-press ss-lift-hover" style={{ flex: 1, position: "relative", overflow: "hidden", padding: "14px", borderRadius: 18, textAlign: "left", cursor: "pointer", background: "linear-gradient(150deg, rgba(245,166,35,0.16), var(--ss-glass-1))", border: `1px solid ${wheelReady ? "#ffcf5c66" : "var(--ss-hairline-lo)"}` }}>
                {wheelReady && <span aria-hidden style={{ position: "absolute", right: 10, top: 10, width: 8, height: 8, borderRadius: 999, background: "#ffcf5c", boxShadow: "0 0 10px #ffcf5c", animation: "ss-glow-pulse 1.4s infinite" }} />}
                <IcoWheel size={26} />
                <div style={{ marginTop: 8, color: "var(--ss-ink)", fontSize: 13.5, fontWeight: 800 }}>Колесо дня</div>
                <div style={{ marginTop: 3, color: wheelReady ? "#ffcf5c" : "var(--ss-ink-4)", fontSize: 11, fontWeight: 600, fontVariantNumeric: "tabular-nums" }}>{wheelReady ? "Доступно!" : hhmmss(wheelNext)}</div>
              </button>
              <button onClick={() => setScreen("freebet")} className="ss-press ss-lift-hover" style={{ flex: 1, position: "relative", overflow: "hidden", padding: "14px", borderRadius: 18, textAlign: "left", cursor: "pointer", background: "linear-gradient(150deg, var(--ss-brand-wash), var(--ss-glass-1))", border: `1px solid ${betReady ? "var(--ss-brand-edge)" : "var(--ss-hairline-lo)"}` }}>
                {betReady && <span aria-hidden style={{ position: "absolute", right: 10, top: 10, width: 8, height: 8, borderRadius: 999, background: "var(--ss-brand-hi)", boxShadow: "0 0 10px var(--ss-brand-glow)", animation: "ss-glow-pulse 1.4s infinite" }} />}
                <IcoGift size={26} />
                <div style={{ marginTop: 8, color: "var(--ss-ink)", fontSize: 13.5, fontWeight: 800 }}>Бесплатная ставка</div>
                <div style={{ marginTop: 3, color: betReady ? "var(--ss-brand-hi)" : "var(--ss-ink-4)", fontSize: 11, fontWeight: 600, fontVariantNumeric: "tabular-nums" }}>{betReady ? "Доступно!" : hhmmss(betNext)}</div>
              </button>
            </div>

            {/* Обмен */}
            <button onClick={() => setScreen("exchange")} className="ss-press ss-lift-hover" style={{ display: "flex", alignItems: "center", gap: 12, width: "100%", padding: "14px 16px", borderRadius: 18, marginBottom: 16, textAlign: "left", cursor: "pointer", background: "linear-gradient(100deg, rgba(245,166,35,0.1), var(--ss-brand-wash))", border: "1px solid var(--ss-brand-edge)" }}>
              <span style={{ display: "flex", alignItems: "center", gap: 4 }}><IcoCoin size={22} /><svg viewBox="0 0 24 24" width={16} height={16} fill="none" stroke="var(--ss-ink-3)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6" /></svg><IcoPoint size={22} /></span>
              <span style={{ flex: 1 }}>
                <span style={{ display: "block", color: "var(--ss-ink)", fontSize: 15, fontWeight: 800 }}>Обменять коины на скидку</span>
                <span style={{ display: "block", marginTop: 2, color: "var(--ss-ink-3)", fontSize: 11.5 }}>Курс {CONVERT_RATE} 🪙 = 1 ₽ скидки</span>
              </span>
              <IcoChevron />
            </button>

            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {GAMES.map(g => (
                <button key={g.id} onClick={() => setScreen(g.id)} className="ss-press ss-lift-hover"
                  style={{ display: "flex", alignItems: "center", gap: 14, padding: "16px", borderRadius: 18, textAlign: "left", cursor: "pointer", background: "linear-gradient(150deg, var(--ss-glass-2), var(--ss-glass-1))", border: "1px solid var(--ss-hairline-lo)", boxShadow: "var(--ss-e2), var(--ss-lift)" }}>
                  <span style={{ width: 54, height: 54, flexShrink: 0, borderRadius: 15, display: "grid", placeItems: "center", background: "radial-gradient(circle at 50% 30%, #1a1430, #05060a)", border: "1px solid var(--ss-brand-edge)", boxShadow: "0 0 22px -10px var(--ss-brand-glow)" }}>{g.Ico()}</span>
                  <span style={{ flex: 1, minWidth: 0 }}>
                    <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <b style={{ color: "var(--ss-ink)", fontSize: 16, fontWeight: 800 }}>{g.title}</b>
                      <span style={{ color: "var(--ss-brand-hi)", fontSize: 8.5, fontWeight: 800, letterSpacing: "0.16em", padding: "2px 7px", borderRadius: 999, background: "var(--ss-brand-wash)", border: "1px solid var(--ss-brand-edge)" }}>{g.tag}</span>
                    </span>
                    <span style={{ display: "block", marginTop: 4, color: "var(--ss-ink-3)", fontSize: 12 }}>{g.desc}</span>
                  </span>
                  <IcoChevron />
                </button>
              ))}
            </div>
            <p style={{ margin: "18px 4px 0", color: "var(--ss-ink-4)", fontSize: 10.5, lineHeight: 1.5, textAlign: "center" }}>
              Игра ведётся на внутренние коины и бонусные баллы, а не на деньги. Баллы дают скидку на заказы в пределах лимита лояльности.
            </p>
          </>
        ) : screen === "daily" ? (
          <DailyWheel available={wheelReady} nextInMs={wheelNext} onClaim={claimWheel} />
        ) : screen === "freebet" ? (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 16, padding: "20px 0" }}>
            <div style={{ position: "relative", width: 96, height: 96, borderRadius: 26, display: "grid", placeItems: "center", background: "radial-gradient(circle at 50% 30%, #1a1430, #05060a)", border: "1px solid var(--ss-brand-edge)", boxShadow: "0 0 30px -8px var(--ss-brand-glow)" }}><IcoGift size={44} /></div>
            {betReady ? (
              <>
                <div style={{ textAlign: "center" }}>
                  <div style={{ color: "var(--ss-ink)", fontSize: 18, fontWeight: 800 }}>Забери +{FREE_BET_COINS} коинов</div>
                  <div style={{ marginTop: 4, color: "var(--ss-ink-3)", fontSize: 12.5, maxWidth: 260 }}>Бесплатное пополнение раз в 24 часа — на них можно сыграть в любой мини-игре.</div>
                </div>
                <div style={{ width: "100%" }}><PlayButton onClick={claimBet}>Забрать {FREE_BET_COINS} коинов</PlayButton></div>
              </>
            ) : (
              <div style={{ textAlign: "center" }}>
                <div style={{ color: "var(--ss-ink-3)", fontSize: 13 }}>Следующая бесплатная ставка через</div>
                <div style={{ color: "var(--ss-ink)", fontSize: 26, fontWeight: 800, fontVariantNumeric: "tabular-nums" }}>{hhmmss(betNext)}</div>
              </div>
            )}
            {hint("Заходи каждый день — бесплатные коины копятся и превращаются в реальную скидку через обмен.")}
          </div>
        ) : screen === "exchange" ? (
          <ExchangePanel coins={wallet.current.coins} onConvert={convert} />
        ) : isGame ? (
          screen === "crash" ? <CrashGame bank={bank} />
            : screen === "mines" ? <MinesGame bank={bank} />
              : screen === "tower" ? <TowerGame bank={bank} />
                : screen === "dice" ? <DiceGame bank={bank} />
                  : <WheelGame bank={bank} />
        ) : null}
      </div>
    </div>
  )
}

export default GamesView
