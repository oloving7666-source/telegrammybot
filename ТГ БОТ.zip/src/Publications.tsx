import { useState, useEffect, useRef, useCallback, useMemo } from 'react'
import Cropper from 'react-easy-crop'
import { kv, storage, publishPost, publishVk, notify } from './api'
import { getCroppedRectFile, type PixelCrop } from './cropImage'
import { hScroll, Icon, type IconName } from './shared'

// ─────────────────────────────────────────────────────────────────────────────
// Модуль «Публикации» — профессиональная система управления постами.
//
// Архитектура намеренно модульная: каждая платформа описана адаптером в реестре
// PLATFORM_ADAPTERS. Чтобы добавить новую платформу в будущем, достаточно
// добавить запись в PLATFORMS и реализовать адаптер — остальной код (черновики,
// очередь, планировщик, история, аналитика, журнал) уже платформо-независим.
//
// На этом этапе полностью реализован только Telegram (через edge-функцию
// /publish). Остальные платформы зарегистрированы как «в разработке» и не
// ломают публикацию: если платформа недоступна, остальные продолжают работать.
// ─────────────────────────────────────────────────────────────────────────────

export type Platform = 'telegram' | 'vk' | 'instagram' | 'tiktok' | 'youtube'

interface PubPost {
  id: string
  title: string
  text: string
  mediaUrl?: string          // первое медиа (видео или первое фото) — для совместимости
  mediaType?: 'image' | 'video'
  photos?: string[]          // до 3 фото (альбом); mediaUrl = photos[0]
  platforms: Platform[]
  buttonText: string
  createdAt: number
  updatedAt: number
}
interface QueueItem extends PubPost { scheduledAt: number; attempts: number; lastError?: string }
interface HistoryItem extends PubPost {
  publishedAt: number
  results: Partial<Record<Platform, { ok: boolean; error?: string }>>
  views: number
  clicks: number
}
interface PubEvent { id: string; ts: number; type: string; source: string; message: string; status: 'ok' | 'error' | 'info' }
interface PubSettings {
  channelId: string
  buttonText: string
  buttonUrl: string
  tokens: Record<Platform, string>
  notifications: Record<string, boolean>
  vkGroupId: string   // числовой ID сообщества VK (owner_id = -vkGroupId)
  webUrl: string      // публичная веб-ссылка магазина для соцсетей (не t.me)
}

const MINI_APP_URL = 'https://t.me/Sigma_Space_Bot/sigma'

const PLATFORMS: Array<{ key: Platform; label: string; emoji: string; live: boolean }> = [
  { key: 'telegram',  label: 'Telegram',        emoji: '✈️', live: true },
  { key: 'vk',        label: 'VK',              emoji: '🅥',  live: true },
  { key: 'instagram', label: 'Instagram',       emoji: '📷', live: false },
  { key: 'tiktok',    label: 'TikTok',          emoji: '🎵', live: false },
  { key: 'youtube',   label: 'YouTube Shorts',  emoji: '▶️', live: false },
]
const PLATFORM_LABEL: Record<Platform, string> = Object.fromEntries(PLATFORMS.map(p => [p.key, p.label])) as Record<Platform, string>
const PLATFORM_EMOJI: Record<Platform, string> = Object.fromEntries(PLATFORMS.map(p => [p.key, p.emoji])) as Record<Platform, string>

// Короткая подсказка, где взять API-ключ для каждой платформы.
const PLATFORM_HINT: Record<Platform, string> = {
  telegram:  'Работает через серверный секрет бота — токен здесь не нужен, укажите только Channel ID выше.',
  vk:        'Ключ доступа сообщества (VK → Управление → Работа с API → Ключи доступа).',
  instagram: 'Access Token из Meta for Developers (Instagram Graph API).',
  tiktok:    'Access Token из TikTok for Developers (Content Posting API).',
  youtube:   'OAuth-токен канала (Google Cloud → YouTube Data API v3).',
}

// Платформа считается «подключённой», когда владелец дал доступ: Telegram — через
// серверный секрет + Channel ID; остальные — по вставленному API-ключу. Именно от
// этого зависят бейджи «скоро/подключено» и активность кнопок выбора платформ.
function platformConnected(key: Platform, s: PubSettings): boolean {
  if (key === 'telegram') return !!s.channelId.trim()
  return !!(s.tokens[key] || '').trim()
}

type AdapterResult = { ok: boolean; error?: string }
type Adapter = (post: PubPost, s: PubSettings) => Promise<AdapterResult>

// Реестр адаптеров платформ. Единственная точка, которую нужно расширять при
// добавлении новых платформ.
const PLATFORM_ADAPTERS: Record<Platform, Adapter> = {
  telegram: async (post, s) => {
    if (!s.channelId.trim()) return { ok: false, error: 'Не указан Telegram Channel ID (Настройки)' }
    const isVideo = post.mediaType === 'video'
    const photos = postPhotos(post)
    const caption = [post.title.trim() ? `<b>${post.title.trim()}</b>` : '', post.text.trim()].filter(Boolean).join('\n\n')
    try {
      const r = await publishPost({
        photoUrl: !isVideo && photos.length === 1 ? photos[0] : undefined,
        photos: !isVideo && photos.length > 1 ? photos : undefined,
        videoUrl: isVideo ? post.mediaUrl : undefined,
        caption,
        buttonText: post.buttonText || s.buttonText || '🛍 Открыть магазин',
        channelId: s.channelId.trim(),
      })
      return r?.ok ? { ok: true } : { ok: false, error: r?.error || 'Сервер вернул ошибку' }
    } catch (e) {
      return { ok: false, error: (e as Error).message }
    }
  },
  vk: async (post, s) => {
    if (!(s.tokens.vk || '').trim()) return { ok: false, error: 'Не указан API-ключ VK (Настройки)' }
    if (!(s.vkGroupId || '').trim()) return { ok: false, error: 'Не указан ID сообщества VK (Настройки)' }
    if (post.mediaType === 'video') return { ok: false, error: 'Публикация видео в VK пока не поддерживается — используйте фото или текст' }
    const message = [post.title.trim(), post.text.trim()].filter(Boolean).join('\n\n')
    try {
      const r = await publishVk({
        token: s.tokens.vk.trim(),
        groupId: s.vkGroupId.trim(),
        message,
        photos: postPhotos(post),
        linkUrl: (s.webUrl || '').trim() || undefined,
      })
      return r?.ok ? { ok: true } : { ok: false, error: r?.error || 'VK вернул ошибку' }
    } catch (e) {
      return { ok: false, error: (e as Error).message }
    }
  },
  instagram: async () => ({ ok: false, error: 'Интеграция Instagram в разработке' }),
  tiktok:    async () => ({ ok: false, error: 'Интеграция TikTok в разработке' }),
  youtube:   async () => ({ ok: false, error: 'Интеграция YouTube в разработке' }),
}

// Типы уведомлений владельцу — каждое можно включить/выключить отдельно.
const NOTIF_TYPES: Array<{ key: string; label: string; wired: boolean }> = [
  { key: 'newOrder',       label: 'Новый заказ',                   wired: false },
  { key: 'paymentSuccess', label: 'Успешная оплата',              wired: false },
  { key: 'paymentError',   label: 'Ошибка оплаты',                wired: false },
  { key: 'orderCancel',    label: 'Отмена заказа',                wired: false },
  { key: 'refund',         label: 'Возврат средств',              wired: false },
  { key: 'newUser',        label: 'Новый пользователь',           wired: false },
  { key: 'newReview',      label: 'Новый отзыв',                  wired: false },
  { key: 'publishSuccess', label: 'Успешная публикация',          wired: true },
  { key: 'publishError',   label: 'Ошибка публикации',            wired: true },
  { key: 'scheduledDone',  label: 'Выполнена отложенная публикация', wired: true },
  { key: 'apiError',       label: 'Ошибки API',                   wired: true },
  { key: 'systemError',    label: 'Системные ошибки',             wired: true },
  { key: 'lowStock',       label: 'Низкий остаток товара',        wired: false },
  { key: 'outOfStock',     label: 'Отсутствие товара',            wired: false },
  { key: 'tokenRefresh',   label: 'Требуется обновить токен API',  wired: false },
]

const DEFAULT_SETTINGS: PubSettings = {
  channelId: '',
  buttonText: '🛍 Открыть магазин',
  buttonUrl: MINI_APP_URL,
  tokens: { telegram: '', vk: '', instagram: '', tiktok: '', youtube: '' },
  notifications: Object.fromEntries(NOTIF_TYPES.map(n => [n.key, true])),
  vkGroupId: '',
  webUrl: MINI_APP_URL,
}

// kv-ключи модуля (не пересекаются с существующими данными магазина).
const K = { drafts: 'pub_drafts', queue: 'pub_queue', history: 'pub_history', events: 'pub_events', settings: 'pub_settings' }

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7)
const now = () => Date.now()

// Список фото поста с учётом обратной совместимости (старые посты без photos[]).
function postPhotos(post: PubPost): string[] {
  if (post.photos && post.photos.length) return post.photos
  if (post.mediaType === 'image' && post.mediaUrl) return [post.mediaUrl]
  return []
}

function fmtDateTime(ts: number) {
  const d = new Date(ts)
  return d.toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' })
}
function toLocalInput(ts: number) {
  const d = new Date(ts - d0offset(ts))
  return d.toISOString().slice(0, 16)
}
function d0offset(ts: number) { return new Date(ts).getTimezoneOffset() * 60000 }

type PubTab = 'create' | 'drafts' | 'queue' | 'history' | 'analytics' | 'notify' | 'log' | 'settings'
const PUB_TABS: Array<{ key: PubTab; label: string; icon: IconName }> = [
  { key: 'create',    label: 'Создать',     icon: 'plus' },
  { key: 'drafts',    label: 'Черновики',   icon: 'document' },
  { key: 'queue',     label: 'Очередь',     icon: 'layers' },
  { key: 'history',   label: 'История',     icon: 'sort' },
  { key: 'analytics', label: 'Аналитика',   icon: 'calculator' },
  { key: 'notify',    label: 'Уведомления', icon: 'bell' },
  { key: 'log',       label: 'Журнал',      icon: 'search' },
  { key: 'settings',  label: 'Настройки',   icon: 'gear' },
]

// ── общие мелкие компоненты в стиле проекта ──────────────────────────────────
function Card({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '14px', padding: '14px', ...style }}>{children}</div>
}
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: '12px' }}>
      <p style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 600, margin: '0 0 6px' }}>{label}</p>
      {children}
    </div>
  )
}
const inputStyle: React.CSSProperties = { width: '100%', boxSizing: 'border-box', background: 'var(--bg-elevated)', border: '1px solid var(--border)', borderRadius: '10px', padding: '10px 12px', color: 'var(--text-primary)', fontSize: '13px', fontFamily: 'inherit' }

function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!on)} style={{ width: '42px', height: '24px', borderRadius: '13px', border: 'none', cursor: 'pointer', background: on ? 'var(--accent)' : 'var(--bg-elevated)', position: 'relative', transition: 'background 0.2s', flexShrink: 0 }}>
      <span style={{ position: 'absolute', top: '3px', left: on ? '21px' : '3px', width: '18px', height: '18px', borderRadius: '50%', background: '#fff', transition: 'left 0.2s' }} />
    </button>
  )
}

export default function PublicationsModule() {
  const [tab, setTab] = useState<PubTab>('create')
  const [drafts, setDrafts] = useState<PubPost[]>([])
  const [queue, setQueue] = useState<QueueItem[]>([])
  const [history, setHistory] = useState<HistoryItem[]>([])
  const [events, setEvents] = useState<PubEvent[]>([])
  const [settings, setSettings] = useState<PubSettings>(DEFAULT_SETTINGS)
  const [loaded, setLoaded] = useState(false)
  const [toast, setToast] = useState('')

  const flash = useCallback((t: string) => { setToast(t); setTimeout(() => setToast(''), 2600) }, [])

  // ── загрузка из облака ──
  useEffect(() => {
    let alive = true
    ;(async () => {
      try {
        const res = await kv.mget([K.drafts, K.queue, K.history, K.events, K.settings, 'channelId', 'publishButtonText'])
        if (!alive) return
        setDrafts(Array.isArray(res[K.drafts]) ? res[K.drafts] : [])
        setQueue(Array.isArray(res[K.queue]) ? res[K.queue] : [])
        setHistory(Array.isArray(res[K.history]) ? res[K.history] : [])
        setEvents(Array.isArray(res[K.events]) ? res[K.events] : [])
        const s: PubSettings = { ...DEFAULT_SETTINGS, ...(res[K.settings] || {}), tokens: { ...DEFAULT_SETTINGS.tokens, ...(res[K.settings]?.tokens || {}) }, notifications: { ...DEFAULT_SETTINGS.notifications, ...(res[K.settings]?.notifications || {}) } }
        // Совместимость со старой вкладкой «Публикация»: канал и текст кнопки.
        if (!s.channelId && typeof res.channelId === 'string') s.channelId = res.channelId
        if (typeof res.publishButtonText === 'string' && res.publishButtonText) s.buttonText = res.publishButtonText
        setSettings(s)
      } catch { /* офлайн — работаем с пустыми данными */ }
      if (alive) setLoaded(true)
    })()
    return () => { alive = false }
  }, [])

  // ── персист-хелперы ──
  const saveDrafts  = useCallback((v: PubPost[])    => { setDrafts(v);  kv.set(K.drafts, v).catch(() => {}) }, [])
  const saveQueue   = useCallback((v: QueueItem[])  => { setQueue(v);   kv.set(K.queue, v).catch(() => {}) }, [])
  const saveHistory = useCallback((v: HistoryItem[])=> { setHistory(v); kv.set(K.history, v).catch(() => {}) }, [])

  const logEvent = useCallback((type: string, source: string, message: string, status: PubEvent['status']) => {
    setEvents(prev => {
      const next = [{ id: uid(), ts: now(), type, source, message, status }, ...prev].slice(0, 500)
      kv.set(K.events, next).catch(() => {})
      return next
    })
  }, [])

  const notifyOwner = useCallback((type: string, text: string) => {
    if (!settings.notifications[type]) return
    notify(text).catch(() => {})
  }, [settings.notifications])

  const saveSettings = useCallback((v: PubSettings) => {
    setSettings(v)
    kv.set(K.settings, v).catch(() => {})
    // Дублируем канал/кнопку в старые ключи, чтобы сервер и старая вкладка их видели.
    kv.set('channelId', v.channelId).catch(() => {})
    kv.set('publishButtonText', v.buttonText).catch(() => {})
  }, [])

  // ── ядро публикации: прогоняет пост по всем выбранным платформам ──
  const runPublish = useCallback(async (post: PubPost): Promise<HistoryItem['results']> => {
    const results: HistoryItem['results'] = {}
    for (const p of post.platforms) {
      // Если одна платформа падает — остальные всё равно выполняются.
      try {
        results[p] = await PLATFORM_ADAPTERS[p](post, settings)
      } catch (e) {
        results[p] = { ok: false, error: (e as Error).message }
      }
    }
    return results
  }, [settings])

  const finalizeToHistory = useCallback((post: PubPost, results: HistoryItem['results']) => {
    const okList = post.platforms.filter(p => results[p]?.ok)
    const failList = post.platforms.filter(p => !results[p]?.ok)
    const item: HistoryItem = { ...post, publishedAt: now(), results, views: 0, clicks: 0 }
    setHistory(prev => { const next = [item, ...prev].slice(0, 300); kv.set(K.history, next).catch(() => {}); return next })
    if (okList.length) {
      logEvent('publish', okList.map(p => PLATFORM_LABEL[p]).join(', '), `Опубликовано: ${post.title || post.text.slice(0, 40) || 'без заголовка'}`, 'ok')
      notifyOwner('publishSuccess', `✅ <b>Публикация выполнена</b>\n${post.title || post.text.slice(0, 60)}\nПлатформы: ${okList.map(p => PLATFORM_LABEL[p]).join(', ')}`)
    }
    if (failList.length) {
      failList.forEach(p => logEvent('publish', PLATFORM_LABEL[p], `Ошибка ${PLATFORM_LABEL[p]}: ${results[p]?.error || 'неизвестно'}`, 'error'))
      notifyOwner('publishError', `⚠️ <b>Ошибка публикации</b>\n${post.title || post.text.slice(0, 60)}\n${failList.map(p => `${PLATFORM_LABEL[p]}: ${results[p]?.error}`).join('\n')}`)
    }
    return item
  }, [logEvent, notifyOwner])

  // ── планировщик очереди: публикует «созревшие» задачи, повторяет при сбое ──
  const processingRef = useRef(false)
  const processQueue = useCallback(async () => {
    if (processingRef.current) return
    const due = queue.filter(q => q.scheduledAt <= now())
    if (!due.length) return
    processingRef.current = true
    try {
      let current = queue
      for (const task of due) {
        const results = await runPublish(task)
        const failedLive = task.platforms.filter(p => !results[p]?.ok && PLATFORMS.find(pl => pl.key === p)?.live)
        // Временный сбой live-платформы и попыток ещё меньше 3 — переносим на +2 мин.
        if (failedLive.length && task.attempts < 2) {
          current = current.map(q => q.id === task.id ? { ...q, attempts: q.attempts + 1, lastError: results[failedLive[0]]?.error, scheduledAt: now() + 2 * 60000 } : q)
          logEvent('queue', 'Планировщик', `Повтор попытки (${task.attempts + 1}/3): ${task.title || 'пост'}`, 'info')
        } else {
          finalizeToHistory(task, results)
          current = current.filter(q => q.id !== task.id)
          notifyOwner('scheduledDone', `⏰ <b>Отложенная публикация выполнена</b>\n${task.title || task.text.slice(0, 60)}`)
        }
      }
      saveQueue(current)
    } finally {
      processingRef.current = false
    }
  }, [queue, runPublish, finalizeToHistory, saveQueue, logEvent, notifyOwner])

  useEffect(() => {
    if (!loaded) return
    processQueue()
    const t = setInterval(processQueue, 30000)
    return () => clearInterval(t)
  }, [loaded, processQueue])

  // ── публикация «прямо сейчас» ──
  const publishNow = useCallback(async (post: PubPost) => {
    flash('Публикуем…')
    const results = await runPublish(post)
    finalizeToHistory(post, results)
    const ok = post.platforms.some(p => results[p]?.ok)
    flash(ok ? 'Опубликовано ✓' : 'Не удалось опубликовать')
    setTab('history')
  }, [runPublish, finalizeToHistory, flash])

  const enqueue = useCallback((post: PubPost, at: number) => {
    const item: QueueItem = { ...post, scheduledAt: at, attempts: 0 }
    saveQueue([...queue, item].sort((a, b) => a.scheduledAt - b.scheduledAt))
    logEvent('queue', 'Очередь', `Запланировано на ${fmtDateTime(at)}: ${post.title || 'пост'}`, 'info')
    flash('Добавлено в очередь ✓')
    setTab('queue')
  }, [queue, saveQueue, logEvent, flash])

  if (!loaded) return <div style={{ padding: '40px', textAlign: 'center', color: 'var(--text-muted)', fontSize: '13px' }}>Загрузка модуля публикаций…</div>

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', minHeight: 0 }}>
      {/* Заголовок */}
      <div style={{ padding: '12px 14px 6px' }}>
        <p style={{ color: 'var(--text-primary)', fontSize: '15px', fontWeight: 800, margin: 0 }}>Публикации</p>
        <p style={{ color: 'var(--text-muted)', fontSize: '11px', margin: '2px 0 0' }}>Единый центр контента для соцсетей</p>
      </div>

      {/* Подвкладки */}
      <div ref={hScroll} style={{ display: 'flex', gap: '6px', overflowX: 'auto', scrollbarWidth: 'none', padding: '4px 12px 10px', flexShrink: 0, WebkitOverflowScrolling: 'touch' }}>
        {PUB_TABS.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)} style={{ flexShrink: 0, display: 'flex', alignItems: 'center', gap: '6px', padding: '8px 12px', borderRadius: '10px', border: `1px solid ${tab === t.key ? 'var(--accent)' : 'var(--border)'}`, background: tab === t.key ? 'var(--accent-glow)' : 'var(--bg-card)', cursor: 'pointer' }}>
            <Icon name={t.icon} size={14} color={tab === t.key ? 'var(--accent)' : 'var(--text-muted)'} />
            <span style={{ fontSize: '12px', fontWeight: 600, color: tab === t.key ? 'var(--accent)' : 'var(--text-secondary)', whiteSpace: 'nowrap' }}>{t.label}</span>
            {t.key === 'queue' && queue.length > 0 && <span style={{ fontSize: '10px', fontWeight: 700, color: '#fff', background: 'var(--accent)', borderRadius: '9px', padding: '1px 6px' }}>{queue.length}</span>}
          </button>
        ))}
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '0 12px 20px', minHeight: 0 }}>
        {tab === 'create'   && <Composer settings={settings} drafts={drafts} saveDrafts={saveDrafts} onPublishNow={publishNow} onSchedule={enqueue} flash={flash} logEvent={logEvent} />}
        {tab === 'drafts'   && <DraftsView drafts={drafts} saveDrafts={saveDrafts} onPublishNow={publishNow} onSchedule={enqueue} settings={settings} flash={flash} />}
        {tab === 'queue'    && <QueueView queue={queue} saveQueue={saveQueue} logEvent={logEvent} flash={flash} />}
        {tab === 'history'  && <HistoryView history={history} saveHistory={saveHistory} onRepublish={publishNow} />}
        {tab === 'analytics'&& <AnalyticsView history={history} />}
        {tab === 'notify'   && <NotifyView settings={settings} saveSettings={saveSettings} />}
        {tab === 'log'      && <LogView events={events} onClear={() => { setEvents([]); kv.set(K.events, []).catch(() => {}) }} />}
        {tab === 'settings' && <SettingsView settings={settings} saveSettings={saveSettings} flash={flash} />}
      </div>

      {toast && <div className="toast-enter" style={{ position: 'absolute', bottom: '16px', left: '50%', transform: 'translateX(-50%)', background: 'var(--accent)', color: '#fff', borderRadius: '10px', padding: '9px 18px', fontSize: '12px', fontWeight: 600, zIndex: 200, boxShadow: '0 8px 26px var(--accent-glow)' }}>{toast}</div>}
    </div>
  )
}

// ── платформенный селектор ───────────────────────────────────────────────────
function PlatformPicker({ value, onChange, settings }: { value: Platform[]; onChange: (v: Platform[]) => void; settings: PubSettings }) {
  const toggle = (k: Platform) => onChange(value.includes(k) ? value.filter(x => x !== k) : [...value, k])
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
      {PLATFORMS.map(p => {
        const on = value.includes(p.key)
        const connected = platformConnected(p.key, settings)
        return (
          <button key={p.key} onClick={() => toggle(p.key)} style={{ display: 'flex', alignItems: 'center', gap: '6px', padding: '8px 11px', borderRadius: '10px', border: `1px solid ${on ? 'var(--accent)' : 'var(--border)'}`, background: on ? 'var(--accent-glow)' : 'var(--bg-elevated)', cursor: 'pointer', position: 'relative' }}>
            <span style={{ fontSize: '14px' }}>{p.emoji}</span>
            <span style={{ fontSize: '12px', fontWeight: 600, color: on ? 'var(--accent)' : 'var(--text-secondary)' }}>{p.label}</span>
            {/* Бейдж зависит от наличия ключа: подключено → зелёная точка, иначе «скоро». */}
            {connected
              ? <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: 'var(--success)', flexShrink: 0 }} title="Подключено" />
              : <span style={{ fontSize: '8px', fontWeight: 700, color: 'var(--text-muted)', background: 'var(--bg-card)', borderRadius: '5px', padding: '1px 4px', textTransform: 'uppercase' }}>скоро</span>}
            {on && <Icon name="check" size={12} color="var(--accent)" />}
          </button>
        )
      })}
    </div>
  )
}

// ── создание / редактирование поста ──────────────────────────────────────────
function Composer({ settings, drafts, saveDrafts, onPublishNow, onSchedule, flash, logEvent, editing, onDoneEdit }: {
  settings: PubSettings; drafts: PubPost[]; saveDrafts: (v: PubPost[]) => void
  onPublishNow: (p: PubPost) => void; onSchedule: (p: PubPost, at: number) => void
  flash: (t: string) => void; logEvent: (type: string, source: string, message: string, status: PubEvent['status']) => void
  editing?: PubPost; onDoneEdit?: () => void
}) {
  const MAX_PHOTOS = 3
  const [title, setTitle] = useState(editing?.title ?? '')
  const [text, setText] = useState(editing?.text ?? '')
  const [platforms, setPlatforms] = useState<Platform[]>(editing?.platforms ?? ['telegram'])
  const [photos, setPhotos] = useState<string[]>(editing ? postPhotos(editing) : [])
  const [videoUrl, setVideoUrl] = useState<string | undefined>(editing?.mediaType === 'video' ? editing.mediaUrl : undefined)
  const [buttonText, setButtonText] = useState(editing?.buttonText ?? settings.buttonText)
  const [uploading, setUploading] = useState(false)
  const [when, setWhen] = useState(toLocalInput(now() + 3600_000))
  const photoInputRef = useRef<HTMLInputElement>(null)
  const videoInputRef = useRef<HTMLInputElement>(null)

  // Редактор обрезки: открывается перед вставкой каждого фото.
  const [cropSrc, setCropSrc] = useState<string | null>(null)
  const [crop, setCrop] = useState({ x: 0, y: 0 })
  const [zoom, setZoom] = useState(1)
  const [aspect, setAspect] = useState(1)
  const cropPixels = useRef<PixelCrop | null>(null)
  const ASPECTS: Array<{ label: string; v: number }> = [{ label: '1:1', v: 1 }, { label: '4:5', v: 4 / 5 }, { label: '16:9', v: 16 / 9 }]

  const buildPost = (): PubPost => {
    const isVideo = !!videoUrl
    return {
      id: editing?.id ?? uid(), title, text,
      mediaUrl: isVideo ? videoUrl : photos[0],
      mediaType: isVideo ? 'video' : (photos.length ? 'image' : undefined),
      photos: isVideo ? undefined : photos,
      platforms,
      buttonText: buttonText || settings.buttonText,
      createdAt: editing?.createdAt ?? now(), updatedAt: now(),
    }
  }

  // Выбор фото → сразу открываем редактор обрезки (не грузим до подтверждения).
  const onPhotoFile = (file: File) => { setCrop({ x: 0, y: 0 }); setZoom(1); setCropSrc(URL.createObjectURL(file)) }
  const closeCrop = () => { if (cropSrc) URL.revokeObjectURL(cropSrc); setCropSrc(null) }

  const applyCrop = async () => {
    if (!cropSrc || !cropPixels.current) return
    setUploading(true)
    try {
      const file = await getCroppedRectFile(cropSrc, cropPixels.current, 1600)
      const url = await storage.upload(file)
      setPhotos(prev => [...prev, url].slice(0, MAX_PHOTOS))
      setVideoUrl(undefined)
      flash('Фото добавлено ✓')
      closeCrop()
    } catch (e) {
      flash('Ошибка: ' + (e as Error).message)
      logEvent('media', 'Обрезка', (e as Error).message, 'error')
    } finally {
      setUploading(false)
    }
  }

  const uploadVideo = async (file: File) => {
    setUploading(true)
    try {
      const url = await storage.upload(file)
      setVideoUrl(url); setPhotos([])
      flash('Видео загружено ✓')
    } catch (e) {
      flash('Ошибка загрузки: ' + (e as Error).message)
      logEvent('media', 'Загрузка', (e as Error).message, 'error')
    } finally {
      setUploading(false)
    }
  }

  const valid = (text.trim() || photos.length > 0 || videoUrl) && platforms.length > 0
  const captionLen = (title ? title.length + 2 : 0) + text.length

  const saveDraft = () => {
    const post = buildPost()
    const exists = drafts.some(d => d.id === post.id)
    saveDrafts(exists ? drafts.map(d => d.id === post.id ? post : d) : [post, ...drafts])
    flash('Сохранено в черновики ✓')
    onDoneEdit?.()
  }

  return (
    <div>
      <Card style={{ marginBottom: '12px' }}>
        <Field label="Платформы"><PlatformPicker value={platforms} onChange={setPlatforms} settings={settings} /></Field>

        <Field label="Заголовок">
          <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Заголовок поста (необязательно)" style={inputStyle} />
        </Field>

        <Field label={`Текст публикации · ${captionLen}/1024 · поддержка HTML`}>
          <textarea value={text} onChange={e => setText(e.target.value)} rows={5} maxLength={1024}
            placeholder="Текст поста. Можно использовать <b>жирный</b>, <i>курсив</i>, <a href='…'>ссылки</a>." style={{ ...inputStyle, resize: 'vertical' }} />
        </Field>

        <Field label={`Фото (до ${MAX_PHOTOS}) или видео`}>
          <input ref={photoInputRef} type="file" accept="image/*" hidden onChange={e => { const f = e.target.files?.[0]; if (f) onPhotoFile(f); e.currentTarget.value = '' }} />
          <input ref={videoInputRef} type="file" accept="video/*" hidden onChange={e => { const f = e.target.files?.[0]; if (f) uploadVideo(f); e.currentTarget.value = '' }} />

          {videoUrl ? (
            <div style={{ position: 'relative', borderRadius: '12px', overflow: 'hidden', border: '1px solid var(--border)' }}>
              <video src={videoUrl} controls style={{ width: '100%', display: 'block', maxHeight: '240px', background: '#000' }} />
              <button onClick={() => setVideoUrl(undefined)} style={{ position: 'absolute', top: '8px', right: '8px', width: '28px', height: '28px', borderRadius: '8px', background: 'rgba(0,0,0,0.6)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="close" size={15} color="#fff" /></button>
            </div>
          ) : (
            <>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px' }}>
                {photos.map((url, i) => (
                  <div key={url + i} style={{ position: 'relative', aspectRatio: '1', borderRadius: '10px', overflow: 'hidden', border: '1px solid var(--border)' }}>
                    <img src={url} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                    {i === 0 && <span style={{ position: 'absolute', bottom: '4px', left: '4px', fontSize: '8px', fontWeight: 700, color: '#fff', background: 'rgba(0,0,0,0.6)', borderRadius: '5px', padding: '1px 5px' }}>обложка</span>}
                    <button onClick={() => setPhotos(prev => prev.filter((_, idx) => idx !== i))} style={{ position: 'absolute', top: '4px', right: '4px', width: '22px', height: '22px', borderRadius: '7px', background: 'rgba(0,0,0,0.6)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name="close" size={12} color="#fff" /></button>
                  </div>
                ))}
                {photos.length < MAX_PHOTOS && (
                  <button onClick={() => photoInputRef.current?.click()} disabled={uploading} style={{ aspectRatio: '1', borderRadius: '10px', background: 'var(--bg-elevated)', border: '1px dashed var(--border)', cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '4px' }}>
                    <Icon name="camera" size={18} color="var(--accent)" />
                    <span style={{ color: 'var(--text-secondary)', fontSize: '10px', fontWeight: 600 }}>Добавить</span>
                  </button>
                )}
              </div>
              {photos.length === 0 && (
                <button onClick={() => videoInputRef.current?.click()} disabled={uploading} style={{ ...inputStyle, marginTop: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', cursor: 'pointer', padding: '12px', borderStyle: 'dashed' }}>
                  <Icon name="film" size={15} color="var(--accent)" />
                  <span style={{ color: 'var(--text-secondary)', fontSize: '12px', fontWeight: 600 }}>{uploading ? 'Загрузка…' : 'Или загрузить видео'}</span>
                </button>
              )}
              <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '8px 0 0', lineHeight: 1.5 }}>Перед вставкой фото можно обрезать и подвинуть. Несколько фото публикуются альбомом (в Telegram-альбоме ссылка на магазин добавляется текстом).</p>
            </>
          )}
        </Field>

        <Field label="Текст кнопки под постом">
          <input value={buttonText} onChange={e => setButtonText(e.target.value)} placeholder="🛍 Открыть магазин" style={inputStyle} />
          <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', margin: '6px 0 0' }}>Кнопка ведёт на Mini App: {settings.buttonUrl}</p>
        </Field>
      </Card>

      {/* Предпросмотр */}
      <p style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 700, margin: '0 0 8px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Предпросмотр</p>
      <div style={{ background: 'var(--bg-elevated)', borderRadius: '14px', padding: '10px', marginBottom: '14px', border: '1px solid var(--border)' }}>
        {videoUrl
          ? <video src={videoUrl} controls style={{ width: '100%', borderRadius: '10px', maxHeight: '200px', background: '#000' }} />
          : photos.length === 1
            ? <img src={photos[0]} alt="" style={{ width: '100%', borderRadius: '10px', maxHeight: '200px', objectFit: 'cover' }} />
            : photos.length > 1
              ? <div style={{ display: 'grid', gridTemplateColumns: `repeat(${photos.length}, 1fr)`, gap: '4px' }}>
                  {photos.map((url, i) => <img key={url + i} src={url} alt="" style={{ width: '100%', borderRadius: '8px', aspectRatio: '1', objectFit: 'cover' }} />)}
                </div>
              : null}
        <div style={{ padding: '8px 4px 4px' }}>
          {title && <p style={{ color: 'var(--text-primary)', fontSize: '14px', fontWeight: 800, margin: '0 0 4px' }}>{title}</p>}
          <p style={{ color: 'var(--text-secondary)', fontSize: '12.5px', margin: 0, whiteSpace: 'pre-wrap', lineHeight: 1.5 }}>{text || <span style={{ color: 'var(--text-muted)' }}>Текст поста…</span>}</p>
        </div>
        <div style={{ marginTop: '8px', background: 'var(--accent)', color: '#fff', borderRadius: '9px', padding: '9px', textAlign: 'center', fontSize: '13px', fontWeight: 700 }}>{buttonText || settings.buttonText}</div>
      </div>

      {/* Действия */}
      <div style={{ display: 'flex', gap: '8px', marginBottom: '10px' }}>
        <button className="btn-secondary" style={{ flex: 1 }} onClick={saveDraft} disabled={!valid}>В черновики</button>
        <button className="btn-primary" style={{ flex: 1, opacity: valid ? 1 : 0.5 }} disabled={!valid} onClick={() => { onPublishNow(buildPost()); onDoneEdit?.() }}>Опубликовать</button>
      </div>

      <Card>
        <Field label="Отложенная публикация — дата и время">
          <input type="datetime-local" value={when} onChange={e => setWhen(e.target.value)} style={inputStyle} />
        </Field>
        <button className="btn-primary" disabled={!valid} style={{ opacity: valid ? 1 : 0.5 }}
          onClick={() => { const at = new Date(when).getTime(); if (at < now()) { flash('Выберите время в будущем'); return } onSchedule(buildPost(), at); onDoneEdit?.() }}>
          Запланировать
        </button>
      </Card>

      {/* Редактор обрезки фото — двигай и масштабируй перед вставкой */}
      {cropSrc && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 300, background: 'rgba(0,0,0,0.92)', display: 'flex', flexDirection: 'column' }}>
          <div style={{ position: 'relative', flex: 1, minHeight: 0 }}>
            <Cropper image={cropSrc} crop={crop} zoom={zoom} aspect={aspect} showGrid
              onCropChange={setCrop} onZoomChange={setZoom} onCropComplete={(_, px) => { cropPixels.current = px }} />
          </div>
          <div style={{ padding: '14px 16px calc(14px + env(safe-area-inset-bottom))', background: 'var(--bg-card)', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            <div style={{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
              {ASPECTS.map(a => (
                <button key={a.label} onClick={() => setAspect(a.v)} style={{ padding: '6px 14px', borderRadius: '9px', border: `1px solid ${aspect === a.v ? 'var(--accent)' : 'var(--border)'}`, background: aspect === a.v ? 'var(--accent-glow)' : 'var(--bg-elevated)', color: aspect === a.v ? 'var(--accent)' : 'var(--text-secondary)', fontSize: '12px', fontWeight: 600, cursor: 'pointer' }}>{a.label}</button>
              ))}
            </div>
            <input type="range" min={1} max={3} step={0.01} value={zoom} onChange={e => setZoom(Number(e.target.value))} style={{ width: '100%', accentColor: 'var(--accent)' }} />
            <div style={{ display: 'flex', gap: '8px' }}>
              <button className="btn-secondary" style={{ flex: 1 }} onClick={closeCrop} disabled={uploading}>Отмена</button>
              <button className="btn-primary" style={{ flex: 2 }} onClick={applyCrop} disabled={uploading}>{uploading ? 'Загрузка…' : 'Готово'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ── черновики ────────────────────────────────────────────────────────────────
function DraftsView({ drafts, saveDrafts, onPublishNow, onSchedule, settings, flash }: {
  drafts: PubPost[]; saveDrafts: (v: PubPost[]) => void; onPublishNow: (p: PubPost) => void
  onSchedule: (p: PubPost, at: number) => void; settings: PubSettings; flash: (t: string) => void
}) {
  const [editing, setEditing] = useState<PubPost | null>(null)
  if (editing) return <Composer editing={editing} settings={settings} drafts={drafts} saveDrafts={saveDrafts} onPublishNow={onPublishNow} onSchedule={onSchedule} flash={flash} logEvent={() => {}} onDoneEdit={() => setEditing(null)} />
  if (!drafts.length) return <Empty icon="document" text="Черновиков пока нет" />
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
      {drafts.map(d => (
        <Card key={d.id}>
          <PostSummary post={d} />
          <div style={{ display: 'flex', gap: '8px', marginTop: '10px' }}>
            <button className="btn-secondary" style={{ flex: 1, fontSize: '12px', padding: '8px' }} onClick={() => setEditing(d)}>Изменить</button>
            <button className="btn-primary" style={{ flex: 1, fontSize: '12px', padding: '8px' }} onClick={() => { saveDrafts(drafts.filter(x => x.id !== d.id)); onPublishNow(d) }}>Опубликовать</button>
            <button onClick={() => { if (confirm('Удалить черновик?')) saveDrafts(drafts.filter(x => x.id !== d.id)) }} style={iconBtn}><Icon name="trash" size={15} color="var(--danger)" /></button>
          </div>
        </Card>
      ))}
    </div>
  )
}

// ── очередь ──────────────────────────────────────────────────────────────────
function QueueView({ queue, saveQueue, logEvent, flash }: {
  queue: QueueItem[]; saveQueue: (v: QueueItem[]) => void
  logEvent: (type: string, source: string, message: string, status: PubEvent['status']) => void; flash: (t: string) => void
}) {
  const [editId, setEditId] = useState<string | null>(null)
  const [when, setWhen] = useState('')

  // Мини-календарь: сколько задач на каждый день ближайшего месяца.
  const byDay = useMemo(() => {
    const m: Record<string, number> = {}
    queue.forEach(q => { const k = new Date(q.scheduledAt).toDateString(); m[k] = (m[k] || 0) + 1 })
    return m
  }, [queue])
  const days = useMemo(() => Array.from({ length: 35 }, (_, i) => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() + i - d.getDay() + 1); return d }), [])

  return (
    <div>
      {/* Календарь очереди */}
      <Card style={{ marginBottom: '12px' }}>
        <p style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 700, margin: '0 0 8px' }}>Календарь публикаций</p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: '4px' }}>
          {['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'].map(d => <div key={d} style={{ textAlign: 'center', fontSize: '9px', color: 'var(--text-muted)', fontWeight: 600 }}>{d}</div>)}
          {days.map(d => {
            const cnt = byDay[d.toDateString()] || 0
            const isToday = d.toDateString() === new Date().toDateString()
            return (
              <div key={d.toISOString()} style={{ aspectRatio: '1', borderRadius: '8px', border: `1px solid ${isToday ? 'var(--accent)' : 'var(--border)'}`, background: cnt ? 'var(--accent-glow)' : 'var(--bg-elevated)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <span style={{ fontSize: '11px', fontWeight: 700, color: cnt ? 'var(--accent)' : 'var(--text-secondary)' }}>{d.getDate()}</span>
                {cnt > 0 && <span style={{ fontSize: '8px', fontWeight: 700, color: 'var(--accent)' }}>{cnt}</span>}
              </div>
            )
          })}
        </div>
      </Card>

      {!queue.length ? <Empty icon="layers" text="Очередь пуста" /> : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          {queue.map(q => (
            <Card key={q.id}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
                <Icon name="bell" size={13} color="var(--accent)" />
                <span style={{ fontSize: '12px', fontWeight: 700, color: 'var(--accent)' }}>{fmtDateTime(q.scheduledAt)}</span>
                {q.attempts > 0 && <span style={{ fontSize: '10px', color: 'var(--danger)', fontWeight: 600 }}>· попытка {q.attempts + 1}/3</span>}
              </div>
              <PostSummary post={q} />
              {q.lastError && <p style={{ color: 'var(--danger)', fontSize: '10.5px', margin: '6px 0 0' }}>Последняя ошибка: {q.lastError}</p>}
              {editId === q.id ? (
                <div style={{ display: 'flex', gap: '8px', marginTop: '10px' }}>
                  <input type="datetime-local" value={when} onChange={e => setWhen(e.target.value)} style={{ ...inputStyle, flex: 1 }} />
                  <button className="btn-primary" style={{ padding: '8px 12px', fontSize: '12px' }} onClick={() => { const at = new Date(when).getTime(); if (at < now()) { flash('Время в будущем'); return } saveQueue(queue.map(x => x.id === q.id ? { ...x, scheduledAt: at } : x).sort((a, b) => a.scheduledAt - b.scheduledAt)); setEditId(null); flash('Время изменено ✓') }}>ОК</button>
                </div>
              ) : (
                <div style={{ display: 'flex', gap: '8px', marginTop: '10px' }}>
                  <button className="btn-secondary" style={{ flex: 1, fontSize: '12px', padding: '8px' }} onClick={() => { setEditId(q.id); setWhen(toLocalInput(q.scheduledAt)) }}>Изменить время</button>
                  <button onClick={() => { if (confirm('Удалить из очереди?')) { saveQueue(queue.filter(x => x.id !== q.id)); logEvent('queue', 'Очередь', `Отменена публикация: ${q.title || 'пост'}`, 'info') } }} style={iconBtn}><Icon name="trash" size={15} color="var(--danger)" /></button>
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

// ── история ──────────────────────────────────────────────────────────────────
function HistoryView({ history, saveHistory, onRepublish }: {
  history: HistoryItem[]; saveHistory: (v: HistoryItem[]) => void; onRepublish: (p: PubPost) => void
}) {
  if (!history.length) return <Empty icon="sort" text="История пуста" />
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
      {history.map(h => {
        const okCount = Object.values(h.results).filter(r => r?.ok).length
        const failCount = Object.values(h.results).filter(r => r && !r.ok).length
        return (
          <Card key={h.id}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' }}>
              <span style={{ fontSize: '11px', color: 'var(--text-muted)', fontWeight: 600 }}>{fmtDateTime(h.publishedAt)}</span>
              {okCount > 0 && <span style={{ fontSize: '10px', fontWeight: 700, color: 'var(--success)', background: 'rgba(52,201,125,0.14)', borderRadius: '6px', padding: '2px 7px' }}>✓ {okCount}</span>}
              {failCount > 0 && <span style={{ fontSize: '10px', fontWeight: 700, color: 'var(--danger)', background: 'rgba(239,68,68,0.12)', borderRadius: '6px', padding: '2px 7px' }}>✕ {failCount}</span>}
            </div>
            <PostSummary post={h} />
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '5px', marginTop: '8px' }}>
              {h.platforms.map(p => (
                <span key={p} style={{ fontSize: '10px', fontWeight: 600, borderRadius: '6px', padding: '2px 7px', color: h.results[p]?.ok ? 'var(--success)' : 'var(--danger)', background: h.results[p]?.ok ? 'rgba(52,201,125,0.12)' : 'rgba(239,68,68,0.1)' }}>
                  {PLATFORM_EMOJI[p]} {PLATFORM_LABEL[p]}{h.results[p]?.ok ? '' : ' ✕'}
                </span>
              ))}
            </div>
            <div style={{ display: 'flex', gap: '8px', marginTop: '10px' }}>
              <button className="btn-secondary" style={{ flex: 1, fontSize: '12px', padding: '8px' }} onClick={() => onRepublish(h)}>Опубликовать снова</button>
              <button onClick={() => { if (confirm('Удалить из истории?')) saveHistory(history.filter(x => x.id !== h.id)) }} style={iconBtn}><Icon name="trash" size={15} color="var(--danger)" /></button>
            </div>
          </Card>
        )
      })}
    </div>
  )
}

// ── аналитика ────────────────────────────────────────────────────────────────
function AnalyticsView({ history }: { history: HistoryItem[] }) {
  const [period, setPeriod] = useState<'day' | 'week' | 'month'>('day')
  const [platform, setPlatform] = useState<Platform | 'all'>('all')

  const filtered = useMemo(() => platform === 'all' ? history : history.filter(h => h.platforms.includes(platform)), [history, platform])

  const stats = useMemo(() => {
    let ok = 0, fail = 0, views = 0, clicks = 0
    filtered.forEach(h => {
      const rel = platform === 'all' ? Object.values(h.results) : [h.results[platform as Platform]]
      rel.forEach(r => { if (r?.ok) ok++; else if (r) fail++ })
      views += h.views; clicks += h.clicks
    })
    return { total: filtered.length, ok, fail, views, clicks }
  }, [filtered, platform])

  // Группировка по периодам для графика.
  const buckets = useMemo(() => {
    const keyOf = (ts: number) => {
      const d = new Date(ts)
      if (period === 'day') return d.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' })
      if (period === 'week') { const w = new Date(d); w.setDate(d.getDate() - d.getDay() + 1); return w.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' }) }
      return d.toLocaleDateString('ru-RU', { month: 'short', year: '2-digit' })
    }
    const m = new Map<string, number>()
    filtered.forEach(h => { const k = keyOf(h.publishedAt); m.set(k, (m.get(k) || 0) + 1) })
    return Array.from(m.entries()).slice(-8)
  }, [filtered, period])
  const maxBar = Math.max(1, ...buckets.map(b => b[1]))

  const cards: Array<{ label: string; val: number; color: string }> = [
    { label: 'Публикаций', val: stats.total, color: 'var(--accent)' },
    { label: 'Успешных', val: stats.ok, color: 'var(--success)' },
    { label: 'Ошибок', val: stats.fail, color: 'var(--danger)' },
    { label: 'Просмотров', val: stats.views, color: 'var(--text-secondary)' },
    { label: 'Переходов', val: stats.clicks, color: 'var(--text-secondary)' },
  ]

  return (
    <div>
      <div style={{ display: 'flex', gap: '6px', marginBottom: '12px', flexWrap: 'wrap' }}>
        <select value={platform} onChange={e => setPlatform(e.target.value as Platform | 'all')} style={{ ...inputStyle, width: 'auto', flex: 1 }}>
          <option value="all">Все платформы</option>
          {PLATFORMS.map(p => <option key={p.key} value={p.key}>{p.label}</option>)}
        </select>
        <div style={{ display: 'flex', borderRadius: '10px', overflow: 'hidden', border: '1px solid var(--border)' }}>
          {(['day', 'week', 'month'] as const).map(p => (
            <button key={p} onClick={() => setPeriod(p)} style={{ padding: '9px 12px', border: 'none', cursor: 'pointer', fontSize: '11px', fontWeight: 600, background: period === p ? 'var(--accent)' : 'var(--bg-elevated)', color: period === p ? '#fff' : 'var(--text-secondary)' }}>{p === 'day' ? 'Дни' : p === 'week' ? 'Недели' : 'Месяцы'}</button>
          ))}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(90px, 1fr))', gap: '8px', marginBottom: '14px' }}>
        {cards.map(c => (
          <Card key={c.label} style={{ padding: '12px' }}>
            <p style={{ fontSize: '22px', fontWeight: 800, margin: 0, color: c.color }}>{c.val}</p>
            <p style={{ fontSize: '10.5px', color: 'var(--text-muted)', margin: '2px 0 0' }}>{c.label}</p>
          </Card>
        ))}
      </div>

      <Card>
        <p style={{ color: 'var(--text-muted)', fontSize: '11px', fontWeight: 700, margin: '0 0 12px' }}>Публикации по периодам</p>
        {buckets.length ? (
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: '8px', height: '130px' }}>
            {buckets.map(([label, val]) => (
              <div key={label} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '5px', height: '100%', justifyContent: 'flex-end' }}>
                <span style={{ fontSize: '10px', fontWeight: 700, color: 'var(--accent)' }}>{val}</span>
                <div style={{ width: '100%', maxWidth: '32px', height: `${(val / maxBar) * 90}%`, minHeight: '4px', background: 'var(--accent-grad)', borderRadius: '6px 6px 0 0' }} />
                <span style={{ fontSize: '8.5px', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>{label}</span>
              </div>
            ))}
          </div>
        ) : <p style={{ color: 'var(--text-muted)', fontSize: '12px', textAlign: 'center', padding: '20px 0' }}>Недостаточно данных</p>}
      </Card>
      <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '10px 2px 0', lineHeight: 1.5 }}>Просмотры и переходы будут заполняться автоматически по мере подключения статистики платформ.</p>
    </div>
  )
}

// ── уведомления ──────────────────────────────────────────────────────────────
function NotifyView({ settings, saveSettings }: { settings: PubSettings; saveSettings: (v: PubSettings) => void }) {
  const setNotif = (key: string, v: boolean) => saveSettings({ ...settings, notifications: { ...settings.notifications, [key]: v } })
  return (
    <div>
      <Card style={{ marginBottom: '12px' }}>
        <p style={{ color: 'var(--text-secondary)', fontSize: '12px', margin: 0, lineHeight: 1.5 }}>Уведомления приходят владельцу в Telegram. Каждый тип можно включить или выключить отдельно.</p>
      </Card>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {NOTIF_TYPES.map(n => (
          <div key={n.key} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '10px', padding: '11px 14px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '12px' }}>
            <div style={{ minWidth: 0 }}>
              <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 600, margin: 0 }}>{n.label}</p>
              <p style={{ color: n.wired ? 'var(--success)' : 'var(--text-muted)', fontSize: '10px', margin: '2px 0 0' }}>{n.wired ? 'Активно' : 'Готово к подключению'}</p>
            </div>
            <Toggle on={!!settings.notifications[n.key]} onChange={v => setNotif(n.key, v)} />
          </div>
        ))}
      </div>
    </div>
  )
}

// ── журнал событий ───────────────────────────────────────────────────────────
function LogView({ events, onClear }: { events: PubEvent[]; onClear: () => void }) {
  const [q, setQ] = useState('')
  const [status, setStatus] = useState<'all' | PubEvent['status']>('all')
  const [sortAsc, setSortAsc] = useState(false)
  const filtered = useMemo(() => {
    let e = events
    if (status !== 'all') e = e.filter(x => x.status === status)
    if (q.trim()) { const s = q.toLowerCase(); e = e.filter(x => x.message.toLowerCase().includes(s) || x.source.toLowerCase().includes(s) || x.type.toLowerCase().includes(s)) }
    return [...e].sort((a, b) => sortAsc ? a.ts - b.ts : b.ts - a.ts)
  }, [events, q, status, sortAsc])
  const dot = { ok: 'var(--success)', error: 'var(--danger)', info: 'var(--accent)' }
  return (
    <div>
      <div style={{ display: 'flex', gap: '6px', marginBottom: '10px' }}>
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Поиск по журналу…" style={{ ...inputStyle, flex: 1 }} />
        <button onClick={() => setSortAsc(s => !s)} style={iconBtn} title="Сортировка"><Icon name="sort" size={16} color="var(--text-secondary)" /></button>
      </div>
      <div style={{ display: 'flex', gap: '6px', marginBottom: '10px' }}>
        {(['all', 'ok', 'error', 'info'] as const).map(s => (
          <button key={s} onClick={() => setStatus(s)} style={{ padding: '6px 12px', borderRadius: '9px', border: `1px solid ${status === s ? 'var(--accent)' : 'var(--border)'}`, background: status === s ? 'var(--accent-glow)' : 'var(--bg-card)', color: status === s ? 'var(--accent)' : 'var(--text-secondary)', fontSize: '11px', fontWeight: 600, cursor: 'pointer' }}>{s === 'all' ? 'Все' : s === 'ok' ? 'Успех' : s === 'error' ? 'Ошибки' : 'Инфо'}</button>
        ))}
        {events.length > 0 && <button onClick={() => { if (confirm('Очистить журнал?')) onClear() }} style={{ ...iconBtn, marginLeft: 'auto' }}><Icon name="trash" size={15} color="var(--danger)" /></button>}
      </div>
      {!filtered.length ? <Empty icon="search" text="Событий нет" /> : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
          {filtered.map(e => (
            <div key={e.id} style={{ display: 'flex', gap: '10px', padding: '10px 12px', background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: '10px' }}>
              <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: dot[e.status], marginTop: '5px', flexShrink: 0 }} />
              <div style={{ minWidth: 0, flex: 1 }}>
                <p style={{ color: 'var(--text-primary)', fontSize: '12.5px', margin: 0, lineHeight: 1.4 }}>{e.message}</p>
                <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '3px 0 0' }}>{e.source} · {fmtDateTime(e.ts)}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ── настройки публикаций ─────────────────────────────────────────────────────
function SettingsView({ settings, saveSettings, flash }: { settings: PubSettings; saveSettings: (v: PubSettings) => void; flash: (t: string) => void }) {
  const [channelId, setChannelId] = useState(settings.channelId)
  const [buttonText, setButtonText] = useState(settings.buttonText)
  const [open, setOpen] = useState<Platform | null>(null)
  return (
    <div>
      <Card style={{ marginBottom: '12px' }}>
        <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, margin: '0 0 10px' }}>Telegram-канал</p>
        <Field label="Telegram Channel ID (указывается один раз)">
          <input value={channelId} onChange={e => setChannelId(e.target.value)} placeholder="@my_channel или -100…" style={inputStyle} />
        </Field>
        <Field label="Текст кнопки по умолчанию">
          <input value={buttonText} onChange={e => setButtonText(e.target.value)} placeholder="🛍 Открыть магазин" style={inputStyle} />
        </Field>
        <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', margin: '0 0 10px' }}>Кнопка ведёт на Mini App: {settings.buttonUrl}. Бот должен быть администратором канала.</p>
        <button className="btn-primary" onClick={() => { saveSettings({ ...settings, channelId: channelId.trim(), buttonText: buttonText.trim() || DEFAULT_SETTINGS.buttonText }); flash('Сохранено ✓') }}>Сохранить</button>
      </Card>

      <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, margin: '2px 2px 4px' }}>Соцсети и API-ключи</p>
      <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', margin: '0 2px 12px', lineHeight: 1.5 }}>Нажмите на соцсеть, чтобы вставить ключ. Как только ключ сохранён — она сразу становится доступной для публикации.</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {PLATFORMS.map(p => (
          <PlatformBoard
            key={p.key}
            platform={p.key}
            settings={settings}
            expanded={open === p.key}
            onToggle={() => setOpen(open === p.key ? null : p.key)}
            saveSettings={saveSettings}
            flash={flash}
          />
        ))}
      </div>
    </div>
  )
}

// Отдельный «борд» для каждой соцсети: кликаешь — раскрывается ввод ключа. Статус
// (подключено / не подключено) сразу меняется, как только ключ сохранён.
function PlatformBoard({ platform, settings, expanded, onToggle, saveSettings, flash }: {
  platform: Platform; settings: PubSettings; expanded: boolean; onToggle: () => void
  saveSettings: (v: PubSettings) => void; flash: (t: string) => void
}) {
  const meta = PLATFORMS.find(p => p.key === platform)!
  const isTelegram = platform === 'telegram'
  const isVk = platform === 'vk'
  const connected = platformConnected(platform, settings)
  const [token, setToken] = useState(settings.tokens[platform] || '')
  const [vkGroupId, setVkGroupId] = useState(settings.vkGroupId || '')
  const [webUrl, setWebUrl] = useState(settings.webUrl || '')
  useEffect(() => { setToken(settings.tokens[platform] || '') }, [settings.tokens, platform])
  useEffect(() => { setVkGroupId(settings.vkGroupId || ''); setWebUrl(settings.webUrl || '') }, [settings.vkGroupId, settings.webUrl])

  const save = () => {
    const next: PubSettings = { ...settings, tokens: { ...settings.tokens, [platform]: token.trim() } }
    if (isVk) { next.vkGroupId = vkGroupId.trim(); next.webUrl = webUrl.trim() }
    saveSettings(next)
    flash(token.trim() ? `${meta.label}: сохранено ✓` : `${meta.label}: ключ удалён`)
  }

  return (
    <div style={{ background: 'var(--bg-card)', border: `1px solid ${connected ? 'var(--accent)' : 'var(--border)'}`, borderRadius: '14px', overflow: 'hidden' }}>
      <button onClick={onToggle} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: '10px', padding: '13px 14px', background: 'transparent', border: 'none', cursor: 'pointer', textAlign: 'left' }}>
        <span style={{ fontSize: '20px', width: '30px', textAlign: 'center' }}>{meta.emoji}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ color: 'var(--text-primary)', fontSize: '13.5px', fontWeight: 700, margin: 0 }}>{meta.label}</p>
          <p style={{ fontSize: '10.5px', margin: '2px 0 0', fontWeight: 600, color: connected ? 'var(--success)' : 'var(--text-muted)' }}>
            {connected ? '● Подключено' : '○ Не подключено'}
          </p>
        </div>
        <Icon name={expanded ? 'chevron-up' : 'chevron-down'} size={16} color="var(--text-muted)" />
      </button>

      {expanded && (
        <div style={{ padding: '0 14px 14px', borderTop: '1px solid var(--border)' }}>
          <p style={{ color: 'var(--text-muted)', fontSize: '10.5px', margin: '12px 0 10px', lineHeight: 1.5 }}>{PLATFORM_HINT[platform]}</p>
          {isTelegram ? (
            <p style={{ color: 'var(--text-secondary)', fontSize: '11.5px', margin: 0, lineHeight: 1.5 }}>
              Telegram уже работает через серверный секрет. Достаточно указать Channel ID в блоке «Telegram-канал» выше.
            </p>
          ) : (
            <>
              <input type="password" value={token} onChange={e => setToken(e.target.value)} placeholder="Вставьте API-ключ" style={inputStyle} />
              {isVk && (
                <>
                  <input value={vkGroupId} onChange={e => setVkGroupId(e.target.value)} placeholder="ID сообщества VK (например 123456789)" style={{ ...inputStyle, marginTop: '8px' }} />
                  <input value={webUrl} onChange={e => setWebUrl(e.target.value)} placeholder="Ссылка магазина для поста (веб-URL)" style={{ ...inputStyle, marginTop: '8px' }} />
                  <p style={{ color: 'var(--text-muted)', fontSize: '10px', margin: '8px 0 0', lineHeight: 1.5 }}>
                    ID сообщества — только цифры (из адреса vk.com/club<b>123…</b> или в настройках сообщества). Ссылка t.me открывается лишь в Telegram — для VK лучше указать обычный веб-адрес магазина.
                  </p>
                </>
              )}
              <div style={{ display: 'flex', gap: '8px', marginTop: '10px' }}>
                {connected && <button className="btn-secondary" style={{ flex: 1 }} onClick={() => { setToken(''); saveSettings({ ...settings, tokens: { ...settings.tokens, [platform]: '' } }); flash(`${meta.label}: ключ удалён`) }}>Удалить</button>}
                <button className="btn-primary" style={{ flex: 1 }} onClick={save}>Сохранить ключ</button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  )
}

// ── общие вспомогательные ────────────────────────────────────────────────────
const iconBtn: React.CSSProperties = { width: '38px', height: '38px', borderRadius: '10px', background: 'var(--bg-elevated)', border: '1px solid var(--border)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }

function PostSummary({ post }: { post: PubPost }) {
  return (
    <div style={{ display: 'flex', gap: '10px' }}>
      {post.mediaUrl && (post.mediaType === 'video'
        ? <div style={{ width: '52px', height: '52px', borderRadius: '10px', background: '#000', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', overflow: 'hidden' }}><video src={post.mediaUrl} style={{ width: '100%', height: '100%', objectFit: 'cover', opacity: 0.7 }} /><Icon name="film" size={18} color="#fff" /></div>
        : <img src={post.mediaUrl} alt="" style={{ width: '52px', height: '52px', borderRadius: '10px', objectFit: 'cover', flexShrink: 0 }} />)}
      <div style={{ minWidth: 0, flex: 1 }}>
        {post.title && <p style={{ color: 'var(--text-primary)', fontSize: '13px', fontWeight: 700, margin: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{post.title}</p>}
        <p style={{ color: 'var(--text-secondary)', fontSize: '11.5px', margin: '2px 0 0', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden', lineHeight: 1.4 }}>{post.text || <span style={{ color: 'var(--text-muted)' }}>Без текста</span>}</p>
        <div style={{ display: 'flex', gap: '4px', marginTop: '4px' }}>{post.platforms.map(p => <span key={p} style={{ fontSize: '11px' }} title={PLATFORM_LABEL[p]}>{PLATFORM_EMOJI[p]}</span>)}</div>
      </div>
    </div>
  )
}

function Empty({ icon, text }: { icon: IconName; text: string }) {
  return (
    <div style={{ textAlign: 'center', padding: '48px 20px', color: 'var(--text-muted)' }}>
      <div style={{ width: '52px', height: '52px', borderRadius: '16px', background: 'var(--bg-elevated)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px' }}><Icon name={icon} size={22} color="var(--text-muted)" /></div>
      <p style={{ fontSize: '13px', margin: 0 }}>{text}</p>
    </div>
  )
}
